
namespace AssetWorks.UI.M5.TestAutomation.Common
{
    public static class ScreensUrl
    {
        public static string WorkOrderMain = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX?INFO=WORK ORDER MAIN";

        public static string DepartmentMain = "/PRESENTATION/DEPT/DEFAULT.ASPX";

        public static string UnitMain = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX?INFO=UNIT MAIN";

        public static string ComponentMain = "/PRESENTATION/COMPONENT/DEFAULT.ASPX";

        public static string WorkOrderDepartmentRequisitions = "/PRESENTATION/WORKREQUEST/DEPTREQ.ASPX";

        public static string DepartmentNumberChange = "/PRESENTATION/DEPT/DEPTNOCHG.ASPX";

        public static string WorkRequestMain = "/PRESENTATION/WORKREQUEST/DEFAULT.ASPX";

        public static string DepartmentCopy = "/PRESENTATION/DEPT/DUPLICATOR.ASPX";

        public static string UnitDepartmentChange = "/PRESENTATION/UNIT/UNITDEPTCHANGE.ASPX";

        public static string DepartmentGroups = "/PRESENTATION/SECURITY/DEPTGROUPMAINT.ASPX";

        public static string BillingCodes = "/PRESENTATION/BILLCODEMAINT/DEFAULT.ASPX";

        public static string AssetClassCodes = "/PRESENTATION/MISCCODES/CATEGORYCLASS.ASPX";

        public static string SystemStateCountryCodes = "/PRESENTATION/MISCCODES/STATE_COUNTRYCODE.ASPX";

        public static string MCCMain = "/PRESENTATION/MCC/DEFAULT.ASPX";

        public static string DirectAccountCodes = "/PRESENTATION/DIRACCT/DEFAULT.ASPX";

        public static string StandardJobMCC = "/PRESENTATION/STANDJOB/STANDJOBMCC.ASPX";

        public static string SystemCodes = "/PRESENTATION/SYSCOMP/SYSCODES.ASPX";

        public static string EmployeeMain = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX?INFO=EMPLOYEE MAIN";

        public static string PartListDisposal = "/PRESENTATION/PARTS/PARTDISPOSAL.ASPX";

        public static string PartMainCatalog = "/PRESENTATION/PARTS/DEFAULT.ASPX";

        public static string MotorPoolRentalClass = "/MOTORPOOL/MOTORPOOL/MPRENTALCLASS.ASPX";

        public static string RoleMaintenance = "/PRESENTATION/SECURITY/USERROLE.ASPX";

        public static string VendorMain = "/PRESENTATION/VENDOR/DEFAULT.ASPX";

        public static string VendorCopy = "/PRESENTATION/VENDOR/DUPLICATOR.ASPX";

        public static string VendorNumberChange = "/PRESENTATION/VENDOR/VENDORNOCHG.ASPX";

        public static string CustomerMain = "/EXCUST/FRAMES/DEFAULT.ASPX";

        public static string ApplicationUserMaintenance = "/PRESENTATION/SECURITY/USERAPP.ASPX";

        public static string PartInventoryLocManager = "/PRESENTATION/PARTS/PARTINVLOC.ASPX";

        public static string PartInventoryAdjustment = "/PRESENTATION/PARTS/PARTADJINV.ASPX";

        public static string UnitRequest = "/PRESENTATION/UNITACQUISITION/UNITREQUEST.ASPX";

        public static string CustomerTypeCodes = "/EXCUST/FRAMES/CUSTOMERTYPE.ASPX";

        public static string BookingTypeCodes = "/EXCUST/FRAMES/BOOKINGTYPECODES.ASPX";

        public static string ApplicationUserCopy = "/PRESENTATION/SECURITY/DUPLICATOR_USERAPP.ASPX";

        public static string EquipmentProfileTypes = "/PRESENTATION/MISCCODES/EQUIPPROFILETYPE.ASPX";

        public static string EquipmentTypesSKU = "/EQF/EQUIPMENT/EQUIPMENTTYPES.ASPX";

        public static string EquipmentConditions = "/EQF/EQUIPMENT/EQUIPMENTCONDITIONS.ASPX";

        public static string EquipmentReassign = "/EQF/EQUIPMENT/EQUIPMENTREASSIGN.ASPX";

        public static string TaxType = "/PRESENTATION/MISCCODES/TAXTYPE.ASPX";

        public static string PartBinPage = "/PRESENTATION/PARTS/BINMAIN.ASPX";

        public static string UnitPurchaseOrders = "/PRESENTATION/UNITACQUISITION/UNITREQPO.ASPX";

        public static string UnitCopy = "/PRESENTATION/UNIT/DUPLICATOR.ASPX";

        public static string PositionCode = "/PRESENTATION/MISCCODES/POSITIONMAINT.ASPX";

        public static string SystemPosition = "/PRESENTATION/SYSCOMP/SYSPOSCODES.ASPX";

        public static string EmployeeTitle = "/PRESENTATION/EMPLOYEES/EMPTITLE.ASPX";

        public static string SystemFlag = "/PRESENTATION/CONTROL/MODMAINT.ASPX";

        public static string NonCompanyUnitMain = "/OPERCTL/OPERATOR/DRIVERNCVEH.ASPX";

        public static string UnitPurchaseRequisitions = "/PRESENTATION/UNITACQUISITION/NEWUNIT.ASPX";

        public static string RoleCopy = "/PRESENTATION/SECURITY/DUPLICATOR.ASPX";

        public static string TaxScheme = "/PRESENTATION/MISCCODES/TAXSCHEME.ASPX";

        public static string BillingFixedCharges = "/PRESENTATION/BILLCODEMAINT/BILLVALIDFIX.ASPX";

        public static string EmployeeTransfer = "/PRESENTATION/EMPLOYEES/EMPTRANSFER.ASPX";

        public static string EmployeeGroup = "/PRESENTATION/EMPLOYEES/EMPGROUPMAINT.ASPX";

        public static string EmployeeShiftAssignment = "/PRESENTATION/EMPLOYEES/EMPSHIFTASSIGN.ASPX";

        public static string CustomerContract = "/EXCUST/FRAMES/CUSTCONTRACT.ASPX";

        public static string CustomerContractCopy= "/EXCUST/FRAMES/CUSTCONTRACTCOPY.ASPX";

        public static string EmployeeCopy = "/PRESENTATION/EMPLOYEES/DUPLICATOR.ASPX";

        public static string PurchaseRequisitions = "/PRESENTATION/PARTS/PREQUISITION.ASPX";

        public static string PurchaseOrder = "/PRESENTATION/PARTS/POMAINT.ASPX";

        public static string EquipmentProfile = "/PRESENTATION/MISCCODES/EQUIPPROFILEMAINT.ASPX";

        public static string UnitRequestApprove = "/PRESENTATION/UNITACQUISITION/UNITREQUESTAPPROVE.ASPX";
 
        public static string ItemMasterDefinition = "/PRESENTATION/ITEMMAINT/DEFAULT.ASPX";

        public static string MCCCopy = "/PRESENTATION/MCC/DUPLICATOR.ASPX";

        public static string MarkUpScheme = "/PRESENTATION/MISCCODES/MARKUPSCHEME.ASPX";

        public static string MarkupTypes = "/PRESENTATION/MISCCODES/MARKUPSETUP.ASPX";

        public static string CopyMarkUpScheme = "/PRESENTATION/MISCCODES/MARKUPSCHEMEDUP.ASPX";

        public static string MCCUnitDisplay = "/PRESENTATION/MCC/MCCUNITSCOMP.ASPX";

        public static string MCCQuery= "/PRESENTATION/MCC/MCCDISPLAY.ASPX";

        public static string EmployeeNumberChange = "/PRESENTATION/EMPLOYEES/EMPNOCHG.ASPX";

        public static string AccidentType = "/PRESENTATION/MISCCODES/ACCIDENTTYPES.ASPX";

        public static string AccidentCategory = "/PRESENTATION/ACCIDENT/ACCIDENTCATEGORY.ASPX";
      
        public static string VendorContract = "/PRESENTATION/PARTS/PCONTRACT.ASPX";

        public static string ActiveUserDisplay = "/PRESENTATION/SYSTEM/ACTIVEUSERS.ASPX";

        public static string ComponentCopy = "/PRESENTATION/COMPONENT/DUPLICATOR.ASPX";

        public static string ComponentNumberChange = "/PRESENTATION/COMPONENT/COMPNOCHG.ASPX";

        public static string BillingAdjustment = "/PRESENTATION/BILLCODEMAINT/BILLUNITADJ.ASPX";

        public static string BookingSourceCodes = "/EXCUST/FRAMES/BOOKINGSOURCECODES.ASPX";

        public static string BookingDeclineCancelCodes = "/EXCUST/FRAMES/BOOKINGDECLREASON.ASPX";
      
        public static string BookingAppointment = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX?INFO=BOOKING APPOINTMENT";

        public static string EmployeeTrainingTranscipt = "/PRESENTATION/EMPLOYEES/EMPTRAINING.ASPX";

        public static string EmpTrainingCourseSetUp = "/PRESENTATION/EMPLOYEES/COURSE.ASPX";

        public static string BillingUnitAccounts = "/PRESENTATION/BILLCODEMAINT/BILLUNITACCT2.ASPX";

        public static string BookingChangeDateReason = "/EXCUST/FRAMES/DATECHANGEREASON.ASPX";
        
        public static string EmpCourseQuery = "/PRESENTATION/EMPLOYEES/COURSEATTENDQRY.ASPX";

        public static string ResourceType = "/PRESENTATION/SHOPPLANNING/RESOURCETYPE.ASPX";

        public static string FuelProducts = "/PRESENTATION/PRODGENMAINT/DEFAULT.ASPX";

        public static string EmployeeItems = "/PRESENTATION/EMPLOYEES/EMPLOYEEITEM.ASPX";
        
        public static string AccidentCause = "/PRESENTATION/MISCCODES/ACCIDENTCAUSE.ASPX";

        public static string WorkRequestCampaignManager = "/PRESENTATION/WORKREQUEST/CAMPAIGN.ASPX";

        public static string LocationMain = "/PRESENTATION/GENLLOC/DEFAULT.ASPX";

        public static string WarrantyTechSpec = "/PRESENTATION/TECHSPEC/TECHSPECWARR.ASPX";

        public static string CompanyDefinition = "/PRESENTATION/CONTROL/DEFAULT.ASPX";

        public static string BillingCodeCopy = "/PRESENTATION/BILLCODEMAINT/BILLCODEDUPLICATOR.ASPX";

        public static string BillingItems = "/PRESENTATION/BILLCODEMAINT/BILLITEM.ASPX";

        public static string BillingItemSource = "/PRESENTATION/BILLCODEMAINT/BILLITEMSOURCE.ASPX";

        public static string AccidentEntry = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX?INFO=ACCIDENT";

        public static string EmployeePlannedAbsences = "/PRESENTATION/EMPLOYEES/EMPPLANABSENCE.ASPX";

        public static string LaborWedge = "/PRESENTATION/WORKORDER/LABORWEDGE.ASPX";

        public static string EquipmentRequest = "/EQF/EQUIPMENT/EQUIPMENTREQUEST.ASPX";

        public static string MenuMaintenance = "/PRESENTATION/MENUMAINT/DEFAULT.ASPX";

        public static string BillingIndirectItems = "/PRESENTATION/BILLCODEMAINT/BILLINDACCT.ASPX";

        public static string MotorPoolManager = "/MOTORPOOL/MOTORPOOL/DEFAULT.ASPX";

        public static string ProductSetupTanks = "/PRESENTATION/GENLLOC/LOCTANKSETTINGS.ASPX";    
        
        public static string WorkRequestIncident = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX?INFO=INCIDENT ENTRY";

        public static string DriverStatusCodes = "/PRESENTATION/EMPLOYEES/DRIVERSTATUSCODES.ASPX";

        public static string DriverAllocationReasons = "/OPERCTL/OPERATOR/DRIVERALLOCREASONS.ASPX";
        
        public static string ServiceOrder = "/PRESENTATION/WORKORDER/SERVICEORDER.ASPX";

        public static string BillingDepartmentAccounts = "/PRESENTATION/DEPT/BILLDEPTMAINT.ASPX";

        public static string BillSingleDepartmentAccount = "/PRESENTATION/DEPT/BILLSINGLEDEPTMAINT.ASPX";

        public static string BillSingleUnitAccount = "/PRESENTATION/BILLCODEMAINT/BILLSINGLEUNITACCT2.ASPX";

        public static string DriverTypes = "/PRESENTATION/EMPLOYEES/DRIVERTYPECODES.ASPX";
        
        public static string PartClassCodes = "/PRESENTATION/PARTS/PARTCLASSCODE.ASPX";

        public static string MotorPoolAssignUnit = "/MOTORPOOL/MOTORPOOL/MPASSIGNUNIT.ASPX";
        
        public static string DriverEventClasses = "/OPERCTL/OPERATOR/DRIVEREVENTCLASSES.ASPX";

        public static string DriverEventTypes = "/OPERCTL/OPERATOR/DRIVEREVENTTYPES.ASPX";

        public static string DriverLicenseClasses = "/OPERCTL/OPERATOR/DRIVERLICENCECLASSES.ASPX";

        public static string IndirectAccountCodes = "/PRESENTATION/INDACCT/DEFAULT.ASPX";
        
        public static string EquipRetReasons = "/EQF/EQUIPMENT/EQUIPMENTRETURNREASONS.ASPX";

        public static string MotorPoolReservation = "/MOTORPOOL/MOTORPOOL/RESERVATION.ASPX";

        public static string MotorPoolReservationAssignment = "/MOTORPOOL/MOTORPOOL/RESERVEASSIGN.ASPX";
        
        public static string DriverEventItem = "/OPERCTL/OPERATOR/DRIVEREVENTITEMS.ASPX";

        public static string ProductOrder = "/PRESENTATION/FUEL/PRODORDER.ASPX";

        public static string ProductReceive = "/PRESENTATION/FUEL/PRODRECEIVE.ASPX";

        public static string EquipMentCheckOut = "/EQF/EQUIPMENT/EQUIPMENTCHECKINCHECKOUT.ASPX";

        public static string EquipMentCheckIN = "/EQF/EQUIPMENT/EQUIPMENTCHECKIN.ASPX";

        public static string EquipMentCheckQuery= "/EQF/EQUIPMENT/EQUIPMENTCHECKQUERY.ASPX";

        public static string ProductSetupDepartment = "/PRESENTATION/DEPT/DEPTPROD.ASPX";
       
        public static string DriverMain = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX?INFO=DRIVER MAIN";

        public static string ServiceOrderQuery = "/PRESENTATION/WORKORDER/SERVICEPOQUERY.ASPX";

        public static string ServiceOrderReceipt = "/PRESENTATION/WORKORDER/SERVICEORDERRECV.ASPX";

        public static string ProductSetupLocation = "/PRESENTATION/PRODGENMAINT/PRODLOC.ASPX";

        public static string ProductSetUpEmployees = "/PRESENTATION/EMPLOYEES/EMPPROD.ASPX";

        public static string UnitOfMeasure = "/PRESENTATION/PARTCODES/UNITOFMEASURE.ASPX";

        public static string ProductSetupTanksHose = "/PRESENTATION/GENLLOC/LOCHOSESETTINGS.ASPX";
        
        public static string PartMerge = "/PRESENTATION/PARTS/PARTMERGE.ASPX";
        
        public static string PartNumberChange = "/PRESENTATION/PARTS/PARTNOCHG.ASPX";

        public static string PartLocInquiry = "/PRESENTATION/PARTS/INVLOCINQUIRY.ASPX";

        public static string PartRequest = "/PRESENTATION/PARTS/PARTREQUEST.ASPX";
        
        public static string LocationGroups = "/PRESENTATION/SECURITY/LOCGROUPMAINT.ASPX";
        
        public static string TestSuite = "/PRESENTATION/TESTSUITES/DEFAULT.ASPX";
        
        public static string HazardousMaterial = "/PRESENTATION/PARTCODES/HAZMATCODE.ASPX";
      
        public static string PartChargeCode = "/PRESENTATION/PARTS/PARTCHGCODE.ASPX";
        
        public static string CostCategoryCodes = "/PRESENTATION/MISCCODES/COSTCATCODES.ASPX";

        public static string DirectTestSuiteResult = "/PRESENTATION/TESTSUITES/DIRECTTESTRESULTS.ASPX";

        public static string TestHistoryQuery = "/PRESENTATION/TESTSUITES/TESTHISTORY.ASPX";

        public static string ShiftMaintenance = "/PRESENTATION/SHIFT/DEFAULT.ASPX";

        public static string EmissionsRating = "/PRESENTATION/ZONES/EMISSIONSRATING.ASPX";

        public static string VEDClassCodes = "/PRESENTATION/MISCCODES/VEDCLASSCODES.ASPX";

        public static string PayrollPayClassStep = "/PRESENTATION/EMPLOYEES/EMPPAYCLASS.ASPX";

        public static string DistributorMain = "/PRESENTATION/DISTRIBUTOR/DEFAULT.ASPX";

        public static string CategoryMain = "/PRESENTATION/UNITCATEGORY/DEFAULT.ASPX";

        public static string VisionRating = "/PRESENTATION/ZONES/VISIONRATING.ASPX";

        public static string AvailabilityStatusCodes = "/PRESENTATION/UNITAVAILABILITY/OPERSTATUSCODE.ASPX";

        public static string PriceTypes = "/PRESENTATION/MISCCODES/PRICETYPES.ASPX";
        
        public static string EditDashboard = "/DASHBOARD/OPERATIONAL/DASHEDIT.ASPX";

        public static string DisposalReason = "/PRESENTATION/MISCCODES/DISPOSALRSN.ASPX";

        public static string WorkOrderCopy = "/PRESENTATION/WORKORDER/DUPLICATOR.ASPX";

        public static string TestSuiteGroup = "/PRESENTATION/SECURITY/TESTSUITEGROUPMAINT.ASPX";

        public static string WarrantyPartSetup = "/PRESENTATION/WARRANTY/PVENDWARR.ASPX";

        public static string WorkOrderExpress = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX?INFO=WORK ORDER EXPRESS";

        public static string WorkOrderLaborChargeQuery = "/PRESENTATION/EMPLOYEES/LABORINQBYUNIT.ASPX";

        public static string PartsKitPage = "/PRESENTATION/PARTS/PARTKIT.ASPX";

        public static string EmployeeAssignment = "/PRESENTATION/ASSIGNMENT/SUPASSIGNVIEW.ASPX";

        public static string ComponentAssignmentHistory = "/PRESENTATION/COMPONENT/COMPASGNHIST.ASPX";

        public static string PartJournalQuery = "/PRESENTATION/PARTS/INVTRANSBYPART.ASPX";

        public static string PartReceive = "/PRESENTATION/PARTS/PARTSRECV.ASPX";
        
        public static string DriverLicenseIssuingAuthority = "/OPERCTL/OPERATOR/DRIVERISSUINGAUTHS.ASPX";

        public static string DriverLicenseType = "/OPERCTL/OPERATOR/DRIVERLICENCETYPES.ASPX";

        public static string DriverEventEntry = "/OPERCTL/OPERATOR/DRIVEREVENTENTRY.ASPX";

        public static string DriverClassCode = "/PRESENTATION/EMPLOYEES/DRIVERCLASSCODES.ASPX";

        public static string PartIssue = "/PRESENTATION/PARTS/PARTISSUEALL.ASPX";

        public static string ComponentDisposal = "/PRESENTATION/COMPONENT/COMPDISPOSALSALE.ASPX";

        public static string DriverTripEntry = "/OPERCTL/OPERATOR/DRIVERTRIPENTRY.ASPX";

        public static string CommercialWorkOrder = "/PRESENTATION/WORKORDERCOMM/DEFAULT.ASPX";

        public static string PartTransfer = "/PRESENTATION/PARTS/PARTSXFER.ASPX";

        public static string PartTransferRequest = "/PRESENTATION/PARTS/PREQUESTTFR.ASPX";
      
        public static string PartRequestHandling = "/PRESENTATION/PARTS/PARTREQHANDLING.ASPX";

        public static string PartRequisitionApproval = "/PRESENTATION/PARTS/MULTIREQAPPROVE.ASPX";

        public static string PurchaseOrderQuery = "/PRESENTATION/PARTS/POLIST.ASPX";
      
        public static string DriverEventQuery = "/OPERCTL/OPERATOR/DRIVEREVENTQRY.ASPX";

        public static string ShipmentTerms = "/PRESENTATION/MISCCODES/SHIPTERMS.ASPX";

        public static string ClaimCategoryDefinition = "/PRESENTATION/WARRANTY/WARRCATEGORY.ASPX";

        public static string WarrantyClaimManager = "/PRESENTATION/WARRANTY/WARRCLAIM.ASPX?INFO=W";
      
        public static string MotorpoolUnitsListedByLocation = "/MOTORPOOL/MOTORPOOL/MPUNITLOCATION.ASPX";

        public static string MotorPoolLocationUnitAssignment = "/MOTORPOOL/MOTORPOOL/MPLOCUNITS.ASPX";
      
        public static string PartReturn = "/PRESENTATION/PARTS/PARTSRETURN.ASPX";

        public static string PartReserves = "/PRESENTATION/PARTS/PARTRESERVES.ASPX";

        public static string WorkrequestPlan = "/PRESENTATION/WORKREQUEST/WORKPLAN.ASPX";

        public static string AssetControlCategoryBudgetOptions = "/PRESENTATION/UNITCATEGORY/CATEGORYITEMS.ASPX";

        public static string UnitDisposal = "/PRESENTATION/UNIT/UNITDISPOSALSALE.ASPX";
      
        public static string PayrollTimeTypes = "/PRESENTATION/EMPLOYEES/TIMETYPE.ASPX";

        public static string PayrollTimeTypeMatrix = "/PRESENTATION/EMPLOYEES/TIMETYPEMATRIX.ASPX";
      
        public static string HolidayCalendar = "/PRESENTATION/CALENDAR/HOLIDAY.ASPX";

        public static string ProductSetupTankTypes = "/PRESENTATION/TANKTYPEMAINT/DEFAULT.ASPX";

        public static string ProductSetupUnits = "/PRESENTATION/UNIT/UNITPROD.ASPX";

        public static string ProductIssueVendorIndirect = "/PRESENTATION/FUEL/PRODISSUE4.ASPX";

        public static string MaintenanceTimeSlot = "/CUSTVIEW/MAINT_APT/TIMESLOT.ASPX";

        public static string LaborTimeCard = "/PRESENTATION/WORKORDER/LABORENTRYEM.ASPX";

        public static string PayrollLaborApproval = "/PRESENTATION/WORKORDER/LABORAPPROVAL.ASPX";
      
        public static string MotorPoolApprovalFrame = "/MOTORPOOL/MOTORPOOL/MPAPPROVAL.ASPX";
      
        public static string MotorpoolPortal = "/PRESENTATION/SCREENDESIGNER/PROCESS.ASPX";

        public static string IndirectAccountGroups = "/PRESENTATION/SECURITY/INDACCTGROUPMAINT.ASPX";
      
        public static string ZoneClassCodes = "/PRESENTATION/ZONES/ZONECLASSCODES.ASPX";

        public static string ZoneClassMaintenance = "/PRESENTATION/ZONES/ZONECLASSESMAINT.ASPX";

        public static string TimeZones = "/PRESENTATION/MISCCODES/TIMEZONES.ASPX";

        public static string DAFCodeMaintenance = "/PRESENTATION/SECURITY/DAFDEFFRAME.ASPX";

        public static string DeptGroupDAFMaintenance = "/PRESENTATION/SECURITY/DEPTGROUPDAFFRAME.ASPX";

        public static string DepartmentQuoteRules = "/PRESENTATION/DEPT/DEPTQUOTATION.ASPX";

        public static string ZoneChargeCodes = "/PRESENTATION/ZONES/ZONECHARGECODES.ASPX";

        public static string Zones = "/PRESENTATION/ZONES/ZONES.ASPX";

        public static string ZonesCopy = "/PRESENTATION/ZONES/ZONEDUPLICATOR.ASPX";

        public static string ZoneChargeQuery = "/PRESENTATION/ZONES/ZONECHARGEQUERY.ASPX";

        public static string ShiftTypes = "/PRESENTATION/MISCCODES/SCHEDSHIFTS.ASPX";

        public static string ShopPlanningSchedule = "/PRESENTATION/SHOPPLANNING/PLANSCHEDULE.ASPX";

        public static string DisposalMethod = "/PRESENTATION/MISCCODES/DISPOSALMETHOD.ASPX";

        public static string DisposalCause = "/PRESENTATION/MISCCODES/DISPOSALCAUSE.ASPX";

    }
}