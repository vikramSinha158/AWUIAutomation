﻿using System;
using System.Data.Common;

namespace AssetWorks.UI.M5.TestAutomation.Common
{
    public static class Screens
    {
        public static string WorkOrderMain = "Work Order Main";

        public static string DepartmentMain = "Department Main";

        public static string UnitMain = "Unit Main";

        public static string ComponentMain = "Component Main";

        public static string WorkOrderDepartmentRequisitions = "Work Order Department Requisitions";

        public static string DepartmentNumberChange = "Department Number Change";

        public static string WorkRequestMain = "Work Request Main";

        public static string DepartmentCopy = "Department Copy";

        public static string UnitDepartmentChange = "Unit Department Change";

        public static string DepartmentGroups = "Department Groups";

        public static string BillingCodes = "Billing Codes";

        public static string AssetClassCodes = "Asset Class Codes";

        public static string SystemStateCountryCodes = "System State/Country Codes";

        public static string MCCMain = "MCC Main";

        public static string DirectAccountCodes = "Direct Account Codes";

        public static string StandardJobMCC = "Standard Job MCC";

        public static string SystemCodes = "System Codes";

        public static string PositionCodes = "Position Codes";

        public static string EmployeeMain = "Employee Main";

        public static string PartListDisposal = "Part List/Disposal";

        public static string PartMainCatalog = "Part Main Catalog";

        public static string MotorPoolRentalClass = "Motor Pool Rental Class";
        
        public static string RoleMaintenance = "Role Maintenance";
        
        public static string VendorMain = "Vendor Main";

        public static string CustomerMain = "Customer Main";

        public static string ApplicationUserMaintenance = "Application User Maintenance";

        public static string UnitRequest = "Unit Request";

        public static string TechSpecMain = "Tech Spec Main";

        public static string TechSpecCopy = "Tech Spec Copy";

        public static string StandardJobTechSpec = "Standard Job Tech Spec";

        public static string CustomerTypeCodes = "Customer Type Codes";

        public static string BookingTypeCodes = "Booking Type Codes";

        public static string UnitRequestCopy = "Unit Request Copy";

        public static string UnitGroup = "Unit Group";

        public static string ApplicationUserCopy = "Application User Copy";

        public static string ComponentItems = "Component Items";

        public static string ChatGroupMaintenance = "Chat Group Maintenance";


    }
}
