﻿using log4net;
using AssetWorks.UI.Core.Utils;
using System.Collections.Generic;
using System.Data.Common;

namespace AssetWorks.UI.M5.TestAutomation.Common
{
    /// <summary>
    /// Settings class
    /// </summary>
    public static class Settings
    {
        public static string? AUT { get; set; }

        public static string? UserName { get; set; }

        public static string? Password { get; set; }

        public static string? BrowserName { get; set; }

        public static string? AppSettingPath = new CommonUtils().SolutionPath().ToString() + "\\appsettings.json";

        public static Dictionary<string, string> ConfigSettings { get; set; }

        public static Dictionary<string, string> TData { get; set; }

        public static char UserDelimeter { get; set; } = ':';

        public static string TestDataPath { get; set; } = new CommonUtils().GetFolderPath("TestData") + "TestData.json";

        public static string TestPlanSummary { get; set; }

        public static string ExtentReportPath { get; set; }

        public static int ImplicitWait { get; set; }

        public static int MinExplicitlyWaitTime { get; set; }

        public static int MidExplicitlyWaitTime { get; set; }

        public static int MaxExplicitlyWaitTime { get; set; }

        public static bool ExtentReport { get; set; }

        public static string WorkOrderMain { get; set; }

        public static string Location { get; set; }

        public static string Department { get; set; }

        public static string UnitNumber { get; set; }

        public static bool Logs { get; set; }

        public static ILog Logger { get; set; }

        public static string DepartmentMain { get; set; }

        public static string ComponentNumber { get; set; }

        public static string DepartmentNumber { get; set; }

        public static string DepartmentStatusFlag { get; set; }

        public static string WorkOrderDepartmentRequisitions { get; set; }

        public static string WODeptRequisitionNo { get; set; }

        public static string DepartmentRequisitionDesc { get; set; }

        public static string DepartmentRequisitionDeptNo { get; set; }

        public static string DepartmentRequisitiondirectAccNo { get; set; }

        public static string DepartmentNumberChange { get; set; }

        public static string WorkRequestMain { get; set; }

        public static string JobCode { get; set; }

        public static string EmployeeCode { get; set; }

        public static string EmployeeName { get; set; }

        public static string EmployeePosition { get; set; }

        public static string TimeType { get; set; }

        public static string PayClass { get; set; }

        public static string PayStep { get; set; }

        public static string DepartmentCopy { get; set; }

        public static string UnitDepartmentChange { get; set; }

        public static string DepartmentGroups { get; set; }

        public static string BillingCodes { get; set; }

        public static string ActionDialog = "//span[text()='Action Required']";

        public static string AssetClassCodes { get; set; }

        public static string SystemStateCountryCodes { get; set; }

        public static string MCCMain { get; set; }

        public static string DBType { get; set; }

        public static string Environment { get; set; }

        public static string OracleConnectionString { get; set; }

        public static string SQLConnectionString { get; set; }

        public static DbConnection connection { get; set; }

        public static List<string> TestSuiteWorkRequest = new List<string>();

    }
}
