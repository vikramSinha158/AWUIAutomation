﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Billing
{
    [TestFixture]
    [Category("Billing")]
    internal class BillingTest : Hooks
    {

        [TestCase("BillingCodeTestData.json", "Billing", true, Description = "M5-Verifying Create And Delete BillingCode ")]
        public void QA707_QA1232_CreateAndDeleteBillingCode(object[] testParameter)
        {
            AddBillingInformation DataObject = CommonUtil.DataObjectForKey("AddBillingInformation").ToObject<AddBillingInformation>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingCodePage();
            string BillingCode = CurrentPage.As<BillingPageActions>().CreateBillingCode(DataObject);
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeInfo(DataObject, BillingCode);
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeDeletion(BillingCode);
        }

        [TestCase("BillingFixedChargeTestData.json", "BillingFixedChargeData", true, Description = "M5-Verifying Create And Delete BillingCode "), Order(1)]
        public void QA833_QA834_QA835_CreateUpdateAndDeleteBillingItem(object[] testParameter)
        {
            BillingFixedCharge BillingFixedCharge = CommonUtil.DataObjectForKey("QA833_BillingFixedCharge").ToObject<BillingFixedCharge>();
            BillingFixedCharge EditedBillingFixedCharge = CommonUtil.DataObjectForKey("QA834_BillingFixedCharge").ToObject<BillingFixedCharge>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingFixedCharges();
            string BillitemValue = CurrentPage.As<BillingFixedChargePageActions>().AddBillingFixedCharges(BillingFixedCharge);
            CurrentPage.As<BillingFixedChargePageActions>().VerifyBillingFixedCharges(BillingFixedCharge, BillitemValue);
            Settings.Logger.Info("------------Finishing executing test 'QA833 Create Billing Item' -------------------");
            EditedBillingFixedCharge.BillingItem = BillitemValue;
            CurrentPage.As<BillingFixedChargePageActions>().UpdateBillingFixedCharges(EditedBillingFixedCharge);
            CurrentPage.As<BillingFixedChargePageActions>().VerifyBillingFixedCharges(EditedBillingFixedCharge, EditedBillingFixedCharge.BillingItem);
            CommonUtil.AddPassedTestCase("QA834");
            Settings.Logger.Info("------------Finishing executing test 'QA834 Update Billing Item' -------------------");
            CurrentPage.As<BillingFixedChargePageActions>().DeleteNewAddedBillingCharges(BillitemValue);
            CurrentPage.As<BillingFixedChargePageActions>().VerifyBillingFixedChargeDeletion(BillitemValue);
            CommonUtil.AddPassedTestCase("QA835");
            Settings.Logger.Info("------------Finishing executing test 'QA835 Delete Billing Item' -------------------");
        }

        [Test, Description("M5-Verify Edit Billing Item ")]
        public void QA834_UpdateBillingItem()
        {
            CommonUtil.VerifyPassedTestCase("QA834");
            Settings.Logger.Info("QA834 merged with 'QA833_QA834_QA835_CreateUpdateAndDeleteBillingItem' ");
        }

        [Test, Description("M5-Verify Delete Billing Item ")]
        public void QA835_DeleteBillingItem()
        {
            CommonUtil.VerifyPassedTestCase("QA835");
            Settings.Logger.Info("QA835 merged with 'QA833_QA834_QA835_CreateUpdateAndDeleteBillingItem' ");
        }

        [TestCase("BillingCodeTestData.json", "Billing", true, Description = "M5-Verifying Create And Delete BillingCode "), Order(1)]
        public void QA831_QA829_AddBillingAdjustment(object[] testParameter)
        {
            BillingAdjustment? BillingAdjustmentData = CommonUtil.DataObjectForKey("BillingAdjustment").ToObject<BillingAdjustment>();
            BillingAdjustment? EditBillingAdjustmentData = CommonUtil.DataObjectForKey("QA829_UpdateBillingDeptAdjustment").ToObject<BillingAdjustment>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingAdjustment();
            CurrentPage.As<BillingAdjustmentPageActions>().AddAndUpdateBillingAdjustment(BillingAdjustmentData);
            CurrentPage.As<BillingAdjustmentPageActions>().VerifyBillingAdjustment(BillingAdjustmentData);
            CurrentPage.As<BillingAdjustmentPageActions>().AddAndUpdateBillingAdjustment(EditBillingAdjustmentData);
            Settings.Logger.Info("------------Finishing executing test 'QA831 Add  Billing Adjustment' -------------------");
            CurrentPage.As<BillingAdjustmentPageActions>().VerifyBillingAdjustment(EditBillingAdjustmentData);
            CommonUtil.AddPassedTestCase("QA829");
            Settings.Logger.Info("------------Finishing executing test 'QA829 Update  Billing Adjustment' -------------------");
            CurrentPage.As<BillingAdjustmentPageActions>().DeleteBillingAdjustmentTable(BillingAdjustmentData.UnitDeptNo);        
        }

        [Test, Description("M5-Verify Edit Billing Dept Adjustment ")]
        public void QA829_UpdateBillingDeptAdjustment()
        {
            CommonUtil.VerifyPassedTestCase("QA829");
            Settings.Logger.Info("QA829 merged with 'QA831_QA829_AddBillingAdjustment' ");
        }

        [TestCase]
        public void QA1144_CompanyDefinitionWithAccountTemplateTab()
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateCompanyDefinition();
            CurrentPage.As<CompanyDefinitionPageActions>().FillAccountTemplateTab(false);
            CurrentPage.As<CompanyDefinitionPageActions>().VerifyAccountTemplateTab(false);
            CurrentPage.As<CompanyDefinitionPageActions>().FillAccountTemplateTab(true);
            CurrentPage.As<CompanyDefinitionPageActions>().VerifyAccountTemplateTab(true);
        }

        [TestCase("BillingCodeTestData.json", "Billing", true, Description = "M5-Verifying Create And Delete BillingCode "), Order(1)]
        public void QA1163_QA1226_CreateAndEditBillingCodeDetailTab(object[] testParameter)
        {
            AddBillingInformation DataObject = CommonUtil.DataObjectForKey("QA1163_CreateBillingCodeWitDetailTab").ToObject<AddBillingInformation>();
            AddBillingInformation EditDataObject = CommonUtil.DataObjectForKey("QA1226_CreateBillingCodeWitDetailTab").ToObject<AddBillingInformation>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingCodePage();
            string BillingCode = CurrentPage.As<BillingPageActions>().CreateBillingCode(DataObject);
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeInfo(DataObject, BillingCode);
            Settings.Logger.Info("------------Finishing executing test 'QA1163 Create Billing Code DetailTab' -------------------");
            CurrentPage.As<BillingPageActions>().UpdateBillingCode(EditDataObject, BillingCode);
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeInfo(EditDataObject, BillingCode);
            CommonUtil.AddPassedTestCase("QA1226");
            Settings.Logger.Info("------------Finishing executing test 'QA1226 update Billing Code DetailTab' -------------------");
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeDeletion(BillingCode);
        }

        [TestCase("BillingCodeTestData.json", "Billing", true, Description = "M5-Verifying Create And Delete BillingCode ")]
        public void QA705_CreateBillingCodeNONLEASED(object[] testParameter)
        {
            AddBillingInformation DataObject = CommonUtil.DataObjectForKey("QA705_CreateBillingCodeWitNONLEASED").ToObject<AddBillingInformation>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingCodePage();
            string BillingCode = CurrentPage.As<BillingPageActions>().CreateBillingCode(DataObject);
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeInfo(DataObject, BillingCode);
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeDeletion(BillingCode);
        }

        [TestCase("BillingCodeTestData.json", "Billing", true, Description = "M5-Verifying Create Billing Code Motor Pool "), Order(1)]
        public void QA1142_QA1227_CreateAndUpdateBillingCodeMotorPool(object[] testParameter)
        {
            AddBillingInformation DataObject = CommonUtil.DataObjectForKey("QA1142_CreateBillingCodeWitMotorPoolTab").ToObject<AddBillingInformation>();
            AddBillingInformation EditDataObject = CommonUtil.DataObjectForKey("QA1227_UpdateBillingCodeWitMotorPoolTab").ToObject<AddBillingInformation>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingCodePage();
            string BillingCode = CurrentPage.As<BillingPageActions>().CreateBillingCode(DataObject);
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeInfo(DataObject, BillingCode);
            Settings.Logger.Info("------------Finishing executing test 'QA1142 Create Billing Code Motorpool' -------------------");
            CurrentPage.As<BillingPageActions>().UpdateBillingCode(EditDataObject, BillingCode);
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeInfo(EditDataObject, BillingCode);
            CommonUtil.AddPassedTestCase("QA1227");
            Settings.Logger.Info("------------Finishing executing test 'QA1227 update Billing Code Motorpool' -------------------");
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeDeletion(BillingCode);
        }

        [TestCase("BillingCodeTestData.json", "Billing", true, Description = "M5-Verifying Create Billing Code Fixed Tab "), Order(1)]
        public void QA1143_QA1228_QA717_CreateUpdateAndDeleteBillingCodeFixedTab(object[] testParameter)
        {
            AddBillingInformation DataObject = CommonUtil.DataObjectForKey("QA1143_CreateBillingCodeWitFixedTab").ToObject<AddBillingInformation>();
            AddBillingInformation EditDataObject = CommonUtil.DataObjectForKey("QA1228_UpdateBillingCodeWitFixedTab").ToObject<AddBillingInformation>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingCodePage();
            string BillingCode = CurrentPage.As<BillingPageActions>().CreateBillingCode(DataObject);
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeInfo(DataObject, BillingCode);
            Settings.Logger.Info("------------Finishing executing test 'QA1143 Added Billing Code CodeFixedTab' -------------------");
            CurrentPage.As<BillingPageActions>().UpdateBillingCode(EditDataObject, BillingCode);
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeInfo(EditDataObject, BillingCode);
            CommonUtil.AddPassedTestCase("QA1228");
            Settings.Logger.Info("------------Finishing executing test 'QA1228 updated Billing Code CodeFixedTab' -------------------");
            CurrentPage.As<BillingPageActions>().DeleteFixedTable(BillingCode);
            CurrentPage.As<BillingPageActions>().VerifyDeletionFixedTable(BillingCode);
            CommonUtil.AddPassedTestCase("QA717");
            Settings.Logger.Info("------------Finishing executing test 'QA717 Deleted Billing Code CodeFixedTable' -------------------");
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeDeletion(BillingCode);          
        }

        [Test, Description("M5-Verify Deleted Billing CodeFixedTable ")]
        public void QA717_DeletedBillingCodeFixedTable()
        {
            CommonUtil.VerifyPassedTestCase("QA717");
            Settings.Logger.Info("QA829 merged with 'QA831_QA829_AddBillingAdjustment' ");
        }

        [TestCase("BillingCodeTestData.json", "Billing", true, Description = "M5-Verifying Create QA714_CopyBillingCode ")]
        public void QA714_CopyBillingCode(object[] testParameter)
        {
            AddBillingInformation DataObject = CommonUtil.DataObjectForKey("QA714_BillingCodeCopy").ToObject<AddBillingInformation>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateBillingCodeCopy();
            DataObject.BillingCode = CurrentPage.As<BillingCodeCopyPageActions>().CopyExistingBillingCode(DataObject);
            CurrentPage = _pageNavigate.NavigateToBillingCodePage();
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeInfo(DataObject, DataObject.BillingCode);
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeDeletion(DataObject.BillingCode);
        }

        [Test, Description("M5-Verify Edit Billing Code ")]
        public void QA710_UpdateBillingCode()
        {
            CommonUtil.VerifyPassedTestCase("QA1226");
            Settings.Logger.Info("QA1226 merged with 'QA1163_QA1226_CreateAndEditBillingCodeDetailTab' ");
            CommonUtil.VerifyPassedTestCase("QA1227");
            Settings.Logger.Info("QA1227 merged with 'QA1142_QA1227_CreateAndUpdateBillingCodeMotorPool' ");
            CommonUtil.VerifyPassedTestCase("QA1228");
            Settings.Logger.Info("QA1228 merged with 'QA1143_QA1228_CreateAndUpdateBillingCodeFixedTab' ");
        }

        [TestCase("BillingCodeTestData.json", "Billing", true, Description = "M5-Verifying Cannot Delete Associated Billing Code ")]
        public void QA712_CannotDeleteAssociatedBillingCode(object[] testParameter)
        {
            AddBillingInformation DataObject = CommonUtil.DataObjectForKey("QA712_CannotDeleteAssociatedBillingCode").ToObject<AddBillingInformation>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingCodePage();
            CurrentPage.As<BillingPageActions>().VerifyAssociatedBillingCodeNotDeleted(DataObject);
        }

        [TestCase("BillingFixedChargeTestData.json", "BillingFixedChargeData", true, Description = "M5-Verifying Billing Items Set And Unset ")]
        public void QA797_BillingItemsSetAndUnset(object[] testParameter)
        {
            BillingFixedCharge BillingFixedCharge = CommonUtil.DataObjectForKey("QA797_BillingItemsSetAndUnset").ToObject<BillingFixedCharge>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingFixedCharges();
            string BillitemValue = CurrentPage.As<BillingFixedChargePageActions>().AddBillingFixedCharges(BillingFixedCharge);
            CurrentPage = _pageNavigate.NavigateBillingItems();
            CurrentPage.As<BillingItemsPageActions>().SetAndUnsetBillCharge(BillitemValue, true);
            CurrentPage.As<BillingItemsPageActions>().VerifySetAndUnsetBillCharge(BillitemValue, true);
            CurrentPage.As<BillingItemsPageActions>().SetAndUnsetBillCharge(BillitemValue, false);
            CurrentPage.As<BillingItemsPageActions>().VerifySetAndUnsetBillCharge(BillitemValue, false);
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            CurrentPage.As<BillingFixedChargePageActions>().DeleteNewAddedBillingCharges(BillitemValue);
        }

        [TestCase("BillingItemSourceTestData.json", "BillingItemSource", true, Description = "M5-Verifying Billing Item Source")]
        public void QA812_BillingItemSource(object[] testParameter)
        {
            List<BillingFixedCharge> BillingItemObject = CommonUtil.DataObjectForKey("BillingFixedChargeData").ToObject<List<BillingFixedCharge>>();
            BillingItemSourceDetail BillingItemSource = CommonUtil.DataObjectForKey("QA812_BillingItemSource").ToObject<BillingItemSourceDetail>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingFixedCharges();
            BillingItemSource.BillingItemSourceList = CurrentPage.As<BillingFixedChargePageActions>().AddMultipleBillingFixedCharges(BillingItemObject);
            CurrentPage = _pageNavigate.NavigateBillingItemSources();
            CurrentPage.As<BillingItemSourcePageActions>().AddBillingItemSource(BillingItemSource);
            CurrentPage.As<BillingItemSourcePageActions>().VerifyBillingItemSource(BillingItemSource);
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            CurrentPage.As<BillingFixedChargePageActions>().DeleteMultipleBillItem(BillingItemSource.BillingItemSourceList);
        }

        [TestCase("BillingItemSourceTestData.json", "BillingItemSource", true, Description = "M5-Verifying Billing Item Source")]
        public void QA1241_BillingItemSource(object[] testParameter)
        {
            List<BillingFixedCharge> BillingItemObject = CommonUtil.DataObjectForKey("BillingFixedChargeData").ToObject<List<BillingFixedCharge>>();
            BillingItemSourceDetail BillingItemSource = CommonUtil.DataObjectForKey("QA1241_BillingItemSource").ToObject<BillingItemSourceDetail>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingFixedCharges();
            BillingItemSource.BillingItemSourceList = CurrentPage.As<BillingFixedChargePageActions>().AddMultipleBillingFixedCharges(BillingItemObject);
            CurrentPage = _pageNavigate.NavigateBillingItemSources();
            CurrentPage.As<BillingItemSourcePageActions>().AddBillingItemSource(BillingItemSource);
            CurrentPage.As<BillingItemSourcePageActions>().VerifyBillingItemSource(BillingItemSource);
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            CurrentPage.As<BillingFixedChargePageActions>().DeleteMultipleBillItem(BillingItemSource.BillingItemSourceList);
        }

        [TestCase("BillingItemSourceTestData.json", "BillingItemSource", true, Description = "M5-Verifying Billing Item Source")]
        public void QA1242_BillingItemSource(object[] testParameter)
        {
            List<BillingFixedCharge> BillingItemObject = CommonUtil.DataObjectForKey("BillingFixedChargeData").ToObject<List<BillingFixedCharge>>();
            BillingItemSourceDetail BillingItemSource = CommonUtil.DataObjectForKey("QA1242_BillingItemSource").ToObject<BillingItemSourceDetail>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingFixedCharges();
            BillingItemSource.BillingItemSourceList = CurrentPage.As<BillingFixedChargePageActions>().AddMultipleBillingFixedCharges(BillingItemObject);
            CurrentPage = _pageNavigate.NavigateBillingItemSources();
            CurrentPage.As<BillingItemSourcePageActions>().AddBillingItemSource(BillingItemSource);
            CurrentPage.As<BillingItemSourcePageActions>().VerifyBillingItemSource(BillingItemSource);
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            CurrentPage.As<BillingFixedChargePageActions>().DeleteMultipleBillItem(BillingItemSource.BillingItemSourceList);
        }

        [TestCase("BillingItemSourceTestData.json", "BillingItemSource", true, Description = "M5-Verifying Billing Item Source")]
        public void QA1243_BillingItemSource(object[] testParameter)
        {
            List<BillingFixedCharge> BillingItemObject = CommonUtil.DataObjectForKey("BillingFixedChargeData").ToObject<List<BillingFixedCharge>>();
            BillingItemSourceDetail BillingItemSource = CommonUtil.DataObjectForKey("QA1243_BillingItemSource").ToObject<BillingItemSourceDetail>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingFixedCharges();
            BillingItemSource.BillingItemSourceList = CurrentPage.As<BillingFixedChargePageActions>().AddMultipleBillingFixedCharges(BillingItemObject);
            CurrentPage = _pageNavigate.NavigateBillingItemSources();
            CurrentPage.As<BillingItemSourcePageActions>().AddBillingItemSource(BillingItemSource);
            CurrentPage.As<BillingItemSourcePageActions>().VerifyBillingItemSource(BillingItemSource);
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            CurrentPage.As<BillingFixedChargePageActions>().DeleteMultipleBillItem(BillingItemSource.BillingItemSourceList);
        }

        [TestCase("BillingIndirectItemsTestData.json", "BillingIndirectItems", true, Description = "M5-Verifying Billing Indirect Items "), Order(1)]
        public void QA836_QA838_AddAndDeleteBillingIndirectItems(object[] testParameter)
        {
            BillingIndirectItems DataObject = CommonUtil.DataObjectForKey("QA836_AddBillingIndirectItems").ToObject<BillingIndirectItems>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateBillingIndirectItems();
            CurrentPage.As<BillingIndirectItemsPageActions>().AddIndirectAccountsBillItems(DataObject);
            CurrentPage.As<BillingIndirectItemsPageActions>().VerifyIndirectAccountsBillItem(DataObject);
            Settings.Logger.Info("------------Finishing executing test ' QA836 Add Billing Indirec tItems' -------------------");
            CurrentPage.As<BillingIndirectItemsPageActions>().DeleteIndirectAccountsBillItem(DataObject);
            CurrentPage.As<BillingIndirectItemsPageActions>().VerifyDeleteIndirectAccountsBillItem(DataObject);
            CommonUtil.AddPassedTestCase("QA838");
            Settings.Logger.Info("------------Finishing executing test ' QA838 Delete Billing Indirec tItems' -------------------");
        }

        [Test, Description("M5-Verify DeleteBillingIndirectItems")]
        public void QA838_DeleteBillingIndirectItems()
        {
            CommonUtil.VerifyPassedTestCase("QA838");
            Settings.Logger.Info(" QA838 Merged with  'QA836_QA838_AddAndDeleteBillingIndirectItems'");
        }

        [TestCase("BillingIndirectItemsTestData.json", "BillingIndirectItems", true, Description = "M5-Verifying Billing Indirect Items "), Order(1)]
        public void QA837_UpdateBillingIndirectItems(object[] testParameter)
        {
            BillingIndirectItems BillingIndirectItems = CommonUtil.DataObjectForKey("QA837_BillingIndirectItems").ToObject<BillingIndirectItems>();
            BillingIndirectItems EditBillingIndirectItems = CommonUtil.DataObjectForKey("QA837_UpdateBillingIndirectItems").ToObject<BillingIndirectItems>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateBillingIndirectItems();
            Settings.Logger.Info("Adding Billing Indirec tItems");
            CurrentPage.As<BillingIndirectItemsPageActions>().AddIndirectAccountsBillItems(BillingIndirectItems);
            CurrentPage.As<BillingIndirectItemsPageActions>().VerifyIndirectAccountsBillItem(BillingIndirectItems);
            Settings.Logger.Info("Editing Billing Indirec tItems");
            CurrentPage.As<BillingIndirectItemsPageActions>().AddIndirectAccountsBillItems(EditBillingIndirectItems);
            CurrentPage.As<BillingIndirectItemsPageActions>().VerifyIndirectAccountsBillItem(EditBillingIndirectItems);
            Settings.Logger.Info("Deleting Billing Indirec tItems");
            CurrentPage.As<BillingIndirectItemsPageActions>().DeleteIndirectAccountsBillItem(EditBillingIndirectItems);
        }

        [TestCase("BillingDepartmentAccountsTestData.json", "BillingDepartmentAccounts", Description = "M5 Department Billing Accounts Set Expense Account for Item")]
        public void QA757_BillingDepartmentAccounts(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            BillingDepartment BillingDetails = CommonUtil.DataObjectForKey("QA757_BillingDepartment").ToObject<BillingDepartment>();
            List<BillingFixedCharge> BillingItemObject = CommonUtil.DataObjectForKey("BillingFixedChargeData").ToObject<List<BillingFixedCharge>>();
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            BillingDetails.BillItemlist = CurrentPage.As<BillingFixedChargePageActions>().AddMultipleBillingFixedCharges(BillingItemObject);
            CurrentPage = _pageNavigate.NavigateBillingDepartmentAccount();
            CurrentPage.As<BillingDepartmentAccountsPageActions>().AddBillingAccountInformation(BillingDetails);
            CurrentPage.As<BillingDepartmentAccountsPageActions>().VerifyBillingAccountInformation(BillingDetails);
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            CurrentPage.As<BillingFixedChargePageActions>().DeleteMultipleBillItem(BillingDetails.BillItemlist);
        }

        [TestCase("BillingDepartmentAccountsTestData.json", "BillingDepartmentAccounts", Description = "M5 Department Billing Accounts Update Expense and Revenue Accounts for Item"), Order(1)]
        public void QA766_QA769_UpdateAndDeleteBillingDepartmentAccounts(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            BillingDepartment BillingDetails = CommonUtil.DataObjectForKey("QA766_BillingDepartment").ToObject<BillingDepartment>();
            BillingDepartment EditBillingDetails = CommonUtil.DataObjectForKey("QA766_EditBillingDepartment").ToObject<BillingDepartment>();
            List<BillingFixedCharge> BillingItemObject = CommonUtil.DataObjectForKey("BillingFixedChargeData").ToObject<List<BillingFixedCharge>>();
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            BillingDetails.BillItemlist = CurrentPage.As<BillingFixedChargePageActions>().AddMultipleBillingFixedCharges(BillingItemObject);
            CurrentPage = _pageNavigate.NavigateBillingDepartmentAccount();
            CurrentPage.As<BillingDepartmentAccountsPageActions>().AddBillingAccountInformation(BillingDetails);
            CurrentPage.As<BillingDepartmentAccountsPageActions>().VerifyBillingAccountInformation(BillingDetails);
            EditBillingDetails.BillItemlist = BillingDetails.BillItemlist;
            CurrentPage.As<BillingDepartmentAccountsPageActions>().AddBillingAccountInformation(EditBillingDetails);
            CurrentPage.As<BillingDepartmentAccountsPageActions>().VerifyBillingAccountInformation(EditBillingDetails);
            Settings.Logger.Info("------------Finishing executing test 'QA766 ,Update  Billing Department Accounts ' -------------------");
            CurrentPage.As<BillingDepartmentAccountsPageActions>().DeleteBillItemDepartmentAccount(EditBillingDetails.DepartmentNo, BillingDetails.BillItemlist[0]);
            CurrentPage.As<BillingDepartmentAccountsPageActions>().VerifyDeletionBillItemDepartmentAccount(EditBillingDetails.DepartmentNo, BillingDetails.BillItemlist[0]);
            CommonUtil.AddPassedTestCase("QA769");
            Settings.Logger.Info("------------Finishing executing test 'QA769 ,Delete  Billing Department Accounts ' -------------------");
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            CurrentPage.As<BillingFixedChargePageActions>().DeleteMultipleBillItem(BillingDetails.BillItemlist);
        }

        [Test, Description("M5-Verify Delete  Billing Department Accounts ")]
        public void QA769_DeleteBillingDepartmentAccounts()
        {
            CommonUtil.VerifyPassedTestCase("QA769");
            Settings.Logger.Info("QA769 merged with 'QQA766_QA769_UpdateAndDeleteBillingDepartmentAccounts' ");
        }

        [TestCase("BillSingleDepartmentAccountTestData.json", "BillSingleDepartmentAccount", Description = "M5 Bill Single Department Account Set Expense Account and Revenue Account for Department "), Order(1)]
        public void QA738_QA735_QA736_QA737_AddUpdateAndDeleteBillSingleDepartment(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            SingleDepartmentDetails DataObject = CommonUtil.DataObjectForKey("QA738_SingleDepartmentDetails").ToObject<SingleDepartmentDetails>();
            SingleDepartmentDetails UpdateDataObject = CommonUtil.DataObjectForKey("QA736_UpdateSingleDepartmentDetails").ToObject<SingleDepartmentDetails>();
            CurrentPage = _pageNavigate.NavigateBillSingleDepartmentAccount();
            CurrentPage.As<BillSingleDepartmentAccountPageActions>().FillDepartmentInformation(DataObject);
            CurrentPage.As<BillSingleDepartmentAccountPageActions>().VerifyDepartmentInformation(DataObject);
            CommonUtil.AddPassedTestCase("QA735");
            Settings.Logger.Info("------------Finishing executing test 'QA738 and QA735 ,Set Expense Account and Revenue Account' -------------------");
            CurrentPage.As<BillSingleDepartmentAccountPageActions>().FillDepartmentInformation(UpdateDataObject);
            CurrentPage.As<BillSingleDepartmentAccountPageActions>().VerifyDepartmentInformation(UpdateDataObject);
            CommonUtil.AddPassedTestCase("QA736");
            Settings.Logger.Info("------------Finishing executing test 'QA736 ,Update  Expense Account and Revenue Account' -------------------");
            CurrentPage.As<BillSingleDepartmentAccountPageActions>().VerifySingleDepartmentAccountDeletion(DataObject.Department);
            CommonUtil.AddPassedTestCase("QA737");
            Settings.Logger.Info("------------Finishing executing test 'QA737 ,Delete Bill Single Department' -------------------");
        }

        [Test, Description("M5-Verify Set Revenue Account")]
        public void QA735_SetRevenueAccount()
        {
            CommonUtil.VerifyPassedTestCase("QA735");
            Settings.Logger.Info("QA735 merged with 'QA738_QA735_QA736_QA737_AddUpdateAndDeleteBillSingleDepartment' ");
        }

        [Test, Description("M5-Verify Update Bill Single Department")]
        public void QA736_UpdatBillSingleDepartment()
        {
            CommonUtil.VerifyPassedTestCase("QA736");
            Settings.Logger.Info("QA736 merged with 'QA738_QA735_QA736_QA737_AddUpdateAndDeleteBillSingleDepartment' ");
        }

        [Test, Description("M5-Verify Delete Bill Single Department")]
        public void QA737_DeleteBillSingleDepartment()
        {
            CommonUtil.VerifyPassedTestCase("QA737");
            Settings.Logger.Info("QA737 merged with 'QA738_QA735_QA736_QA737_AddUpdateAndDeleteBillSingleDepartment' ");
        }

        [TestCase("BillingUnitAccountsTestData.json", "BillingUnitAccounts",
            Description = "M5 Billing Unit Accounts Update record with new Effective Date and Expense Account"), Order(1)]
        public void QA789_QA788_UpdateAndDeleteRecordWithEffectiveDateAndExpenseAccount(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            BillingUnitAccountDetail UpdateUnitAccount = CommonUtil.DataObjectForKey("QA789_UpdateUnitAccountDetails").ToObject<BillingUnitAccountDetail>();
            BillingFixedCharge BillingFixedCharge = CommonUtil.DataObjectForKey("BillingFixedCharge").ToObject<BillingFixedCharge>();
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            UpdateUnitAccount.BillItem = CurrentPage.As<BillingFixedChargePageActions>().AddBillingFixedCharges(BillingFixedCharge);
            CurrentPage = _pageNavigate.NavigateToBillingUnitAccountsPage();
            CurrentPage.As<BillingUnitAccountsPageActions>().AddEffectiveDateExpenseAccountRevenueAccount(UpdateUnitAccount);
            CurrentPage.As<BillingUnitAccountsPageActions>().VerifyEffectiveDateExpenseAccountRevenueAccount(UpdateUnitAccount);
            CurrentPage.As<BillingUnitAccountsPageActions>().DeleteEffectiveDateExpenseAccountRevenueAccount(UpdateUnitAccount);
            CurrentPage.As<BillingUnitAccountsPageActions>().VerifyDeleteEffectiveDateExpenseAccountRevenueAccount(UpdateUnitAccount);
            Settings.Logger.Info("------------Finishing executing test 'QA789 Update Expense Account ' -------------------");
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            CurrentPage.As<BillingFixedChargePageActions>().DeleteNewAddedBillingCharges(UpdateUnitAccount.BillItem);
            CommonUtil.AddPassedTestCase("QA788");
            Settings.Logger.Info("------------Finishing executing test 'QA788 Delete Expense Account ' -------------------");
        }

        [Test, Description("M5-Verify Delete Expense Account ")]
        public void QA788_DeleteExpenseAccount()
        {
            CommonUtil.VerifyPassedTestCase("QA788");
            Settings.Logger.Info("QA788 merged with 'QA789_QA788_UpdateAndDeleteRecordWithEffectiveDateAndExpenseAccount' ");
        }

        [TestCase("BillingUnitAccountsTestData.json", "BillingUnitAccounts",
            Description = "M5 Billing Unit Accounts Update record with new Effective Date and Revenue Account")]
        public void QA790_UpdateRecordWithEffectiveDateAndRevenueAccount(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            BillingUnitAccountDetail UpdateUnitAccount = CommonUtil.DataObjectForKey("QA790_UpdateUnitAccountDetails").ToObject<BillingUnitAccountDetail>();
            BillingFixedCharge BillingFixedCharge = CommonUtil.DataObjectForKey("BillingFixedCharge").ToObject<BillingFixedCharge>();
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            UpdateUnitAccount.BillItem = CurrentPage.As<BillingFixedChargePageActions>().AddBillingFixedCharges(BillingFixedCharge);
            CurrentPage = _pageNavigate.NavigateToBillingUnitAccountsPage();
            CurrentPage.As<BillingUnitAccountsPageActions>().AddEffectiveDateExpenseAccountRevenueAccount(UpdateUnitAccount);
            CurrentPage.As<BillingUnitAccountsPageActions>().VerifyEffectiveDateExpenseAccountRevenueAccount(UpdateUnitAccount);
            CurrentPage.As<BillingUnitAccountsPageActions>().DeleteEffectiveDateExpenseAccountRevenueAccount(UpdateUnitAccount);
            CurrentPage.As<BillingUnitAccountsPageActions>().VerifyDeleteEffectiveDateExpenseAccountRevenueAccount(UpdateUnitAccount);
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            CurrentPage.As<BillingFixedChargePageActions>().DeleteNewAddedBillingCharges(UpdateUnitAccount.BillItem);
        }

        [TestCase("BillingUnitAccountsTestData.json", "BillingUnitAccounts",
            Description = "M5 Billing Unit Accounts Set Expense Accounts for Multiple Bill Items")]

        public void QA792_AddMultipleExpenseAccountstoDiffenrentBillItems(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            List<BillingFixedCharge> BillingItemObject = CommonUtil.DataObjectForKey("QA_BillingFixedCharge").ToObject<List<BillingFixedCharge>>();
            UnitAccountDetails UpdateUnitAccount = CommonUtil.DataObjectForKey("QA792_UpdateUnitAccountDetailsA").ToObject<UnitAccountDetails>();
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            UpdateUnitAccount.BillingItemList = CurrentPage.As<BillingFixedChargePageActions>().AddMultipleBillingFixedCharges(BillingItemObject);
            CurrentPage = _pageNavigate.NavigateToBillingUnitAccountsPage();
            CurrentPage.As<BillingUnitAccountsPageActions>().AddExpenseAccountBillItemsWithAllCurrent(UpdateUnitAccount);
            CurrentPage.As<BillingUnitAccountsPageActions>().VerifyExpenseAccountBillItemsWithAllCurrent(UpdateUnitAccount);
            CurrentPage.As<BillingUnitAccountsPageActions>().DeleteExpenseAccountBillItemsWithAllCurrent(UpdateUnitAccount);
            CurrentPage.As<BillingUnitAccountsPageActions>().VerifyDeleteExpenseAccountBillItemsWithAllCurrent(UpdateUnitAccount);
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            CurrentPage.As<BillingFixedChargePageActions>().DeleteMultipleBillItem(UpdateUnitAccount.BillingItemList);
        }

        [TestCase("BillingUnitAccountsTestData.json", "BillingUnitAccounts",
            Description = "M5  Billing Unit Accounts - Allocate Expense to Multiple Accounts and Delete"), Order(1)]
        public void QA786_QA787_AddAndDeleteExpenseAccountAllocationBillItem(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            BillingFixedCharge BillingFixedCharge = CommonUtil.DataObjectForKey("BillingFixedCharge").ToObject<BillingFixedCharge>();
            UnitAccountDetails UpdateUnitAccount = CommonUtil.DataObjectForKey("QA786_BillitemAllocationDetail").ToObject<UnitAccountDetails>();
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            UpdateUnitAccount.BillItem = CurrentPage.As<BillingFixedChargePageActions>().AddBillingFixedCharges(BillingFixedCharge);
            CurrentPage = _pageNavigate.NavigateToBillingUnitAccountsPage();
            CurrentPage.As<BillingUnitAccountsPageActions>().AddExpenseAccountBillItemsWithAllCurrent(UpdateUnitAccount);
            CurrentPage.As<BillingUnitAccountsPageActions>().VerifyExpenseAccountBillItemsWithAllCurrent(UpdateUnitAccount);
            CurrentPage.As<BillingUnitAccountsPageActions>().DeleteExpenseAccountBillItemsWithAllCurrent(UpdateUnitAccount);
            CurrentPage.As<BillingUnitAccountsPageActions>().VerifyDeleteExpenseAccountBillItemsWithAllCurrent(UpdateUnitAccount);
            Settings.Logger.Info("------------Finishing executing test 'QA786 Delete Expense Account from the Expense Allocations ' -------------------");
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            CurrentPage.As<BillingFixedChargePageActions>().DeleteNewAddedBillingCharges(UpdateUnitAccount.BillItem);
            CommonUtil.AddPassedTestCase("QA787");
            Settings.Logger.Info("------------Finishing executing test 'QA787 Delete Expense Account from the Expense Allocations ' -------------------");
        }

        [Test, Description("M5-Verify Delete Expense Account from the Expense Allocations")]
        public void QA787_DeleteExpenseAccountfromExpenseAllocations()
        {
            CommonUtil.VerifyPassedTestCase("QA787");
            Settings.Logger.Info("QA788 merged with 'QA786_QA787_AddAndDeleteExpenseAccountAllocationBillItem' ");
        }


        [TestCase("BillingDepartmentAccountsTestData.json", "BillingDepartmentAccounts", Description = "M5 Department Billing Accounts - Set Revenue Account for Item")]
        public void QA758_BillingDepartmentRevenueAccounts(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            BillingDepartment BillingDetails = CommonUtil.DataObjectForKey("QA758_BillingDepartment").ToObject<BillingDepartment>();
            List<BillingFixedCharge> BillingItemObject = CommonUtil.DataObjectForKey("BillingFixedChargeData").ToObject<List<BillingFixedCharge>>();
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            BillingDetails.BillItemlist = CurrentPage.As<BillingFixedChargePageActions>().AddMultipleBillingFixedCharges(BillingItemObject);
            CurrentPage = _pageNavigate.NavigateBillingDepartmentAccount();
            CurrentPage.As<BillingDepartmentAccountsPageActions>().AddBillingAccountInformation(BillingDetails);
            CurrentPage.As<BillingDepartmentAccountsPageActions>().VerifyBillingAccountInformation(BillingDetails);
            CurrentPage = _pageNavigate.NavigateToBillingFixedCharges();
            CurrentPage.As<BillingFixedChargePageActions>().DeleteMultipleBillItem(BillingDetails.BillItemlist);
        }

        [TestCase("BillingSingleUnitAccountTestData.json", "BillSingleUnitAccount", Description = "M5-Billing-Bill Single Unit Account-Allocate Expense to Multiple Accounts and Delete"), Order(1)]
        public void QA751_QA753_QA754_AddUpdateAndDelete_UnitExpenseAccount(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            BillSingleUnitDetail Dataobject = CommonUtil.DataObjectForKey("QA751_BillSingleUnitDetail").ToObject<BillSingleUnitDetail>();
            BillSingleUnitDetail EditDataobject = CommonUtil.DataObjectForKey("QA754_BillSingleUnitDetail").ToObject<BillSingleUnitDetail>();
            CurrentPage = _pageNavigate.NavigateToBookingBillingSingleUnitAccountPage();
            BillingSingleUnitAccountPage.ExpenseEffectiveDates.Clear();
            CurrentPage.As<BillingSingleUnitAccountPageActions>().AddBillSingleUnitAccount(Dataobject);
            CurrentPage.As<BillingSingleUnitAccountPageActions>().VerifyBillSingleUnitAccount(Dataobject);
            Settings.Logger.Info("------------Finishing executing test ' QA751 Add Multiple Accounts to Unit Expense Account ' -------------------");
            CurrentPage.As<BillingSingleUnitAccountPageActions>().AddBillSingleUnitAccount(EditDataobject);
           CurrentPage.As<BillingSingleUnitAccountPageActions>().VerifyBillSingleUnitAccount(EditDataobject);
            CommonUtil.AddPassedTestCase("QA754");
            Settings.Logger.Info("------------Finishing executing test ' QA754 Update Unit Expense Account ' -------------------");
            CurrentPage.As<BillingSingleUnitAccountPageActions>().DeleteBillSingleUnitAccount(Dataobject);
            CurrentPage.As<BillingSingleUnitAccountPageActions>().VerifyDeletionBillSingleUnitAccount(Dataobject);
            CommonUtil.AddPassedTestCase("QA753");
            Settings.Logger.Info("------------Finishing executing test ' QA753 Delete Unit Expense Account ' -------------------");
        }

        [Test, Description("M5 - Billing - Bill Single Unit Account - Delete Expense Account ")]
        public void QA753_DeleteMultipleAccountstoUnitExpenseAccount()
        {
            Settings.Logger.Info("QA753 merged with 'QA751_QA753_QA754_AddUpdateAndDelete_UnitExpenseAccount' ");
            CommonUtil.VerifyPassedTestCase("QA753");        
        }

        [Test, Description("M5 - Billing - Update Bill Single Unit Account ")]
        public void QA754_UpdateUnitExpenseAccount()
        {
            Settings.Logger.Info("QA754 merged with 'QA751_QA753_QA754_AddUpdateAndDelete_UnitExpenseAccount' ");
            CommonUtil.VerifyPassedTestCase("QA754");         
        }

        [TestCase("BillingCodeTestData.json", "Billing", true, Description = "M5-Verifying Add,Delete And Update Billing AdjustmentUnit "), Order(1)]
        public void QA826_QA821_QA832_AddUpdateAndDeleteBillingUnitAdjustmentUnit(object[] testParameter)
        {
            BillingAdjustment? BillingAdjustmentData = CommonUtil.DataObjectForKey("QA826_BillingAdjustment").ToObject<BillingAdjustment>();
            BillingAdjustment? AddAnotherBillingRowData = CommonUtil.DataObjectForKey("QA826_UpdateBillingAdjustment").ToObject<BillingAdjustment>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingAdjustment();
            CurrentPage.As<BillingAdjustmentPageActions>().AddAndUpdateBillingAdjustment(BillingAdjustmentData);
            CurrentPage.As<BillingAdjustmentPageActions>().VerifyBillingAdjustment(BillingAdjustmentData);
            Settings.Logger.Info("------------Finishing executing test ' QA826 Add Billing AdjustmentUnit' -------------------");
            CurrentPage.As<BillingAdjustmentPageActions>().AddAndUpdateBillingAdjustment(AddAnotherBillingRowData);
            CurrentPage.As<BillingAdjustmentPageActions>().VerifyBillingAdjustment(AddAnotherBillingRowData);
            CommonUtil.AddPassedTestCase("QA821");
            Settings.Logger.Info("------------Finishing executing test ' QA821 Update Billing AdjustmentUnit' -------------------");
            CurrentPage.As<BillingAdjustmentPageActions>().DeleteBillingAdjustmentTable(AddAnotherBillingRowData.UnitDeptNo);
            CurrentPage.As<BillingAdjustmentPageActions>().VerifyDeleteBillingAdjustmentTable(AddAnotherBillingRowData.UnitDeptNo);
            CommonUtil.AddPassedTestCase("QA832");
            Settings.Logger.Info("------------Finishing executing test ' QA832 Delete Billing AdjustmentUnit' -------------------");
        }

        [Test, Description("M5-Verify Updat  BillingUnitAdjustmentUnit")]
        public void QA821_UpdateBillingUnitAdjustmentUnit()
        {
            CommonUtil.VerifyPassedTestCase("QA821");
            Settings.Logger.Info(" QA821 Merged with  'QA826_QA821_QA832_AddUpdateAndDeleteBillingUnitAdjustmentUnit'");
        }

        [Test, Description("M5-Verify Delete BillingUnitAdjustmentUnit ")]
        public void QA832_DeleteBillingUnitAdjustmentUnit()
        {
            CommonUtil.VerifyPassedTestCase("QA832");
            Settings.Logger.Info("  QA832 Merged with  'QA826_QA821_QA832_AddUpdateAndDeleteBillingUnitAdjustmentUnit'");
        }

        [TestCase("BillingCodeTestData.json", "Billing", true, Description = "M5-Verifying Disable Billing Code ")]
        public void QA709_DisableBillingCodee(object[] testParameter)
        {
            AddBillingInformation DataObject = CommonUtil.DataObjectForKey("QA709_DisableBillingCodee").ToObject<AddBillingInformation>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBillingCodePage();
            CurrentPage.As<BillingPageActions>().ChangeBillingCodeState(DataObject.BillingCode, DataObject.BillingCodeDisabled);
            CurrentPage.As<BillingPageActions>().VerifyBillingCodeState(DataObject);
            CurrentPage.As<BillingPageActions>().ChangeBillingCodeState(DataObject.BillingCode, DataObject.BillingCodeEnabled);
        }

        [TestCase("BillingSingleUnitAccountTestData.json", "BillSingleUnitAccount", Description = "M5-Billing-Bill Single Unit Revenue Accounts Add,update and Delete"), Order(1)]
        public void QA760_QA755_QA756_AddUpdateAndDelete_UnitRevenueAccount(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            BillSingleUnitDetail Dataobject = CommonUtil.DataObjectForKey("QA760_BillSingleUnitDetail").ToObject<BillSingleUnitDetail>();
            BillSingleUnitDetail EditDataobject = CommonUtil.DataObjectForKey("QA755_BillSingleUnitDetail").ToObject<BillSingleUnitDetail>();
            CurrentPage = _pageNavigate.NavigateToBookingBillingSingleUnitAccountPage();
            CurrentPage.As<BillingSingleUnitAccountPageActions>().AddBillSingleUnitAccount(Dataobject);
            CurrentPage.As<BillingSingleUnitAccountPageActions>().VerifyBillSingleUnitAccount(Dataobject);
            Settings.Logger.Info("------------Finishing executing test ' QA760 Add Unit Revenue Account ' -------------------");
            CurrentPage.As<BillingSingleUnitAccountPageActions>().AddBillSingleUnitAccount(EditDataobject);
            CurrentPage.As<BillingSingleUnitAccountPageActions>().VerifyBillSingleUnitAccount(EditDataobject);
            CommonUtil.AddPassedTestCase("QA755");
            Settings.Logger.Info("------------Finishing executing test ' QA755 Update Unit Revenue Account ' -------------------");
            CurrentPage.As<BillingSingleUnitAccountPageActions>().DeleteBillSingleUnitAccount(Dataobject);
            CurrentPage.As<BillingSingleUnitAccountPageActions>().VerifyDeletionBillSingleUnitAccount(Dataobject);
            CommonUtil.AddPassedTestCase("QA756");
            Settings.Logger.Info("------------Finishing executing test ' 756 Delete Unit Revenue Account ' -------------------");
            CurrentPage.As<BillingSingleUnitAccountPageActions>().DeleteBillSingleUnitAccount(EditDataobject);
            CurrentPage.As<BillingSingleUnitAccountPageActions>().VerifyDeletionBillSingleUnitAccount(EditDataobject);
        }

        [Test, Description("M5 - Billing - Bill Single Unit Account - Update Revenue Account ")]
        public void QA755_UpdateUnitRevenueAccount()
        {
            Settings.Logger.Info("QA755 merged with 'QA760_QA755_QA756_AddUpdateAndDelete_UnitRevenueAccount' ");
            CommonUtil.VerifyPassedTestCase("QA755");
        }

        [Test, Description("M5 - Billing - Delete Bill Single Unit Revenue Account ")]
        public void QA756_DeleteUnitRevenueAccount()
        {
            Settings.Logger.Info("QA756 merged with 'QA760_QA755_QA756_AddUpdateAndDelete_UnitRevenueAccount' ");
            CommonUtil.VerifyPassedTestCase("QA756");
        }

        [TestCase("BillingSingleUnitAccountTestData.json", "BillSingleUnitAccount", Description = "M5-Billing-Bill Single Unit Account- Delete Expense Account from the Expense Allocations"), Order(1)]
        public void QA752_DeleteExpenseAccountFromExpenseAllocations(object[] testParameter)
        {
            Settings.Logger.Info("Updating System Flags");
            Dictionary<string, string> flags = CommonUtil.DataObjectForKey("SystemFlags").ToObject<Dictionary<string, string>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            OriginalSystemFlags = CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(flags);
            IsFlagsChanged = true;
            BillSingleUnitDetail Dataobject = CommonUtil.DataObjectForKey("QA752_BillSingleUnitDetail").ToObject<BillSingleUnitDetail>();
            CurrentPage = _pageNavigate.NavigateToBookingBillingSingleUnitAccountPage();
            BillingSingleUnitAccountPage.ExpenseEffectiveDates.Clear();
            CurrentPage.As<BillingSingleUnitAccountPageActions>().AddBillSingleUnitAccount(Dataobject);
            CurrentPage.As<BillingSingleUnitAccountPageActions>().DeleteExpenseAccountFromAllocationsFrame(Dataobject);
            CurrentPage.As<BillingSingleUnitAccountPageActions>().VerifyDeletionBillSingleUnitAccount(Dataobject);
            Settings.Logger.Info("------------Finishing executing test ' QA752 Delete Unit Expense Account FromE xpense Allocations' -------------------");
        }
    }
}