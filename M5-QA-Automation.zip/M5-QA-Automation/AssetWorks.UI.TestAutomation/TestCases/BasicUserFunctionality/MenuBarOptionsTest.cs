﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.Accidents;
using AssetWorks.UI.M5.TestAutomation.Actions.BasicUserFunctionality;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.BasicUserFunctionality
{
    [TestFixture]
    internal class MenuBarOptionsTest : Hooks
    {

        [TestCase("BasicUserFuncTestData.json", "QA726_ValidateMenuBarOptions",
            Description = "M5-Basic User Functionality-Validate Menu Bar options")]
        public void QA726_ValidateMenuBarOptions(object[] testParameter)
        {
            MenuBarOptionsActions menuBar = new MenuBarOptionsActions(Driver);
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToApplicationUserMaintenancePage();
            menuBar.SelectPageFromHistoryMenu(CommonUtil.DataForKey("PageName"));
            menuBar.VerifyPageTitle(CommonUtil.DataForKey("ApplicationPageTitle"));
            menuBar.SelectReports();
            menuBar.VerifyPageTitle(CommonUtil.DataForKey("ReportsPageTitle"));
            menuBar.SelectDashboard();
            menuBar.VerifyPageTitle(CommonUtil.DataForKey("DashboardPageTitle"));
            menuBar.SelectAndVerifyChatWindow();
            menuBar.SelectAndVerifyHelpFile();
        }

        [TestCase("BasicUserFuncTestData.json", "QA734_FavoritingFrame",
            Description = "M5-Basic User Functionality-Validate Menu Bar options")]
        public void QA734_FavoritingFrame(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToSystemFlagPage();
            MenuBarOptionsActions menuBar = new MenuBarOptionsActions(Driver);
            menuBar.SelectandVerifyAddFavourites("SystemListItem");
        }

        [TestCase("BasicUserFuncTestData.json", "QA725_ValidateTargetIcon", 
            Description = "M5-Basic User Functionality-Validate Target Icon on Menu Bar")]
        public void QA725_ValidateTargetIcon(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToApplicationUserMaintenancePage();
            MenuBarOptionsActions _menuBar = new MenuBarOptionsActions(Driver);
            _menuBar.SelectTargettIcon();
            _menuBar.VerifyTargetIcon(CommonUtil.DataForKey("ExpectedNewWindowTitle"));
            _menuBar.LoggOffApplicationAndSwitchToParentWindow();                  
            loginpage.LoginM5(CommonUtil.DataForKey("Appuser"), CommonUtil.DataForKey("Password"));            
        }

        [TestCase("BasicUserFuncTestData.json", "QA729_AddHomepageToExistingUser", Description = "M5-Basic User Functionality-Validate Menu Bar options")]
        public void QA729_AddingExistingHomepageToExistingUser(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToApplicationUserMaintenancePage();
            MenuBarOptionsActions menuBar = new MenuBarOptionsActions(Driver);
            LoginPageActions login = new LoginPageActions(Driver);
            menuBar.EditHomePageDetails(CommonUtil.DataForKey("AppUser"), CommonUtil.DataForKey("HomepageData"));
            login.LoggOffApplication();
            login.LoginM5(CommonUtil.DataForKey("AppUser"), CommonUtil.DataForKey("Password"));
            menuBar.VerifyHomePageText(CommonUtil.DataForKey("HomePageText"));
        }

        [TestCase("BasicUserFuncTestData.json", "QA1148_AccidentTypesReauthenticate",
            TestName = "QA1148_MenuMaintenanceAccidentTypesReauthenticateOnSave",
            Description = "M5-Menu Maintenance - Accident type Re-authenticate on Save")]
        public void QA1148_MenuMaintenanceAccidentTypesReauthenticateOnSave(object[] testParameter)
        {
            MenuMaintenanceSetting parameterU = CommonUtil.DataObjectForKey("Update").ToObject<MenuMaintenanceSetting>();
            MenuMaintenanceSetting parameterR = CommonUtil.DataObjectForKey("Revert").ToObject<MenuMaintenanceSetting>();
            AccidentType accType = CommonUtil.DataObjectForKey("AccidentType").ToObject<AccidentType>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToMenuMaintenancePage();
            CurrentPage.As<MenuMaintenancePageActions>().UpdateReauthenticateOnSave(parameterU);
            CurrentPage = _pageNavigate.NavigateToAccidentTypePage();
            accType.ATName = CurrentPage.As<AccidentsTypePageActions>().CreateAccidentType(accType);
            CurrentPage.As<AccidentsTypePageActions>().VerifyAccidentTypeDeletion(accType);
            CurrentPage = _pageNavigate.NavigateToMenuMaintenancePage();
            CurrentPage.As<MenuMaintenancePageActions>().UpdateReauthenticateOnSave(parameterR);
        }

    }
}
