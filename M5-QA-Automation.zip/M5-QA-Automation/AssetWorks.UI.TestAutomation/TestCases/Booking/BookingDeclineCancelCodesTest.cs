﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Booking;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using NUnit.Framework;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.BookingDeclineCancelCodes;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Booking
{
    [TestFixture]
    internal class BookingDeclineCancelCodesTest : Hooks
    {
        
        [TestCase("BookingDeclineCancelCodeTestData.json", "BookingDeclineCancelCodes", 
            TestName = "QA721_CreateBookingCodesDecline", Description= "M5-Booking-Booking Decline Cancel Codes-Create New Decline Code")]

        public void QA721_CreateBookingCodesDecline(object[] testParameter)
        {
            BookingCodeDetails bookingDclnCnclCodeTC1 = CommonUtil.DataObjectForKey("QA721_BookingCodeDetails").ToObject<BookingCodeDetails>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBookingDeclineCancelCodesPage();
            bookingDclnCnclCodeTC1.BookingCode = CurrentPage.As<BookingDeclineCancelCodesPageActions>().CreateBookingDeclineCancelCode(bookingDclnCnclCodeTC1);
            CurrentPage.As<BookingDeclineCancelCodesPageActions>().VerifyBookingCode(bookingDclnCnclCodeTC1);
            Settings.Logger.Info("QA721 - Create Booking Decline Cancel Code completed successfully.!");
            CurrentPage.As<BookingDeclineCancelCodesPageActions>().DeleteBookingCode(bookingDclnCnclCodeTC1);
            CurrentPage.As<BookingDeclineCancelCodesPageActions>().VerifyDeleteBookingCode(bookingDclnCnclCodeTC1);
            Settings.Logger.Info("QA721 - Delete Booking Decline Cancel Code completed successfully.!");
        }

        [TestCase("BookingDeclineCancelCodeTestData.json", "BookingDeclineCancelCodes",
            TestName = "QA722_CreateBookingCodesDeclineCancelDisable", Description = "M5-Booking-Booking Decline Cancel Codes-Create New Cancel Decline Code")]

        public void QA722_CreateBookingCodesDeclineCancelDisable(object[] testParameter)
        {
            BookingCodeDetails bookingDclnCnclCodeTC1 = CommonUtil.DataObjectForKey("QA722_BookingCodeDetails").ToObject<BookingCodeDetails>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBookingDeclineCancelCodesPage();
            bookingDclnCnclCodeTC1.BookingCode = CurrentPage.As<BookingDeclineCancelCodesPageActions>().CreateBookingDeclineCancelCode(bookingDclnCnclCodeTC1);
            CurrentPage.As<BookingDeclineCancelCodesPageActions>().VerifyBookingCode(bookingDclnCnclCodeTC1);
            Settings.Logger.Info("QA722 - Create Booking Decline Cancel Code completed successfully.!");
            CurrentPage.As<BookingDeclineCancelCodesPageActions>().DeleteBookingCode(bookingDclnCnclCodeTC1);
            CurrentPage.As<BookingDeclineCancelCodesPageActions>().VerifyDeleteBookingCode(bookingDclnCnclCodeTC1);
            Settings.Logger.Info("QA722 - Delete Booking Decline Cancel Code completed successfully.!");
        }
        [TestCase("BookingDeclineCancelCodeTestData.json", "BookingDeclineCancelCodes",
            TestName = "QA720_CreateBookingCodesCancelDisable", Description = "M5-Booking-Booking Decline Cancel Codes-Create New Cancel Code")]

        public void QA720_CreateBookingCodesCancelDisable(object[] testParameter)
        {
            BookingCodeDetails bookingDclnCnclCodeTC1 = CommonUtil.DataObjectForKey("QA720_BookingCodeDetails").ToObject<BookingCodeDetails>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBookingDeclineCancelCodesPage();
            bookingDclnCnclCodeTC1.BookingCode = CurrentPage.As<BookingDeclineCancelCodesPageActions>().CreateBookingDeclineCancelCode(bookingDclnCnclCodeTC1);
            CurrentPage.As<BookingDeclineCancelCodesPageActions>().VerifyBookingCode(bookingDclnCnclCodeTC1);
            Settings.Logger.Info("QA720 - Create Booking Decline Cancel Code completed successfully.!");
            CurrentPage.As<BookingDeclineCancelCodesPageActions>().DeleteBookingCode(bookingDclnCnclCodeTC1);
            CurrentPage.As<BookingDeclineCancelCodesPageActions>().VerifyDeleteBookingCode(bookingDclnCnclCodeTC1);
            Settings.Logger.Info("QA720 - Delete Booking Decline Cancel Code completed successfully.!");
        }

    }
}
