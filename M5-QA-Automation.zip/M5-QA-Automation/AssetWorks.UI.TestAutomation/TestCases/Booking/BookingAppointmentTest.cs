﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Booking
{
    [TestFixture]
    internal class BookingApointmentTest : Hooks
    {
        [TestCase("BookingAppointmentTestData.json", "BookingAppointment"), Description ("M5-Booking-New Booking Appointment")]
        public void QA888_NewBookingAppointment(object[] testParameter)
        {
            BookingAppointment bookingObject = CommonUtil.DataObjectForKey("QA888_NewAppointment").ToObject<BookingAppointment>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBookingAppointmentPage();
            bookingObject.BookingNumber=CurrentPage.As<BookingAppointmentPageActions>().CreateBookingAppointment(bookingObject);
            BookingAppointment verifybooking = CommonUtil.DataObjectForKey("QA888_VerifyNewAppointment").ToObject<BookingAppointment>();
            bookingObject.Location=verifybooking.Location;
            bookingObject.CustNO=verifybooking.CustNO;
            bookingObject.BookingStatus=verifybooking.BookingStatus;
            bookingObject.EquipProfile=verifybooking.EquipProfile;
            CurrentPage.As<BookingAppointmentPageActions>().VerifyBookingAppointment(bookingObject);
        }    


    }
}
