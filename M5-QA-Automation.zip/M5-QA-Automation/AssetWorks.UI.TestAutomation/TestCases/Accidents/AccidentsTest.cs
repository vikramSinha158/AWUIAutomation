using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.Accidents;

namespace AssetWorks.UI.M5.TestAutomation.TestCases.Accident
{
    [TestFixture]
    internal class AccidentsTest : Hooks
    {
        [TestCase("AccidentsTestData.json", "CreateAccidentType",
            TestName = "QA679_QA680_QA681_QA682_QA684_CreateUpdateDisableEnableDeleteAccidentType",
            Description = "M5-Create Update Disable Enable Delete Accident Type"), Order(1)]
        public void QA679_QA680_QA681_QA682_QA684_CreateUpdateDisableEnableDeleteAccidentType(object[] testParameter)
        {
            AccidentType accTypeC = CommonUtil.DataObjectForKey("QA679_AccidentType").ToObject<AccidentType>();
            AccidentType accTypeD = CommonUtil.DataObjectForKey("QA680_AccidentType").ToObject<AccidentType>();
            AccidentType accTypeE = CommonUtil.DataObjectForKey("QA681_AccidentType").ToObject<AccidentType>();
            AccidentType accTypeU = CommonUtil.DataObjectForKey("QA682_AccidentType").ToObject<AccidentType>();

            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToAccidentTypePage();
            accTypeC.ATName = CurrentPage.As<AccidentsTypePageActions>().CreateAccidentType(accTypeC);
            CurrentPage.As<AccidentsTypePageActions>().VerifyAccidentType(accTypeC);
            CommonUtil.AddPassedTestCase("QA679");
            Settings.Logger.Info("--------Execution completed for test ' QA679 Create Accident Type' ------");
            accTypeU.ATName = accTypeE.ATName = accTypeD.ATName = accTypeC.ATName;
            CurrentPage.As<AccidentsTypePageActions>().UpdateAccidentTypes(accTypeD);
            CurrentPage.As<AccidentsTypePageActions>().VerifyAccidentType(accTypeD);
            CommonUtil.AddPassedTestCase("QA680");
            Settings.Logger.Info("--------Execution completed for test ' QA680 Disable Accident Type' ------");
            CurrentPage.As<AccidentsTypePageActions>().UpdateAccidentTypes(accTypeE);
            CurrentPage.As<AccidentsTypePageActions>().VerifyAccidentType(accTypeE);
            CommonUtil.AddPassedTestCase("QA681");
            Settings.Logger.Info("--------Execution completed for test ' QA681 Enable Accident Type' ------");
            CurrentPage.As<AccidentsTypePageActions>().UpdateAccidentTypes(accTypeU);
            CurrentPage.As<AccidentsTypePageActions>().VerifyAccidentType(accTypeU);
            CommonUtil.AddPassedTestCase("QA682");
            Settings.Logger.Info("--------Execution completed for test ' QA682 Update Accident Type' ------");
            CurrentPage.As<AccidentsTypePageActions>().VerifyAccidentTypeDeletion(accTypeC);
            Settings.Logger.Info("--------Execution completed for test ' QA684 Delete Accident Type' ------");
        }

        [Test, Description("M5-Accident-Accident Type-Delete Accident Type")]
        public void QA679_DeleteAccidentType()
        {
            CommonUtil.VerifyPassedTestCase("QA679");
        }

        [Test, Description("M5-Accident-Accident Type-Disable Accident Type")]
        public void QA680_DisableAccidentType()
        {
            CommonUtil.VerifyPassedTestCase("QA680");
        }

        [Test, Description("M5-Accident-Accident Type-Enable Accident Type")]
        public void QA681_EnableAccidentType()
        {
            CommonUtil.VerifyPassedTestCase("QA681");
        }

        [Test, Description("M5-Accident-Accident Type-Edit Accident Type Description")]
        public void QA682_UpdateAccidentType()
        {
            CommonUtil.VerifyPassedTestCase("QA682");
        }

        [TestCase("AccidentsTestData.json", "CreateAccidentCategory", Description = "M5-Accident-CreateEditAndDeleteAccidentCategory"), Order(1)]
        public void QA687_QA693_QA694_QA689_CreateEditAndDeleteAccidentCategory(object[] testParameter)
        {
            AccidentCategory createAccidentCategory = CommonUtil.DataObjectForKey("AccidentCategoryC").ToObject<AccidentCategory>();
            AccidentCategory editAccidentCategory = CommonUtil.DataObjectForKey("AccidentCategoryE").ToObject<AccidentCategory>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToAccidentCategoryPage();
            editAccidentCategory.CategoryCode = CurrentPage.As<AccidentCategoryPageActions>().CreateAccidentCategory(createAccidentCategory);
            CurrentPage.As<AccidentCategoryPageActions>().VerifyAccidentCategory(createAccidentCategory);
            Settings.Logger.Info("--------Execution completed for test 'QA687 Create and Verify Accident Category' ------");
            CurrentPage.As<AccidentCategoryPageActions>().EditAccidentCategory(editAccidentCategory);
            CurrentPage.As<AccidentCategoryPageActions>().VerifyAccidentCategory(editAccidentCategory);
            CommonUtil.AddPassedTestCase("QA693");
            Settings.Logger.Info("--------Execution completed for test 'QA693 Edit Accident Category' ------");
            editAccidentCategory.CategoryEnable = false;
            CurrentPage.As<AccidentCategoryPageActions>().EditAccidentCategory(editAccidentCategory);
            CurrentPage.As<AccidentCategoryPageActions>().VerifyAccidentCategory(editAccidentCategory);
            CommonUtil.AddPassedTestCase("QA689");
            Settings.Logger.Info("--------Execution completed for test 'QA689 Enable Accident Category'------");
            CurrentPage.As<AccidentCategoryPageActions>().DeleteAccidentCategory(editAccidentCategory.CategoryCode);
            CurrentPage.As<AccidentCategoryPageActions>().VerifyAfterDeletionAccidentCategory(editAccidentCategory.CategoryCode);
            CommonUtil.AddPassedTestCase("QA694");
            Settings.Logger.Info("--------Execution completed for test 'QA694 Delete Accident Category'------");

        }

        [Test, Description("M5-Edit Accident Category, Merged with- QA687_QA693_QA694_QA689_CreateEditAndDeleteAccidentCategory")]
        public void QA693_EditAccidentCategory()
        {
            CommonUtil.VerifyPassedTestCase("QA693");
        }

        [Test, Description("M5-DeleteAccidentCategory, Merged with- QA687_QA693_QA694_QA689_CreateEditAndDeleteAccidentCategory")]
        public void QA694_DeleteAccidentCategory()
        {
            CommonUtil.VerifyPassedTestCase("QA694");
        }

        [Test, Description("M5-Enable Accident Category, Merged with- QA687_QA693_QA694_QA689_CreateEditAndDeleteAccidentCategory")]
        public void QA689_EnableAccidentCategory()
        {
            CommonUtil.VerifyPassedTestCase("QA689");
        }

        [TestCase("AccidentsTestData.json", "CreateAccidentCause"), Description("M5-Accident-CreateNewAccidentCause(no address)"), Order(1)]
        [Category("dummy")]
        public void QA696_QA701_QA699_CreateEditEnableDisableDelteAccidentCause(object[] testParameter)
        {
            AccidentCause createAccidentCause = CommonUtil.DataObjectForKey("AccidentCauseC").ToObject<AccidentCause>();
            AccidentCause editAccidentCause = CommonUtil.DataObjectForKey("AccidentCauseE").ToObject<AccidentCause>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToAccidentCausePage();
            createAccidentCause.CauseNo = CurrentPage.As<AccidentCausePageActions>().CreateAccidentCause(createAccidentCause);
            editAccidentCause.CauseNo = createAccidentCause.CauseNo;
            CurrentPage.As<AccidentCausePageActions>().VerifyAccidentCauseDescription(createAccidentCause);
            Settings.Logger.Info("--------Execution completed for test 'QA696 Create and Verify Accident Cause' ------");
            editAccidentCause.CauseEnable = true;
            CurrentPage.As<AccidentCausePageActions>().EditAccidentCause(editAccidentCause);
            CurrentPage.As<AccidentCausePageActions>().VerifyAccidentCauseDescription(editAccidentCause);
            CommonUtil.AddPassedTestCase("QA701");
            Settings.Logger.Info("--------Execution completed for test 'QA701 Edit Accident Cause' ------");
            editAccidentCause.CauseEnable = false;
            CurrentPage.As<AccidentCausePageActions>().EditAccidentCause(editAccidentCause);
            CurrentPage.As<AccidentCausePageActions>().VerifyAccidentCauseDescription(editAccidentCause);
            CurrentPage.As<AccidentCausePageActions>().DeleteAccidentCause(editAccidentCause.CauseNo);
            CurrentPage.As<AccidentCausePageActions>().VerifyAfterDeletionAccidentCause(editAccidentCause.CauseNo);
            CommonUtil.AddPassedTestCase("QA699");
            Settings.Logger.Info("--------Execution completed for test 'QA699 Enable Accident Cause and Delete and Verify Accident Cause' ------");
        }

        [Test, Description("M5-EnableDisable Accident Category, Merged with-QA696_QA701_QA699_CreateEditEnableDisableDelteAccidentCause")]
        [Category("dummy")]
        public void QA699_EnableDisableDeleteAccidentCause()
        {
            CommonUtil.VerifyPassedTestCase("QA699");
        }

        [Test, Description("M5-Edit Accident Category, Merged with- QA696_QA701_QA699_CreateEditEnableDisableDelteAccidentCause")]
        [Category("dummy")]
        public void QA701_EditAccidentCause()
        {
            CommonUtil.VerifyPassedTestCase("QA701");
        }

        [TestCase("AccidentsTestData.json", "CreateAccidentEnry", Description = "M5-Accident-CreateAccidentEntry"),Order(1)]
        public void QA713_QA1153_QA1154_CreateAndVerifyAccidentEntry(object[] testParameter)
        {
            UnitMain unit = CommonUtil.DataObjectForKey("UnitDetails").ToObject<UnitMain>();
            AccidentEntry createAccidentEntry = CommonUtil.DataObjectForKey("AccidentEntryC").ToObject<AccidentEntry>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            unit.IsAddNew = true;
            createAccidentEntry.UnitNo = CurrentPage.As<UnitMainPageActions>().CreateUnit(unit);
            CurrentPage = _pageNavigate.NavigateToAccidentEntryPage();
            createAccidentEntry.AccidentNo = CurrentPage.As<AccidentEntryPageActions>().CreateAccidentEntry(createAccidentEntry);
            CurrentPage.As<AccidentEntryPageActions>().VerifyAccidentEntry(createAccidentEntry);
            CommonUtil.AddPassedTestCase("QA1153");
            CommonUtil.AddPassedTestCase("QA1154");
            Settings.Logger.Info("--------Execution completed for test ' QA713,QA1153 and QA1154 Creation and Verification for Accident Entry' ------");

        }

        [Test, Description("M5-CreateAndVerifyAccidentCategoryForVendorTab")]
        public void QA1153_CreateAndVerifyAccidenteEntryForVendorTab()
        {
            CommonUtil.VerifyPassedTestCase("QA1153");
            
        }

        [Test, Description("M5-CreateAndVerifyAccidentCategoryForWorkRequestTab")]
        public void QA1154_CreateAndVerifyAccidentCategoryForWorRequestTab()
        {
            CommonUtil.VerifyPassedTestCase("QA1154");
        }

        [TestCase("AccidentsTestData.json", "QA1152_AccidentEntryAccidentDetailAndUnitDamageTabs",
            TestName = "QA1152_AccidentEntryAccidentDetailAndUnitDamageTabs", Description = "M5-Accident-CreateAccidentEntry")]
        public void QA1152_AccidentEntryAccidentDetailAndUnitDamageTabs(object[] testParameter)
        {
            AccidentEntry accidentEntry = CommonUtil.DataObjectForKey("AccidentEntry").ToObject<AccidentEntry>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToAccidentEntryPage();
            accidentEntry.AccidentNo = CurrentPage.As<AccidentEntryPageActions>().CreateAccidentEntry(accidentEntry);
            CurrentPage.As<AccidentEntryPageActions>().VerifyAccidentEntry(accidentEntry);
        }

        [TestCase("AccidentsTestData.json", "QA1155_AccidentEntryInsuranceClaimsAndPaymentTabs",
            TestName = "QA1155_AccidentEntryInsuranceClaimsAndPaymentTabs", Description = "M5-Accident-CreateAccidentEntry")]
        public void QA1155_AccidentEntryInsuranceClaimsAndPaymentTabs(object[] testParameter)
        {
            AccidentEntry accidentEntry = CommonUtil.DataObjectForKey("AccidentEntry").ToObject<AccidentEntry>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToAccidentEntryPage();
            accidentEntry.AccidentNo = CurrentPage.As<AccidentEntryPageActions>().CreateAccidentEntry(accidentEntry);
            CurrentPage.As<AccidentEntryPageActions>().VerifyAccidentEntry(accidentEntry);
        }
    }
}