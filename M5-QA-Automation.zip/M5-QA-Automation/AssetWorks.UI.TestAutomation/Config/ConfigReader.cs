﻿using AssetWorks.UI.Core.Utils;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.Config
{
    /// <summary>
    /// Configurations reader
    /// </summary>
    public class ConfigReader
    {
        /// <summary>
        /// Intialize Configurations Settings
        /// </summary>
        public static void IntializeConfigSettings()
        {
            Settings.ConfigSettings = new CommonUtils().LoadFiles(Settings.AppSettingPath, Settings.UserDelimeter);
            Settings.TData = new CommonUtils().LoadFiles(Settings.TestDataPath, Settings.UserDelimeter);
        }
        

    }
}
