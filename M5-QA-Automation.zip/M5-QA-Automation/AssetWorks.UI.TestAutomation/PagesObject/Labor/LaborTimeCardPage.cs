﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using System.Collections.Generic;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Labor
{
    internal class LaborTimeCardPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal LaborTimeCardPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        internal readonly string _headerIWO = "Indirect /\r\nWork Order";

        [FindsBy(How = How.XPath, Using = "//input[@id='EmployeeNo']")]
        internal readonly IWebElement? _inputEmployeeNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Pin']")]
        internal readonly IWebElement? _inputPin = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='LaborDate']")]
        internal readonly IWebElement? _inputPayrollDate = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='LaborEntryEMFrame']")]
        internal IWebElement? _frameTimeEntry = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='laborTable']/tbody")]
        internal IWebElement? _tableTimeEntry = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='laborTable']/tbody/tr")]
        internal IList<IWebElement>? _tableTimeEntryTotalRows = null;

        internal IWebElement? _inputEntry(int rowId) => Driver.FindElement(By.XPath($"//input[@id='wonumber${rowId}']"));
        internal IWebElement? _selectType(int rowId) => Driver.FindElement(By.XPath($"//select[@id='Type$new_{rowId}']"));
        internal IWebElement? _inputWorkOrder(int rowId) => Driver.FindElement(By.XPath($"//input[@id='wonumber$new_{rowId}']"));
        internal IWebElement? _inputJob(int rowId) => Driver.FindElement(By.XPath($"//input[@id='Job$new_{rowId}']"));
        internal IWebElement? _inputTimeIn(int rowId) => Driver.FindElement(By.XPath($"//input[@id='timein$new_{rowId}']"));
        internal IWebElement? _inputTimeOut(int rowId) => Driver.FindElement(By.XPath($"//input[@id='timeout$new_{rowId}']"));
        internal IWebElement? _inputTimeType(int rowId) => Driver.FindElement(By.XPath($"//input[@id='TimeType$new_{rowId}']"));
        internal IWebElement? _inputPayClass(int rowId) => Driver.FindElement(By.XPath($"//input[@id='PayClass$new_{rowId}']"));
        internal IWebElement? _inputPayStep(int rowId) => Driver.FindElement(By.XPath($"//input[@id='PayStep$new_{rowId}']"));
        internal IWebElement? _inputPosition(int rowId) => Driver.FindElement(By.XPath($"//input[@id='Position$new_{rowId}']"));
        internal IWebElement? _inputUnion(int rowId) => Driver.FindElement(By.XPath($"//input[@id='Union$new_{rowId}']"));
    }
}
