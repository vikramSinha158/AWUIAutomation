﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Labor
{
    internal class HolidayCalendarPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal HolidayCalendarPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        internal readonly string _headerDate = "Date";

        [FindsBy(How = How.XPath, Using = "//input[@id='FiscalYear']")]
        internal readonly IWebElement? _inputFiscalYear = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='HolidayFrame']")]
        internal readonly IWebElement? _frameHoliday = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='holidayTable']/tbody")]
        internal readonly IWebElement? _tableHoliday = null;

        internal IWebElement? _inputNewDate(int row) => Driver.FindElement(By.XPath($"//input[@id='date$new_{row}']"));
        internal IWebElement? _inputNewIndirectAccount(int row) => Driver.FindElement(By.XPath($"//input[@id='indacct$new_{row}']"));
        internal IWebElement? _inputNewHolidayDescription(int row) => Driver.FindElement(By.XPath($"//input[@id='description$new_{row}']"));
    }
}
