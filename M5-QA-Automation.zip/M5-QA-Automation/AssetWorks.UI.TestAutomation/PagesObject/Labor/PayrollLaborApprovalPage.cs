﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Labor
{
    internal class PayrollLaborApprovalPage : BasePage
    {
        internal readonly string _headerShiftStart = "Shift\r\nStart";
        internal readonly string _headerEmployeeNo = "Employee\r\nNo";
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal PayrollLaborApprovalPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='SupervNo']")]
        internal readonly IWebElement? _inputSupervisorNo = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Title']")]
        internal readonly IWebElement? _selectTitle = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DateApproveStart']")]
        internal readonly IWebElement? _inputFromDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DateApproveEnd']")]
        internal readonly IWebElement? _inputToDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='union']")]
        internal readonly IWebElement? _inputUnion = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='empLoc']")]
        internal readonly IWebElement? _inputEmpLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='RetrieveBtn']")]
        internal readonly IWebElement? _btnRetrieve = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ApproveAllBtn']")]
        internal readonly IWebElement? _btnApproveAll = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='LaborApprFrame']")]
        internal IWebElement? _frameLaborApproval = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='LaborApprTable']/tbody")]
        internal IWebElement? _tableLaborApproval = null;

        [FindsBy(How = How.XPath, Using = "//body/p")]
        internal IWebElement? _tableMsg = null;
    }
}
