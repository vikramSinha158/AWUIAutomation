﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Labor
{
    internal class LaborWedgePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal LaborWedgePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='EmployeeNo']")]
        internal readonly IWebElement? _inputEmployeeNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Pin']")]
        internal readonly IWebElement? _inputPin = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NWOUnitNo']")]
        internal readonly IWebElement? _inputNWOUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NWOIndCode']")]
        internal readonly IWebElement? _inputNWOIndCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NewJobCode']")]
        internal readonly IWebElement? _inputNewJobCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NewPosition']")]
        internal readonly IWebElement? _inputNewPosition = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='WoTimeType']")]
        internal readonly IWebElement? _inputWoTimeType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='WoPayClass']")]
        internal readonly IWebElement? _inputWoPayClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='WoPayStep']")]
        internal readonly IWebElement? _inputWoPayStep = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NewPunchTime']")]
        internal readonly IWebElement? _inputNewPunchTime = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='JobStatus']")]
        internal readonly IWebElement? _inputJobStatus = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='CurrentLaborFrame']")]
        internal IWebElement? _frameCurrentLabor = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='currTable']/tbody")]
        internal IWebElement? _tableCurrentLabor = null;

        [FindsBy(How = How.XPath, Using = "//span[@id='addjob']")]
        internal readonly IWebElement? _addJobs = null;

        [FindsBy(How = How.XPath, Using = "//span[@id='joblbl']")]
        internal readonly IWebElement? _jobAssignments = null;

        internal IWebElement? _linkAddJob(string wo) => Driver.FindElement(By.XPath($"//a[@wo='{wo}']"));

        //Add Jobs to Work Order
        [FindsBy(How = How.XPath, Using = "//iframe[@name='AddJobsFrame']")]
        internal IWebElement? _frameAddJobs = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='jobTable']/tbody")]
        internal IWebElement? _tableAddJobs = null;

        internal IWebElement? _inputNewJob(int row) => Driver.FindElement(By.XPath($"//input[@id='job$new_{row}']"));
        internal IWebElement? _inputNewStatus(int row) => Driver.FindElement(By.XPath($"//input[@id='status$new_{row}']"));
        internal IWebElement? _inputNewJobReason(int row) => Driver.FindElement(By.XPath($"//input[@id='job_reason$new_{row}']"));

        //Part Requests for this Job
        [FindsBy(How = How.XPath, Using = "//div[@id='addPartRequest1']")]
        internal readonly IWebElement? _addPartRequest = null;

        [FindsBy(How = How.XPath, Using = "//div[@id='hpartHoverTbl']")]
        internal readonly IWebElement? _partHoverTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@class='tip-table']//div//tbody/tr/td[4]")]
        internal readonly IWebElement? _partAssign = null;
    }
}
