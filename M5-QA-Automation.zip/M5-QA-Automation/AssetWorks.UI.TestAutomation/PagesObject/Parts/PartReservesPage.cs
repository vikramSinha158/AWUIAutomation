﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class PartReservesPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public PartReservesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//select[@name='pStatus']")]
        internal readonly IWebElement? _partStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='StatusDtS']")]
        internal readonly IWebElement? _StatusDateFrom = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='StatusDtE']")]
        internal readonly IWebElement? _StatusDateTo = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='Status']")]
        internal readonly IWebElement? _reservesStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='PartNo']")]
        internal readonly IWebElement? _partNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='reqButton']")]
        internal readonly IWebElement? _retrieve = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PartReserveFram']")]
        internal readonly IWebElement? _partReserveFram = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartTable']")]
        internal readonly IWebElement? _partTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartTable']//tbody//tr")]
        internal IList<IWebElement>? _partTableRows = null;
    }
}
