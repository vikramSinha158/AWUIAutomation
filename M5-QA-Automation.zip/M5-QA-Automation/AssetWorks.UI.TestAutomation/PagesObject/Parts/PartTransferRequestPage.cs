﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class PartTransferRequestPage : BasePage
    {
        internal ExtendedPageActions ExtendedPage => new ExtendedPageActions(Driver);

        public PartTransferRequestPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='fmLoc']")]
        internal readonly IWebElement? _inputShippingFromLoc = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='typeCode']")]
        internal readonly IWebElement? _selectReserveCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PartNum']")]
        internal readonly IWebElement? _inputPartNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='daysNum']")]
        internal readonly IWebElement? _inputDaysBack = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='rStatus']")]
        internal readonly IWebElement? _selectStatus = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='Retrieve']")]
        internal IWebElement? _buttonRetrieve = null;


        //Transfer Request Detail 
        [FindsBy(How = How.XPath, Using = "//iframe[@name='PRequestTFRFrame']")]
        internal readonly IWebElement? _framePartRequests = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartTable']")]
        internal readonly IWebElement? _tablePartRequests = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PartNo$new_0']")]
        internal readonly IWebElement? _inputPartNoNew = null;
    }
}
