﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class PartJournalQueryPage : BasePage
    {
        internal ExtendedPageActions ExtendedPage => new ExtendedPageActions(Driver);

        public PartJournalQueryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='loc']")]
        internal readonly IWebElement? _inputLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PartNo']")]
        internal readonly IWebElement? _inputPartNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PDesc']")]
        internal readonly IWebElement? _inputPartDesc = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='ResvType']")]
        internal readonly IWebElement? _selectReservationType = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='transcode']")]
        internal readonly IWebElement? _selectTransactionCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='invno']")]
        internal readonly IWebElement? _inputInvoiceNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='Clear']")]
        internal readonly IWebElement? _buttonClear = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='Retrieve']")]
        internal readonly IWebElement? _buttonRetrieve = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='InvTransByPartFrame']")]
        internal readonly IWebElement? _frameQueryResults = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='InvTransByPartTable']")]
        internal readonly IWebElement? _tableQueryResults = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ResvFor']")]
        internal readonly IWebElement? _inputReservRefNo = null;
    }
}
