﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class PartChargeCodePage : BasePage
    {
        public PartChargeCodePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        internal ExtendedPageActions ExtendedPage => new(Driver);

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PartChgCodeFrame']")]
        internal IWebElement? _framePartChargeCode = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='ChargeCodeTable']/tbody")]
        internal IWebElement? _tableChargeCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='chgCode$new_0']")]
        internal IWebElement? _inputChargeCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='description$new_0']")]
        internal IWebElement? _inputDescription = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='chargeType$new_0']")]
        internal IWebElement? _selectChargeType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Default_fl$new_0']")]
        internal IWebElement? _checkboxDefault = null;
    }
}
