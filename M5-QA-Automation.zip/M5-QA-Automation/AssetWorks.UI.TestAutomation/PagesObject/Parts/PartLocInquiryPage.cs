﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    public class PartLocInquiryPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public PartLocInquiryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.Id, Using = "PartNo1")]
        internal IWebElement? _partNo = null;

        [FindsBy(How = How.Id, Using = "loctype")]
        internal IWebElement? _location = null;

        [FindsBy(How = How.Id, Using = "showloc")]
        internal IWebElement? _showloc = null;

        [FindsBy(How = How.Id, Using = "Idept")]
        internal IWebElement? _department = null;

        [FindsBy(How = How.Id, Using = "Retrieve")]
        internal IWebElement? _retrive = null;

        [FindsBy(How = How.Name, Using = "InvLocInquiryFrame")]
        internal IWebElement? _invLocInquiryTableFrame = null;

        [FindsBy(How = How.Id, Using = "InvLocInquiryTable")]
        internal IWebElement? _invLocInquiryTable = null;
        internal IList<IWebElement>? _partQueryResult => Driver.FindElements(By.XPath("//table[@id='InvLocInquiryTable']//tbody//tr"));
        internal IWebElement? _verifyDept(string dept) => Driver.FindElement(By.XPath($"//input[@value='{dept}']"));
        internal IWebElement? _verifyQueryResult(string dept, string infoToBeVerified) => Driver.FindElement(By.XPath($"//input[@value='{dept}']/ancestor::tr//input[@value='{infoToBeVerified}']"));
        internal IWebElement? _verifyLocation(string dept, string loc) => Driver.FindElement(By.XPath($"//input[@value='{dept}']/ancestor::tr//div[@loccode='{loc}']"));
      }
}
