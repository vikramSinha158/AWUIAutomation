﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    public class PartClassCodesPage: BasePage
    {
        public PartClassCodesPage(IWebDriver Driver) : base(Driver) => PageFactory.InitElements(Driver, this);

        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        [FindsBy(How = How.Name, Using = "PartClassCodeFrame")]
        internal IWebElement? _partClassCodeFrame = null;

        [FindsBy(How = How.Id, Using = "PartClassCodeTable")]
        internal IWebElement? _partClassCodeTable = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PART_CLASS$new_0']")]
        internal IWebElement? _partClassNew = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DESCRIPTION$new_0']")]
        internal IWebElement? _descriptionNew = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DISABLED_FL$new_0']")]
        internal IWebElement? _disabledCheckNew = null;

        internal IWebElement? _createdClassCode(string code)=> Driver.FindElement(By.XPath($"//input[@value='{code}']"));
        internal IList<IWebElement>? _createdClassCodeCount(string code) => Driver.FindElements(By.XPath($"//input[@value='{code}']"));

        internal IWebElement? _createdClassCodeDescription(string code) => Driver.FindElement(By.XPath($"//input[@value='{code}']/ancestor::tr//input[contains(@id,'DESCRIPTION')]"));
        internal IWebElement? _createdClassCodeDisabledCheck(string code) => Driver.FindElement(By.XPath($"//input[@value='{code}']/ancestor::tr//input[contains(@id,'DISABLED')]"));
       
    }
}
