﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;


namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class UnitOfMeasurePage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);            

        public UnitOfMeasurePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='code$new_0']")]
        internal readonly IWebElement? _codeNew = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='desc$new_0']")]
        internal readonly IWebElement? _descriptionNew = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='disabled$new_0']")]
        internal readonly IWebElement? _disabledNew = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='default$new_0']")]
        internal readonly IWebElement? _defaultNew = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='conv_factor$new_0']")]
        internal readonly IWebElement? _usgFactorNew = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='UnitFrame']")]
        internal IWebElement? _UnitFrame = null;    

        [FindsBy(How = How.XPath, Using = "//table[@id='UnitTable']/tbody")]
        internal readonly IWebElement? _UnitTable = null;
    }
}
