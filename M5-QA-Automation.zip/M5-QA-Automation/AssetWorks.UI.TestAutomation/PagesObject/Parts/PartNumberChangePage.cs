﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    public class PartNumberChangePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public PartNumberChangePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }
        [FindsBy(How = How.Id, Using = "PartNo")]
        internal IWebElement? _partNo = null;

        [FindsBy(How = How.Id, Using = "PDesc")]
        internal IWebElement? _partDesc = null;

        [FindsBy(How = How.Id, Using = "Mfg")]
        internal IWebElement? _manufacturer = null;

        [FindsBy(How = How.Id, Using = "NewPartNo")]
        internal IWebElement? _newPartNo = null;

        [FindsBy(How = How.Id, Using = "NewMfg")]
        internal IWebElement? _newManufacturer = null;
    }
}
