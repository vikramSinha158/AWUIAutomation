﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class PartBinPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);     
        internal string _binLocator= "bin$new_";
        internal string _descriptionLocator = "desc$new_";
        internal string _disabledLocator = "disabled$new_";
        internal CreatePartPin? _createPartBinObject = null;       

        public PartBinPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='startRange']")]
        internal readonly IWebElement? _binCodeInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='RetrieveBtn']")]
        internal readonly IWebElement? _retrieveBtn = null;


        [FindsBy(How = How.XPath, Using = "//iframe[@name='BinMainFrame']")]
        internal IWebElement? _framePartBin = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BinMainTable']/tbody/tr")]
        internal readonly IList<IWebElement>? _tablerows = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BinMainTable']/tbody")]
        internal readonly IWebElement? _tablePartBin = null;


    }
}
