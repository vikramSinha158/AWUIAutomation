﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class PartMainCatalogPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal readonly string _headerSerial = "Serial\r\nNo";

        public PartMainCatalogPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }  

        [FindsBy(How = How.XPath, Using = "//input[@id='PartNo']")]
        internal IWebElement? _inputPartNo = null;

        [FindsBy(How = How.Id, Using = "Mfg")]
        internal IWebElement? _manufacturer = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PDesc']")]
        internal IWebElement? _inputPDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='sprice']")]
        internal IWebElement? _inputSPrice = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='aprice']")]
        internal IWebElement? _inputAPrice = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='rprice']")]
        internal IWebElement? _inputRPrice = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DISCOUNT_CODE']")]
        internal IWebElement? _inputPDiscountCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='umeas']")]
        internal IWebElement? _inputUnitOfInventory = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Commodity']")]
        internal IWebElement? _inputCommodity = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ChgCode']")]
        internal IWebElement? _inputChargeCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='COST_CAT_CODE']")]
        internal IWebElement? _inputCostCategory = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PART_CLASS']")]
        internal IWebElement? _inputPartClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='sys']")]
        internal IWebElement? _inputATAsys = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='comp']")]
        internal IWebElement? _inputATAcomp = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ata_part']")]
        internal IWebElement? _inputATApart = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='snc']")]
        internal IWebElement? _selectStockType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PriVendor']")]
        internal IWebElement? _inputPriVendor = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SecVendor']")]
        internal IWebElement? _inputSecVendor = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='season']")]
        internal IWebElement? _inputSeasonCode = null;

        [FindsBy(How = How.Id, Using = "Note")]
        internal IWebElement? _extendedPartDescription = null;

        [FindsBy(How = How.Id, Using = "Serialized")]
        internal IWebElement? _serialized = null;

        [FindsBy(How = How.Id, Using = "autoGenSerial")]
        internal IWebElement? _autoGenSerial = null;

        [FindsBy(How = How.Id, Using = "reUseSerial")]
        internal IWebElement? _reUseSerial = null;

        [FindsBy(How = How.Id, Using = "lottedFlag")]
        internal IWebElement? _lottedFlag = null;

        [FindsBy(How = How.Id, Using = "core_do")]
        internal IWebElement? _coreCharge = null;

        [FindsBy(How = How.Id, Using = "core_fl")]
        internal IWebElement? _core_fl = null;

        [FindsBy(How = How.XPath, Using = "//div[@id='divLocation']")]
        internal IWebElement? _linkLocation = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Warranty']")]
        internal IWebElement? _selectWarranty = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Hazard']")]
        internal IWebElement? _selectHazardous = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='serialBtn']")]
        internal IWebElement? _buttonserial = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PartSerialDetailFrame']")]
        internal IWebElement? _framePartSerial = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartSerialTable']/tbody")]
        internal IWebElement? _tablePartSerial = null;
    }
}
