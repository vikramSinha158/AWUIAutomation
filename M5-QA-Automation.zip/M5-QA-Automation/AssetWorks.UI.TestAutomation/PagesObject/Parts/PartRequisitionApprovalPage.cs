﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class PartRequisitionApprovalPage : BasePage
    {
        public PartRequisitionApprovalPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        internal ExtendedPageActions ExtendedPage => new(Driver);

        [FindsBy(How = How.XPath, Using = "//input[@id='reqno']")]
        internal IWebElement? _inputRequisitionNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='requestor']")]
        internal IWebElement? _inputRequestor = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='hvendor']")]
        internal IWebElement? _inputVendor = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='needed']")]
        internal IWebElement? _inputNeededBy = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='StatusDtS']")]
        internal IWebElement? _inputStartDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='StatusDtE']")]
        internal IWebElement? _inputEndDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PartNo']")]
        internal IWebElement? _inputPartNo = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='chargeCode']")]
        internal IWebElement? _selectReservedFor = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='reqButton']")]
        internal IWebElement? _btnRetrieve = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='bProcess']")]
        internal IWebElement? _checkboxProcess = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='RejReason']")]
        internal IWebElement? _selectRejReason = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PReqListFrame']")]
        internal IWebElement? _frameReqList = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PReqListTable']")]
        internal IWebElement? _tableReqList = null;
    }
}
