﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class PartTransferPage : BasePage
    {
        internal ExtendedPageActions ExtendedPage => new ExtendedPageActions(Driver);

        public PartTransferPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='loc']")]
        internal readonly IWebElement? _inputShippingLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='empID']")]
        internal readonly IWebElement? _inputEmployeeID = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='toLoc']")]
        internal readonly IWebElement? _inputRecvLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ticketNo']")]
        internal readonly IWebElement? _inputTicketNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='pvendor']")]
        internal readonly IWebElement? _inputVendor = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PartNum']")]
        internal readonly IWebElement? _inputPartNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='tfrAdded']")]
        internal readonly IWebElement? _checkboxAdded = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='tfrRequest']")]
        internal readonly IWebElement? _checkboxRequest = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='tfrPick']")]
        internal readonly IWebElement? _checkboxPick = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='tfrComplete']")]
        internal readonly IWebElement? _checkboxComplete = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='Retrieve']")]
        internal IWebElement? _buttonRetrieve = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='prtNothingBtn']")]
        internal IWebElement? _buttonPrintNothing = null;


        //Part Transfer Detail 
        [FindsBy(How = How.XPath, Using = "//iframe[@name='PartTransferFrame']")]
        internal readonly IWebElement? _framePartTransfer = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartTable']")]
        internal readonly IWebElement? _tablePartTransfer = null;

        internal IWebElement? _inputStatus(string row) => Driver.FindElement(By.XPath($"//input[@id='status$new_{row}']"));
        internal IWebElement? _inputRecvLoc(string row) => Driver.FindElement(By.XPath($"//input[@id='ShipTo$new_{row}']"));
        internal IWebElement? _inputPartNo(string row) => Driver.FindElement(By.XPath($"//input[@id='PartNo$new_{row}']"));
    }
}
