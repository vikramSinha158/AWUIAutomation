﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class WarrantyPartSetupPage : BasePage
    {
        internal ExtendedPageActions ExtendedPage => new(Driver);

        public WarrantyPartSetupPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='PartNo']")]
        internal IWebElement? _inputPartNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Vendor_No']")]
        internal IWebElement? _inputVendorNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Warranty_CD']")]
        internal IWebElement? _inputWarrantyCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Terms_Usage']")]
        internal IWebElement? _inputTermsUsage = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Terms_Time']")]
        internal IWebElement? _inputTermsTime = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Usage_UM']")]
        internal IWebElement? _selectUsageUM = null;
    }
}
