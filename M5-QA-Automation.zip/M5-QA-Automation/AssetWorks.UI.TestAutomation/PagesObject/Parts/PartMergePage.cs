﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    public class PartMergePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public PartMergePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.Id, Using = "PartNo")]
        internal IWebElement? _partNo = null;

        [FindsBy(How = How.Id, Using = "PDesc")]
        internal IWebElement? _partDesc = null;

        [FindsBy(How = How.Id, Using = "Mfg")]
        internal IWebElement? _manufacturer = null;

        [FindsBy(How = How.Id, Using = "RemainPartNo")]
        internal IWebElement? _remainPartNo = null;

        [FindsBy(How = How.Id, Using = "NewMfg")]
        internal IWebElement? _newManufacturer = null;

        [FindsBy(How = How.Name, Using = "PartMergeFrame")]
        internal IWebElement? _partMergeFrame = null;

        [FindsBy(How = How.Name, Using = "PartMergeTable")]
        internal IWebElement? _partMergeTable = null;

        [FindsBy(How = How.XPath, Using = "//span[@id='LTPartMergeFrame']")]
        internal IWebElement? _partMergeCount = null;

        internal IWebElement? _verifyMergedInfo(string oldPartNo, string mergeInfoToBeVerified) => Driver.FindElement(By.XPath($"//input[@value='{oldPartNo}']/ancestor::tr//input[@value='{mergeInfoToBeVerified}']"));

    }
}
