﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class PartIssuePage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);       

        public PartIssuePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//select[@name='stocktype']")]
        internal readonly IWebElement? _stocktype = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='issueTo']")]
        internal readonly IWebElement? _issueTo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='CustEmpNo']")]
        internal readonly IWebElement? _issuingEmpNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='vendNo']")]
        internal readonly IWebElement? _vendorNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='effDT']")]
        internal readonly IWebElement? _effectiveDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='invNo']")]
        internal readonly IWebElement? _invoiceNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='RefNo']")]
        internal readonly IWebElement? _refNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='orderDt']")]
        internal readonly IWebElement? _orderDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='discount']")]
        internal readonly IWebElement? _discount = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='proNumber']")]
        internal readonly IWebElement? _proNumber = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='IssueToAllFrame']")]
        internal readonly IWebElement? _issueToAllFrame = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='KitPartsFrame']")]
        internal readonly IWebElement? _partListFrame = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ContentM']")]
        internal readonly IWebElement? _partListContentFrame = null;

        [FindsBy(How = How.Id, Using = "KitPartsTable")]
        internal readonly IWebElement? _partListTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartsTable']")]
        internal readonly IWebElement? _partsTable = null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Part Kit List']")]
        internal IWebElement? _partKitLink = null;

        public IWebElement? _DeptNO(int i) => Driver.FindElement(By.Id($"DeptNo$new_{i}"));

        public IWebElement? _PartNO(int i) => Driver.FindElement(By.Id($"PartNo$new_{i}"));

        public IWebElement? _Qnty(int i) => Driver.FindElement(By.Id($"cpqty$new_{i}"));

        public IWebElement? _FailCode(int i) => Driver.FindElement(By.Id($"cpfail$new_{i}"));

        [FindsBy(How = How.XPath, Using = "//input[@name='PartNo$new_0']")]
        internal readonly IWebElement? _partNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@type='search']")]
        internal IWebElement? _searchtext = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='lovBodyTable']/tbody/tr/td/span")]
        internal IWebElement? _firstListItem = null;

        [FindsBy(How = How.Id, Using = "showFilterButton")]
        internal IWebElement? _showFilterButton = null;
    }
}
