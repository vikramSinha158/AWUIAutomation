﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class PartAdjustmentPage : BasePage
    {
        public PartAdjustmentPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        internal ExtendedPageActions ExtendedPage => new(Driver);

        [FindsBy(How = How.XPath, Using = "//input[@id='PartNo']")]
        internal IWebElement? _inputPartNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Reason']")]
        internal IWebElement? _ReasonCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='EmpNo']")]
        internal IWebElement? _EmployeeNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AdjQtyOnHand']")]
        internal IWebElement? _AdjustmentQty = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='AdjPrice']")]
        internal IWebElement? _AdjustmentPrice = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='Notes']")]
        internal IWebElement? _Notes = null;
      
        [FindsBy(How = How.XPath, Using = "//input[@name='QtyOnHand']")]
        internal IWebElement? _QtyOnHand = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='pLot']")]
        internal readonly IWebElement? _inputLotNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='mfgDate']")]
        internal readonly IWebElement? _inputLotMfgDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='expDate']")]
        internal readonly IWebElement? _inputLotExpDate = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='lotInfoBtn']")]
        internal readonly IWebElement? _lotInfoBtn = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='SerialEntryFrame']")]
        internal readonly IWebElement? _frameSerialEntry = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SerialNo$new_0']")]
        internal readonly IWebElement? _inputSerialNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='mfgDate$new_0']")]
        internal readonly IWebElement? _inputSnMfgDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='expDate$new_0']")]
        internal readonly IWebElement? _inputSnExpDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='SPartNo']")]
        internal IWebElement? _serialPartNo = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='PartSerialUnitLeft']")]
        internal IWebElement? _partSerialUnitLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='PartSerialUnitRight']")]
        internal IWebElement? _partSerialUnitRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='PartSerialUnitMoveRight']")]
        internal IWebElement? _partSerialUnitMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='PartSerialUnitMoveLeft']")]
        internal IWebElement? _partSerialUnitMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='SerialFrame']")]
        internal IWebElement? _serialFrame = null;
    }
}
