﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class PartRequestHandlingPage : BasePage
    {
        internal ExtendedPageActions ExtendedPage => new ExtendedPageActions(Driver);

        public PartRequestHandlingPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//select[@id='optselLG']")]
        internal readonly IWebElement? _selectOption = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='loc']")]
        internal readonly IWebElement? _inputLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='unitNo']")]
        internal readonly IWebElement? _inputUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='woNo']")]
        internal readonly IWebElement? _inputWoNo = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='rStatus']")]
        internal readonly IWebElement? _selectStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='reqDate']")]
        internal readonly IWebElement? _inputNeedBy = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='ReqRetrieve']")]
        internal readonly IWebElement? _buttonRetrieve = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='clear']")]
        internal readonly IWebElement? _buttonClear = null;

        //Existing Requests
        [FindsBy(How = How.XPath, Using = "//iframe[@name='PartReqHandlingFrame']")]
        internal readonly IWebElement? _framePartReqHandling = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartReqDetailTable']")]
        internal readonly IWebElement? _tablePartReqDetail = null;
    }
}
