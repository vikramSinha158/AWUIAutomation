﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class PartRequestPage : BasePage
    {
        internal ExtendedPageActions ExtendedPage => new ExtendedPageActions(Driver);
        
        public PartRequestPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='EmployeeNo']")]
        internal readonly IWebElement? _employeeNumber = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='unitNo']")]
        internal readonly IWebElement? _unitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='woNo']")]
        internal readonly IWebElement? _woNo = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PartRequestFrame']")]
        internal readonly IWebElement? _partRequestFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartReqDetailTable']")]
        internal readonly IWebElement? _tablePartRequest = null;

        [FindsBy(How = How.XPath, Using = "//iframe[contains(@id,'Content2')]")]
        internal IWebElement? _noteButtonContentFrame = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='clearBtn']")]
        internal readonly IWebElement? _clearBtn = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='note$new_0']")]
        internal readonly IWebElement? _testNote = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='locked$new_0']")]
        internal readonly IWebElement? _locked = null;

        internal IWebElement? _inputJobCode(string row) => Driver.FindElement(By.XPath($"//input[@name='job$new_{row}']"));
        internal IWebElement? _inputPartNo(string row) => Driver.FindElement(By.XPath($"//input[@name='PartNo$new_{row}']"));
        internal IWebElement? _inputRequestQuantity(string row) => Driver.FindElement(By.XPath($"//input[@name='reqQty$new_{row}']"));
        internal IWebElement? _inputNeededByDate(string row) => Driver.FindElement(By.XPath($"//input[@name='reqDt$new_{row}']"));

    }
}
