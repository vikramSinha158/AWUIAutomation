﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class PartsKitPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
          

        public PartsKitPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.Id, Using = "KitNo")]
        internal readonly IWebElement? _kitNo = null;

        [FindsBy(How = How.Id, Using = "KDesc")]
        internal readonly IWebElement? _kDesc = null;

        [FindsBy(How = How.Id, Using = "part$new_0")]
        internal readonly IWebElement? _partNo = null;

        public IWebElement? _PartNO(int i) => Driver.FindElement(By.Id($"part$new_{i}"));

        public IWebElement? _PartQuantity(int i) => Driver.FindElement(By.Id($"pQty$new_{i}"));
        
        [FindsBy(How = How.Id, Using = "pDesc$new_0")]
        internal readonly IWebElement? _partDesc = null;

        [FindsBy(How = How.Id, Using = "pMfg$new_0")]
        internal readonly IWebElement? _partManufacturer = null;

        [FindsBy(How = How.Id, Using = "pQty$new_0")]
        internal readonly IWebElement? _partQuantity = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PartKitFrame']")]
        internal IWebElement? _framePartKit = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartKitTable']/tbody")]
        internal readonly IWebElement? _tablePartKit = null;
    }
}
