﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Parts;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class PartReceivePage : BasePage
    {
        internal ExtendedPageActions ExtendedPage => new(Driver);

        internal ListOfValuesPageActions Lov => new(Driver);
        
        internal PartsAdjustmentPageActions PartsAdjustment => new(Driver);

        internal readonly string _headerSerial = "Serial\r\nNo";

        public PartReceivePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//select[@id='dispType']")]
        internal readonly IWebElement? _selectType = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='prtNothingBtn']")]
        internal IWebElement? _buttonPrintNothing = null;


        //Vendor With PO
        [FindsBy(How = How.XPath, Using = "//input[@id='pono1']")]
        internal readonly IWebElement? _inputPOno1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='vennumber1']")]
        internal readonly IWebElement? _inputVendorNo1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CustEmpNo1']")]
        internal readonly IWebElement? _inputEmployee1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='invno1']")]
        internal readonly IWebElement? _inputInvoiceNo1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='effdt']")]
        internal readonly IWebElement? _inputEffectiveDate1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ApplyTax1Scheme']")]
        internal readonly IWebElement? _inputTaxScheme1 = null;

        //Vendor Without PO
        [FindsBy(How = How.XPath, Using = "//input[@id='pono2']")]
        internal readonly IWebElement? _inputPOno2 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='vennumber2']")]
        internal readonly IWebElement? _inputVendorNo2 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CustEmpNo']")]
        internal readonly IWebElement? _inputEmployee2 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='invno2']")]
        internal readonly IWebElement? _inputInvoiceNo2 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='effdt2']")]
        internal readonly IWebElement? _inputEffectiveDate2 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ApplyTax2Scheme']")]
        internal readonly IWebElement? _inputTaxScheme2 = null;

        //Transfer Ticket No
        [FindsBy(How = How.XPath, Using = "//input[@id='TfrTcktNo']")]
        internal readonly IWebElement? _inputTransferTicketNo = null;

        //Return to Vendor
        [FindsBy(How = How.XPath, Using = "//input[@id='vennumber3']")]
        internal readonly IWebElement? _inputVendorNo3 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CustEmpNo3']")]
        internal readonly IWebElement? _inputEmployee3 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='invno3']")]
        internal readonly IWebElement? _inputInvoiceNo3 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='venInvdt3']")]
        internal readonly IWebElement? _inputInvoiceDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='pono3']")]
        internal readonly IWebElement? _inputPOno3 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Contract3']")]
        internal readonly IWebElement? _inputContract3 = null;

        //Parts Details
        [FindsBy(How = How.XPath, Using = "//iframe[@name='PartsRecvFrame']")]
        internal readonly IWebElement? _framePartsRecv = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartRcvTable']")]
        internal readonly IWebElement? _tablePartsRecv = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PartNo$new_0']")]
        internal readonly IWebElement? _inputPartNoNew = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='quantity$new_0']")]
        internal readonly IWebElement? _inputQuantityNew = null;

        //Lot No Entry
        [FindsBy(How = How.XPath, Using = "//input[@id='pLot']")]
        internal readonly IWebElement? _inputLotNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='mfgDate']")]
        internal readonly IWebElement? _inputLotMfgDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='expDate']")]
        internal readonly IWebElement? _inputLotExpDate = null;

        //Part Serial Entry
        [FindsBy(How = How.XPath, Using = "//iframe[@name='SerialEntryFrame']")]
        internal readonly IWebElement? _frameSerialEntry = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='SerialEntryTable']/tbody")]
        internal readonly IWebElement? _tableSerialEntry = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SerialNo$new_0']")]
        internal readonly IWebElement? _inputSerialNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='mfgDate$new_0']")]
        internal readonly IWebElement? _inputSnMfgDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='expDate$new_0']")]
        internal readonly IWebElement? _inputSnExpDate = null;
        
        [FindsBy(How = How.XPath, Using = "//table[@id='PartRcvNegTable']")]
        internal readonly IWebElement? _tablePartRcvNeg = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PartNo3$new_0']")]
        internal readonly IWebElement? _inputPartNo3New = null;

        //Serial Number Generation
        [FindsBy(How = How.XPath, Using = "//input[@id='sLength']")]
        internal readonly IWebElement? _inputSerialNumberLength = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='prefix']")]
        internal readonly IWebElement? _inputPrefix = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='sufix']")]
        internal readonly IWebElement? _inputSuffix = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='startNo']")]
        internal readonly IWebElement? _inputStartingNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='smfgDate']")]
        internal readonly IWebElement? _inputSMfgDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='emfgDate']")]
        internal readonly IWebElement? _inputSExpDate = null;


        public IWebElement? _PartNO(int i) => Driver.FindElement(By.Id($"PartNo$new_{i}"));
        public IWebElement? _PartQuantity(int i) => Driver.FindElement(By.Id($"quantity$new_{i}"));
    }
}
