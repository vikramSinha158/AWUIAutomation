﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Parts
{
    internal class PartReturnPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public PartReturnPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//select[@name='issueTo']")]
        internal readonly IWebElement? _returnTo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='issueNum']")]
        internal readonly IWebElement? _issueNum = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='proNumber']")]
        internal readonly IWebElement? _proNumber = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='transDtTo']")]
        internal readonly IWebElement? _transDtTo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='CustEmpNo']")]
        internal readonly IWebElement? _custEmpNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='Retrieve']")]
        internal readonly IWebElement? _retrieve = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PartReturnFrame']")]
        internal readonly IWebElement? _partReturnFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartReturnTable']")]
        internal readonly IWebElement? _partReturnTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartReturnTable']//tbody//tr")]
        internal IList<IWebElement>? _partReturnTableRows = null;
    }
}
