﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Units
{
    internal class UnitCopyPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public UnitCopyPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        public static string _newUnitNo { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='UnitNo']")]
        internal readonly IWebElement? _inputUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Ctr']")]
        internal readonly IWebElement? _inputNoOfCopies = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NewUnitNo']")]
        internal readonly IWebElement? _inputNewUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='NewButton']")]
        internal readonly IWebElement? _buttonAddNew = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='copyUnitDesc']")]
        internal readonly IWebElement? _checkboxCopyUnitDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='copyUnitPurchPrice']")]
        internal readonly IWebElement? _checkboxCopyUnitPurchPrice = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='copyAttachments']")]
        internal readonly IWebElement? _checkboxCopyAttachments = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='copyCustomer']")]
        internal readonly IWebElement? _checkboxCopyCustomer = null;
    }
}
