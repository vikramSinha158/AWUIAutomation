﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Units
{
    internal class UnitRequestPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public UnitRequestPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        public string _unitRequestNumber { get; set; }

        public string _unitNumber { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='RequestNo']")]
        internal readonly IWebElement? _inputRequestNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='newReq']")]
        internal readonly IWebElement? _buttonNewRequest = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Status']")]
        internal readonly IWebElement? _selectStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='StatusDate']")]
        internal readonly IWebElement? _inputStatusDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UnitNo']")]
        internal readonly IWebElement? _inputUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='newUnit']")]
        internal readonly IWebElement? _buttonNewUnit = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='ReqType']")]
        internal readonly IWebElement? _selectReqType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Requestor']")]
        internal readonly IWebElement? _inputRequestor = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Ownership']")]
        internal readonly IWebElement? _selectOwnership = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DeliveryDt']")]
        internal readonly IWebElement? _inputDeliveryDt = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='LeaseType']")]
        internal readonly IWebElement? _inputLeaseType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='btnReOpen']")]
        internal readonly IWebElement? _buttonReopen = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Approver']")]
        internal readonly IWebElement? _inputApprover = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='btnReject']")]
        internal readonly IWebElement? _buttonReject = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='RejectRsn']")]
        internal readonly IWebElement? _inputRejectReason = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='btnApprove']")]
        internal readonly IWebElement? _buttonApprove = null;

        //Detail tab
        [FindsBy(How = How.XPath, Using = "//input[@id='ReplUnit']")]
        internal readonly IWebElement? _inputReplacesUnit = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='DIS_STATUS_CD']")]
        internal readonly IWebElement? _selectDisposalStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='OwnerDept']")]
        internal readonly IWebElement? _inputOwnerDept = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EST_DIS_DT']")]
        internal readonly IWebElement? _inputEstimatedDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UsingDept']")]
        internal readonly IWebElement? _inputUsingDept = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DISPOSAL_REASON']")]
        internal readonly IWebElement? _inputDisposalReason = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PARKING_LOC']")]
        internal readonly IWebElement? _inputParkingLoc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='empNo']")]
        internal readonly IWebElement? _inputEmployee = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MaintLoc']")]
        internal readonly IWebElement? _inputMaintLoc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='FuelLoc']")]
        internal readonly IWebElement? _inputFuelLoc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DelLoc']")]
        internal readonly IWebElement? _inputDelLoc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ACT_CODE']")]
        internal readonly IWebElement? _inputActivity = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SPEC_NO']")]
        internal readonly IWebElement? _inputTechSpec = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Mcc']")]
        internal readonly IWebElement? _inputMcc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Operator']")]
        internal readonly IWebElement? _inputOperator = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@id='Note']")]
        internal readonly IWebElement? _inputNote = null;

        //Category Options tab
        [FindsBy(How = How.XPath, Using = "//input[@id='CateCode']")]
        internal readonly IWebElement? _inputCategoryCode = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='NewUnitFrame']")]
        internal IWebElement? _frameNewUnit = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='CateOpTable']//tbody")]
        internal IWebElement? _tableOptionSelection = null;


        //Class tab
        [FindsBy(How = How.XPath, Using = "//input[@id='CLASS1']")]
        internal readonly IWebElement? _inputClass1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CLASS2']")]
        internal readonly IWebElement? _inputClass2 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CLASS3']")]
        internal readonly IWebElement? _inputClass3 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CLASS4']")]
        internal readonly IWebElement? _inputClass4 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CLASS5']")]
        internal readonly IWebElement? _inputClass5 = null;
    }
}
