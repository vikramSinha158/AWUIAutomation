﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Units
{
    internal class UnitDisposalPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new(Driver);

        public UnitDisposalPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='DispUnitNo']")]
        internal readonly IWebElement? _inputUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='STATUS']")]
        internal readonly IWebElement? _inputStatus = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='DIS_STATUS_CD']")]
        internal readonly IWebElement? _selectDisposalStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DISPOSAL_REASON']")]
        internal readonly IWebElement? _inputDisposalReason = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='DISPOSAL_CAUSE']")]
        internal readonly IWebElement? _selectDisposalCause = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EST_DIS_DT']")]
        internal readonly IWebElement? _inputEstimatedDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DIS_AUTH_NO']")]
        internal readonly IWebElement? _authorizedby = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='empNo']")]
        internal readonly IWebElement? _empNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='REPLUNIT']")]
        internal readonly IWebElement? _replacementUnit = null;

        //Billing Information
        [FindsBy(How = How.XPath, Using = "//input[@id='NEW_BILL_CODE']")]
        internal readonly IWebElement? _newBillingCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NEW_EFF_DT']")]
        internal readonly IWebElement? _newEffectiveDatet = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@id='NOTES']")]
        internal readonly IWebElement? _notes = null;

        //Sale Info Tab
        [FindsBy(How = How.XPath, Using = "//input[@id='UNIT_DIS_DT']")]
        internal readonly IWebElement? _inputDisposalDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DIS_REF_NO']")]
        internal readonly IWebElement? _referenceNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DIS_REF_DT']")]
        internal readonly IWebElement? _referenceDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DISPOSAL_TO']")]
        internal readonly IWebElement? _disposalTo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PICK_UP_DT']")]
        internal readonly IWebElement? _pickupDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SIGNED_RELEASE_DT']")]
        internal readonly IWebElement? _signedReleaseDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DRIVER_LIC_REC_DT']")]
        internal readonly IWebElement? _driverLicenseReceivedDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SALE_AGREE_DT']")]
        internal readonly IWebElement? _saleAgreementDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SOLD_BY_EMP']")]
        internal readonly IWebElement? _soldBy = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='FINANCIER']")]
        internal readonly IWebElement? _financier = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='RECEIVED_BY']")]
        internal readonly IWebElement? _cashReceivedBy = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PAID_DT']")]
        internal readonly IWebElement? _paidDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CHK_ISSUE_BANK']")]
        internal readonly IWebElement? _bankIssuingCheck = null;

        //Sale Values
        [FindsBy(How = How.XPath, Using = "//input[@id='STORAGE_FEES']")]
        internal readonly IWebElement? _storageFees = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='OTHER_PROCEEDS']")]
        internal readonly IWebElement? _otherProceeds = null;

        //Pre Sale  Tab
        [FindsBy(How = How.XPath, Using = "//input[@id='DROP_DT']")]
        internal readonly IWebElement? _dropDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DROP_LOC']")]
        internal readonly IWebElement? _dropLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DROP_AUC_DT']")]
        internal readonly IWebElement? _dropAuctionDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DROP_AUC_LOC']")]
        internal readonly IWebElement? _dropAuctionLocation = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='SALES_CLASS']")]
        internal readonly IWebElement? _salesClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SALE_READY_DT']")]
        internal readonly IWebElement? _saleReadyDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ON_HOLD_FL']")]
        internal readonly IWebElement? _onHold = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='RETURNING_TIRES_FL']")]
        internal readonly IWebElement? _returningTires = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TIRES_RETURNED_FL']")]
        internal readonly IWebElement? _tiresReturned = null;
    }
}

