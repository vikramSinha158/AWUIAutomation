﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Units
{
    internal class NonCompanyUnitMainPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public NonCompanyUnitMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='NcvNo']")]
        internal IWebElement? _inputNCUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='STATUS']")]
        internal IWebElement? _selectNCUStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='STATUS_CHG_DT']")]
        internal IWebElement? _inputNCUStatusChangeDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='VEH_DESC']")]
        internal IWebElement? _inputNCUDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NCV_Year']")]
        internal IWebElement? _inputNCUYear = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NCV_MANF']")]
        internal IWebElement? _inputNCUManufacturer = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NCV_MAKE']")]
        internal IWebElement? _inputNCUMake = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NCV_MODEL']")]
        internal IWebElement? _inputNCUModel = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CategoryNo']")]
        internal IWebElement? _inputNCUCategoryNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CategoryDesc']")]
        internal IWebElement? _inputNCUCategoryDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='GPW']")]
        internal IWebElement? _inputNCUGPW = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='METER']")]
        internal IWebElement? _inputNCUMeter = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='METER_DATE']")]
        internal IWebElement? _inputNCUMeterDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UsingDept']")]
        internal IWebElement? _inputNCUUsingDept = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UsingDeptDesc']")]
        internal IWebElement? _inputNCUUsingDeptDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PARKING_LOC']")]
        internal IWebElement? _inputNCUParkingLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ParkLocDesc']")]
        internal IWebElement? _inputNCUParkingLocationDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='LICENCE_CLASS']")]
        internal IWebElement? _inputNCULicenseClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CLASS_NAME']")]
        internal IWebElement? _inputNCULicenseClassName = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='cboVehLicCat']")]
        internal IWebElement? _selectNCULicenseCategory = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Color']")]
        internal IWebElement? _inputNCUColor = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Seating_Cap']")]
        internal IWebElement? _inputNCUSeatingCap = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NcvFuelProd']")]
        internal IWebElement? _inputNCUFuelProduct = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='FuelName']")]
        internal IWebElement? _inputNCUFuelName = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='VEH_REF']")]
        internal IWebElement? _inputNCUVehicleRef = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='VEH_OWNER']")]
        internal IWebElement? _inputNCUVehicleOwner = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='udcsel']")]
        internal IWebElement? _selectNCUDriverType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DRIVER_NO']")]
        internal IWebElement? _inputNCUDriverNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DRIVER_NAMERO']")]
        internal IWebElement? _inputNCUDriverDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='REG_REFNO']")]
        internal IWebElement? _inputNCURegistrationRef = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='REG_DTEXP']")]
        internal IWebElement? _inputNCURegExpiry = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='INSP_CERTNO']")]
        internal IWebElement? _inputNCUInspectionCert = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='INSP_DTEXP']")]
        internal IWebElement? _inputNCUInspExpiry = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='INSP_REF']")]
        internal IWebElement? _inputNCUInspectionRef = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SERV_REFNO']")]
        internal IWebElement? _inputNCUServiceRef = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SERV_DTLAST']")]
        internal IWebElement? _inputNCULastServiceDt = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SERV_DTDUE']")]
        internal IWebElement? _inputNCUServiceDueDt = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='INS_COMPNAME']")]
        internal IWebElement? _inputNCUInsuranceCo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='INS_POLNO']")]
        internal IWebElement? _inputNCUInsurancePolicy = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='INS_REFNO']")]
        internal IWebElement? _inputNCUInsuranceRef = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='INS_DTEXP']")]
        internal IWebElement? _inputNCUInsuranceExpiry = null;
    }
}
