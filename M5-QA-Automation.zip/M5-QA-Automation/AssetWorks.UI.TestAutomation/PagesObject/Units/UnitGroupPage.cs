﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;
using System.Collections.Generic;
using System;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Units
{
    internal class UnitGroupPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        internal IWebElement? _leadCheckbox = null;
        internal IWebElement? _unitNo = null;
        internal string _groupUnitName = "GroupUnitNo$new_";
        internal string _leadUnitName = "LeadUnitFl$new_";
        internal string _unitGroupHeader = "Unit No";
        internal string _groupUnitNoId = "GroupUnitNo";
        internal string _leadUnitId = "LeadUnitFl";


        public UnitGroupPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        public string _unitGroupNo = String.Empty;

        public string _unitGroupNoStatus = "Not Available";

        [FindsBy(How = How.XPath, Using = "//input[@id='UnitGroupNo']")]
        internal IWebElement? _inputGroupNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='AvlStatusFl']")]
        internal IWebElement? _inputStatus = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='GroupUnitsFrame']")]
        internal IWebElement? _frameGroupUnits = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='GroupUnitNo$new_0']")]
        internal IWebElement? _inputNewUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='GroupUnitsTable']//tbody//tr//td[@col='0']")]
        internal IList<IWebElement>? _groupUntNoList = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='GroupUnitsTable']")]
        internal IWebElement? _groupUntTable = null;
               
        [FindsBy(How = How.XPath, Using = "//table[@id='GroupUnitsTable']//tr//td[1]/input")]
        internal readonly IWebElement? _inputUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='GroupUnitsTable']//tbody//tr[1]//td[@col='0']/input")]
        internal IWebElement? _unitNoInUnitGroupRow1 = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='GroupUnitsTable']//tbody//tr[2]//td[@col='0']/input")]
        internal IWebElement? _unitNoInUnitGroupRow2 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='LeadUnitFl$new_0']")]
        internal IWebElement? _unitNoCheckbox1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='LeadUnitFl$new_1']")]
        internal IWebElement? _unitNoCheckbox2 = null;

        [FindsBy(How = How.XPath, Using = "//span[@class='errorHeader']")]
        internal IWebElement? _ErrorMessage1 = null;

        [FindsBy(How = How.XPath, Using = "//span[@class='errorCriticalText']")]
        internal IWebElement? _ErrorMessage2 = null;
        
    }
}
