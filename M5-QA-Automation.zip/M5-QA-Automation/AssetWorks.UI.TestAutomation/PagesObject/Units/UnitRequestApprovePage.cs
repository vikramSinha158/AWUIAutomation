﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Units
{
    internal class UnitRequestApprovePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public UnitRequestApprovePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='Parkloc']")]
        internal readonly IWebElement? _URAParking = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='AppMaintloc']")]
        internal readonly IWebElement? _URAMaintenance = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='AppUsingDept']")]
        internal readonly IWebElement? _URAUsing = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='OwnDept']")]
        internal readonly IWebElement? _URAOwning = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Requestor']")]
        internal readonly IWebElement? _URARequestor = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='Retrieve']")]
        internal readonly IWebElement? _buttonRetrieve = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='UnitReqAppFrame']")]
        internal readonly IWebElement? _URATableframe = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='UnitRequestTable']//tbody")]
        internal readonly IWebElement? _URATable = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='closeC2Btn']")]
        internal readonly IWebElement? _buttonClose = null;

    }
}
