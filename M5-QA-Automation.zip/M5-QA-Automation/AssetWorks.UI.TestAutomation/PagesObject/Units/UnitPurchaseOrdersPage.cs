﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Units
{
    internal class UnitPurchaseOrdersPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public UnitPurchaseOrdersPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='UnitAcquisitionNo']")]
        internal IWebElement? _inputPurchaseOrderNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UnitAcquisitionDesc']")]
        internal IWebElement? _inputPurchaseOrderDesc = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='UnitAcquisitionStatus']")]
        internal IWebElement? _selectPurchaseOrderStatus = null;

        //Detail tab
        [FindsBy(How = How.XPath, Using = "//input[@id='VenNumber']")]
        internal IWebElement? _inputVendorNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='VenName']")]
        internal IWebElement? _inputVendorName = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TenderNo']")]
        internal IWebElement? _inputTenderNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Address']")]
        internal IWebElement? _inputAddress = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='txtPhone']")]
        internal IWebElement? _inputPhoneNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='txtPhoneEx']")]
        internal IWebElement? _inputPhoneEx = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='City']")]
        internal IWebElement? _inputCity = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='State']")]
        internal IWebElement? _inputState = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PurchaseDo']")]
        internal IWebElement? _inputPurchaseOrderLimit = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Spec_No']")]
        internal IWebElement? _inputTechSpecNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Spec_Desc']")]
        internal IWebElement? _inputTechSpecDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Creation']")]
        internal IWebElement? _inputCreation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Expiration']")]
        internal IWebElement? _inputExpiration = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@id='Note']")]
        internal IWebElement? _inputNotes = null;

        //Units Tab
        [FindsBy(How = How.XPath, Using = "//iframe[@name='UnitAcquisitionFrame']")]
        internal IWebElement? _frameUnits = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='productTable']/tbody")]
        internal IWebElement? _tableUnits = null;

        //Payment Tab
        [FindsBy(How = How.XPath, Using = "//iframe[@name='UnitPOPaymentFrame']")]
        internal IWebElement? _framePayment = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='paymentTable']/tbody")]
        internal IWebElement? _tablePayment = null;

        //Non-Unit Charges Tab
        [FindsBy(How = How.XPath, Using = "//iframe[@name='NonUnitChargeFrame']")]
        internal IWebElement? _frameCharges = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='nonUnitChgTable']/tbody")]
        internal IWebElement? _tableCharges = null;
    }
}
