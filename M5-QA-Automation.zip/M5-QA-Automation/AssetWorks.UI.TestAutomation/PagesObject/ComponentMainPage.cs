﻿using AssetWorks.UI.Core.Base;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.Core.Extensions;
using System.Threading;
using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class ComponentMainPage : BasePage
    {
        internal string _serialNumber = String.Empty;
        internal string _billNumber = String.Empty;
        internal ComponentMain? _comp = null;
        internal string _serviceDateValue = String.Empty;
        internal string _primaryMeterValue = String.Empty;
        internal string _secondaryMeterValue = String.Empty;
        internal string _componentNotesValue = String.Empty;
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public ComponentMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }      

        [FindsBy(How = How.XPath, Using = "//input[@id='CompNo']")]
        internal readonly IWebElement? _componentInput =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='COMP_DESC']")]
        internal readonly IWebElement? _componentDesc =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SPEC_NO']")]
        internal readonly IWebElement? _componenTechSpec =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SYS_CODE']")]
        internal readonly IWebElement? _systemCode =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PARKING_LOC']")]
        internal readonly IWebElement? _locationCode =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='COMPONENT']")]
        internal readonly IWebElement? _assemblyCode =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MCC']")]
        internal readonly IWebElement? _mcc =null;

        [FindsBy(How = How.XPath, Using = "//input[@name='SERIAL_NO']")]
        internal readonly IWebElement? _serialNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='BIN']")]
        internal readonly IWebElement? _binNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='MAINT_LOC']")]
        internal readonly IWebElement? _maintLoc = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='PartNo']")]
        internal readonly IWebElement? _partNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='OWNING_DEPT']")]
        internal readonly IWebElement? _owningDept = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='IN_SERV_DT']")]
        internal readonly IWebElement? _serviceDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='IN_SERV_METER']")]
        internal readonly IWebElement? _primaryMeter = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='IN_SERV_METER2']")]
        internal readonly IWebElement? _secondaryMeter = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='NOTES']")]
        internal readonly IWebElement? _componentNotes = null;


    }
}
