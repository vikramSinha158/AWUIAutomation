﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Disposal
{
    internal class DisposalReasonPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        public DisposalReasonPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }
        [FindsBy(How = How.XPath, Using = "//input[@name='disposal$new_0']")]
        internal readonly IWebElement? _dispoalReason = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='desc$new_0']")]
        internal readonly IWebElement? _discription= null;

        [FindsBy(How = How.XPath, Using = "//input[@name='disabled$new_0']")]
        internal readonly IWebElement? _disabledCheckbox = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='DisposalFrame']")]
        internal readonly IWebElement? _iframeDisposal = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DisposalTable']")]
        internal readonly IWebElement? _tableDisposal = null;
    }
}
