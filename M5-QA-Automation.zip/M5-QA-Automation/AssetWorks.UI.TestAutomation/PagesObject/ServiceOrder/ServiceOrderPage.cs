﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.ServiceOrder
{
    internal class ServiceOrderPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ServiceOrderPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='pono']")]
        internal readonly IWebElement? _inputPoNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='newPo']")]
        internal readonly IWebElement? _buttonNewPo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='poRefNo']")]
        internal readonly IWebElement? _inputPoRefNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='vendor']")]
        internal readonly IWebElement? _inputVendorNo = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ServicePOMaintFrame']")]
        internal IWebElement? _frameServicePO = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='ServicePOTable']/tbody")]
        internal IWebElement? _tableServicePO = null;
    }
}
