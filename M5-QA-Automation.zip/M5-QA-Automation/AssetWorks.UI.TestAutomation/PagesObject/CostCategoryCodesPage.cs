﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class CostCategoryCodesPage : BasePage
    {
        public CostCategoryCodesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        internal ExtendedPageActions ExtendedPage => new(Driver);

        [FindsBy(How = How.XPath, Using = "//iframe[@name='CostCatCodesFrame']")]
        internal IWebElement? _frameCostCatCodes = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='CostCatCodesTable']/tbody")]
        internal IWebElement? _tableCostCatCodes = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='COST_CAT_CODE$new_0']")]
        internal IWebElement? _inputCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DESCRIPTION$new_0']")]
        internal IWebElement? _inputDescription = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DISABLED_FL$new_0']")]
        internal IWebElement? _checkboxDisabled = null;
    }
}
