﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Zone
{
    internal class ZoneChargeQueryPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public ZoneChargeQueryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='queryZone']")]
        internal readonly IWebElement? _queryZone = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ZoneChargeQueryFrame']")]
        internal IWebElement? _zoneChargeQueryFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='ZoneChargeQueryTable']")]
        internal IWebElement? _zoneChargeQueryTable = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UnitNo']")]
        internal readonly IWebElement? _unitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='RespDeptNo']")]
        internal readonly IWebElement? _respDeptNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ChargeCode']")]
        internal readonly IWebElement? _chargeCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AssetClass']")]
        internal readonly IWebElement? _assetClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AssetCategory']")]
        internal readonly IWebElement? _assetCategory = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='LicenseClass']")]
        internal readonly IWebElement? _licenseClass = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='PriProdType']")]
        internal readonly IWebElement? _priProdType = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='SecProdType']")]
        internal readonly IWebElement? _secProdType = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Class1']")]
        internal readonly IWebElement? _class1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Class2']")]
        internal readonly IWebElement? _class2 = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Class3']")]
        internal readonly IWebElement? _class3 = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Class4']")]
        internal readonly IWebElement? _class4 = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Class5']")]
        internal readonly IWebElement? _class5 = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='VisionRating']")]
        internal readonly IWebElement? _VisionRating = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='EmissionsRating']")]
        internal readonly IWebElement? _emissionsRating = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='CO']")]
        internal readonly IWebElement? _co = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='NOX']")]
        internal readonly IWebElement? _nox = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='PM']")]
        internal readonly IWebElement? _pm= null;

        [FindsBy(How = How.XPath, Using = "//input[@name='MaxRange']")]
        internal readonly IWebElement? _maxRange = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='BatteryRange']")]
        internal readonly IWebElement? _batteryRange = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='CompliantYear']")]
        internal readonly IWebElement? _compliantYear = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='Retrieve']")]
        internal readonly IWebElement? _retrieve = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='Clear']")]
        internal readonly IWebElement? _clear= null;

        [FindsBy(How = How.XPath, Using = "//input[@name='FromChgDate']")]
        internal readonly IWebElement? _fromChgDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ToChgDate']")]
        internal readonly IWebElement? _toChgDate = null;


    }
}
