﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Zone
{
    internal class ZoneClassMaintenancePage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public ZoneClassMaintenancePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='zoneClass']")]
        internal readonly IWebElement? _zoneClass = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ZACLASSFrame']")]
        internal IWebElement? _zoneCLASSFrame = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='CatClassListLeft']")]
        internal IWebElement? _catClassListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='CatClassListRight']")]
        internal IWebElement? _catClassListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='CatClassListMoveRight']")]
        internal IWebElement? _catClassListMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='CatClassListMoveLeft']")]
        internal IWebElement? _catClassListMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ZONECATEGORYFrame']")]
        internal IWebElement? _zoneCategoryFrame = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='CategoryListLeft']")]
        internal IWebElement? _categoryListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='CategoryListRight']")]
        internal IWebElement? _categoryListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='CategoryListMoveRight']")]
        internal IWebElement? _categoryListMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='CategoryListMoveLeft']")]
        internal IWebElement? _categoryListMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='ZoneClassTable']")]
        internal IWebElement? _zoneClassTable = null;
    }
}
