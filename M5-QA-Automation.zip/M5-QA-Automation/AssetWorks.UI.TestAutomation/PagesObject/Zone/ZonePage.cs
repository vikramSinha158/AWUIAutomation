﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Zone
{
    internal class ZonePage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public ZonePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='zone']")]
        internal readonly IWebElement? _zone = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='description']")]
        internal readonly IWebElement? _description = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='department']")]
        internal readonly IWebElement? _department = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='location']")]
        internal readonly IWebElement? _location = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='zonesFrame']")]
        internal IWebElement? _zoneFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='zonesTable']")]
        internal IWebElement? _zonesTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='zonesUnitFrame']")]
        internal IWebElement? _zonesUnitFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='zonesUnitTable']")]
        internal IWebElement? _zonesUnitTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='zonesChargeFrame']")]
        internal IWebElement? _zonesChargeFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='zonesChargeTable']")]
        internal IWebElement? _zonesChargeTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='zonesUnitTable']//tbody//tr")]
        internal IList<IWebElement>? _zonesUnitTableRows = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='zonesChargeTable']//tbody//tr")]
        internal IList<IWebElement>? _zonesChargeTableRows = null;
    }
}
