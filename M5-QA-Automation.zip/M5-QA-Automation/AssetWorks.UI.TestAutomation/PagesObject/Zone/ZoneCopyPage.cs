﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Zone
{
    internal class ZoneCopyPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public ZoneCopyPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='zone']")]
        internal readonly IWebElement? _zone = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='newZone']")]
        internal readonly IWebElement? _newZone = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='newZoneDesc']")]
        internal readonly IWebElement? _newZoneDesc = null;
    }
}
