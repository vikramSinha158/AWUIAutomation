﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;


namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class CustomerMainPage : BasePage
    {
        internal string AddressLine1 = String.Empty;
        internal string Country = String.Empty;
        internal string State = String.Empty;
        internal string City = String.Empty;
        internal string Zip = String.Empty;
        internal string OwningDept = String.Empty;
        internal string InitialJobStatus = String.Empty;
        internal string BillingFrequency = String.Empty;
        internal string CustomerType = String.Empty;
        internal string Description = String.Empty;
        public static string Status = String.Empty;
        public static string Descrption = String.Empty;

        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        public CustomerMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='Customer_No']")]
        internal readonly IWebElement? _customerMainNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Customer_Desc']")]
        internal readonly IWebElement? _customerMainDescription = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Address1']")]
        internal readonly IWebElement? _customerAddress1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='City']")]
        internal readonly IWebElement? _customerCity = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='State']")]
        internal readonly IWebElement? _customerState = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Country']")]
        internal readonly IWebElement? _customerCountry = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Zip_Code']")]
        internal readonly IWebElement? _customerZip = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Job_Status']")]
        internal readonly IWebElement? _jobStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Dept_No']")]
        internal readonly IWebElement? _owningDeptNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Email_Address']")]
        internal readonly IWebElement? _email = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='Bill_Frequency']")]
        internal readonly IWebElement? _billingFrequency = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Customer_Type']")]
        internal readonly IWebElement? _customerType = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Status']")]
        internal readonly IWebElement? _customerStatus = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='srchField']")]
        internal readonly IWebElement? _filterDropdown = null;

        [FindsBy(How = How.XPath, Using = "//input[@type='search']")]
        internal IWebElement? _searchtext = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='lovBodyTable']//tr[1]/td[1]/span")]
        internal IWebElement? _customerSearchResult = null;


    }
}
