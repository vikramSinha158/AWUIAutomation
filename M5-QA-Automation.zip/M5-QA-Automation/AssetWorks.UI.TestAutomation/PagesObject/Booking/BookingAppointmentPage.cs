﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class BookingAppointmentPage: BasePage
    {
        public static string BookingTypeCode { get; set; }
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public BookingAppointmentPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='Unit_No']")]
        internal readonly IWebElement? _unitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Unit_Desc']")]
        internal readonly IWebElement? _unitDesc = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Booking_Status']")]
        internal readonly IWebElement? _bookingStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Customer_No']")]
        internal IWebElement? _customerNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Customer_Desc']")]
        internal IWebElement? _customerDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Alt_Unit_No']")]
        internal IWebElement? _altUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Booking_No']")]
        internal IWebElement? _BookingNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='button1']")]
        internal IWebElement? _newBooking = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Location_No']")]
        internal IWebElement? _location = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='equipProfile']")]
        internal IWebElement? _equipProfile = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Booking_Ref']")]
        internal IWebElement? _bookingRef = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Booking_Source']")]
        internal IWebElement? _bookingSource = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Cancelled_Reason']")]
        internal IWebElement? _cancelledReason = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Booking_Type']")]
        internal IWebElement? _bookingType = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Declined_Reason']")]
        internal IWebElement? _declinedReason = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Caller_Name']")]
        internal IWebElement? _callerName = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Caller_Phone']")]
        internal IWebElement? _callerPhone = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Caller_Email']")]
        internal IWebElement? _callerEmail = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Genuine_Prt']")]
        internal IWebElement? _genuinePrt = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Request_Dt1']")]
        internal IWebElement? _requestDt1 = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='Request_Prd1']")]
        internal IWebElement? _requestPrd1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Booking_Date']")]
        internal IWebElement? _bookingDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Booking_Prd']")]
        internal IWebElement? _bookingPrd = null;

        [FindsBy(How = How.XPath, Using = "//table[@name='mrTable8']")]
        internal IWebElement? _jobInfoTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='mrDataFrame8']")]
        internal IWebElement? _jobInfoFrame = null;
    }
}
