﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class CustomerTypeCodesPage : BasePage
    {       
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public CustomerTypeCodesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='CUSTOMER_TYPE$new_0']")]
        internal readonly IWebElement? _customerTypeCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DESCRIPTION$new_0']")]
        internal readonly IWebElement? _customerTypeDescription = null; 
    
        [FindsBy(How = How.XPath, Using = "//table[@id='CustomerTypeTable']")]
        internal readonly IWebElement? _customerCodeTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='CustomerTypeFrame']")]
        internal IWebElement? _frameCustomerTypeCodes = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DISABLED_FL$new_0']")]
        internal IWebElement? _DisableCheckboxCustomer = null;
    }
}
