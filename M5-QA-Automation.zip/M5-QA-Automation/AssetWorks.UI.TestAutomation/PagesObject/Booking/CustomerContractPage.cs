﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class CustomerContractPage : BasePage
    {
     
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        public CustomerContractPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }
        [FindsBy(How = How.XPath, Using = "//input[@name='Contract_No']")]
        internal readonly IWebElement? _contractNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='button1']")]
        internal readonly IWebElement? _newContract = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Customer_No']")]
        internal readonly IWebElement? _custNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='NewCustomer_No']")]
        internal readonly IWebElement? _newCustNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Customer_Desc']")]
        internal readonly IWebElement? _custDescription = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='Status']")]
        internal readonly IWebElement? _status = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Status_Date']")]
        internal readonly IWebElement? _statusDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Start_Date']")]
        internal readonly IWebElement? _startDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ContractStart']")]
        internal readonly IWebElement? _startDateContract = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Award_Date']")]
        internal readonly IWebElement? _awardDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Award_Amount']")]
        internal readonly IWebElement? _awardAmount = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='FixedPriceJobTable']")]
        internal readonly IWebElement? _tableJob = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='FixedPriceJob']")]
        internal readonly IWebElement? _frameJob = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Job$new_0']")]
        internal readonly IWebElement? _newJob = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Job_Desc$0']")]
        internal readonly IWebElement? _newJobDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Job_Fixed_Price$new_0']")]
        internal readonly IWebElement? _newFixedPrice = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartMatrixTable']")]
        internal readonly IWebElement? _tablePartsMatrix = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PartMatrixFrame']")]
        internal readonly IWebElement? _framePartsMatrix = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='mfg$0']")]
        internal readonly IWebElement? _manufacturer = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='vendor$0']")]
        internal readonly IWebElement? _vendor = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='system$0']")]
        internal readonly IWebElement? _systemCodes = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='LaborMatrixTable']")]
        internal readonly IWebElement? _tableLaborMatrix = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='LaborMatrixFrame']")]
        internal readonly IWebElement? _frameLaborMatrix = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='location$0']")]
        internal readonly IWebElement? _location = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='assetClass$0']")]
        internal readonly IWebElement? _assetClass = null;
       
        [FindsBy(How = How.XPath, Using = "//iframe[@name='FluidMatrixFrame']")]
        internal readonly IWebElement? _frameFluidMatrix = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='FluidMatrixTable']")]
        internal readonly IWebElement? _tableFluidMatrix = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='product_no$0']")]
        internal readonly IWebElement? _product = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='prod_Desc$0']")]
        internal readonly IWebElement? _productdesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='fMarkupPct$0']")]
        internal readonly IWebElement? _markup = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='FixedPricePart']")]
        internal readonly IWebElement? _frameFixedPricePart = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='FixedPricePartTable']")]
        internal readonly IWebElement? _tableFixedPricePart = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Part_No$0']")]
        internal readonly IWebElement? _part = null;       

        [FindsBy(How = How.XPath, Using = " //textarea[@id='Notes']")]
        internal readonly IWebElement? _contractNotes = null;
        
        [FindsBy(How = How.XPath, Using = " //textarea[@id='Booking_Notes']")]
        internal readonly IWebElement? _bookingNotes = null;
    }
}
