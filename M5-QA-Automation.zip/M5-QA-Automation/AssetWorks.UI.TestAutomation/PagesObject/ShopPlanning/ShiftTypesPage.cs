﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.ShopPlanning
{
    internal class ShiftTypesPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public ShiftTypesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='SchedShiftsFrame']")]
        internal IWebElement? _schedShiftsFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='SchedShiftTable']")]
        internal IWebElement? _schedShiftTable = null;
    }
}
