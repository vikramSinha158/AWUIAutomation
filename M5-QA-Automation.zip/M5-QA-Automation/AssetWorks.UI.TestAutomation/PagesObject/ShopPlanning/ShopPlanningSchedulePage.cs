﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.ShopPlanning
{
    internal class ShopPlanningSchedulePage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public ShopPlanningSchedulePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='loc']")]
        internal IWebElement? _location = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PlanScheduleFrame']")]
        internal IWebElement? _planScheduleFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PlanScheduleTable']")]
        internal IWebElement? _planScheduleTable = null;
    
    }
}
