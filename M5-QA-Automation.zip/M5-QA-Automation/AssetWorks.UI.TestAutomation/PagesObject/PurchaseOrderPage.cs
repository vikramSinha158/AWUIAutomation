﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class PurchaseOrderPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public PurchaseOrderPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//button[@id='newPo']")]
        internal readonly IWebElement? _newPO = null;

        [FindsBy(How = How.XPath, Using = " //input[@name='vendor']")]
        internal readonly IWebElement? _vendorNumber = null;
       
        [FindsBy(How = How.XPath, Using = "//input[@name='poRefNo']")]
        internal readonly IWebElement? _poRefNo = null;

        [FindsBy(How = How.XPath, Using = " //input[@name='pono']")]
        internal readonly IWebElement? _poNO = null;

        [FindsBy(How = How.XPath, Using = " //select[@id='poStatus']")]
        internal readonly IWebElement? _selectStatus = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='POMaintFrame']")]
        internal readonly IWebElement? _framePO = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartTable']")]
        internal readonly IWebElement? _tablePart = null;

        internal IWebElement? _inputNewPartNo(string row) => Driver.FindElement(By.XPath($"//input[@id='POPartNo$new_{row}']"));

        [FindsBy(How = How.XPath, Using = "//iframe[@name='POMaintVendReqFrame']")]
        internal readonly IWebElement? _vendorReqFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='POMaintVendReqTable']")]
        internal readonly IWebElement? _vendorReqsTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='POMaintReqFrame']")]
        internal readonly IWebElement? _getOtherReqFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='POMaintReqTable']")]
        internal readonly IWebElement? _getOtherReqTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='RequestListTable']")]
        internal readonly IWebElement? _requestListTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PartRequestListFrame']")]
        internal readonly IWebElement? _partRequestListFrame = null;

        //Shipping Address Distributor
        [FindsBy(How = How.XPath, Using = "//input[@name='shippingName']")]
        internal readonly IWebElement? _shippingName = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='shippingAddr1']")]
        internal readonly IWebElement? _shippingAddress1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='shippingAddr2']")]
        internal readonly IWebElement? _shippingAddress2 = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='shippingCity']")]
        internal readonly IWebElement? _shippingCity = null;
  
        [FindsBy(How = How.XPath, Using = "//input[@name='shippingState']")]
        internal readonly IWebElement? _shippingState = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='shippingCountry']")]
        internal readonly IWebElement? _shippingCountry = null;
       
        [FindsBy(How = How.XPath, Using = "//input[@name='shippingContact']")]
        internal readonly IWebElement? _shippingContact = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='shippingPhone']")]
        internal readonly IWebElement? _shippingPhone = null;
        
        [FindsBy(How = How.XPath, Using = "//textarea[@name='shippingNotes']")]
        internal readonly IWebElement? _shippingNotes = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='dist']")]
        internal readonly IWebElement? _distName = null;
      
        [FindsBy(How = How.XPath, Using = "//textarea[@name='Notes']")]
        internal readonly IWebElement? _poNotes = null;

        //PO Items
        [FindsBy(How = How.XPath, Using = "//iframe[@name='POItemFrame']")]
        internal readonly IWebElement? _framePOItem = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='POItemTable']")]
        internal readonly IWebElement? _tablePOItem = null;

        internal IWebElement? _inputNewItem(string row) => Driver.FindElement(By.XPath($"//input[@id='item$new_{row}']"));
    }
}