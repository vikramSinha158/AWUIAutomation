﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class EmployeeAssignmentPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public EmployeeAssignmentPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='UnitNo']")]
        internal readonly IWebElement? _unitNoInput = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='udcsel']")]
        internal readonly IWebElement? _unitDeptCompDd = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='jobcode']")]
        internal readonly IWebElement? _jobcode = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='jobrsn']")]
        internal readonly IWebElement? _jobrsn = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='button2']")]
        internal readonly IWebElement? _retrieveBtn = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EmpAssignFrame']")]
        internal readonly IWebElement? _empAssignFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EmpAssignTable']")]
        internal readonly IWebElement? _empAssignTable = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='wonumber']")]
        internal IWebElement? _workOrderNumber = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='button1']")]
        internal readonly IWebElement? _clearBtn = null;

    }
}
