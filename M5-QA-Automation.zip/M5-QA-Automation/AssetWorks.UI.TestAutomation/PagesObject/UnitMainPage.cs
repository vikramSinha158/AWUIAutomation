﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject

{
    //This class needs some rectification
    public class UnitMainPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public UnitMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//span[text()='Action Required']")]
        internal IWebElement? _createDialog = null;

        [FindsBy(How = How.XPath, Using = "//button[text()='Create']")]
        internal IWebElement? _createButon = null;

        [FindsBy(How = How.XPath, Using = "//a[text()='Dept/Locations']")]
        internal IWebElement? _deptLocations = null;

        [FindsBy(How = How.XPath, Using = "//a[text()='Meter/Accounting']")]
        internal IWebElement? _meterAccounting = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='savebutton']")]
        internal IWebElement? _unitSaveBuuton = null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Department Information']")]
        internal IWebElement? _deptInfo = null;

        //--------------
        [FindsBy(How = How.XPath, Using = "//input[@id='UnitNo']")]
        internal IWebElement? _unitNoInput =null;

        [FindsBy(How = How.XPath, Using = "//button[@id='NewButton']")]
        internal IWebElement? _buttonAddNew = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UNITDESC']")]
        internal IWebElement? _descriptionInput =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='STATUS']")]
        internal IWebElement? _inputStatus =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='USER_UNIT_NO']")]
        internal IWebElement? _inputAlternateUnitNo = null;

        //Asset/Codes Tab
        [FindsBy(How = How.XPath, Using = "//input[@id='SERIAL_NO']")]
        internal IWebElement? _inputSerialNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MCC']")]
        internal IWebElement? _inputMCC = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ACT_CODE']")]
        internal IWebElement? _inputActivityCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SPEC_NO']")]
        internal IWebElement? _inputTechSpecNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ASSET_TYPE']")]
        internal IWebElement? _inputAssetType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EQUIPMENT_TYPE']")]
        internal IWebElement? _inputEquipmentType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='licClassCode']")]
        internal IWebElement? _inputLicenseClassCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='retroFl']")]
        internal IWebElement? _checkboxRetrofitted = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='retroDesc']")]
        internal IWebElement? _inputRetrofittedDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='BILLING_CODE']")]
        internal IWebElement? _billingCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='high_priority']")]
        internal IWebElement? _checkboxHighPriority = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TELEMATICS_FL']")]
        internal IWebElement? _checkboxTelematics = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TelMeter']")]
        internal IWebElement? _checkboxTelematicsMeter = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CALIBRATION_DT']")]
        internal IWebElement? _inputCalibrationDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CALIBRATION_EXPIR_DT']")]
        internal IWebElement? _inputCalibrationExpiresDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EQUIPMENT_CONDITION']")]
        internal IWebElement? _inputConditionCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EMPLOYEE_OWNED_FL']")]
        internal IWebElement? _checkboxEmployeeOwned = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EMP_NO']")]
        internal IWebElement? _inputEmployeeNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ATT_SERIAL_NO']")]
        internal IWebElement? _inputAttSerialNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ATT_SPEC_NO']")]
        internal IWebElement? _inputAttTechSpecNo = null;

        //Dept/Locations Tab
        [FindsBy(How = How.XPath, Using = "//input[@id='EX_CUSTNO']")]
        internal IWebElement? _inputCustomer = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='OWNER_DEPTNO']")]
        internal IWebElement? _deptOwner = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='USING_DEPTNO']")]
        internal IWebElement? _deptUsing = null;
      
        [FindsBy(How = How.XPath, Using = "//input[@id='PARKING_LOC']")]
        internal IWebElement? _parkingLoc =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MAINT_LOC']")]
        internal IWebElement? _maintLoc =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='FUELING_LOC']")]
        internal IWebElement? _fuelingLoc =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DELIVERY_LOC']")]
        internal IWebElement? _deliveryLoc =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CURRENT_LOC']")]
        internal IWebElement? _currentLoc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='BIN']")]
        internal IWebElement? _binNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='OPERATOR']")]
        internal IWebElement? _inputOperator = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MP_SHARE_POOL']")]
        internal IWebElement? _checkboxSharePool = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MP_RENTAL_CLASS']")]
        internal IWebElement? _inputMotorPoolClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MP_LOCATION']")]
        internal IWebElement? _inputMotorPoolLocation = null;

        //Class Tab
        [FindsBy(How = How.XPath, Using = "//input[@id='SHIFT_CODE1']")]
        internal IWebElement? _inputShiftCode1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SHIFT_CODE2']")]
        internal IWebElement? _inputShiftCode2 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SHIFT_CODE3']")]
        internal IWebElement? _inputShiftCode3 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SHIFT_CODE4']")]
        internal IWebElement? _inputShiftCode4 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SHIFT_CODE5']")]
        internal IWebElement? _inputShiftCode5 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CLASS1']")]
        internal IWebElement? _inputClass1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CLASS2']")]
        internal IWebElement? _inputClass2 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CLASS3']")]
        internal IWebElement? _inputClass3 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CLASS4']")]
        internal IWebElement? _inputClass4 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CLASS5']")]
        internal IWebElement? _inputClass5 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='OPER_CLASS']")]
        internal IWebElement? _inputOperationalClass = null;

        //Meter/Accounting Tab
        [FindsBy(How = How.XPath, Using = "//input[@id='ACQUIS_METER']")]
        internal IWebElement? _inputAcquisitionMeter = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ACQUIS_DT']")]
        internal IWebElement? _acquisitionDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ARRIVAL_DT']")]
        internal IWebElement? _inputAcquisitionArrivalDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='IN_SERV_METER']")]
        internal IWebElement? _inputInServiceMeter = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='IN_SERV_DT']")]
        internal IWebElement? _serviceDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MFG_DT']")]
        internal IWebElement? _inputManufactureDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MarkupScheme']")]
        internal IWebElement? _inputMarkupScheme = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PO_NUMBER']")]
        internal IWebElement? _inputPONumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PURCHASE_DO']")]
        internal IWebElement? _inputTotalPurchasePrice = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TaxExempt']")]
        internal IWebElement? _checkboxTaxExempt = null;

        //License/Notes Tab
        [FindsBy(How = How.XPath, Using = "//iframe[@name='LicPermFrame']")]
        internal IWebElement? _frameLicensePermit = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='licperm_no$new_0']")]
        internal IWebElement? _inputNewLicenseNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='VED_CLASS']")]
        internal IWebElement? _inputVEDClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TITLE_NO']")]
        internal IWebElement? _inputTitleNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ASSET_NO']")]
        internal IWebElement? _inputAssetNo = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@id='NOTES']")]
        internal IWebElement? _inputUnitNotes = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@id='WONOTES']")]
        internal IWebElement? _inputUnitWONotes = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@id='CUSTOMERNOTES']")]
        internal IWebElement? _inputCustomerNotes = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ACQUIS_METER2']")]
        internal IWebElement? _inputInSecondaryMeterAcquis = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='IN_SERV_METER2']")]
        internal IWebElement? _inputInSecondaryMeterService = null;

    }
}
