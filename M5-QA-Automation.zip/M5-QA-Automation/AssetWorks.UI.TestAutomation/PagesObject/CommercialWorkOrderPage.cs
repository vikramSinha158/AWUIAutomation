﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class CommercialWorkOrderPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public CommercialWorkOrderPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='aUnitNo']")]
        internal readonly IWebElement? _unitNoInput = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='newWO']")]
        internal readonly IWebElement? _newWOBtn = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='VISIT_REASON']")]
        internal readonly IWebElement? _visitReason = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='OPEN_DT']")]
        internal readonly IWebElement? _openDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='PROMISE_DT']")]
        internal readonly IWebElement? _dueDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='COMPLETED_DT']")]
        internal readonly IWebElement? _completeDate = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='WOCommVendFrame']")]
        internal readonly IWebElement? _wOCommVendFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='VendorTable']")]
        internal readonly IWebElement? _vendorTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='WOCommJobFrame']")]
        internal readonly IWebElement? _WOCommJobFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='JobTable']")]
        internal readonly IWebElement? _jobTable = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='wonumber']")]
        internal readonly IWebElement? _wonumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='INV_NO']")]
        internal readonly IWebElement? _invoiceNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='INV_DT']")]
        internal readonly IWebElement? _invoiceDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='aCloseDt']")]
        internal readonly IWebElement? _invoiceChangeWODate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='CLOSE_DT']")]
        internal readonly IWebElement? _coloseDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='STATUS']")]
        internal readonly IWebElement? _woStatus = null;

    }
}
