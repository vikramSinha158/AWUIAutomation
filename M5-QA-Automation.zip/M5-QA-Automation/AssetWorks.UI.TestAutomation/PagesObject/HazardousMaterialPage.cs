﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class HazardousMaterialPage : BasePage
    {
        internal ExtendedPageActions ExtendedPage => new (Driver);
        public HazardousMaterialPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='HazardCodesFrame']")]
        internal IWebElement? _frameHazardCodes = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='HazardCodesTable']/tbody")]
        internal IWebElement? _tableHazardCodes = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Hazardcode$new_0']")]
        internal IWebElement? _inputShipName = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='hazClass$new_0']")]
        internal IWebElement? _inputClassDivision = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='hazID$new_0']")]
        internal IWebElement? _inputIdNumber = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='packGrp$new_0']")]
        internal IWebElement? _selectPackGroup = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='desc$new_0']")]
        internal IWebElement? _inputDescription = null;


        // Hazardous Material Setup
        [FindsBy(How = How.XPath, Using = "//input[@id='pShiName']")]
        internal IWebElement? _inputProperShippingName = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='hazClass']")]
        internal IWebElement? _inputHazClass = null;
    }
}
