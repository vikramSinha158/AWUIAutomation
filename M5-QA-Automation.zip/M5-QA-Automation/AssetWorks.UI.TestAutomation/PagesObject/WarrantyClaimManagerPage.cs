﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class WarrantyClaimManagerPage : BasePage
    {
        internal readonly string _chargeType = "Charge\r\nType";
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public WarrantyClaimManagerPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='VenNumber']")]
        internal IWebElement? _inputVendorNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ClaimNo']")]
        internal IWebElement? _inputClaimNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='NewButton']")]
        internal IWebElement? _buttonNewClaimNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='WoNo']")]
        internal IWebElement? _inputWorkOrderNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='processEmp']")]
        internal IWebElement? _inputProcessEmp = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='warrCategory']")]
        internal IWebElement? _inputCategory = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='warrclaimSummaryFrame']")]
        internal IWebElement? _frameWarrClaimSummary = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='warrclaimSummaryTable']/tbody")]
        internal IWebElement? _tableWarrClaimSummary = null;
    }
}
