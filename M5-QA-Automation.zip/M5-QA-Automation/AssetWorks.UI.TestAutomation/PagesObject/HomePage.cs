﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class HomePage : BasePage
    {
        internal string locatorHome = "//button[contains(text(),'Home')]//span[@class='mdl-button__ripple-container']";

        public HomePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Home')]//span[@class='mdl-button__ripple-container']")]
        internal IWebElement? _homeTab =null;

        [FindsBy(How = How.XPath, Using = "//select[@id='menuReduce']")]
        internal IWebElement? _mainMain =null;

        [FindsBy(How = How.XPath, Using = "//select[@id='enteredLocation']")]
        internal IWebElement? _enteredLocation = null;

        [FindsBy(How = How.XPath, Using = "//div[@id='mvMessageArea3']/p/span")]
        internal IWebElement? _mvMessageArea = null;

    }
}
