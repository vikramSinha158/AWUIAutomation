﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class ItemMasterDefinitionPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public ItemMasterDefinitionPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//select[@id='Target']")]
        internal IWebElement? _selectTarget = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ItemMaintFrame']")]
        internal IWebElement? _frameItemMain = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='ItemMaintTable']/tbody")]
        internal IWebElement? _tableItemMain = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='item$new_0']")]
        internal IWebElement? _inputNewItem = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='field_type$new_0']")]
        internal IWebElement? _selectNewType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='mandatory_fl$new_0']")]
        internal IWebElement? _inputNewMandatory = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='validate_fl$new_0']")]
        internal IWebElement? _inputNewValidated = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='defaultval$new_0']")]
        internal IWebElement? _inputNewDefaultValue = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='disabled$new_0']")]
        internal IWebElement? _inputNewDisabled = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ItemValueFrame']")]
        internal IWebElement? _frameItemValue = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='ItemValueTable']/tbody")]
        internal IWebElement? _tableItemValue = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='itemValue$new_0']")]
        internal IWebElement? _inputNewItemValue = null;
    }
}