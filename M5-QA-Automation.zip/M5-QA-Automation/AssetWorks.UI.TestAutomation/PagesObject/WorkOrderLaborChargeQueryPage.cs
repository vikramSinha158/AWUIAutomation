﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class WorkOrderLaborChargeQueryPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public WorkOrderLaborChargeQueryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='UnitNo']")]
        internal readonly IWebElement? _unitDeptCompInput = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='udcsel']")]
        internal readonly IWebElement? _unitDeptCompDd = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='loc']")]
        internal readonly IWebElement? _location = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='jobcode']")]
        internal readonly IWebElement? _jobcode = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='wrsyscode']")]
        internal readonly IWebElement? _wrsyscode = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='position']")]
        internal readonly IWebElement? _position = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='start']")]
        internal readonly IWebElement? _startDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='end']")]
        internal readonly IWebElement? _startEnd = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='Retrieve']")]
        internal readonly IWebElement? _retrieveBtn = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='LaborInqByUnitFrame']")]
        internal readonly IWebElement? _laborInqByUnitFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='LaborInqByUnitTable']")]
        internal readonly IWebElement? _laborInqByUnitTable = null;

    }
}
