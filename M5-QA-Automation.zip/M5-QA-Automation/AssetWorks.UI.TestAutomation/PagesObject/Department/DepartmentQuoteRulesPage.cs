﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Department
{
    internal class DepartmentQuoteRulesPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public DepartmentQuoteRulesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='DeptNumber']")]
        internal IWebElement? _deptNumber = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='DeptQuoteFrame']")]
        internal IWebElement? _deptQuoteFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DeptQuoteTable']")]
        internal IWebElement? _deptQuoteTable = null;
    }
}
