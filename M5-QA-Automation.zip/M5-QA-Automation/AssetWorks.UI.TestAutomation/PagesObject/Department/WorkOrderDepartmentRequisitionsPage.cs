﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Department
{
    internal class WorkOrderDepartmentRequisitionsPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public WorkOrderDepartmentRequisitionsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//span[@class='ScreenTitle']")]
        internal readonly IWebElement? _departmentRequisitionsTitle =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ReqNo']")]
        internal readonly IWebElement? _inputRequisitionNumber =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ReqDesc']")]
        internal readonly IWebElement? _inputRequisitionDescription =null;

        [FindsBy(How = How.XPath, Using = "//select[@id='ReqStatus']")]
        internal readonly IWebElement? _selectRequisitionStatus =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DeptNo']")]
        internal readonly IWebElement? _inputReqDepartmentNumber =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DirAcctNo']")]
        internal readonly IWebElement? _inputReqDirectAccountNumber =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ReqCreated']")]
        internal readonly IWebElement? _inputReqCreated =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='WOCount']")]
        internal readonly IWebElement? _inputReqWorkOrderCount =null;

    }
}
