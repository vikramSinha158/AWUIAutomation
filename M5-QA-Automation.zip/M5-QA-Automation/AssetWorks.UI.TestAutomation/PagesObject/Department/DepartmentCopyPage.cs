﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Department
{
    internal class DepartmentCopyPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal DepartmentCopyPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='DeptNumber']")]
        internal readonly IWebElement? _inputDeptNumber =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DeptDesc']")]
        internal readonly IWebElement? _inputDeptDescription =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='STATUS']")]
        internal readonly IWebElement? _inputDeptStatus =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NewDeptNumber']")]
        internal readonly IWebElement? _inputNewDeptNumber =null;

    }
}
