﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Equipment
{
    internal class EquipCheckOutPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public EquipCheckOutPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='FromLocation']")]
        internal IWebElement? _Location = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='REQUEST_EMP_NO']")]
        internal IWebElement? _REQUEST_EMP_NO = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='RequestedByName']")]
        internal IWebElement? _RequestedByName = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='REQUEST_ID']")]
        internal IWebElement? _REQUEST_ID = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='TARGET_TYPE_SEL']")]
        internal IWebElement? _TARGET_TYPE_SEL = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TARGET_TYPE']")]
        internal IWebElement? _TARGET_TYPE = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TARGET_TYPE_NAME']")]
        internal IWebElement? _TARGET_TYPE_NAME = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ISSUING_EMP_ID']")]
        internal IWebElement? _ISSUING_EMP_ID = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CHECKOUT_EMP_ID']")]
        internal IWebElement? _CHECKOUT_EMP_ID = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='RESPONSIBLE_EMP_ID']")]
        internal IWebElement? _RESPONSIBLE_EMP_ID = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ContactName']")]
        internal IWebElement? _ContactName = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ContactPhone']")]
        internal IWebElement? _ContactPhone = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ContactEmail']")]
        internal IWebElement? _ContactEmail = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='btnRetrieve']")]
        internal IWebElement? _btnRetrieve = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='btnClear']")]
        internal IWebElement? _btnClear = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EquipReqSumFrame']")]
        internal IWebElement? _EquipReqSumFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EquipReqSumFrameTable']")]
        internal IWebElement? _EquipReqSumFrameTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EquipmentCheckOutFrame']")]
        internal IWebElement? _EquipmentCheckOutFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EquipmentCheckOutTable']")]
        internal IWebElement? _EquipmentCheckOutTable = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EQUIP_NO$new_0']")]
        internal IWebElement? _EquipmentNoNew = null;
    }
    
}
