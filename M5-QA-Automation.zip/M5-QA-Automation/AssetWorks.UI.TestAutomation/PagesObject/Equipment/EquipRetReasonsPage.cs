﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class EquipRetReasonsPage : BasePage
    {       
        internal ExtendedPageActions _extendPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public EquipRetReasonsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EquipmentReturnReasonsFrame']")]
        internal readonly IWebElement? _frameEquipRetReason = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EquipmentReturnReasonsTable']/tbody/tr")]
        internal readonly IList<IWebElement>? _tablerowsEquipRetReason = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EquipmentReturnReasonsTable']")]
        internal readonly IWebElement? _tableEquipRetReason = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='EQUIPMENT_RETURN_REASON$new_0']")]
        internal readonly IWebElement? _inputNewCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DESCRIPTION$new_0']")]
        internal readonly IWebElement? _inputNewDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DEFAULT_FL$new_0']")]
        internal readonly IWebElement? _ckbNewDefault = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DISABLED_FL$new_0']")]
        internal readonly IWebElement? _ckbNewDisabled = null;
    }
}
