﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class EquipProfileTypesMainPage : BasePage
    {
        internal static string ECode = String.Empty;
        internal static string EDescription = String.Empty;   

        internal ExtendedPageActions _extendPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public EquipProfileTypesMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EquipProfTypeFrame']")]
        internal readonly IWebElement? _frameEquipProfileType = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EPTypeTable']/tbody/tr")]
        internal readonly IList<IWebElement>? _tablerows = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EPTypeTable']")]
        internal readonly IWebElement? _tableEquipProfileType = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='code$new_0']")]
        internal readonly IWebElement? _inputNewCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='desc$new_0']")]
        internal readonly IWebElement? _inputNewDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='default$new_0']")]
        internal readonly IWebElement? _ckbNewDefault = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='disabled$new_0']")]
        internal readonly IWebElement? _ckbNewDisabled = null;


    }
}
