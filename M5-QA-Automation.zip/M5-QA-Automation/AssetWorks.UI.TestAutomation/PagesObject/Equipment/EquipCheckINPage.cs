﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Equipment
{
    internal class EquipCheckINPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public EquipCheckINPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='CHECKIN_LOCATION']")]
        internal IWebElement? _CHECKIN_LOCATION = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='RETURN_EMP_ID']")]
        internal IWebElement? _RETURN_EMP_ID = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CheckInEmployeeName']")]
        internal IWebElement? _CheckInEmployeeName = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='FROM_LOCATION']")]
        internal IWebElement? _FROM_LOCATION = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='TARGET_TYPE_SEL']")]
        internal IWebElement? _TARGET_TYPE_SEL = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TARGET_TYPE']")]
        internal IWebElement? _TARGET_TYPE = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TARGET_TYPE_NAME']")]
        internal IWebElement? _TARGET_TYPE_NAME = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='RESPONSIBLE_PARTY']")]
        internal IWebElement? _RESPONSIBLE_PARTY = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DATE_FROM']")]
        internal IWebElement? _DATE_FROM = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DATE_TO']")]
        internal IWebElement? _DATE_TO = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EQUIPMENT_TYPE']")]
        internal IWebElement? _EQUIPMENT_TYPE = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SKU']")]
        internal IWebElement? _SKU = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EQUIPMENT_NUM']")]
        internal IWebElement? _EQUIPMENT_NUM = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='btnRetrieve']")]
        internal IWebElement? _btnRetrieve = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='btnClear']")]
        internal IWebElement? _btnClear = null;  

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EquipmentCheckInFrame']")]
        internal IWebElement? _EquipmentCheckInFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EquipmentCheckInTable']")]
        internal IWebElement? _EquipmentCheckInTable = null;
    }
}
