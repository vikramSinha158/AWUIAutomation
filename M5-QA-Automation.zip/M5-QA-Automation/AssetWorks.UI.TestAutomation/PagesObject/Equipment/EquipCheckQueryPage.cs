﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Equipment
{
    internal class EquipCheckQueryPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public EquipCheckQueryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='TO_LOCATION']")]
        internal IWebElement? _TO_LOCATION = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='CHECK_STATUS']")]
        internal IWebElement? _CHECK_STATUS = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='REQUEST_ID']")]
        internal IWebElement? _REQUEST_ID = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='RETURN_REASON']")]
        internal IWebElement? _RETURN_REASON = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='EMPLOYEE_OWNED_FL']")]
        internal IWebElement? _EMPLOYEE_OWNED_FL = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='FROM_LOCATION']")]
        internal IWebElement? _FROM_LOCATION = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='TARGET_TYPE_SEL']")]
        internal IWebElement? _TARGET_TYPE_SEL = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TARGET_TYPE']")]
        internal IWebElement? _TARGET_TYPE = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TARGET_TYPE_NAME']")]
        internal IWebElement? _TARGET_TYPE_NAME = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='RESPONSIBLE_PARTY']")]
        internal IWebElement? _RESPONSIBLE_PARTY = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CHECKOUT_DATE_FROM']")]
        internal IWebElement? _CHECKOUT_DATE_FROM = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CHECKOUT_DATE_TO']")]
        internal IWebElement? _CHECKOUT_DATE_TO = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='RETURN_DATE_FROM']")]
        internal IWebElement? _RETURN_DATE_FROM = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='RETURN_DATE_TO']")]
        internal IWebElement? _RETURN_DATE_TO = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EQUIPMENT_TYPE']")]
        internal IWebElement? _EQUIPMENT_TYPE = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SKU']")]
        internal IWebElement? _SKU = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EQUIP_NO']")]
        internal IWebElement? _EQUIP_NO = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='btnRetrieve']")]
        internal IWebElement? _btnRetrieve = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='btnClear']")]
        internal IWebElement? _btnClear = null;  

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EquipmentCheckQueryFrame']")]
        internal IWebElement? _EquipmentCheckQueryFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EquipmentCheckQueryTable']")]
        internal IWebElement? _EquipmentCheckQueryTable = null;

        [FindsBy(How = How.XPath, Using = "//button[@title='Close']")]
        internal IWebElement? _btnNotesClose = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@id='splNote']")]
        internal IWebElement? _NoteText = null;
    }
}
