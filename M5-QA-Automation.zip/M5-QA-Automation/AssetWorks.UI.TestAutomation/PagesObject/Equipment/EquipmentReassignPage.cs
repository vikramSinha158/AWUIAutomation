﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Equipment
{
    internal class EquipmentReassignPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        
        public EquipmentReassignPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//select[@name='TARGET_TYPE_SEL']")]
        internal readonly IWebElement? _assignedTo = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='RESPONSIBLE_PARTY']")]
        internal readonly IWebElement? _responsibleParty = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='EQUIP_NO']")]
        internal readonly IWebElement? _equipmentNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='EQUIP_NO$0']")]
        internal readonly IWebElement? _colEquipmentNo = null;
        
        [FindsBy(How = How.XPath, Using = "//table[@id='EquipmentReassignTable']")]
        internal readonly IWebElement? _tableEquipmentReassign = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='FROM_LOCATION']")]
        internal readonly IWebElement? _fromLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='EQUIPMENT_TYPE']")]
        internal readonly IWebElement? _equipmentType = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='CHECKOUT_DATE_FROM']")]
        internal readonly IWebElement? _checkoutDateFrom = null;       

        [FindsBy(How = How.XPath, Using = "//input[@name='CHECKOUT_DATE_TO']")]
        internal readonly IWebElement? _checkoutDateTo = null;
        
        [FindsBy(How = How.XPath, Using = "//button[@name='btnRetrieve']")]
        internal readonly IWebElement? _buttonRetreive = null;        

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EquipmentReassignFrame']")]
        internal readonly IWebElement? _frameReassign = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='REASSIGN$0']")]
        internal readonly IWebElement? _reassign = null;
  
        [FindsBy(How = How.XPath, Using = "//select[@name='REASSIGN_TO$0']")]
        internal readonly IWebElement? _reassignTo = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='REASSIGN_NUMBER$0']")]
        internal readonly IWebElement? _reassignNumber = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='SKU$0']")]
        internal readonly IWebElement? _SKU = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='OUT_CONDITION$0']")]
        internal readonly IWebElement? _condition = null;
       
        [FindsBy(How = How.XPath, Using = "//input[@name='Checked_OUT_To$0']")]
        internal readonly IWebElement? _checkedOutTo = null;

    }
}
