﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Dashboard
{
    /// <summary>
    /// Page object class for Department Main
    /// </summary>
    internal class EditDashboardPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        internal EditDashboardPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        public static string KPI = "Kpi$";
        public static string Title = "title$";       

        [FindsBy(How = How.XPath, Using = "//span[text()='Application User']")]
        internal readonly IWebElement? _applicationUser = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='DashName']")]
        internal readonly IWebElement? _dashName = null;        

        [FindsBy(How = How.Id, Using = "UserId")]
        internal readonly IWebElement? _userRole = null;        

        [FindsBy(How = How.Id, Using = "newDashBtn")]
        internal readonly IWebElement? _newDashBtn = null;

        [FindsBy(How = How.Id, Using = "DashNamePopup")]
        internal readonly IWebElement? _dashNamePopup = null;        

        [FindsBy(How = How.XPath, Using = "//table[@id='DashboardTable']")]
        internal readonly IWebElement? _dashTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='DashboardFrame']")]
        internal readonly IWebElement? _dashFrame = null;

    }
}
