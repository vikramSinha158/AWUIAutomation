﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class AssetControlCategoryPage : BasePage
    {
        internal ExtendedPageActions ExtendedPage => new(Driver);

        public AssetControlCategoryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='Category']")]
        internal IWebElement? _inputCategory = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Description']")]
        internal IWebElement? _inputCatDescription = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='BudgetAmount']")]
        internal IWebElement? _inputBudgetAmount = null;

        //Options Tab
        [FindsBy(How = How.XPath, Using = "//iframe[@name='ItemFrame']")]
        internal IWebElement? _frameOptions = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='ItemTable']/tbody")]
        internal IWebElement? _tableOptions = null;
    }
}
