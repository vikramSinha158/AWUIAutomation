﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Distributor
{
    /// <summary>
    /// Page object class for Department Main
    /// </summary>
    internal class DistributorMainPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        internal DistributorMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.Id, Using = "DistNumber")]
        internal readonly IWebElement? _distNumber = null;

        [FindsBy(How = How.Id, Using = "Name")]
        internal readonly IWebElement? _distName = null;    

        [FindsBy(How = How.Id, Using = "Disable")]
        internal readonly IWebElement? _disabled = null;

        [FindsBy(How = How.Id, Using = "Address1")]
        internal readonly IWebElement? _address1 = null;

        [FindsBy(How = How.Id, Using = "Address2")]
        internal readonly IWebElement? _address2 = null;

        [FindsBy(How = How.Id, Using = "City")]
        internal readonly IWebElement? _city = null;

        [FindsBy(How = How.Id, Using = "State")]
        internal readonly IWebElement? _state = null;

        [FindsBy(How = How.Id, Using = "Zip")]
        internal readonly IWebElement? _zip = null;

        [FindsBy(How = How.Id, Using = "country")]
        internal readonly IWebElement? _country = null;

        [FindsBy(How = How.Id, Using = "Contact")]
        internal readonly IWebElement? _contact = null;

        [FindsBy(How = How.Id, Using = "Phone")]
        internal readonly IWebElement? _phone = null;

        [FindsBy(How = How.Id, Using = "PhoneEx")]
        internal readonly IWebElement? _phoneExt = null;

        [FindsBy(How = How.Id, Using = "Email")]
        internal readonly IWebElement? _email = null;

        [FindsBy(How = How.Id, Using = "Fax")]
        internal readonly IWebElement? _fax = null;
    }
}
