﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.MarkUp
{
    internal class MarkupTypesPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public MarkupTypesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        internal readonly string _headerMarkupType = "Markup Type";
        internal readonly string _selectLookup1 = "lookup_1";
        internal readonly string _selectLookup2 = "lookup_2";
        internal readonly string _selectLookup3 = "lookup_3";
        internal readonly string _selectLookup4 = "lookup_4";

        [FindsBy(How = How.XPath, Using = "//iframe[@name='MarkupTypesFrame']")]
        internal readonly IWebElement? _frameMarkupTypes = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='MarkupTypesTable']")]
        internal readonly IWebElement? _tableMarkupTypes = null;
    }
}
