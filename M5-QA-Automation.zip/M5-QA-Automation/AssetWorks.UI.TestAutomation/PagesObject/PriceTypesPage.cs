﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class PriceTypesPage : BasePage
    {
        internal ExtendedPageActions ExtendedPage => new(Driver);

        public PriceTypesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PriceTypesFrame']")]
        internal readonly IWebElement? _framePriceTypes = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PriceTypesTable']/tbody")]
        internal readonly IWebElement? _tablePriceTypes = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='code$new_0']")]
        internal readonly IWebElement? _inputCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='desc$new_0']")]
        internal readonly IWebElement? _inputDescription = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='AdjPC$new_0']")]
        internal readonly IWebElement? _inputAdjustmentPC = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DiscPC$new_0']")]
        internal readonly IWebElement? _inputDiscountPC = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DiscDays$new_0']")]
        internal readonly IWebElement? _inputDiscountDays = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ShipTerms$new_0']")]
        internal readonly IWebElement? _inputShipTerms = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='TaxFl$new_0']")]
        internal readonly IWebElement? _inputTaxFlag = null;
    }
}
