﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.TestSuite
{
    internal class TestHistoryQueryPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public TestHistoryQueryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//select[@name='udcsel']")]
        internal IWebElement? _historyItemName = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UnitNo']")]
        internal IWebElement? _historyItemNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='TestSuiteName']")]
        internal IWebElement? _testSuiteName = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='FromDt']")]
        internal IWebElement? _fromDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ToDt']")]
        internal IWebElement? _toDate = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='TestHistoryFrame']")]
        internal IWebElement? _testHistoryFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='TestHistoryTable']")]
        internal IWebElement? _testHistoryTable = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='Retrieve']")]
        internal IWebElement? _retrieve = null;
    }
}
