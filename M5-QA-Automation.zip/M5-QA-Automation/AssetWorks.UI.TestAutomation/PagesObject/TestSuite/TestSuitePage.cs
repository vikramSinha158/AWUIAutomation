﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.TestSuite
{
    internal class TestSuitePage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public TestSuitePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='TestSuiteName']")]
        internal IWebElement? _testSuiteName = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Desc']")]
        internal IWebElement? _testSuiteNameDesc = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='EnabledFl']")]
        internal IWebElement? _enabledFl = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='nextTestSuiteName']")]
        internal IWebElement? _nextTestSuiteName = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='linkTestSuiteName']")]
        internal IWebElement? _linkTestSuiteName = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='JobCode']")]
        internal IWebElement? _JobCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='JobReason']")]
        internal IWebElement? _jobReason = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='JobPriority']")]
        internal IWebElement? _jobPriority = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='TestSuiteTestsFrame']")]
        internal IWebElement? _testSuiteTestsFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='testTable']")]
        internal IWebElement? _testTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='testTable']//tbody//tr")]
        internal IList<IWebElement>? _testTableRows = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BillUnitAdjTable']")]
        internal IWebElement? _billUnitAdjTable1 = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BillUnitAdjTable']//tbody//tr")]
        internal IList<IWebElement>? _billUnitAdjTableRows11 = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab0']")]
        internal IWebElement? _testTab = null;

    }
}
