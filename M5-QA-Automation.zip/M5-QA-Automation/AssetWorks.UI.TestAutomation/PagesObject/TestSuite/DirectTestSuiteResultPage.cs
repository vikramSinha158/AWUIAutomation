﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.TestSuite
{
    internal class DirectTestSuiteResultPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public DirectTestSuiteResultPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='Loc']")]
        internal IWebElement? _loc = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='udcsel']")]
        internal IWebElement? _itemName = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UnitNo']")]
        internal IWebElement? _unitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='TestSuiteName']")]
        internal IWebElement? _testSuiteName = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='RefNo']")]
        internal IWebElement? _refNo = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='DirectTestResultsFrame']")]
        internal IWebElement? _directTestResultsFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='testTable']")]
        internal IWebElement? _testTable = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Result']")]
        internal IWebElement? _testSuiteResult = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Status']")]
        internal IWebElement? _testSuitStatus = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='CompleteBtn']")]
        internal IWebElement? _testSuitCompleteBtn = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Umeterwidget1:reading1']")]
        internal IWebElement? _meterreading1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Umeterwidget1:reading2']")]
        internal IWebElement? _meterreading2 = null;

    }
}
