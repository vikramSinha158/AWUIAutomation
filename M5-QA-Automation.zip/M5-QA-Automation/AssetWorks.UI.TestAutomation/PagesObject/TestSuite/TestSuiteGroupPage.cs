﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.TestSuite
{
    internal class TestSuiteGroupPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public TestSuiteGroupPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='TSGroup']")]
        internal IWebElement? _tSGroup = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='DeptListLeft']")]
        internal IWebElement? _tsgListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='DeptListRight']")]
        internal IWebElement? _tsgListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='DeptListMoveRight']")]
        internal IWebElement? _tsgListMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='DeptListMoveLeft']")]
        internal IWebElement? _tsgListMoveLeft = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='TSGroupMaintFrame']")]
        internal IWebElement? _tSGroupMaintFrame = null;
    }
}
