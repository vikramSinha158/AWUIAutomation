﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    public class ExtendedPage : BasePage
    {
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public ExtendedPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//button[@id='savebutton']")]
        internal IWebElement? _buttonSave =null;

        [FindsBy(How = How.XPath, Using = "//button[@id='undobutton']")]
        internal IWebElement? _buttonUndo =null;

        [FindsBy(How = How.XPath, Using = "//button[@id='undoallbutton']")]
        internal IWebElement? _buttonRefresh =null;

        [FindsBy(How = How.XPath, Using = "//button[@id='deletebutton']")]
        internal IWebElement? _buttonDelete =null;

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Home')]//span[@class='mdl-button__ripple-container']")]
        internal IWebElement? _homeTab =null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Action Required']")]
        internal IWebElement? _createDialog =null;

        [FindsBy(How = How.XPath, Using = "//iframe[contains(@id,'Content')]")]
        internal IWebElement? _contentFrame =null;

        [FindsBy(How = How.XPath, Using = "//span[text()='Error Messages and Warnings']")]
        internal IWebElement? _errorWarningDisplay =null;
       
        [FindsBy(How = How.XPath, Using = "//span[@class='errorCriticalText']")]
        internal IWebElement? _errorCriticalText =null;

        [FindsBy(How = How.XPath, Using = "//thead[@class='tableFloatingHeaderOriginal']")]
        internal IWebElement? _tableHeaders = null;

        [FindsBy(How = How.XPath, Using = "//nav[@id='mainRelatedMenu']")]
        internal IWebElement? _navRelatedMenu = null;

        [FindsBy(How = How.XPath, Using = "//div[contains(@id,'dialog-area')]")]
        internal IWebElement? _dialogArea = null;

        [FindsBy(How = How.XPath, Using = "//div[contains(@id,'dialog-area')]//textarea")]
        internal IWebElement? _txtAreaNotes = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='helpbutton']")]
        internal IWebElement? _helpBtn = null;

        [FindsBy(How = How.XPath, Using = "//div//span[@class='ScreenTitle']")]
        internal readonly IWebElement? _menuBarOptionsHeader = null;

        [FindsBy(How = How.XPath, Using = "//div[contains(@id,'dialog-area')]//p[1]")]
        internal readonly IWebElement? _dialogTitle = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@id='Content2']")]
        internal IWebElement? _contentFrame2 = null;

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'OK')]")]
        internal IWebElement? _OkBtn = null;

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Attach a new file')]")]
        internal readonly IWebElement? _attachNewFile = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='theFile']")]
        internal readonly IWebElement? _chooseFile = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='theDesc']")]
        internal readonly IWebElement? _FileDesc = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='newAttButton']")]
        internal readonly IWebElement? _attachNewFileBtn = null;

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Attach a web address')]")]
        internal readonly IWebElement? _attachWebAddress = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='theUrl']")]
        internal readonly IWebElement? _webAddress = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='theDesc']")]
        internal readonly IWebElement? _webAddressDesc = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='attButton']")]
        internal readonly IWebElement? _attachAddressBtn = null;

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Attach a previously uploaded file or web address')]")]
        internal readonly IWebElement? _attachExistingFile = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='assocFile']")]
        internal readonly IWebElement? _previousUploadedFile = null;

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Associate')]")]
        internal readonly IWebElement? _associateBtn = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='closeC2Btn']")]
        internal readonly IWebElement? _closeShowAttachmentsBtn = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ShowAttachmentsFrame']")]
        internal readonly IWebElement? _showAttachmentsFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='attachTable']")]
        internal readonly IWebElement? _attachTable = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='CompleteBtn']")]
        internal IWebElement? _completeBtn = null;
    }
}
