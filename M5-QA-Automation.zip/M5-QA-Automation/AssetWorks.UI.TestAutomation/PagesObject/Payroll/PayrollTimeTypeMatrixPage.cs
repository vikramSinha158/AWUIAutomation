﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Payroll
{
    internal class PayrollTimeTypeMatrixPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public PayrollTimeTypeMatrixPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='MatrixFrame']")]
        internal readonly IWebElement? _frameMatrix = null;

        [FindsBy(How = How.Id, Using = "matrixTable")]
        internal readonly IWebElement? _tableMatrix = null;

        [FindsBy(How = How.Id, Using = "base$new_0")]
        internal readonly IWebElement? _newBasePay = null;

        [FindsBy(How = How.Id, Using = "overtime$new_0")]
        internal readonly IWebElement? _newOvertime = null;

        [FindsBy(How = How.Id, Using = "dbltime$new_0")]
        internal readonly IWebElement? _newDoubletime = null;
    }
}
