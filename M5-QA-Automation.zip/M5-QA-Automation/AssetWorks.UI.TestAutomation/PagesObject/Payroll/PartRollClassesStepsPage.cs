﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class PartRollClassesStepsPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);     
          

        public PartRollClassesStepsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.Id, Using = "payclass$new_0")]
        internal readonly IWebElement? _payClassNew = null;

        [FindsBy(How = How.Id, Using = "paystep$new_0")]
        internal readonly IWebElement? _payStepNew = null;     

        [FindsBy(How = How.Id, Using = "desc$new_0")]
        internal readonly IWebElement? _descNew = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EmpPayClassFrame']")]
        internal IWebElement? _frameEmpPayClass = null;
    }
}
