﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Payroll
{
    internal class PayrollTimeTypesPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public PayrollTimeTypesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='TimeTypeFrame']")]
        internal readonly IWebElement? _frameTimeType = null;

        [FindsBy(How = How.Id, Using = "TimeTypeTable")]
        internal readonly IWebElement? _tableTimeType = null;

        [FindsBy(How = How.Id, Using = "code$new_0")]
        internal readonly IWebElement? _newCode = null;

        [FindsBy(How = How.Id, Using = "desc$new_0")]
        internal readonly IWebElement? _newDesc = null;

        [FindsBy(How = How.Id, Using = "MaxHours$new_0")]
        internal readonly IWebElement? _newMaxHours = null;
    }
}
