﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;


namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class AppUserMaintenanceMainPage : BasePage
    {

        public static string ApplicationUser { get; set; }
        public static string Name { get; set; }
        public static string UserRole { get; set; }
        public static string NewUserID { get; set; }
        public static string NewUserName { get; set; }


        internal ExtendedPageActions _extendPage => new ExtendedPageActions(Driver);


        public AppUserMaintenanceMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='UserApp']")]
        internal readonly IWebElement? _appUser = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AllowWeb']")]
        internal readonly IWebElement? _allowWebAccessChb = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AppPass']")]
        internal readonly IWebElement? _appPassword = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AppAllowChangePw']")]
        internal readonly IWebElement? _allowChangePasswordChb = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AllowMobile']")]
        internal readonly IWebElement? _allowMobileAccessChb = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='MobilePass']")]
        internal readonly IWebElement? _mobilePassword = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='AdHocAccess']")]
        internal readonly IWebElement? _adhocAccess = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='AdHocLevel']")]
        internal readonly IWebElement? _adhocStartingFolder = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UserID']")]
        internal readonly IWebElement? _userRole = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Timeout']")]
        internal readonly IWebElement? _idleTimeout = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UserDashboardFl']")]
        internal readonly IWebElement? _userDashboardChb = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='CePooled']")]
        internal readonly IWebElement? _pooledChb = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='CeOutPath']")]
        internal readonly IWebElement? _crystalEnterpriseOutputPath = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='StyleDir']")]
        internal readonly IWebElement? _stylesheetDirectory = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='HomePg']")]
        internal readonly IWebElement? _homePage = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='TopPMMLevelName']")]
        internal readonly IWebElement? _startingPMM = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UniqueId']")]
        internal readonly IWebElement? _uniqueID = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UserDesc']")]
        internal readonly IWebElement? _userName = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UserEmpNo']")]
        internal readonly IWebElement? _userEmpNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UserDiv']")]
        internal readonly IWebElement? _userDivision = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Dept']")]
        internal readonly IWebElement? _department = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Phone']")]
        internal readonly IWebElement? _phone = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DeptGroup']")]
        internal readonly IWebElement? _deptGroup = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Email']")]
        internal readonly IWebElement? _email = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='VendorNo']")]
        internal readonly IWebElement? _vendorNo = null;


        [FindsBy(How = How.XPath, Using = "//input[@name='NewUserId']")]
        internal readonly IWebElement? _newUserId = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='NewName']")]
        internal readonly IWebElement? _newUserName = null;
    }
}
