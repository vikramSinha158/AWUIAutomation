﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.DAFCode
{
    internal class DeptGroupDAFMaintenancePage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public DeptGroupDAFMaintenancePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='DeptGroup']")]
        internal IWebElement? _deptGroup = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='DeptGroupDAFFrame']")]
        internal IWebElement? _deptGroupDAFFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DeptGroupDAFTable']")]
        internal IWebElement? _deptGroupDAFTable = null;
    }
}
