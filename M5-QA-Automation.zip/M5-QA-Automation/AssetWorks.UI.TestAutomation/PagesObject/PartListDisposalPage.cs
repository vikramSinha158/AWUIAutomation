﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class PartListDisposalPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public PartListDisposalPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//select[@id='searchType']")]
        internal IWebElement? _selectSearchType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UnitDeptNo']")]
        internal IWebElement? _inputUnitDeptNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UNIT_DESC']")]
        internal IWebElement? _inputUnitDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='effDT']")]
        internal IWebElement? _inputSearchFromDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ShowAll']")]
        internal IWebElement? _inputShowAll = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='DisposalPartsFrame']")]
        internal IWebElement? _frameDisposalParts = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DisposalPartsTable']/tbody")]
        internal IWebElement? _tableDisposalParts = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Rsn$new_0']")]
        internal IWebElement? _inputNewReason = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PartNo$new_0']")]
        internal IWebElement? _inputNewPart = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='qty$new_0']")]
        internal IWebElement? _inputNewQuantity = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='issueValue$new_0']")]
        internal IWebElement? _inputNewIssueValue = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='Notes$new_0']")]
        internal IWebElement? _buttonNewNotes = null;

    }
}
