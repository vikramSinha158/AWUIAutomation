﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class WorkOrderCopyPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public WorkOrderCopyPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='wonumber']")]
        internal IWebElement? _wonumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='unitno0']")]
        internal IWebElement? _unitno = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='newwo0']")]
        internal IWebElement? _newWo = null;

        public IWebElement? _unit(int i) => Driver.FindElement(By.Id($"unitno{i}"));
        public IWebElement? _workorder(int i) => Driver.FindElement(By.Id($"newwo{i}"));
    }
}
