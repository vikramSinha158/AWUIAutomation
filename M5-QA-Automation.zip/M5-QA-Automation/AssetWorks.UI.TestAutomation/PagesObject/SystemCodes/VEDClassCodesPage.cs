﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes
{
    internal class VEDClassCodesPage : BasePage
    {

        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        internal VEDClassCodesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='VEDClassCodesFrame']")]
        internal IWebElement? _vEDClassCodesFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='VEDClassCodesTable']")]
        internal IWebElement? _vEDClassCodesTable = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='code$new_0']")]
        internal IWebElement? _inputNewCode = null;
    }
}
