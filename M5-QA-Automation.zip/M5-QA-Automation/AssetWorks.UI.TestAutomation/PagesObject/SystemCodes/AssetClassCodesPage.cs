﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes
{
    internal class AssetClassCodesPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal AssetClassCodesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }


        [FindsBy(How = How.XPath, Using = "//iframe[@name='CateClassFrame']")]
        internal IWebElement? _frameAssetClassCodes = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='cateclassTable']/tbody")]
        internal IWebElement? _tableAssetClassCodes = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='code$new_0']")]
        internal IWebElement? _inputNewCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='desc$new_0']")]
        internal IWebElement? _inputNewDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='smooth_shift$new_0']")]
        internal IWebElement? _inputNewSmoothShift = null;
    }
}
