﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes
{
    internal class SystemPositionPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        internal SystemPositionPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }          

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PosFrame']")]
        internal IWebElement? _frameSystemPositionCodes = null;

        [FindsBy(How = How.XPath, Using = "//table[@class='SelectorWidget']/tbody")]
        internal IWebElement? _tableSystemPosition = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='SysCode']")]
        internal IWebElement? _inputSystemCode = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='Choice1Left']")]
        internal IWebElement? _listLeftElement = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='Choice1Right']")]
        internal IWebElement? _listRightElement = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='Choice1MoveRight']")]
        internal IWebElement? _btnMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='Choice1MoveLeft']")]
        internal IWebElement? _btnMoveLeft = null;
    }
}
