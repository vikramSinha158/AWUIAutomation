﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes
{
    internal class ClaimCategoryDefinitionPage : BasePage
    {
        internal readonly string _headerWarrCategory = "Warr\r\nCategory";
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ClaimCategoryDefinitionPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='WarrCategoryFrame']")]
        internal IWebElement? _frameWarrCategory = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='WarrCategoryTable']/tbody")]
        internal IWebElement? _tableWarrCategory = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='warrCategory$new_0']")]
        internal IWebElement? _inputWarrCategory = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='desc$new_0']")]
        internal IWebElement? _inputWarrCategoryDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='claim_amt_prohib_fl$new_0']")]
        internal IWebElement? _checkboxClaimAmtProhibitied = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='save_amt_prohib_fl$new_0']")]
        internal IWebElement? _checkboxSaveAmtProhibitied = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='disabled$new_0']")]
        internal IWebElement? _checkboxDisabled = null;
    }
}
