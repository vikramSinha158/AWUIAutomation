﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes
{
    internal class DirectAccountCodesPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal DirectAccountCodesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='diracct']")]
        internal IWebElement? _inputDirectAccount = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Desc']")]
        internal IWebElement? _inputDescription = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Disabled']")]
        internal IWebElement? _selectDisabled = null;
    }
}
