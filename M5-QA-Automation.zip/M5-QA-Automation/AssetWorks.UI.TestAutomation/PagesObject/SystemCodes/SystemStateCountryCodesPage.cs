﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes
{
    internal class SystemStateCountryCodesPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        internal SystemStateCountryCodesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='CountryFrame']")]
        internal IWebElement? _frameCountry = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='StateFrame']")]
        internal IWebElement? _frameState = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='CountryTable']/tbody")]
        internal IWebElement? _tableCountry = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='StateTable']/tbody")]
        internal IWebElement? _tableState = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='code$new_0']")]
        internal IWebElement? _inputNewCountryCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='desc$new_0']")]
        internal IWebElement? _inputNewCountryDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='stcodeleng$new_0']")]
        internal IWebElement? _inputNewStateCodeLeng = null;

        internal IWebElement? _inputNewStateCode(string row) => Driver.FindElement(By.XPath($"//input[@id='stcode$new_{row}']"));
        internal IWebElement? _inputNewStateDesc(string row) => Driver.FindElement(By.XPath($"//input[@id='stdesc$new_{row}']"));
    }
}
