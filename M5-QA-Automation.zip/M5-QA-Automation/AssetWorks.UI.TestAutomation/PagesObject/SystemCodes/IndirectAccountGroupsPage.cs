﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using System.Collections.Generic;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes
{
    internal class IndirectAccountGroupsPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal IndirectAccountGroupsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='IndAcctGroup']")]
        internal IWebElement? _inputGroupName = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='IndAcctGroupMaintFrame']")]
        internal readonly IWebElement? _frameIndAcctGroup = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='IndAcctListLeft']")]
        internal readonly IWebElement? _selectIndAcctListLeft = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='IndAcctListRight']")]
        internal readonly IWebElement? _selectIndAcctListRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='IndAcctListMoveRight']")]
        internal readonly IWebElement? _buttonIndAcctListMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='IndAcctListMoveLeft']")]
        internal readonly IWebElement? _buttonIndAcctListMoveLeft = null;
    }
}
