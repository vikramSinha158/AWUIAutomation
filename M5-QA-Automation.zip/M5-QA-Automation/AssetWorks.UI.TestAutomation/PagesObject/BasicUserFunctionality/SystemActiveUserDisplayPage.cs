﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.BasicUserFunctionality
{
    internal class SystemActiveUserDisplayPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public SystemActiveUserDisplayPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//button[@id='reloadBtn']")]
        internal readonly IWebElement? _systemActiveReloadButton = null;
       
        [FindsBy(How = How.XPath, Using = "//input[@id='licUsers']")]
        internal readonly IWebElement? _licensedCount = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='actUsers']")]
        internal readonly IWebElement? _actUsers = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='user$0']")]
        internal readonly IWebElement? _user =null;
        
        [FindsBy(How = How.XPath, Using = "//input[@id='loginDt$0']")]
        internal readonly IWebElement? _login = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='lastFrame$0']")] 
        internal readonly IWebElement? _lastFrame = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='lastAct$0']")]
        internal readonly IWebElement? _lastActivity = null;
       
        [FindsBy(How = How.XPath, Using = " //table[@id='UserTable']")]
        internal readonly IWebElement? _userTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ActiveUsersFrame']")]
        internal readonly IWebElement?_userFrame = null;
    }
}
