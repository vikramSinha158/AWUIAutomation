﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.BasicUserFunctionality;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.BasicUserFunctionality
{
    [TestFixture]
    public class MenuBarOptionsPage : BasePage
    {
        public static string ApplicationUser { get; set; }
        public static string Home { get; set; }
        public static string Favourites { get; set; }
        public static string History { get; set; }
        public static string Reports { get; set; }
        public static string Dashboard { get; set; }

        internal ExtendedPageActions _extendPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);      

        internal LoginPageActions _loginPage => new LoginPageActions(Driver);

        public MenuBarOptionsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='UserApp']")]
        internal readonly IWebElement? _appUser = null;

        [FindsBy(How = How.XPath, Using = "//a[text()='History']")]
        internal readonly IWebElement? _history = null;

        [FindsBy(How = How.XPath, Using = "//nav[@id='mainHistoryMenu']//li//li//a[contains(text(),'Application')]")]
        internal readonly IWebElement? _applicationUserMaintenance = null;
       
        [FindsBy(How = How.XPath, Using = "//span[@class='ScreenTitle']")]
        internal readonly IWebElement? _applicationUserMaintenanceHeader = null;

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Reports')]")]
        internal readonly IWebElement? _reports = null;

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Dashboard')]")]
        internal readonly IWebElement? _dashboard = null;
        
        [FindsBy(How = How.XPath, Using = "//button[@id='chatCountTD']")]
        internal readonly IWebElement? _chatButton = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='helpbutton']")]
        internal readonly IWebElement? _helpFile = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='chatNewBtn']")]
        internal readonly IWebElement? _chatNewBtn = null;
       
        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Operational Dashboard')]")]
        internal readonly IWebElement? _helpFileNewWindow = null;
       
        [FindsBy(How = How.XPath, Using = "//button[@title='Close']")]
        internal readonly IWebElement? _closeChatWindow = null;      

        [FindsBy(How = How.XPath, Using = "//li[@key='homepg']//span[@id='addFav']")]
        internal readonly IWebElement? _addFav = null;        

        [FindsBy(How = How.XPath, Using = "//span[@onclick='removeFavorite()']")]
        internal readonly IWebElement? _removeFav = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='switchTargetBtn']")]
        internal IWebElement? _tagetWindowButton = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='menuReduce']")]
        internal IWebElement? _mainMain = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='HomePg']")]
        internal readonly IWebElement? _homePage = null;

    }
}
