﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class TaxSchemeMainPage : BasePage
    {
        internal static string TaxSchemeID = String.Empty;
        internal string _line = "line_no$";
        internal string _topOfLine = "onTopLine$";
        internal string _taxType = "taxType$";
        internal string _taxRate = "taxRate$";
        internal string _flatRate = "flatRate$";
        internal string _alternateFlatRate = "alterFlatRate$";
        internal string tableRows = "//table[@id='TaxSchemeTable']/tbody/tr";

        internal ExtendedPageActions _extendPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public TaxSchemeMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='taxscheme']")]
        internal readonly IWebElement? _inputTaxScheme = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='SchemeDesc']")]
        internal readonly IWebElement? _inputSchemeDesc = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='Disabled']")]
        internal readonly IWebElement? _disableTaxScheme = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='EffDate']")]
        internal readonly IWebElement? _effectiveDate = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='appliedTo']")]
        internal readonly IWebElement? _appliedTo = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='calcucType']")]
        internal readonly IWebElement? _calcucType = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='TaxSchemeFrame']")]
        internal readonly IWebElement? _frameTaxScheme = null;     

        [FindsBy(How = How.XPath, Using = "//table[@id='TaxSchemeTable']")]
        internal readonly IWebElement? _tableTaxScheme = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='line_no$new_0']")]
        internal readonly IWebElement? _inputLine = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='onTopLine$new_0']")]
        internal readonly IWebElement? _inputTopOfLine = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='taxType$new_0']")]
        internal readonly IWebElement? _inputTaxType = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='taxRate$new_0']")]
        internal readonly IWebElement? _inputTaxRate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='flatRate$new_0']")]
        internal readonly IWebElement? _inputFlatRate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='alterFlatRate$new_0']")]
        internal readonly IWebElement? _inputAlternateFlatRate = null;
    }
}
