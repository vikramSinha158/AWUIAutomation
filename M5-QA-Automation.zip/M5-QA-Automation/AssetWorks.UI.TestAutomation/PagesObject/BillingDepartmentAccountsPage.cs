﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class BillingDepartmentAccountsPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public BillingDepartmentAccountsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }
        [FindsBy(How = How.XPath, Using = "//input[@id='DeptNumber']")]
        internal readonly IWebElement? _departmentNumber = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='BillDeptFrame']")]
        internal readonly IWebElement? _iframebillingAccount = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BillDeptExpTable']")]
        internal readonly IWebElement? _billingAccountTable = null;

    }

}
