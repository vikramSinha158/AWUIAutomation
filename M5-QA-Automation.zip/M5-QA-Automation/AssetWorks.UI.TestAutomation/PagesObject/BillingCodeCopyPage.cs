﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class BillingCodeCopyPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public BillingCodeCopyPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='existBillCode']")]
        internal IWebElement? _existBillCodeInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='newBillCode']")]
        internal IWebElement? _newBillCodeInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='newDescription']")]
        internal IWebElement? _newDescriptionInput = null;
    }
}
