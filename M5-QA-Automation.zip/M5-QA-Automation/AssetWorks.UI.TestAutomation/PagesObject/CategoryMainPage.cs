﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class CategoryMainPage : BasePage
    {
        internal ExtendedPageActions ExtendedPage => new(Driver);

        public CategoryMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='Category']")]
        internal IWebElement? _inputCategoryCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CategoryDesc']")]
        internal IWebElement? _inputCategoryDesc = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Disabled']")]
        internal IWebElement? _selectDisabled = null;

        //Details Information Tab
        [FindsBy(How = How.XPath, Using = "//input[@id='MRF']")]
        internal IWebElement? _inputMaintRepairUnits = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='OffHwyPct']")]
        internal IWebElement? _inputOffRoadUse = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Budgetdo']")]
        internal IWebElement? _inputBaseUnitCost = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='anninflatfact']")]
        internal IWebElement? _inputInflationFactor = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='LeadTm']")]
        internal IWebElement? _inputLeadTime = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Expectdt']")]
        internal IWebElement? _inputAge = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ExpectUsage1']")]
        internal IWebElement? _inputMeter1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ExpectUsage2']")]
        internal IWebElement? _inputMeter2 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='LTDMaintCost']")]
        internal IWebElement? _inputLTDMaintCost = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='DeprecTerm']")]
        internal IWebElement? _inputDepreciationTerm = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Salvagepc']")]
        internal IWebElement? _inputSalvage = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='DeprecType']")]
        internal IWebElement? _selectDepreciationType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Rate']")]
        internal IWebElement? _inputRate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='FinancingTerm']")]
        internal IWebElement? _inputFinancingTerm = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='InterestType']")]
        internal IWebElement? _selectInterestType = null;
    }
}
