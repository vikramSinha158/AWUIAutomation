﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct
{
    internal class ProductSetupEmployeePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public ProductSetupEmployeePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.Id, Using = "AssignID")]
        internal readonly IWebElement? _employeeIdInput = null;

        [FindsBy(How = How.Id, Using = "PINReqFl")]
        internal readonly IWebElement? _pinRequiredInput = null;

        [FindsBy(How = How.Id, Using = "ICUSupervFl")]
        internal readonly IWebElement? _icuRequiredInput = null;

        [FindsBy(How = How.Id, Using = "UnitReqFl")]
        internal readonly IWebElement? _unitNumberRequired = null;

        [FindsBy(How = How.Id, Using = "ShiftRstFl")]
        internal readonly IWebElement? _restrictedToShiftRequired = null;

        [FindsBy(How = How.Id, Using = "product_no$new_0")]
        internal readonly IWebElement? _productNumber = null;

        [FindsBy(How = How.Id, Using = "description$new_0")]
        internal readonly IWebElement? _productDescription = null;

        [FindsBy(How = How.Id, Using = "CardNo$new_0")]
        internal readonly IWebElement? _cardNo = null;

        [FindsBy(How = How.Id, Using = "EffDate$new_0")]
        internal readonly IWebElement? _effectiveDate = null;

        [FindsBy(How = How.Id, Using = "EndDate$new_0")]
        internal readonly IWebElement? _expirationDate = null;

        [FindsBy(How = How.Id, Using = "VendorNo$new_0")]
        internal readonly IWebElement? _vendorNo = null;

        [FindsBy(How = How.Id, Using = "PromptID$new_0")]
        internal readonly IWebElement? _promptId = null;

        [FindsBy(How = How.Id, Using = "Pin$new_0")]
        internal readonly IWebElement? _pinId = null;

        [FindsBy(How = How.Id, Using = "MsgText$new_0")]
        internal readonly IWebElement? _messageText = null;

        [FindsBy(How = How.Id, Using = "DeviceSrNo$new_0")]
        internal readonly IWebElement? _deviceSerial = null;

        [FindsBy(How = How.Id, Using = "Card_Disabled$new_0")]
        internal readonly IWebElement? _cardDisable = null;

        [FindsBy(How = How.Id, Using = "splNote")]
        internal readonly IWebElement? _cardMaintenanceNotes = null;

        [FindsBy(How = How.Id, Using = "Notes$new_0")]
        internal readonly IWebElement? _cardNotes = null;

        [FindsBy(How = How.Id, Using = "Notes$0")]
        internal readonly IWebElement? _cardNote = null;

        [FindsBy(How = How.Id, Using = "userData1$new_0")]
        internal readonly IWebElement? _userData1 = null;

        [FindsBy(How = How.Id, Using = "userData2$new_0")]
        internal readonly IWebElement? _userData2 = null;

        [FindsBy(How = How.Id, Using = "okNote")]
        internal readonly IWebElement? _cardMaintenanceOkButton = null;

        [FindsBy(How = How.Name, Using = "CardFrame")]
        internal readonly IWebElement? _cardFrame = null;

        [FindsBy(How = How.Name, Using = "EmpProdFrame")]
        internal readonly IWebElement? _productInformationFrame = null;

        [FindsBy(How = How.XPath, Using = "//a[text()='Product Infomation']")]
        internal readonly IWebElement? _productInformation = null;

        [FindsBy(How = How.XPath, Using = "//a[text()='Card Infomation']")]
        internal readonly IWebElement? _cardInformation = null;

        [FindsBy(How = How.Id, Using = "productTable")]
        internal readonly IWebElement? _productTable = null;

        [FindsBy(How = How.Id, Using = "CardTable")]
        internal readonly IWebElement? _cardTable = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@name,'CardNo$') and not(contains(@name,'CardNo$new'))]")]
        internal readonly IWebElement? _cardNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@name,'CardNo$') and not(contains(@name,'CardNo$new'))]")]
        internal readonly IList<IWebElement>? _cardNumbers = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@name,'product_no$') and not(contains(@name,'product_no$new'))]")]
        internal readonly IWebElement? _product = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@name,'product_no$') and not(contains(@name,'product_no$new'))]")]
        internal readonly IList<IWebElement>? _products = null;

        [FindsBy(How = How.XPath, Using = "//a[text()='PIN Management']")]
        internal readonly IWebElement? PinManagementTab = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='productTable']")]
        internal IWebElement? _productbl = null;
    }
}
