﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct
{
    internal class ProductSetupTanksHosePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public ProductSetupTanksHosePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='genloc']")]
        internal readonly IWebElement? _fuelLocation = null;

        [FindsBy(How = How.Name, Using = "LocFuelHoseFrame")]
        internal readonly IWebElement? _fuelHoseFrame = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'hHose_no$') and not(contains(@id,'hHose_no$new_0'))]")]
        internal readonly IList<IWebElement>? _hoseNumbers = null;

        [FindsBy(How = How.Id, Using = "hHose_no$new_0")]
        internal readonly IWebElement? _hoseNo = null;

        [FindsBy(How = How.Id, Using = "hTank_no$new_0")]
        internal readonly IWebElement? _tankNo = null;
        
        [FindsBy(How = How.Id, Using = "hCard_no$new_0")]
        internal readonly IWebElement? _dedicatedCardNumber = null;

        [FindsBy(How = How.Id, Using = "EVRII_comp$new_0")]
        internal readonly IWebElement? _evrComplaint = null;

        [FindsBy(How = How.Id, Using = "defuel_fl$new_0")]
        internal readonly IWebElement? _defuelingHose = null;

        [FindsBy(How = How.Id, Using = "LocFuelHoseTable")]
        internal readonly IWebElement? _hoseTable = null;
    }
}
