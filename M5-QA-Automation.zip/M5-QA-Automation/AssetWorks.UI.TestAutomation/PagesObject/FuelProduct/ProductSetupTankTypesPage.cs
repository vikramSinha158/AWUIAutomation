﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct
{
    internal class ProductSetupTankTypesPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public ProductSetupTankTypesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='TankTypeKey']")]
        internal readonly IWebElement? _tankTypeKey = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Capacity']")]
        internal readonly IWebElement? _capacity = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ConvFl']")]
        internal readonly IWebElement? _convFl = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='MfrInfoFrame']")]
        internal IWebElement? _mfrInfoFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='mfrinfoTable']")]
        internal IWebElement? _tankManufacturersinfoTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='StickConvrsnFrame']")]
        internal IWebElement? _stickConvrsnFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='stickconvrsnTable']")]
        internal IWebElement? _stickConversionTableTable = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='Note']")]
        internal readonly IWebElement? _note = null;
    }
}
