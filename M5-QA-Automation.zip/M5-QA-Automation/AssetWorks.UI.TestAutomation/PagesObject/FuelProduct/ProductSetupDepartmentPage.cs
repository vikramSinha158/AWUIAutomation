﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct
{
    internal class ProductSetupDepartmentPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public ProductSetupDepartmentPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='AssignID']")]
        internal readonly IWebElement? _department = null;

        [FindsBy(How = How.Id, Using = "EmployeeRequired")]
        internal readonly IWebElement? _employeeRequired = null;

        

        [FindsBy(How = How.Name, Using = "fraDepartment")]
        internal readonly IWebElement? _frameDepartment = null;

        [FindsBy(How = How.Id, Using = "EMP_VALIDATE_FL")]
        internal readonly IWebElement? _validateEmployee = null;

        [FindsBy(How = How.XPath, Using = "//a[text()='Products']")]
        internal readonly IWebElement? _productsTab = null;

        [FindsBy(How = How.XPath, Using = "//a[text()='Cards']")]
        internal readonly IWebElement? _cardsTab = null;

        [FindsBy(How = How.Id, Using = "CardTable")]
        internal readonly IWebElement? _cardTable = null;

        [FindsBy(How = How.Id, Using = "productTable")]
        internal readonly IWebElement? _productTable = null;

        [FindsBy(How = How.Id, Using = "Notes$new_0")]
        internal readonly IWebElement? _cardNotes = null;

        [FindsBy(How = How.Id, Using = "Notes$0")]
        internal readonly IWebElement? _cardNote = null;

        [FindsBy(How = How.Id, Using = "okNote")]
        internal readonly IWebElement? _cardMaintenanceOkButton = null;

        [FindsBy(How = How.Name, Using = "CardFrame")]
        internal readonly IWebElement? _cardFrame = null;


        [FindsBy(How = How.Name, Using = "ProdInfoFrame")]
        internal readonly IWebElement? _prodInfoFrame = null;

        [FindsBy(How = How.Id, Using = "splNote")]
        internal readonly IWebElement? _cardMaintenanceNotes = null;

        [FindsBy(How = How.Id, Using = "CardNo$new_0")]
        internal readonly IWebElement? _cardNo = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'CardNo$') and not(contains(@id,'CardNo$new_0'))]")]
        internal readonly IList<IWebElement>? _cardNos = null;

        [FindsBy(How = How.XPath, Using = "//input[contains(@id,'product_no$') and not(contains(@id,'product_no$new_0'))]")]
        internal readonly IList<IWebElement>? _productNos = null;

        [FindsBy(How = How.Id, Using = "product_no$new_0")]
        internal readonly IWebElement? _productNo = null;

        [FindsBy(How = How.Id, Using = "tank_capacity$new_0")]
        internal readonly IWebElement? _tankCapacity = null;


        [FindsBy(How = How.Id, Using = "EffDate$new_0")]
        internal readonly IWebElement? _effectiveDate = null;

        [FindsBy(How = How.Id, Using = "EndDate$new_0")]
        internal readonly IWebElement? _expirationDate = null;

        [FindsBy(How = How.Id, Using = "VendorNo$new_0")]
        internal readonly IWebElement? _vendorNo = null;

        [FindsBy(How = How.Id, Using = "PromptID$new_0")]
        internal readonly IWebElement? _promptId = null;

        [FindsBy(How = How.Id, Using = "Pin$new_0")]
        internal readonly IWebElement? _pinId = null;

        [FindsBy(How = How.Id, Using = "MsgText$new_0")]
        internal readonly IWebElement? _messageText = null;

        [FindsBy(How = How.Id, Using = "DeviceSrNo$new_0")]
        internal readonly IWebElement? _deviceSerial = null;

        [FindsBy(How = How.Id, Using = "Card_Disabled$new_0")]
        internal readonly IWebElement? _cardDisable = null;

        [FindsBy(How = How.Id, Using = "userData1$new_0")]
        internal readonly IWebElement? _userData1 = null;

        [FindsBy(How = How.Id, Using = "userData2$new_0")]
        internal readonly IWebElement? _userData2 = null;

        internal IWebElement? _productEditMode(string EditMode) => Driver.FindElement(By.XPath($"//label[text()='{EditMode}']/preceding-sibling::input[1]"));

        
    }
}
