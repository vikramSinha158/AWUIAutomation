﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct
{
    internal class ProductSetupUnitPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public ProductSetupUnitPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='AssignID']")]
        internal readonly IWebElement? _assignUnitID = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ValidMeter']")]
        internal readonly IWebElement? _enforceValidMeter = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='MeterCount']")]
        internal readonly IWebElement? _meterCount = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='ResShift']")]
        internal IWebElement? _resShift = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Meter2Count']")]
        internal readonly IWebElement? _meter2Count = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='EmployeeRequired']")]
        internal readonly IWebElement? _employeeRequired = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='EMP_VALIDATE_FL']")]
        internal IWebElement? _validateEmployee = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='rbManual']")]
        internal IWebElement? _manual = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ProdInfoFrame']")]
        internal IWebElement? _prodInfoFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='productTable']")]
        internal IWebElement? _productTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='CardFrame']")]
        internal IWebElement? _cardFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='CardTable']")]
        internal IWebElement? _cardTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='productTable']//tbody//tr")]
        internal IList<IWebElement>? _productTableRows = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='CardTable']//tbody//tr")]
        internal IList<IWebElement>? _cardTableTableRows = null;


    }
}
