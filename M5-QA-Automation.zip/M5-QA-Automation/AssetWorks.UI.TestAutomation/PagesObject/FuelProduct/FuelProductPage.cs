﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct
{
    internal class FuelProductPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public FuelProductPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='ProductKey']")]
        internal readonly IWebElement? _fuelProductNumber = null;


        [FindsBy(How = How.XPath, Using = "//input[@name='ProductDesc']")]
        internal readonly IWebElement? _fuelProductDescription = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='ProdType']")]
        internal readonly IWebElement? _fuelProductType= null;  

        [FindsBy(How = How.XPath, Using = " //select[@name='PriceMethod']")]
        internal readonly IWebElement? _Markup = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UnitIssue']")]
        internal readonly IWebElement? _fuelProductUnitIssue = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='UnitIssueDesc']")]
        internal readonly IWebElement? _fuelProductUnitIssueDesc = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='PriceMethod']")]
        internal readonly IWebElement? _fuelProductMarkUp= null;
      
        [FindsBy(How = How.XPath, Using = "//input[@name='PartNo']")]
        internal readonly IWebElement? _fuelProductAssociatedPart = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='PartDesc']")]
        internal readonly IWebElement? _fuelProductAssociatedPartDesc = null;


        [FindsBy(How = How.XPath, Using = "//input[@name='FuelType']")]
        internal readonly IWebElement? _fuelProductFuelType = null;
        

        [FindsBy(How = How.XPath, Using = "//input[@name='FuelTypeDesc']")]
        internal readonly IWebElement? _fuelProductFuelTypeDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='InsideBillItem']")]
        internal readonly IWebElement? _fuelInsideBillItem = null;
        

        [FindsBy(How = How.XPath, Using = "//input[@name='InsideBillDesc']")]
        internal readonly IWebElement? _fuelInsideBillItemDesc = null;


        [FindsBy(How = How.XPath, Using = "//input[@name='OutsideBillItem']")]
        internal readonly IWebElement? _fuelOutsideBillItem = null;
       
        [FindsBy(How = How.XPath, Using = "//input[@name='OutsideBillDesc']")]
        internal readonly IWebElement? _fuelOutsideBillItemDesc = null;

        [FindsBy(How = How.XPath, Using = " //input[@name='MarkUpBillItem']")]
        internal readonly IWebElement? _fuelMarkupBillItem = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='MarkUpBillDesc']")]
        internal readonly IWebElement? _fuelMarkupBillItemDesc = null;

        [FindsBy(How = How.XPath, Using = " //input[@name='UnitPr']")]
        internal readonly IWebElement? _fuelUnitPrice = null;

        [FindsBy(How = How.XPath, Using = " //input[@name='FlatMarkupPr']")]
        internal readonly IWebElement? _fuelFlatMarkupPrice = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='PctMarkup']")]
        internal readonly IWebElement? _fuelMarkupPrice = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='JobReason']")]
        internal readonly IWebElement? _jobReason = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='JobReasonDesc']")]
        internal readonly IWebElement? _jobReasonDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Job_Code']")]
        internal readonly IWebElement? _jobCode = null;       

        [FindsBy(How = How.XPath, Using = "//input[@name='JobDesc']")]
        internal readonly IWebElement? _jobCodeDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='CarwebFl']")]
        internal readonly IWebElement? _carWebProduct = null;
        
        [FindsBy(How = How.XPath, Using = "//select[@name='ApplyTaxAsFl']")]
        internal readonly IWebElement? _applyTax = null;
    }
}
