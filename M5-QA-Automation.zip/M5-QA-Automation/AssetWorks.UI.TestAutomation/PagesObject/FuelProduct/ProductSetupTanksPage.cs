﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct
{
    internal class ProductSetupTanksPage :BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal string _headerTankNo = "Tank No";

        public ProductSetupTanksPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }
        [FindsBy(How = How.Id, Using = "tTank_no$new_0")]
        internal readonly IWebElement? _tankNo = null;

        [FindsBy(How = How.Id, Using = "tProd_no$new_0")]
        internal readonly IWebElement? _productNo = null;

        [FindsBy(How = How.Id, Using = "tTank_Type$new_0")]
        internal readonly IWebElement? _productType = null;

        [FindsBy(How = How.Id, Using = "genloc")]  
        internal readonly IWebElement? _fuelLocation = null;

        [FindsBy(How = How.Id, Using = "tAdj_Acct$new_0")]
        internal readonly IWebElement? _adjAccount = null;

        [FindsBy(How = How.Id, Using = "EVRII_reqd$new_0")]
        internal readonly IWebElement? _checkBoxEVR = null;

        [FindsBy(How = How.Id, Using = "Content")]
        internal readonly IWebElement? _iframe = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='LocFuelTankTable']")]
        internal readonly IWebElement? _LocFuelTankTable = null;     

        [FindsBy(How = How.XPath, Using = "//iframe[@name='LocFuelTankFrame']")]
        internal readonly IWebElement? _LocFuelTankFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='LocFuelTankTable']//tbody//tr")]
        internal IList<IWebElement>? _LocFuelTankTableRows = null;
         internal IList<IWebElement>? _verifyTankNo(string TankNo) => Driver.FindElements(By.XPath($"//input[@value='{TankNo}']"));
    }
}
