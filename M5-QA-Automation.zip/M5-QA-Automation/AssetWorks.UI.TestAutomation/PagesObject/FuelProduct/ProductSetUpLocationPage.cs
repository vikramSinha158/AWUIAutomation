﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct
{
    internal class ProductSetUpLocationPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);


        public ProductSetUpLocationPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.Id, Using = "Loc")]
        internal readonly IWebElement? _location = null;

        [FindsBy(How = How.Id, Using = "Prod_No")]
        internal readonly IWebElement? _productNo = null;

        [FindsBy(How = How.Id, Using = "Tank_No")]
        internal readonly IWebElement? _tankNo = null;

        [FindsBy(How = How.Id, Using = "Max_Level_Qty")]
        internal readonly IWebElement? _maxQuantity = null;

        [FindsBy(How = How.Id, Using = "Min_Level_Qty")]
        internal readonly IWebElement? _minimumQuantity = null;

        [FindsBy(How = How.XPath, Using = "//a[text()='Detailed Information']")]
        internal readonly IWebElement? _detailedInformationTab = null;

        [FindsBy(How = How.XPath, Using = "//a[text()='Stock Status']")]
        internal readonly IWebElement? _stockStatusTab = null;

        [FindsBy(How = How.XPath, Using = "//a[text()='Use History']")]
        internal readonly IWebElement? _useHistory = null;

        [FindsBy(How = How.Id, Using = "Xaction_Pr")]
        internal readonly IWebElement? _perTransactionCharge = null;

        [FindsBy(How = How.Id, Using = "Unit_Pr")]
        internal readonly IWebElement? _unitPR = null;

        internal IWebElement? methodTrackingStock(string method) => Driver.FindElement(By.XPath($"//fieldset[@id='StockTracking']/label[contains(text(),'{method}')]/preceding-sibling::input[1]"));
        internal IWebElement? issueQuantityCalculation(string issue) => Driver.FindElement(By.XPath($"//fieldset[@id='IssueQtyCalc']/label[contains(text(),'{issue}')]/preceding-sibling::input[1]"));
    }
}
