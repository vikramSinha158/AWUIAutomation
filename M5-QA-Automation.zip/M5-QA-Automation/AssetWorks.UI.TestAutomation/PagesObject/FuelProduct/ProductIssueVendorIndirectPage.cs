﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct
{
    internal class ProductIssueVendorIndirectPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public ProductIssueVendorIndirectPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='Loc']")]
        internal readonly IWebElement? _location = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='IndAcct']")]
        internal readonly IWebElement? _indAcct = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Vendor_No']")]
        internal readonly IWebElement? _vendorNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='PO_No']")]
        internal IWebElement? _poNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Ref_No']")]
        internal readonly IWebElement? _refNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Invoice_No']")]
        internal readonly IWebElement? _invoiceNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='Tax']")]
        internal IWebElement? _tax = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ProdIssueFrame4']")]
        internal IWebElement? _prodIssueFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='ProdIssue4Table']")]
        internal IWebElement? _prodIssue4Table = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='ProdIssue4Table']//tbody//tr")]
        internal IList<IWebElement>? _prodIssue4TableRows = null;

    }
}
