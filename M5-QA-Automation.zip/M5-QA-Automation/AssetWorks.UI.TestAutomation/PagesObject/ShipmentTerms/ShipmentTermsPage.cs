﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;


namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Booking
{
    internal class ShipmentTermsPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        public ShipmentTermsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }
        [FindsBy(How = How.Id, Using = "code$new_0")]
        internal readonly IWebElement? _shipmentCode = null;

        [FindsBy(How = How.Id, Using = "desc$new_0")]
        internal readonly IWebElement? _shipmentCodeDesc = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ShipTermsFrame']")]
        internal readonly IWebElement? _iframeShipmentTerms = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='ShipTermsTable']")]
        internal readonly IWebElement? _ShipTermsTable = null;

      

        [FindsBy(How = How.XPath, Using = "//table[@id='BookingSourceCodesTable']//tbody//tr")]
        internal IList<IWebElement>? _bookingTableRows = null;
    }
}
