﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class WorkOrderExpressPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public WorkOrderExpressPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }


        [FindsBy(How = How.XPath, Using = "//input[@name='objNumber']")]
        internal readonly IWebElement? _woNumberInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='buildbutton']")]
        internal readonly IWebElement? _buildbutton = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='visitReq']")]
        internal readonly IWebElement? _visitReq = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='downtime']")]
        internal readonly IWebElement? _woStartDate = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='mrDataFrame11']")]
        internal readonly IWebElement? _mreJobFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='mrTable11']")]
        internal readonly IWebElement? _mreJobTable = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='cccCompleteBtn']")]
        internal readonly IWebElement? _completeBtn = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='cccCloseBtn']")]
        internal readonly IWebElement? _closeBtn = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='bWoNo']")]
        internal readonly IWebElement? _WoNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='UnitNo']")]
        internal readonly IWebElement? _compDeptUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='wonumber']")]
        internal readonly IWebElement? _wonumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='woStatus']")]
        internal readonly IWebElement? _woStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='woLocation']")]
        internal readonly IWebElement? _woLocation = null;

    }
}
