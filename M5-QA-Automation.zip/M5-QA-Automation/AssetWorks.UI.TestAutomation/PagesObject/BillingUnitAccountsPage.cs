﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class BillingUnitAccountsPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        public BillingUnitAccountsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='UnitNo']")]
        internal readonly IWebElement? _UnitNumber = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='BillItem']")]
        internal readonly IWebElement? _billDropdown = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='BillAcctExpFrame']")]
        internal readonly IWebElement? _frameExpenseaccount = null;
                
        [FindsBy(How = How.XPath, Using = "//table[@id='BillAcctExpTable']")]
        internal readonly IWebElement? _tableExpenseAccount = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='tblBillAcctRev']")]
        internal readonly IWebElement? _tableRevenueAccount = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='BillAcctRevFrame']")]
        internal readonly IWebElement? _frameRevenueAccount = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='BillExpAllocTable']")]
        internal readonly IWebElement? _tableExpenseAllocationAccount = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='BillExpAllocFrame']")]
        internal readonly IWebElement? _iframeExpenseAllocationAccount = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@id='Content2']")]
        internal readonly IWebElement? _iframeContent2ExpenseAllocation = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='closeC2Btn']")]
        internal readonly IWebElement? _Content2closebutton = null;

    }
}
