﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Driver
{
    internal class DriverStatusCodePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public DriverStatusCodePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        public static string _Code = "DRIVER_STATUS$new_";
        public static string _headerCode = "Code";
        internal IWebElement? _inactiveCheckBox = null;
        internal IWebElement? _disabledCheckBox = null;

        [FindsBy(How = How.Name, Using = "DriverStatusCodesFrame")]
        internal readonly IWebElement? _tableFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DriverStatusCodesTable']")]
        internal readonly IWebElement? _driverStatusCodeTable = null;
    }
}
