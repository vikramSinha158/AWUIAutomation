﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Driver
{
    internal class DriverTripEntryPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public DriverTripEntryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }
        //Driver Trip Entry
        [FindsBy(How = How.Id, Using = "DriverNo")]
        internal readonly IWebElement? _driverNo = null;

        [FindsBy(How = How.Id, Using = "START_DT")]
        internal readonly IWebElement? _startDate = null;

        [FindsBy(How = How.Id, Using = "END_DT")]
        internal readonly IWebElement? _endDate = null;

        [FindsBy(How = How.Id, Using = "START_MILES")]
        internal readonly IWebElement? _startMiles = null;

        [FindsBy(How = How.Id, Using = "END_MILES")]
        internal readonly IWebElement? _endMiles = null;

        [FindsBy(How = How.Id, Using = "BIZ_MILES")]
        internal readonly IWebElement? _businessMile = null;

        [FindsBy(How = How.Id, Using = "PERS_MILES")]
        internal readonly IWebElement? _personalMile = null;

        [FindsBy(How = How.Id, Using = "ALLOC_REASON")]
        internal readonly IWebElement? _AllocationReasonCode = null;

        //Vechile Details
        [FindsBy(How = How.Id, Using = "udcsel")]
        internal readonly IWebElement? _VechileTypeDropdown = null;

        [FindsBy(How = How.Id, Using = "UNIT_NO")]
        internal readonly IWebElement? _unitNumber = null;

        //Table Entry
        [FindsBy(How = How.Name, Using = "DriverTripEntryFrame")]
        internal readonly IWebElement? _tableFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DriverTripEntryTable']")]
        internal readonly IWebElement? _driverTripEntryTable = null;
    }
}
