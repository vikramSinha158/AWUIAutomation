﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Driver
{
    internal class DriverEventEntryPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public DriverEventEntryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }
        //Driver Event Entry
        [FindsBy(How = How.Id, Using = "DriverNo")]
        internal readonly IWebElement? _driverNo = null;

        [FindsBy(How = How.Id, Using = "DriverName")]
        internal readonly IWebElement? _driverName = null;

        [FindsBy(How = How.Id, Using = "StatusDesc")]
        internal readonly IWebElement? _statusDesc = null;

        [FindsBy(How = How.Id, Using = "EvttypCode")]
        internal readonly IWebElement? _evttypCode = null;

        [FindsBy(How = How.Id, Using = "EvttypDesc")]
        internal readonly IWebElement? _evttypDesc = null;

        [FindsBy(How = How.Id, Using = "EvtRank")]
        internal readonly IWebElement? _evtRank = null;

        [FindsBy(How = How.Id, Using = "EvtClsCode")]
        internal readonly IWebElement? _evtClsCode = null;

        [FindsBy(How = How.Id, Using = "EvtClsDesc")]
        internal readonly IWebElement? _evtClsDesc = null;

        [FindsBy(How = How.Id, Using = "EventDate")]
        internal readonly IWebElement? _eventDate = null;

        //Event Scheduling
        [FindsBy(How = How.Id, Using = "Planned_date")]
        internal readonly IWebElement? _plannedDate = null;

        [FindsBy(How = How.Id, Using = "Act_date")]
        internal readonly IWebElement? _actDate = null;

        [FindsBy(How = How.Id, Using = "Exp_date")]
        internal readonly IWebElement? _expDate = null;

        //Event Comments
        [FindsBy(How = How.Id, Using = "EvtDetail")]
        internal readonly IWebElement? _evtDetail = null;

        [FindsBy(How = How.Id, Using = "EvtPlace")]
        internal readonly IWebElement? _evtPlace = null;

        [FindsBy(How = How.Id, Using = "Evt_ref")]
        internal readonly IWebElement? _evtRef = null;

        [FindsBy(How = How.Id, Using = "Evt_comment")]
        internal readonly IWebElement? _evtComment = null;

        [FindsBy(How = How.Id, Using = "Evt_result")]
        internal readonly IWebElement? _evtResult = null;

        //Notes
        [FindsBy(How = How.Id, Using = "Evt_notes")]
        internal readonly IWebElement? _evtNotes = null;

        //Table Entry
        [FindsBy(How = How.Name, Using = "DriverEvtItemsFrame")]
        internal readonly IWebElement? _tableFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DriverEvtItemsTable']")]
        internal readonly IWebElement? _driverEvtItemsTable = null;
    }
}
