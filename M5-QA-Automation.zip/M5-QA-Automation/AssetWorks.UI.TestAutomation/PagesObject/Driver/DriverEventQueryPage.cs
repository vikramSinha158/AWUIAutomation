﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Driver
{
    internal class DriverEventQueryPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public DriverEventQueryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }
        //Driver Event Query
        [FindsBy(How = How.Id, Using = "DRIVER_NO")]
        internal readonly IWebElement? _driverNo = null;

        [FindsBy(How = How.Id, Using = "EVT_CLASS")]
        internal readonly IWebElement? _eventClass = null;

        [FindsBy(How = How.Id, Using = "EVT_TYPE")]
        internal readonly IWebElement? _eventType = null;

        [FindsBy(How = How.Id, Using = "fromDt")]
        internal readonly IWebElement? _StartDate = null;

        [FindsBy(How = How.Id, Using = "toDt")]
        internal readonly IWebElement? _endDate = null;

        [FindsBy(How = How.Id, Using = "selopt")]
        internal readonly IWebElement? _queryTypeDropdown = null;

        [FindsBy(How = How.Id, Using = "selmonths")]
        internal readonly IWebElement? _queryRange = null;

        [FindsBy(How = How.Id, Using = "Clear")]
        internal readonly IWebElement? _clearBtn = null;

        [FindsBy(How = How.Id, Using = "Retrieve")]
        internal readonly IWebElement? _RetrieveBtn = null;

        
        //Table Entry
        [FindsBy(How = How.Name, Using = "DriverEventQryFrame")]
        internal readonly IWebElement? _tableFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DriverEventQryTable']")]
        internal readonly IWebElement? _driverEvtQueryTable = null;
    }
}
