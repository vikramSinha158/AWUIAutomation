﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Driver
{
    internal class DriverLicenseTypePage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public DriverLicenseTypePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        public static string _headerLicenceTypeCode = "Code";

        internal IWebElement? _disabledCheckBox = null;

        [FindsBy(How = How.Id, Using = "issueAuthCode")]
        internal readonly IWebElement? _issuingAuthorityTxtBox = null;

        [FindsBy(How = How.Name, Using = "DriverLicenceTypesFrame")]
        internal readonly IWebElement? _tableFrame = null;

        [FindsBy(How = How.Name, Using = "Content")]
        internal readonly IWebElement? _contentFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DriverLicenceTypesTable']")]
        internal readonly IWebElement? _driverLicenceTypeTable = null;
    }
}
