﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class DriverClassCodesPage : BasePage
    {
        public static string BookingTypeCode { get; set; }
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public DriverClassCodesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.Id, Using = "DRIVER_CLASS$new_0")]
        internal readonly IWebElement? _driverClassCode= null;

        [FindsBy(How = How.Id, Using = "DESCRIPTION$new_0")]
        internal readonly IWebElement? _description = null;

        [FindsBy(How = How.Id, Using = "DISABLED_FL$new_0")]
        internal readonly IWebElement? _disabledCheckbox = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='DriverClassCodesTable']")]
        internal readonly IWebElement? _driverClassCodesTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='DriverClassCodesFrame']")]
        internal IWebElement? _driverClassCodesFrame = null;
    }
}
