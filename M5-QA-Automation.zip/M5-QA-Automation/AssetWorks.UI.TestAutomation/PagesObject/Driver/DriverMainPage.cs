﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Driver
{
    internal class DriverMainPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);
        public DriverMainPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//div[contains(@id,'dialog-area')]//p[1]")]
        internal readonly IWebElement? _dialogTitle = null;

        //Genderal Tab 

        [FindsBy(How = How.Id, Using = "EmployeeNo")]
        internal readonly IWebElement? _inputEmployeeID = null;

        [FindsBy(How = How.Id, Using = "txtEmployeeName")]
        internal readonly IWebElement? _inputEmployeeName = null;

        [FindsBy(How = How.Id, Using = "STATUS")]
        internal readonly IWebElement? _inputEmployeeStatusDropdown = null;

        [FindsBy(How = How.Id, Using = "OPERATOR_ID")]
        internal readonly IWebElement? _inputDriverNumber = null;

        [FindsBy(How = How.Id, Using = "TAX_FORM_ONFILE_FL")]
        internal readonly IWebElement? _inputTaxDropdown = null;

        [FindsBy(How = How.Id, Using = "LICENSENO")]
        internal readonly IWebElement? _inputLicenceNo = null;

        [FindsBy(How = How.Id, Using = "LICEXP_DT")]
        internal readonly IWebElement? _inputLicenceExpirtDate = null;

        [FindsBy(How = How.Id, Using = "HOMELOC")]
        internal readonly IWebElement? _inputHomeLocation = null;

        [FindsBy(How = How.Id, Using = "DEPT_NO")]
        internal readonly IWebElement? _inputDepartmentNo = null;

        [FindsBy(How = How.Id, Using = "txtDriverStatus")]
        internal readonly IWebElement? _inputDriverStatus = null;

        [FindsBy(How = How.Id, Using = "txtDriverType")]
        internal readonly IWebElement? _inputDriverType = null;

        [FindsBy(How = How.Id, Using = "txtDriverClass")]
        internal readonly IWebElement? _inputDriverClass = null;

        [FindsBy(How = How.Id, Using = "SHIFT_CODE")]
        internal readonly IWebElement? _inputShiftCode = null;

        [FindsBy(How = How.Id, Using = "Shift_Eff_Dt")]
        internal readonly IWebElement? _inputShiftEffectDate = null;

        [FindsBy(How = How.Id, Using = "ADDRESS1")]
        internal readonly IWebElement? _inputAddress = null;

        [FindsBy(How = How.Id, Using = "CITY")]
        internal readonly IWebElement? _inputCity = null;

        [FindsBy(How = How.Id, Using = "STATE")]
        internal readonly IWebElement? _inputState = null;

        [FindsBy(How = How.Id, Using = "ZIPCODE")]
        internal readonly IWebElement? _inputZipCode = null;

        [FindsBy(How = How.Id, Using = "REGION")]
        internal readonly IWebElement? _inputRegion = null;

        [FindsBy(How = How.Id, Using = "MUNICIPALITY")]
        internal readonly IWebElement? _inputMunicipality = null;

        [FindsBy(How = How.Id, Using = "COUNTY")]
        internal readonly IWebElement? _inputCounty = null;

        [FindsBy(How = How.Id, Using = "DRIVER_PHONE")]
        internal readonly IWebElement? _inputPhoneNumber = null;

        [FindsBy(How = How.Id, Using = "MOBILE")]
        internal readonly IWebElement? _inputMobileNumber = null;

        [FindsBy(How = How.Id, Using = "DRIVER_EMAIL_ADDRESS")]
        internal readonly IWebElement? _inputEmailAddress = null;

        [FindsBy(How = How.Id, Using = "DOB")]
        internal readonly IWebElement? _inputDOB = null;

        [FindsBy(How = How.Id, Using = "BIRTHPLACE")]
        internal readonly IWebElement? _inputBirthPlace = null;

        [FindsBy(How = How.Id, Using = "DATEJOIN")]
        internal readonly IWebElement? _inputDateOfJoin = null;

        [FindsBy(How = How.Id, Using = "TAXREF")]
        internal readonly IWebElement? _inputTaxRefarance = null;

        [FindsBy(How = How.Id, Using = "CALLSIGN")]
        internal readonly IWebElement? _inputCallSign = null;

        [FindsBy(How = How.Id, Using = "CONTACTDTL")]
        internal readonly IWebElement? _inputContactDetails = null;

        [FindsBy(How = How.Id, Using = "DRIVERREF")]
        internal readonly IWebElement? _inputDriverReference = null;

        [FindsBy(How = How.Id, Using = "DRIVER_PIN")]
        internal readonly IWebElement? _inputDriverPin = null;

        [FindsBy(How = How.Id, Using = "NEXTKIN")]
        internal readonly IWebElement? _inputNextKin = null;

        [FindsBy(How = How.Id, Using = "KINCONTACT")]
        internal readonly IWebElement? _inputKinContact = null;

        [FindsBy(How = How.Id, Using = "empNotes")]
        internal readonly IWebElement? _inputNote = null;

        //License Tab

        [FindsBy(How = How.Name, Using = "mrDataFrame17")]
        internal readonly IWebElement? _iframeTableLicenseItem = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='mrTable17']")]
        internal readonly IWebElement? _driverLicenseItemTable = null;

        internal string _headerAuthority = "Authority";

        [FindsBy(How = How.Name, Using = "mrDataFrame20")]
        internal readonly IWebElement? _iframeTableLicenseClasses = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='mrTable20']")]
        internal readonly IWebElement? _driverLicenseClassesTable = null;

        internal string _headerCode = "Code";
        
        //Motor pool tab

        internal string _headerMotorPool = "Motor Pool Class";

        [FindsBy(How = How.Id, Using = "restMPReservation")]
        internal readonly IWebElement? _restMPReservationCheckBox = null;

        [FindsBy(How = How.Name, Using = "mrDataFrame22")]
        internal readonly IWebElement? _iframeTableMotorPoolClasses = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='mrTable22']")]
        internal readonly IWebElement? _driverMotorPoolClassTable = null;

        //Attachments page

        [FindsBy(How = How.Id, Using = "attachbutton")]
        internal readonly IWebElement? _attachButton = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ShowAttachmentsFrame']")]
        internal readonly IWebElement? _showAttachmentsFrame = null;

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Attach a new file')]")]
        internal readonly IWebElement? _attachNewFile = null;

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Attach a web address')]")]
        internal readonly IWebElement? _attachWebAddress = null;

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Attach a previously uploaded file or web address')]")]
        internal readonly IWebElement? _attachExistingFile = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='theFile']")]
        internal readonly IWebElement? _chooseFile = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='theDesc']")]
        internal readonly IWebElement? _FileDesc = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='newAttButton']")]
        internal readonly IWebElement? _attachNewFileBtn = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='assocFile']")]
        internal readonly IWebElement? _previousUploadedFile = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='theUrl']")]
        internal readonly IWebElement? _webAddress = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='theDesc']")]
        internal readonly IWebElement? _webAddressDesc = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='attButton']")]
        internal readonly IWebElement? _attachAddressBtn = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@id='Content2']")]
        internal IWebElement? _contentFrame2 = null;

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'OK')]")]
        internal readonly IWebElement? _OkBtn = null;

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Associate')]")]
        internal readonly IWebElement? _associateBtn = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='attachTable']")]
        internal readonly IWebElement? _attachTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ShowAttachmentsFrame']")]
        internal IWebElement? _attachTableFrame = null;

        internal string _headerDescription = "Description";
    }
}
