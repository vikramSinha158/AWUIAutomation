﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Driver
{
    internal class DriverEventClassesPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        public DriverEventClassesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        public static string _headerClass = "Class";

        internal IWebElement? _disabledCheckBox = null;

        [FindsBy(How = How.Name, Using = "DriverEventClassesFrame")]
        internal readonly IWebElement? _tableFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EventClassesTable']")]
        internal readonly IWebElement? _driverEventClassTable = null;
    }
}
