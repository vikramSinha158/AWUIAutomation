﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class PurchaseRequisitionsPage : BasePage
    {
        internal string _ResvRefNo = "Resv Ref No";
        internal ExtendedPageActions ExtendedPage => new ExtendedPageActions(Driver);

        public PurchaseRequisitionsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='reqno']")]
        internal readonly IWebElement? _reqNoInput = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='reqStatus']")]
        internal readonly IWebElement? _reqStatus = null;

        [FindsBy(How = How.XPath, Using = "//button[@name='newReq']")]
        internal readonly IWebElement? _newReqButton = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='hvendor']")]
        internal readonly IWebElement? _hvendorInput = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='chargeCode']")]
        internal readonly IWebElement? _hresvCodeSelect= null;

        [FindsBy(How = How.XPath, Using = "//input[@name='hQuoted']")]
        internal readonly IWebElement? _hQuotedCheckBox = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='vendor_fl']")]
        internal readonly IWebElement? _hvendorCheckBox = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='special_fl']")]
        internal readonly IWebElement? _specialCheckBox = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PRequisitionFrame']")]
        internal readonly IWebElement? _pRequisitionFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PartTable']")]
        internal readonly IWebElement? _prPartTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PartRequestListFrame']")]
        internal readonly IWebElement? _framePartRequest = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='RequestListTable']")]
        internal readonly IWebElement? _tableRequestList = null;


        internal IWebElement? _inputNewPartNo(string row) => Driver.FindElement(By.XPath($"//input[@id='PartNo$new_{row}']"));
        internal IWebElement? _inputNewQuantity(string row) => Driver.FindElement(By.XPath($"//input[@id='qty$new_{row}']"));
        internal IWebElement? _inputNewUnitCost(string row) => Driver.FindElement(By.XPath($"//input[@id='cpunitcost$new_{row}']"));
        internal IWebElement? _inputNewNeededBy(string row) => Driver.FindElement(By.XPath($"//input[@id='needby$new_{row}']"));
        internal IWebElement? _inputNewResvCode(string row) => Driver.FindElement(By.XPath($"//select[@id='chargeCodeI$new_{row}']"));
        internal IWebElement? _inputNewResvRefNo(string row) => Driver.FindElement(By.XPath($"//input[@id='typeNumI$new_{row}']"));
        internal IWebElement? _inputNewRefNo(string row) => Driver.FindElement(By.XPath($"//input[@id='lineRefNo$new_{row}']"));
        internal IWebElement? _inputNewContract(string row) => Driver.FindElement(By.XPath($"//input[@id='contract$new_{row}']"));
        internal IWebElement? _inputNewNoteBtn(string row) => Driver.FindElement(By.XPath($"//button[@id='noteBtn$new_{row}']"));
        internal IWebElement? _inputNewQuoted(string row) => Driver.FindElement(By.XPath($"//input[@id='Quoted$new_{row}']"));
    }
}
