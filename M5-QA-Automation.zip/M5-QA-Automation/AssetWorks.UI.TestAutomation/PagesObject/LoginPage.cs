﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using NUnit.Framework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.TestAutomation.PagesObject
{
    [TestFixture]
    internal class LoginPage :BasePage
    {
        public LoginPage(IWebDriver Driver):base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='username']")]
        internal IWebElement? _userName =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='pwFld']")]
        internal IWebElement? _password =null;

        [FindsBy(How = How.XPath, Using = "//button[@id='contBtn']")]
        internal IWebElement? _loginButton =null;
      
        [FindsBy(How = How.XPath, Using = "//input[@name='loc']")]
        internal IWebElement? _location =null;

        [FindsBy(How = How.XPath, Using = "//button[@id='myLogoffButton']")]
        internal IWebElement? _loggOff = null;

    }
}
