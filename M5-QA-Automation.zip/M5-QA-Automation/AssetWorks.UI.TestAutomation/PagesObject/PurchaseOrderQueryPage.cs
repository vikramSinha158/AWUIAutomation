﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class PurchaseOrderQueryPage : BasePage
    {
        internal ExtendedPageActions ExtendedPage => new ExtendedPageActions(Driver);

        public PurchaseOrderQueryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='loc']")]
        internal readonly IWebElement? _inputLocation = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='status']")]
        internal readonly IWebElement? _selectStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='dept']")]
        internal readonly IWebElement? _inputDepartment = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='reqNum']")]
        internal readonly IWebElement? _inputRequisitionNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='vendor']")]
        internal readonly IWebElement? _inputVendor = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='PartNo']")]
        internal readonly IWebElement? _inputPartNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='pono']")]
        internal readonly IWebElement? _inputPoNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='poFromDt']")]
        internal readonly IWebElement? _inputPoFromDt = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='poToDt']")]
        internal readonly IWebElement? _inputPoToDt = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='RetrieveBtn']")]
        internal IWebElement? _buttonRetrieve = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ClearBtn']")]
        internal IWebElement? _buttonClear = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='POListFrame']")]
        internal readonly IWebElement? _framePOList = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='POListTable']")]
        internal readonly IWebElement? _tablePOList = null;


        //Purchase Order Detail 
        [FindsBy(How = How.XPath, Using = "//input[@id='CloseBtn']")]
        internal readonly IWebElement? _buttonClosePO = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CancelBtn']")]
        internal readonly IWebElement? _buttonCancelPO = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='PODetailFrame']")]
        internal readonly IWebElement? _framePODetail = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='PODetailTable']")]
        internal readonly IWebElement? _tablePODetail = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='close$0']")]
        internal readonly IWebElement? _buttonCloseLine1 = null;
    }
}
