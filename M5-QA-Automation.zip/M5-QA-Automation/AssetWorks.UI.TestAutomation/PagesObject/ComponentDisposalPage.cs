﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class ComponentDisposalPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        public ComponentDisposalPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='CompNo']")]
        internal readonly IWebElement? _compNoInput = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='DIS_STATUS_CD']")]
        internal readonly IWebElement? _disposalStatusDd = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DISPOSAL_REASON']")]
        internal readonly IWebElement? _disposalreason = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='EST_DIS_DT']")]
        internal readonly IWebElement? _estimatedDate = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab1']")]
        internal readonly IWebElement? _notesTab = null;

        [FindsBy(How = How.XPath, Using = "//a[@href='#divTab2']")]
        internal readonly IWebElement? _salesTab = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='DIS_DT']")]
        internal readonly IWebElement? _disposalDate = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='NOTES']")]
        internal readonly IWebElement? _note = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='STATUS']")]
        internal readonly IWebElement? _status = null;

    }
}
