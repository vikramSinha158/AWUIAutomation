﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class AvailabilityStatusCodesPage : BasePage
    {
        public AvailabilityStatusCodesPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        internal ExtendedPageActions ExtendedPage => new(Driver);

        [FindsBy(How = How.XPath, Using = "//iframe[@name='OperStatusCodeFrame']")]
        internal IWebElement? _frameStatusCode = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='OperStatusCodeTable']/tbody")]
        internal IWebElement? _tableStatusCode = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='operStatus$new_0']")]
        internal IWebElement? _inputStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='dispCode$new_0']")]
        internal IWebElement? _inputDispositionCode	 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='desc$new_0']")]
        internal IWebElement? _inputDescription = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='waitformatefl$new_0']")]
        internal IWebElement? _checkboxWaitForMateFlag = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='disabled$new_0']")]
        internal IWebElement? _checkboxDisabled = null;
    }
}
