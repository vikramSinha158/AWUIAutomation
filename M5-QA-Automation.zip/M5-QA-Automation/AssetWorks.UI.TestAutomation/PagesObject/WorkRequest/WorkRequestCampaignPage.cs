﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.WorkRequest
{
    internal class WorkRequestCampaignPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public WorkRequestCampaignPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.Id, Using = "newCAMP")]
        internal IWebElement? _newCampaign = null;

        [FindsBy(How = How.Id, Using = "CampaignDesc")]
        internal IWebElement? _campaignDesc = null;

        [FindsBy(How = How.Id, Using = "JobCode")]
        internal IWebElement? _jobCode = null;

        [FindsBy(How = How.Id, Using = "JobCodeDesc")]
        internal IWebElement? _jobCodeDesc = null;

        [FindsBy(How = How.Id, Using = "VisitReason")]
        internal IWebElement? _jobReason = null;

        [FindsBy(How = How.XPath, Using = "JobReasonDesc")]
        internal IWebElement? _jobReasonDesc = null;

        [FindsBy(How = How.Id, Using = "EarlDate")]
        internal IWebElement? _earlDate = null;

        [FindsBy(How = How.Id, Using = "PreferDate")]
        internal IWebElement? _preferDate = null;

        [FindsBy(How = How.Id, Using = "LatestDate")]
        internal IWebElement? _latestDate = null;

        [FindsBy(How = How.Id, Using = "CampaignNo")]
        internal IWebElement? _inputCampaignNo = null;

        [FindsBy(How = How.Id, Using = "CampaignState")]
        internal IWebElement? _campaignState = null;
        
        internal IWebElement? _dailogText(string campaignNo) => Driver.FindElement(By.XPath($"//p[text()='Campaign Number {campaignNo} does not exist?']"));

        [FindsBy(How = How.Id, Using = "ReportedBy")]
        internal IWebElement? _reportedBy = null;

        [FindsBy(How = How.Id, Using = "ConPhone")]
        internal IWebElement? _contactPhone = null;

        [FindsBy(How = How.Id, Using = "ReqRef")]
        internal IWebElement? _reqRef = null;

        [FindsBy(How = How.Id, Using = "DirAcct")]
        internal IWebElement? _dirAcct = null;

        [FindsBy(How = How.Id, Using = "MaintLoc")]
        internal IWebElement? _maintLoc = null;

        [FindsBy(How = How.Id, Using = "CrewSize")]
        internal IWebElement? _crewSize = null;

        [FindsBy(How = How.Id, Using = "SpanShiftsfl")]
        internal IWebElement? _spanShiftsflChk = null;

        [FindsBy(How = How.Id, Using = "SpreadDueDt")]
        internal IWebElement? _spreadDueDt = null;

        [FindsBy(How = How.Id, Using = "SendToVendor")]
        internal IWebElement? _sendToVendorChk = null;

        [FindsBy(How = How.Id, Using = "Notes")]
        internal IWebElement? _notes = null;

        [FindsBy(How = How.Id, Using = "complaintNote")]
        internal IWebElement? _complaintNote = null;

        [FindsBy(How = How.Id, Using = "causeNote")]
        internal IWebElement? _causeNote = null;

        [FindsBy(How = How.Id, Using = "correctNote")]
        internal IWebElement? _correctNote = null;

        [FindsBy(How = How.Id, Using = "previewBtn")]
        internal IWebElement?_previewBtn = null;

        [FindsBy(How = How.Id, Using = "customizeBtn")]
        internal IWebElement? _customizeBtn = null;

        [FindsBy(How = How.Id, Using = "finalizeBtn")]
        internal IWebElement? _finalizeBtn = null;

        [FindsBy(How = How.Id, Using = "updateBtn")]
        internal IWebElement? _updateBtn = null;

        [FindsBy(How = How.Id, Using = "unlockBtn")]
        internal IWebElement? _unlockBtn = null;

        [FindsBy(How = How.Name, Using = "ReportFilterFrame")]
        internal IWebElement? _reportFilterFrame = null;

        [FindsBy(How = How.Id, Using = "filterTable")]
        internal IWebElement? _filterTable = null;
        internal IWebElement? _enabledCheckbox(string fieldName) => Driver.FindElement(By.XPath($"//span[text()='{fieldName}']/ancestor:: tr//input[@type='checkbox']"));
        internal IWebElement? _operator(string fieldName) => Driver.FindElement(By.XPath($"//span[text()='{fieldName}']/ancestor:: tr//select"));
        internal IWebElement? _fieldValue(string fieldName) => Driver.FindElement(By.XPath($"//span[text()='{fieldName}']/ancestor:: tr//input[contains(@id,'fv')]"));


    }
}
