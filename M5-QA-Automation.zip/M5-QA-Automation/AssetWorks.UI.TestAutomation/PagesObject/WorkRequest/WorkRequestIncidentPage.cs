﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.WorkRequest
{
    public class WorkRequestIncidentPage: BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        public WorkRequestIncidentPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.Id, Using = "udcsel")]
        internal IWebElement? _selectWRType = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='UnitNo']")]
        internal IWebElement? _inputWRUnitNo = null;

        [FindsBy(How = How.Id, Using = "cbNew")]
        internal IWebElement? _newIncidentBtn = null;

        [FindsBy(How = How.Id, Using = "IncidentNumber")]
        internal IWebElement? _incidentNo = null;

        [FindsBy(How = How.Id, Using = "Note")]
        internal IWebElement? _note = null;

        [FindsBy(How = How.Id, Using = "Status")]
        internal IWebElement? _status = null;

        [FindsBy(How = How.Id, Using = "failState")]
        internal IWebElement? _failState = null;

        [FindsBy(How = How.Id, Using = "ReportedBy")]
        internal IWebElement? _reportedBy = null;

        [FindsBy(How = How.Id, Using = "Phone")]
        internal IWebElement? _phone = null;

        [FindsBy(How = How.Id, Using = "Source")]
        internal IWebElement? _source = null;

        [FindsBy(How = How.Id, Using = "Symptom")]
        internal IWebElement? _symptom = null;

        [FindsBy(How = How.Id, Using = "Priority")]
        internal IWebElement? _priority = null;

        [FindsBy(How = How.Id, Using = "Zone")]
        internal IWebElement? _zone = null;

        [FindsBy(How = How.Id, Using = "Component")]
        internal IWebElement? _compoment = null;

        [FindsBy(How = How.Id, Using = "Condition")]
        internal IWebElement? _condition = null;

        [FindsBy(How = How.Id, Using = "Run")]
        internal IWebElement? _run = null;

        [FindsBy(How = How.Id, Using = "Block")]
        internal IWebElement? _block = null;

        [FindsBy(How = How.Id, Using = "ServiceDate")]
        internal IWebElement? _serviceDate = null;

        [FindsBy(How = How.Id, Using = "Parkloc")]
        internal IWebElement? _parkingLoction = null;

        [FindsBy(How = How.Id, Using = "MaintLoc")]
        internal IWebElement? _mainLocation = null;

        [FindsBy(How = How.Id, Using = "DeptMaintLoc")]
        internal IWebElement? _deptMaintLoc = null;

        [FindsBy(How = How.Id, Using = "DateTime")]
        internal IWebElement? _openDateTime = null;

        [FindsBy(How = How.Id, Using = "StatusChange")]
        internal IWebElement? _lastStatusChange = null;

        [FindsBy(How = How.Id, Using = "IncStatusChange")]
        internal IWebElement? _lastIncidentStatusChange = null;

        [FindsBy(How = How.Id, Using = "wrtextno")]
        internal IWebElement? _wrTextNo = null;

        [FindsBy(How = How.Id, Using = "wrlink")]
        internal IWebElement? _wrLink = null;

        [FindsBy(How = How.Id, Using = "wolink")]
        internal IWebElement? _woLink = null;

        [FindsBy(How = How.Id, Using = "wotextno")]
        internal IWebElement? _woTextNo = null;

        //Work Request
        [FindsBy(How = How.Id, Using = "sjob")]
        internal IWebElement? _wrJob = null;

        [FindsBy(How = How.Id, Using = "slocation")]
        internal IWebElement? _wrLocation = null;

        [FindsBy(How = How.Id, Using = "sjobreason")]
        internal IWebElement? _wrJobReason = null;

        [FindsBy(How = How.Id, Using = "sestcost")]
        internal IWebElement? _wrEstCost = null;

        [FindsBy(How = How.Id, Using = "sesthour")]
        internal IWebElement? _wrEstLabor = null;

        [FindsBy(How = How.Id, Using = "EmpCrew")]
        internal IWebElement? _wrEmployee = null;

        [FindsBy(How = How.Id, Using = "btnwr")]
        internal IWebElement? _btnProcessWR = null;
    }
}
