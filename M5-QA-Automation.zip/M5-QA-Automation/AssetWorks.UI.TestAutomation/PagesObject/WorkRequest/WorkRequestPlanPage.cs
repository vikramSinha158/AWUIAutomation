﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;


namespace AssetWorks.UI.M5.TestAutomation.PagesObject.WorkRequest
{
    internal class WorkRequestPlanPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);       

        public WorkRequestPlanPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.Id, Using = "WorkPlanNo")]
        internal readonly IWebElement? _workPlanNo = null;

        [FindsBy(How = How.Id, Using = "cbNewWorkPlan")]
        internal readonly IWebElement? _newWorkPlan = null;

        [FindsBy(How = How.Id, Using = "PLAN_DT")]
        internal readonly IWebElement? _planDT = null;

        [FindsBy(How = How.Id, Using = "PLAN_DESCRIPTION")]
        internal readonly IWebElement? _planDESCRIPTION = null;

        [FindsBy(How = How.Id, Using = "UnitNo")]
        internal readonly IWebElement? _unitNo = null;

        [FindsBy(How = How.Id, Using = "DUE_WITHIN")]
        internal readonly IWebElement? _dueWITHIN = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='WorkPlanAssignedFrame']")]
        internal readonly IWebElement? _workPlanAssignedFrame = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='WorkPlanUnassignedFrame']")]
        internal readonly IWebElement? _workPlanUnassignedFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='WorkPlanUnassignedTable']")]
        internal readonly IWebElement? _workPlanUnassignedTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='WorkPlanAssignedTable']")]
        internal readonly IWebElement? _workPlanAssignedTable = null;








        [FindsBy(How = How.XPath, Using = "//input[@name='RefNo']")]
        internal readonly IWebElement? _refNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='orderDt']")]
        internal readonly IWebElement? _orderDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='discount']")]
        internal readonly IWebElement? _discount = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='proNumber']")]
        internal readonly IWebElement? _proNumber = null;

      

        [FindsBy(How = How.XPath, Using = "//iframe[@name='KitPartsFrame']")]
        internal readonly IWebElement? _partListFrame = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ContentM']")]
        internal readonly IWebElement? _partListContentFrame = null;

        [FindsBy(How = How.Id, Using = "KitPartsTable")]
        internal readonly IWebElement? _partListTable = null;

       

        [FindsBy(How = How.XPath, Using = "//span[text()='Part Kit List']")]
        internal IWebElement? _partKitLink = null;

        public IWebElement? _PartQuantity(int i) => Driver.FindElement(By.Id($"ShpQty${i}"));

        //public IWebElement? _PartQuantity(int i) => Driver.FindElement(By.Id($"pQty$new_{i}"));

        [FindsBy(How = How.XPath, Using = "//input[@name='PartNo$new_0']")]
        internal readonly IWebElement? _partNumber = null;

        [FindsBy(How = How.XPath, Using = "//input[@type='search']")]
        internal IWebElement? _searchtext = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='lovBodyTable']/tbody/tr/td/span")]
        internal IWebElement? _firstListItem = null;

        [FindsBy(How = How.Id, Using = "showFilterButton")]
        internal IWebElement? _showFilterButton = null;
    }
}
