﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool
{
    internal class MotorpoolUnitsListedByLocationPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal MotorpoolUnitsListedByLocationPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='MPLocation']")]
        internal IWebElement? _inputMPLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MPLocDesc']")]
        internal IWebElement? _inputMPLocationDesc = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='MPUnitLocationFrame']")]
        internal IWebElement? _frameMPUnitLocation = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='MPUnitLocationTable']//tbody")]
        internal IWebElement? _tableMPUnitLocation = null;
    }
}
