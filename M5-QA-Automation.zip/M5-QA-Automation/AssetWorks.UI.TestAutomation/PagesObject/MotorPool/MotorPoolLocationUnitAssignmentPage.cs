﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool
{
    internal class MotorPoolLocationUnitAssignmentPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal MotorPoolLocationUnitAssignmentPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='noLocation']")]
        internal IWebElement? _inputNoLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='noClass']")]
        internal IWebElement? _inputNoClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='noLocationClass']")]
        internal IWebElement? _inputNoLocationClass = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='MPLocUnitsFrame']")]
        internal IWebElement? _frameMPLocUnits = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='MPLocUnitsTable']//tbody")]
        internal IWebElement? _tableMPLocUnits = null;
    }
}
