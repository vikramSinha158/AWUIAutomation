﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool
{
    internal class MotorPoolAssignUnitPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal MotorPoolAssignUnitPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='aUnitNo']")]
        internal IWebElement? _inputUnitNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='button2']")]
        internal IWebElement? _buttonRetrieve = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='button1']")]
        internal IWebElement? _buttonClear = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='MPAssignUnitFrame']")]
        internal IWebElement? _frameAssignUnit = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='MPAssignUnitTable']//tbody")]
        internal IWebElement? _tableAssignUnit = null;
    }
}
