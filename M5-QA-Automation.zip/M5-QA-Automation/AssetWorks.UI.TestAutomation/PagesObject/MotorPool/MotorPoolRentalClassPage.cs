﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool
{
    internal class MotorPoolRentalClassPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal MotorPoolRentalClassPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@name='MPRentalClassFrame']")]
        internal IWebElement? _frameMPRentalClass = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='MotorPoolTable']/tbody")]
        internal IWebElement? _tableMotorPool = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='class$new_0']")]
        internal IWebElement? _inputNewClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='description$new_0']")]
        internal IWebElement? _inputNewDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='prep_duration$new_0']")]
        internal IWebElement? _inputNewPrepDuration = null;

        //Motor Pool Confirmation Codes
        [FindsBy(How = How.XPath, Using = "//input[@id='cRentalClass']")]
        internal IWebElement? _inputRentalClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='cRentalClassDesc']")]
        internal IWebElement? _inputRentalClassDesc = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='MPConfirmCodeFrame']")]
        internal IWebElement? _frameMPConfirmCode = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='MPConfirmCodeTable']/tbody")]
        internal IWebElement? _tableMPConfirmCode = null;
    }
}
