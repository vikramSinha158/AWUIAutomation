﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool
{
    internal class MotorPoolReservationPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal MotorPoolReservationPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='MP_Ticket_No']")]
        internal IWebElement? _inputTicketNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='newMP']")]
        internal IWebElement? _buttonNewTicket = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MPStatus']")]
        internal IWebElement? _inputMPStatus = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Pickup_Location']")]
        internal IWebElement? _selectPickupLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Pickup_Date_Time']")]
        internal IWebElement? _inputPickupDateTime = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Return_Location']")]
        internal IWebElement? _selectReturnLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Return_Date_Time']")]
        internal IWebElement? _inputReturnDateTime = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='CONFIRMATION_CODE']")]
        internal IWebElement? _inputConfirmationCode = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Rental_Class']")]
        internal IWebElement? _selectRentalClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Reserved_For']")]
        internal IWebElement? _inputReservedFor = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='Dept_No']")]
        internal IWebElement? _selectDepartment = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Phone_No']")]
        internal IWebElement? _inputPhoneNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Ref_No']")]
        internal IWebElement? _inputRefNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Destination']")]
        internal IWebElement? _inputDestination = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Requested_By']")]
        internal IWebElement? _inputRequestedBy = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Reason']")]
        internal IWebElement? _inputReason = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Account_No']")]
        internal IWebElement? _inputAccountNo = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@id='Reserve_Notes']")]
        internal IWebElement? _inputReserveNotes = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MPApproverNo']")]
        internal IWebElement? _inputTicketApprover = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='MPApproverName']")]
        internal IWebElement? _inputApproverName = null;
    }
}
