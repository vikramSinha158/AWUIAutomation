﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool
{
    internal class MotorPoolReservationAssignmentPage : BasePage
    {
        internal ExtendedPageActions ExtendedPage => new (Driver);

        internal readonly string headerTicket = "Ticket";

        internal MotorPoolReservationAssignmentPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='mploc']")]
        internal IWebElement? _inputPickupLocation = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='MPAssignFrame']")]
        internal IWebElement? _frameMPAssign = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='MotorPoolTable']")]
        internal IWebElement? _tableMotorPool = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Reserved_For']")]
        internal IWebElement? _inputReservedFor = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Reserved_For_Desc']")]
        internal IWebElement? _inputReservedForDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='Dept_No']")]
        internal IWebElement? _inputDepartment = null;

    }
}
