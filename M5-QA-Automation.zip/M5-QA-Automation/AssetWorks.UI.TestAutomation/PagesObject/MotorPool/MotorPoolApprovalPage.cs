﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool
{
    internal class MotorPoolApprovalPage : BasePage
    {
        internal readonly string _headerTicketNo = "MP\r\nTicket";
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal MotorPoolApprovalPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='aReserved_For']")]
        internal IWebElement? _inputReservedFor = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='aDept_No']")]
        internal IWebElement? _inputRequestDept = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='aPickup_Location']")]
        internal IWebElement? _inputPickupLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='aRental_Class']")]
        internal IWebElement? _inputRentalClass = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='aMP_Ticket_No']")]
        internal IWebElement? _inputMpTicketNo = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='button1']")]
        internal IWebElement? _btnClear = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='button2']")]
        internal IWebElement? _btnRetrieve = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='MPApprovalFrame']")]
        internal IWebElement? _frameMPApproval = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='MPApprovalTable']/tbody")]
        internal IWebElement? _tableMPApproval = null;
    }
}
