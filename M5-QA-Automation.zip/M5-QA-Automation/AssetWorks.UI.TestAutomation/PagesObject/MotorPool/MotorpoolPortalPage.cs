﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool
{
    internal class MotorpoolPortalPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal MotorpoolPortalPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//span[@id='goBtn3']")]
        internal IWebElement? _ViewYourProfile = null;

        [FindsBy(How = How.XPath, Using = "//span[@id='goBtn5']")]
        internal IWebElement? _ViewOrCancelCurrentReservations = null;

        [FindsBy(How = How.XPath, Using = "//span[@id='goBtn7']")]
        internal IWebElement? _MakeaNewReservation = null;

        [FindsBy(How = How.XPath, Using = "//span[@id='goBtn9']")]
        internal IWebElement? _Logoff = null;

        [FindsBy(How = How.XPath, Using = "//div[@id='WRPx2x0']//span")]
        internal IWebElement? _ReturnToMainScreen = null;

        //Motorpool Profile
        [FindsBy(How = How.XPath, Using = "//input[@id='ddNo']")]
        internal IWebElement? _inputDriverNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ddName']")]
        internal IWebElement? _inputDriverName = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ddEmail']")]
        internal IWebElement? _inputEmail = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ddPhoneNo']")]
        internal IWebElement? _inputPhoneNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ddAddress1']")]
        internal IWebElement? _inputAddress1 = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='ddAddress2']")]
        internal IWebElement? _inputAddress2 = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='ddSaveBtn5']")]
        internal IWebElement? _btnSave = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='ddCancelBtn5']")]
        internal IWebElement? _btnCancel = null;

        //Current Reservations
        [FindsBy(How = How.XPath, Using = "//iframe[@name='mrDataFrame5']")]
        internal IWebElement? _framemrData = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='mrTable5']")]
        internal IWebElement? _tablemrData = null;

        [FindsBy(How = How.XPath, Using = "//button[text()= ' Cancel Reservation']")]
        internal IWebElement? _btnCancelReservation = null;

        [FindsBy(How = How.XPath, Using = "//a[text()= 'Email Ticket']")]
        internal IWebElement? _btnEmailTicket = null;

        //New Reservation
        [FindsBy(How = How.XPath, Using = "//input[@id='date_pickup']")]
        internal IWebElement? _inputPickupDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='date_return']")]
        internal IWebElement? _inputReturnDate = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='loc_pickup']")]
        internal IWebElement? _selectPickupLoc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='rloc_same']")]
        internal IWebElement? _chkboxSame = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='loc_return']")]
        internal IWebElement? _selectReturnLoc = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='caAvailTbl']//td/span")]
        internal IWebElement? _btnRentalClass = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='newResvBtn']")]
        internal IWebElement? _btnCreateReservation = null;

        [FindsBy(How = How.XPath, Using = "//span[@id='crConfMsg']")]
        internal IWebElement? _txtConfMsg = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='cfTicket']")]
        internal IWebElement? _inputNewTicket = null;

        [FindsBy(How = How.XPath, Using = "//body")]
        internal IWebElement? _txtLogoff = null;
    }
}
