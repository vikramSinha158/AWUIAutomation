﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class ComponentAssignmentHistoryPage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal string _DepartmentHeaderName = "Department";
       
        public ComponentAssignmentHistoryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='CompNo']")]
        internal IWebElement? _componenNotInput = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='OwningDeptFrame']")]
        internal IWebElement? _DeptFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='OwningDeptTable']")]
        internal IWebElement? _deptTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='OwningDeptTable']//tbody//tr")]
        internal IList<IWebElement>? _DeptTableRows = null;
    }
}
