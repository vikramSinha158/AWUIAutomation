﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    /// <summary>
    /// Page object class for Employee Shift Assign
    /// </summary>
    internal class EmployeeShiftAssignmentPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        
        internal EmployeeShiftAssignmentPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }     

        //General Tab
        [FindsBy(How = How.XPath, Using = "//input[@id='EmployeeNo']")]
        internal readonly IWebElement? _inputEmpID =null;

        [FindsBy(How = How.XPath, Using = "//input[@id='shiftCode$new_0']")]
        internal readonly IWebElement? _shiftCode =null; 

        [FindsBy(How = How.XPath, Using = "//input[@id='shiftDesc$new_0']")]
        internal readonly IWebElement? _shiftDesc = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='effDt$new_0']")]
        internal readonly IWebElement? _effDt = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='ShiftAssignTable']")]
        internal readonly IWebElement? _shiftAssignTable = null;
        
        [FindsBy(How = How.XPath, Using = "//table[@id='ShiftAssignTable']/tbody/tr")]
        internal readonly IWebElement? _shiftAssignTableRows = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ShiftAssignFrame']")]
        internal readonly IWebElement? _shiftAssignFrame = null;
    }
}
