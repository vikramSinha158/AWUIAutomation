﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class EmployeeCourseQueryPage : BasePage
    {
        internal string Course = "Course";
        internal string Location = "Location";
        internal string Employee = "Employee";
        internal string ResourceType = "resourceType";
        internal string VendorNo = "vendorNo";               
        internal string DatePlanned = "DatePlanned";
        internal string DateAttended = "DateAttended";
        internal string NextDate = "NextDate";
        internal string Mark = "Mark";
        internal string Result = "Result";
        internal string Certificate = "Certificate";      

        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public EmployeeCourseQueryPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='course']")]
        internal readonly IWebElement? _course = null;       

        [FindsBy(How = How.XPath, Using = "//input[@name='location']")]
        internal readonly IWebElement? _location = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='employee']")]
        internal readonly IWebElement? _employee = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='resourceType']")]
        internal readonly IWebElement? _resourceType = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='attPlanNext']")]
        internal readonly IWebElement? _attPlanNext = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='vendorNo']")]
        internal readonly IWebElement? _vendorNo = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='fromDate']")]
        internal readonly IWebElement? _fromDate = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='toDate']")]
        internal readonly IWebElement? _toDate = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='Clear']")]
        internal readonly IWebElement? _clearBtn = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='Retrieve']")]
        internal readonly IWebElement? _retrieveBtn = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='CourseAttendQryTable']")]
        internal readonly IWebElement? _courseAttendQryTable = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='CourseAttendQryFrame']")]
        internal readonly IWebElement? _courseAttendQryFrame = null;

    }
}
    