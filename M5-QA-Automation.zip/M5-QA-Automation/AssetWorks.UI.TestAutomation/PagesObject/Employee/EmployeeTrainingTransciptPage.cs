﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject
{
    internal class EmployeeTrainingTransciptPage : BasePage
    {
        internal string Course = "course$";
        internal string CourseDesc = "desc$";
        internal string VendorNo = "vendorNo$";               
        internal string PlannedDate = "plan_dt$";
        internal string AttendedDate = "attend_dt$";
        internal string Result = "result$";
        internal string Grade = "grade$";
        internal string ValidUntil = "valid$"; 
        internal string CertificateNo = "certificate$";
        internal string Notes = "noteBtn$";
        internal string AttachDoc = "attaBtn$";
        internal string AttachDesc = "ATdesc$";

        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        public EmployeeTrainingTransciptPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='EmployeeNo']")]
        internal readonly IWebElement? _employeeNo = null;       

        [FindsBy(How = How.XPath, Using = "//input[@name='txtEmployeeName']")]
        internal readonly IWebElement? _employeeName = null;
        
        [FindsBy(How = How.XPath, Using = "//input[@name='STATUS']")]
        internal readonly IWebElement? _empStatus = null;
    
        [FindsBy(How = How.XPath, Using = "//table[@id='EmpTrainingTable']")]
        internal readonly IWebElement? _empTrainingTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='attachTable']")]
        internal readonly IWebElement? _attachTable = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EmpTrainingTable']/tbody/tr")]
        internal readonly IList<IWebElement>? _empTrainingTableRows = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='EmpTrainingFrame']")]
        internal readonly IWebElement? _empTrainingFrame = null;        

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ShowAttachmentsFrame']")]
        internal readonly IWebElement? _showAttachmentsFrame = null;

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Attach a new file')]")]
        internal readonly IWebElement? _attachNewFile = null;

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Attach a web address')]")]
        internal readonly IWebElement? _attachWebAddress = null;

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Attach a previously uploaded file or web address')]")]
        internal readonly IWebElement? _attachExistingFile = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='theFile']")]
        internal readonly IWebElement? _chooseFile = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='theDesc']")]
        internal readonly IWebElement? _FileDesc = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='newAttButton']")]
        internal readonly IWebElement? _attachNewFileBtn = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='theUrl']")]
        internal readonly IWebElement? _webAddress = null;

        [FindsBy(How = How.XPath, Using = "//textarea[@name='theDesc']")]
        internal readonly IWebElement? _webAddressDesc = null;

        [FindsBy(How = How.XPath, Using = "//button[@id='attButton']")]
        internal readonly IWebElement? _attachAddressBtn = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='assocFile']")]
        internal readonly IWebElement? _previousUploadedFile = null;

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'OK')]")]
        internal readonly IWebElement? _OkBtn = null;

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Associate')]")]
        internal readonly IWebElement? _associateBtn = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@id='Content2']")]
        internal IWebElement? _contentFrame2 = null;


        [FindsBy(How = How.XPath, Using = "//button[@id='closeC2Btn']")]
        internal readonly IWebElement? _closeShowAttachmentsBtn = null;
    }
}
    