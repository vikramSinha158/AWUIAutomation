﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.M5.TestAutomation.Actions;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Employee
{
    internal class ShiftMaintenancePage : BasePage
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        internal ShiftMaintenancePage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@name='shiftno']")]
        internal IWebElement? _shiftno = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='shiftdesc']")]
        internal IWebElement? _shiftdesc = null;

        [FindsBy(How = How.XPath, Using = "//select[@name='shifttype']")]
        internal IWebElement? _shifttype = null;

        [FindsBy(How = How.XPath, Using = "//input[@name='shiftstart']")]
        internal IWebElement? _shiftstart = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='ShiftFrame']")]
        internal IWebElement? _ShiftFrame = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='ShiftTable']")]
        internal IWebElement? _ShiftTable = null;

    }
}
