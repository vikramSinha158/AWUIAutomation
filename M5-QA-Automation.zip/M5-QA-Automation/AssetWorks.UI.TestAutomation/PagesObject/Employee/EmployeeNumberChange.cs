﻿using AssetWorks.UI.Core.Base;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Employee
{
    internal class EmployeeNumberChange : BasePage
    {
        internal EmployeeNumberChange(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='EmployeeNo']")]
        internal readonly IWebElement? _inputEmpID = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='txtEmployeeName']")]
        internal readonly IWebElement? _inputName = null;

        [FindsBy(How = How.XPath, Using = "//select[@id='STATUS']")]
        internal readonly IWebElement? _selectStatus = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='NewEmployeeNo']")]
        internal readonly IWebElement? _inputNewEmpID = null;

        [FindsBy(How = How.XPath, Using = "//span[@class='ScreenTitle']")]
        internal readonly IWebElement? _changeIdScreenName = null;
    }
}
