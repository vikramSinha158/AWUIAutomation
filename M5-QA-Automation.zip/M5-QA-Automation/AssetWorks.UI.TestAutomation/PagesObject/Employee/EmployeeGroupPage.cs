﻿using System;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Employee
{
    internal class EmployeeGroupPage : BasePage
    {
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);

        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        internal EmployeeGroupPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='EmpLoc']")]
        internal readonly IWebElement? _inputEmpLocation = null;

        [FindsBy(How = How.XPath, Using = "//input[@id='EmpGroup']")]
        internal readonly IWebElement? _inputEmpGroup = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='GroupViewFrame']")]
        internal readonly IWebElement? _frameGroupView = null;

        [FindsBy(How = How.XPath, Using = "//table[@id='EmpGroupTable']/tbody")]
        internal readonly IWebElement? _tableEmpGroup = null;

        public IWebElement GetEmpLinkByText(string LinkText)
        {
            if (LinkText == null)
                throw new Exception("Search text can not be null.");
            string path = $"//div[text()='{LinkText}']";
            return _tableEmpGroup.FindElement(By.XPath(path));
        }
    }
}
