﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Base;
using SeleniumExtras.PageObjects;
using AssetWorks.UI.M5.TestAutomation.Actions;

namespace AssetWorks.UI.M5.TestAutomation.PagesObject.Location
{
    internal class LocationGroupsPage : BasePage
    {
        internal ExtendedPageActions Extendedpage => new(Driver);

        public LocationGroupsPage(IWebDriver Driver) : base(Driver)
        {
            PageFactory.InitElements(Driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='LocGroup']")]
        internal readonly IWebElement? _inputName = null;

        [FindsBy(How = How.XPath, Using = "//iframe[@name='LocGroupMaintFrame']")]
        internal readonly IWebElement? _frameLocationGroup = null;

        [FindsBy(How = How.XPath, Using = "//select[@id ='LocListLeft']")]
        internal readonly IWebElement? _selectLocationsNotIncluded = null;

        [FindsBy(How = How.XPath, Using = "//select[@id ='LocListRight']")]
        internal readonly IWebElement? _selectLocationsInGroup = null;

        [FindsBy(How = How.XPath, Using = "//button[@id ='LocListMoveRight']")]
        internal readonly IWebElement? _buttonMoveRight = null;

        [FindsBy(How = How.XPath, Using = "//button[@id ='LocListMoveLeft']")]
        internal readonly IWebElement? _buttonMoveLeft = null;
    }
}
