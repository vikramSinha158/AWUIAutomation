﻿using System;
using log4net;
using Newtonsoft.Json;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading.Tasks;
using AssetWorks.UI.Core.Utils;
using System.Collections.Generic;
using AssetWorks.UI.Core.Reporting;
using AssetWorks.UI.Core.Integrations;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Config;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes;

namespace AssetWorks.UI.M5.TestAutomation.Hook
{
    /// <summary>
    /// Hooks for setting up environment for test cases
    /// </summary>
    [TestFixture]
    public class Hooks : TestInitializeHooks
    {
        private int _runId = 0;
        TestRail testRail = new TestRail();
        List<TestResults> testResults = new List<TestResults>();

        private int count = 0;
        public bool IsFlagsChanged = false;
        public Dictionary<string, string> OriginalSystemFlags;

        internal LoginPageActions loginpage => new LoginPageActions(Driver);

        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        internal HomePageActions _pageNavigate => new HomePageActions(Driver);
        internal ExtendedPageActions _extendedpage => new ExtendedPageActions(Driver);
        public Hooks() { }

        public Hooks(IWebDriver Driver) : base(Driver) { }


        /// <summary>
        /// Before execution run settings
        /// </summary>
        [OneTimeSetUp]
        public void BeforeRun()
        {
            LoadCoreDataSetting(Settings.AppSettingPath);
            ConfigurationData.SetConfigData();
            InitializeCoreLogger(Settings.Logger);
            Settings.Logger.Info("------------------Initilizing Test Execution---------------");
            ExtentReport.SetupExtentreport();
            _runId = InitializeTestrailClient();
        }

        /// <summary>
        /// Before test set up
        /// </summary>
        [SetUp]
        public void Setup()
        {
            Settings.Logger.Info($"------------Starting executing test '{TestContext.CurrentContext.Test.Name}' having Description as '{TestContext.CurrentContext.Test.Properties.Get("Description")}' -------------------");
            if (Settings.BrowserName != null)
            {
                //await AutoUpdateChromeDriver();
                InitializeDriver(Settings.BrowserName);
            }
            Settings.Logger.Info($"Launched {Settings.BrowserName} instance");
            TestContext.TestAdapter _currentTest = TestContext.CurrentContext.Test;
            ExtentReport.CreateTest(_currentTest.Name);
            object?[] _arguments = _currentTest.Arguments;
            if (_arguments.Length > 0)
                CommonUtil.SetTestData(_arguments.GetValue(0));
            if (_arguments.Length > 0)
            {
                List<string> list = JsonConvert.DeserializeObject<List<string>>(JsonConvert.SerializeObject(_arguments.GetValue(0)));
                if (list.Count > 2)
                    if (Convert.ToBoolean(list[2]))
                        Settings.connection = GetDBConnection(Settings.OracleConnectionString, Settings.SQLConnectionString, Settings.DBType);
            }
            NavigateSite(Settings.AUT, Settings.ImplicitWait);
            CurrentPage = loginpage.LoginM5();
            Settings.Logger.Info($"Navigates to application site '{Settings.AUT}' with wait {Settings.ImplicitWait}");
        }


        /// <summary>
        /// After test clean up
        /// </summary>
        [TearDown]
        public void AfterTestRUn()
        {
            if (IsFlagsChanged)
            {
                RevertSystemFlags();
                IsFlagsChanged = false;
                OriginalSystemFlags.Clear();
            }
            ExtentReport.StoreResults(Driver);
            //loginpage.LoggOffApplication();
            CloseBrowser();
            Settings.Logger.Info("Closed browser instance");
            if (_runId > 0)
            {
                var testContext = TestContext.CurrentContext;
                testResults = UpdateCurrentTestResult(testContext);
            }
            Settings.Logger.Info($"==========Finished Test case execution for  '{TestContext.CurrentContext.Test.Name}' =========================");
        }

        /// <summary>
        /// After execution clean up
        /// </summary>
        [OneTimeTearDown]
        public void AfterRun()
        {
            if (_runId > 0)
                testRail.UpdateTestResultsToTestRail(_runId, testResults);
            ExtentReport.FlushExtentReport();
        }

        /// <summary>
        /// Revert System Flags
        /// </summary>
        public void RevertSystemFlags()
        {
            try
            {
                CloseBrowser();
                Settings.Logger.Info("Closed browser instance");
                if (Settings.BrowserName != null)
                {
                    InitializeDriver(Settings.BrowserName);
                    Settings.Logger.Info($"Launched {Settings.BrowserName} instance");
                }
                NavigateSite(Settings.AUT, Settings.ImplicitWait);
                CurrentPage = loginpage.LoginM5();
                Settings.Logger.Info($"Navigates to application site '{Settings.AUT}' with wait {Settings.ImplicitWait}");
                Settings.Logger.Info("Revert System Flags");
                CurrentPage = _pageNavigate.NavigateToSystemFlagPage();
                CurrentPage.As<SystemFlagsPageActions>().UpdateSystemFlags(OriginalSystemFlags);
                count = 0;
            }
            catch (Exception ex)
            {
                Settings.Logger.Info(ex);
                count++;
                if (count < 3)
                    RevertSystemFlags();
                else
                    count = 0;
            }
        }
    }
}
