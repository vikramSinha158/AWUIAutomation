﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class ComponentNumberChangePageActions : ComponentNumberChangePage
    {
        public ComponentNumberChangePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// ChangeComponentNumber
        /// </summary>
        /// <param name="ExistingComponentNo"></param>
        /// <returns></returns>
        public string ChangeComponentNumber(string ExistingComponentNo)
        {
            string ChangeComponentNo = String.Empty;
            _extendpage.SwitchToContentFrame();
            Settings.Logger.Info(" Change Component Number ");
            _compNoInput.SetText(ExistingComponentNo, "Old Component");
            Driver.WaitForReady();
            _newCompNoInput.SetText(CommonUtil.GetRandomStringWithSpecialChars(6), "No Of Coponent Copies ");
            _extendpage.Save();
            _extendpage.SwitchToContentFrame();  
            Driver.WaitForReady();
            ChangeComponentNo = new ComponentMainPageActions(Driver).GetComponentNumber();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info($" Change Component Number { ChangeComponentNo}");
            return ChangeComponentNo;
        }
    }
}
