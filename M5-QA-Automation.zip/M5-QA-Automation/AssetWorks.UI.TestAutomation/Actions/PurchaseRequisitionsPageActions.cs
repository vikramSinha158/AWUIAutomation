﻿using System;
using OpenQA.Selenium;
using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class PurchaseRequisitionsPageActions : PurchaseRequisitionsPage
    {
        public PurchaseRequisitionsPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Part Purchase Requisition
        /// </summary>
        /// <param name="Requisition"></param>
        /// <returns>"RequisitionNo"</returns>
        public string CreatePartPurchaseRequisition(PartPurchaseRequisition Requisition)
        {
            Settings.Logger.Info(" Create Part Purchase Requisition ");
            ExtendedPage.SwitchToContentFrame();
            _newReqButton.ClickElement(" New Requisition ", Driver);
            Driver.WaitForReady();
            _hvendorInput.SetText(Requisition.PRVendor, "Vendor Name");
            Driver.WaitForReady();
            _hQuotedCheckBox.SelectCheckBox("Quoted Check Box", Requisition.QuotedCheckBox);
            Driver.WaitForReady();
            _hvendorCheckBox.SelectCheckBox("vendor Check Box", Requisition.VendorCheckBox);
            Driver.WaitForReady();
            _specialCheckBox.SelectCheckBox("Special Handling", Requisition.SpecialHandling);
            if (Requisition.PartRequestObjects != null)
                FillPartRequestTabDetails(Requisition.PartRequestObjects);
            if (Requisition.RequisitionObjects != null)
                FillRequisitionTabDetails(Requisition.RequisitionObjects);
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.ClicKSave();
            Driver.WaitForSomeTime();
            ExtendedPage.SwitchToContentFrame();
            string RequisitionsNo = _reqNoInput.GetElementValueByAttribute("ovalue");
            Assert.IsTrue(!String.IsNullOrEmpty(RequisitionsNo));
            Driver.SwitchTo().DefaultContent();
            return RequisitionsNo;
        }

        /// <summary>
        /// Fill Part Request Tab Details
        /// </summary>
        /// <param name="partRequests"></param>
        public void FillPartRequestTabDetails(List<PartRequestObject> partRequests)
        {
            Settings.Logger.Info("Fill Part Request Tab Details");
            Driver.ScrollIntoViewAndClick(ExtendedPage.GetTabLinkByText("Part Request"), "Part Request Tab");
            Settings.Logger.Info("Clicked on Part Request Tab");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_framePartRequest, "Part Request Frame");
            foreach(PartRequestObject partRequest in partRequests)
            {
                CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableRequestList, _ResvRefNo, 
                    partRequest.ResvRefNo, "rPartNo"), "Part No", partRequest.PartNo, false, "value");
                ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableRequestList, _ResvRefNo, partRequest.ResvRefNo,
                    "rcheckReq").SelectCheckBox("Select", partRequest.Select);
            }
        }

        /// <summary>
        /// Fill Requisition Tab Details
        /// </summary>
        /// <param name="requisitions"></param>
        public void FillRequisitionTabDetails(List<RequisitionObject> requisitions)
        {
            int rowNo = 0;
            Settings.Logger.Info(" Fill Requisition Tab Details ");
            Driver.SwitchToFrame(_pRequisitionFrame, "pRequisitionFrame");
            foreach (RequisitionObject requisition in requisitions)
            {
                _inputNewPartNo(rowNo.ToString()).Click();
                _inputNewPartNo(rowNo.ToString()).SetText(requisition.PartNo, "Part No");
                Driver.WaitForReady();
                _inputNewQuantity(rowNo.ToString()).SetText(requisition.Quantity, "Quantity");
                Driver.WaitForReady();
                _inputNewUnitCost(rowNo.ToString()).SetText(requisition.UnitCost, "UnitCost");
                Driver.WaitForReady();
                _inputNewNeededBy(rowNo.ToString()).SetText(requisition.NeededBy, "NeededBy");
                Driver.WaitForReady();
                _inputNewResvCode(rowNo.ToString()).SelectFilterValueHavingEqualValue(requisition.ReservationCode);
                Driver.WaitForReady();
                _inputNewResvRefNo(rowNo.ToString()).SetText(requisition.ResvRefNo, "ResvRefNo");
                Driver.WaitForReady();
                _inputNewRefNo(rowNo.ToString()).SetText(requisition.RefNo, "RefNo");
                Driver.WaitForReady();
                _inputNewContract(rowNo.ToString()).SetText(requisition.ContractNo, "ContractNo");
                Driver.WaitForReady();
                if (requisition.AddNote)
                {
                    ExtendedPage.AddNotes(_inputNewNoteBtn(rowNo.ToString()), requisition.AddNoteDetail);
                    Driver.WaitForReady();
                    ExtendedPage.SwitchToTableFrame(_pRequisitionFrame);
                }
                rowNo++;
            }
        }

        /// <summary>
        /// Approve Part Requisition
        /// </summary>
        /// <param name="Requisition"></param>
        public void ApprovePartRequisition(PartPurchaseRequisition Requisition)
        {
            Settings.Logger.Info(" Approve Part Requisition ");
            ExtendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(ExtendedPage.GetTabLinkByText("Requisition"), "Requisition Tab");
            Settings.Logger.Info("Clicked on Requisition Tab");
            Driver.SwitchToFrame(_pRequisitionFrame, "Requisition Frame");
            foreach (RequisitionObject requisition in Requisition.RequisitionObjects)
            {
                if (requisition.Approval)
                {
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_prPartTable, _ResvRefNo, requisition.ResvRefNo, "PartNo").Click();
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_prPartTable, _ResvRefNo, requisition.ResvRefNo,
                        "approval_fl").SelectCheckBox("Rej Approval", requisition.Approval);
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_prPartTable, _ResvRefNo, requisition.ResvRefNo,
                        "RejReason").SetText(requisition.RejectionReason, "RejectionReason");
                    Driver.WaitForReady();
                    Driver.SwitchTo().DefaultContent();
                    ExtendedPage.ActionRequiredWindow("Continue");
                    ExtendedPage.Save();
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Part Requisitions
        /// </summary>
        /// <param name="Requisition"></param>
        /// <param name="RequisitionNumber"></param>
        public void VerifyPartRequisitions(PartPurchaseRequisition Requisition, string RequisitionNumber)
        {
            Settings.Logger.Info(" Verifying Part Requisitions ");
            ExtendedPage.RefreshAndSetText(_reqNoInput, RequisitionNumber, "Requisition Number ");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_hvendorInput, "Equipment Profile ID", Requisition.PRVendor);
            CommonUtil.VerifyCheckboxState(_hQuotedCheckBox, "hQuotedCheckBox", Requisition.QuotedCheckBox);
            CommonUtil.VerifyCheckboxState(_hvendorCheckBox, "vendor Check box", Requisition.VendorCheckBox);
            CommonUtil.VerifyCheckboxState(_specialCheckBox, "Special Handling", Requisition.SpecialHandling);
            Driver.SwitchToFrame(_pRequisitionFrame, "pRequisitionFrame");
            foreach (RequisitionObject requisition in Requisition.RequisitionObjects)
            {
                CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_prPartTable, _ResvRefNo, requisition.ResvRefNo,
                    "PartNo"), "Part No", requisition.PartNo, false, "value");
                CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_prPartTable, _ResvRefNo, requisition.ResvRefNo,
                    "pDesc"), "Part Desc", requisition.PartDesc, false, "value");
                CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_prPartTable, _ResvRefNo, requisition.ResvRefNo,
                    "vendor"), "Vendor", Requisition.PRVendor, false, "value");
                CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_prPartTable, _ResvRefNo, requisition.ResvRefNo,
                    "cpunitcost"), "UnitCost", requisition.UnitCost, false, "value");
                CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_prPartTable, _ResvRefNo, requisition.ResvRefNo,
                    "unitinv"), "Unitinv", requisition.Unitinv, false, "value");
                CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_prPartTable, _ResvRefNo, requisition.ResvRefNo,
                    "needby"), "NeededBy", requisition.NeededBy, false, "value");
                CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_prPartTable, _ResvRefNo, requisition.ResvRefNo,
                    "chargeCodeI"), "ReservationCode", requisition.ReservationCode, true);
                CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_prPartTable, _ResvRefNo, requisition.ResvRefNo,
                    "lineRefNo"), "RefNo", requisition.RefNo, false, "value");
                CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_prPartTable, _ResvRefNo, requisition.ResvRefNo,
                    "RejReason"), "RejectionReason", requisition.RejectionReason, false, "value");
                CommonUtil.VerifyCheckboxState(ExtendedPage.GetTableActionElementByRelatedColumnValue(_prPartTable, _ResvRefNo, requisition.ResvRefNo,
                    "approval_fl"), "Approval", requisition.Approval);
                if (requisition.AddNote)
                {
                    ExtendedPage.VerifyAddedNotes(ExtendedPage.GetTableActionElementByRelatedColumnValue(_prPartTable, _ResvRefNo, requisition.ResvRefNo,
                        "noteBtn"), requisition.AddNoteDetail);
                    ExtendedPage.SwitchToTableFrame(_pRequisitionFrame);
                }
                Settings.Logger.Info($" Successfully Verified Part Requisition for ResvRefNo - {requisition.ResvRefNo}");
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Part Purchase Requisition
        /// </summary>
        /// <param name="RequisitionsNumber"></param>
        /// <param name="Requisition"></param>
        public void DeletePartPurchaseRequisition(string RequisitionsNumber, PartPurchaseRequisition Requisition)
        {
            Settings.Logger.Info(" Verify Deleting Part Purchase Requisition ");
            ExtendedPage.RefreshAndSetText(_reqNoInput, RequisitionsNumber, "PartRequisitions Number ");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_pRequisitionFrame, "pRequisitionFrame");
            foreach (RequisitionObject requisition in Requisition.RequisitionObjects)
            {
                Driver.WaitForReady();
                ExtendedPage.GetTableActionElementByRelatedColumnValue(_prPartTable, _ResvRefNo, requisition.ResvRefNo, "PartNo").Click();
                Driver.SwitchTo().DefaultContent();
                ExtendedPage.ClickOnDeleteButton();
                ExtendedPage.SwitchToTableFrame(_pRequisitionFrame);
            }
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            ExtendedPage.RefreshAndSetText(_reqNoInput, RequisitionsNumber, "PartRequisitions Number ");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_reqStatus, "Status", "DELETED");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Purchase Requisition Status
        /// </summary>
        /// <param name="RequisitionNumber"></param>
        /// <param name="Status"></param>
        public void VerifyPurchaseRequisitionStatus(string RequisitionNumber, string Status)
        {
            Settings.Logger.Info(" Verifying Purchase Requisition Status ");
            ExtendedPage.RefreshAndSetText(_reqNoInput, RequisitionNumber, "Requisition Number ");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_reqStatus, "Status", Status);
            Driver.SwitchTo().DefaultContent();
        }
    }
}
