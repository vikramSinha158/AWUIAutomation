﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.BookingTypeCodes;


namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class BookingTypeCodesPageActions : BookingTypeCodesPage
    {
        public BookingTypeCodesPageActions(IWebDriver Driver) : base(Driver) { }
    

        /// <summary>
        /// Create Booking Type Code
        /// </summary>
        /// <param name="BookingTypecode"></param>
        /// <returns></returns>
        public string CreateBookingTypeCode(BookingCodeDetails BookingTypecode)
        {
            string BookingType=string.Empty;
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(BookingTypecode.BookingType, ref BookingType, "BookingTypeCodesQuery"))
            {
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_frameBookingTypeCodes, "Table frame");
                BookingTypecode.BookingType = BookingType;
                _bokingTypeCode.SetText(BookingTypecode.BookingType, "New Booking Type Code");              
                _bokingTypeDisablecheckbox.SelectCheckBox("Disable CheckBox", BookingTypecode.Disabled);
                _bokingTypeReqAddcheckbox.SelectCheckBox("Require Address", BookingTypecode.AddressRequired);
                Driver.WaitForReady();
                _extendedPage.Save();
            }
            Settings.Logger.Info("Create Booking Type Code Successfully");
            return BookingTypecode.BookingType;
        }

    public void EditBookingTypeCode(BookingCodeDetails bookingTypecode)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSwitchToTable(_frameBookingTypeCodes, "Table Frame");
            Settings.Logger.Info("Edit Booking Type Code : " + bookingTypecode.BookingType);
            if (!bookingTypecode.Disabled)
                _extendedPage.GetTableActionElementByRelatedColumnValue(
               _bookingCodeTable, "Code", bookingTypecode.BookingType, "DISABLED_FL").DeSelectCheckBox("Disabled");
            _extendedPage.GetTableActionElementByRelatedColumnValue(
             _bookingCodeTable, "Code", bookingTypecode.BookingType, "DISABLED_FL").SelectCheckBox("Disabled", bookingTypecode.Disabled);
            _extendedPage.Save();
            Settings.Logger.Info("Edit Accident Cause Successfully");
        }

        /// <summary>
        /// Verify Booking Type Code
        /// </summary>
        /// <param name="BookingTypecode"></param>
        public void VerifyBookingTypeCode(BookingCodeDetails BookingTypecode)
        {
            _extendedPage.SwitchToTableFrame(_frameBookingTypeCodes);
            IWebElement Code = _extendedPage.GetTableActionElementByRelatedColumnValue(
           _bookingCodeTable, "Code", BookingTypecode.BookingType, "BOOKING_TYPE");
            CommonUtil.VerifyElementValue(Code, "Booking Type", BookingTypecode.BookingType, false, "value");
            CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(
           _bookingCodeTable, "Code", BookingTypecode.BookingType, "DISABLED_FL"), "Disable Checkbox", BookingTypecode.Disabled);
            CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(
           _bookingCodeTable, "Code", BookingTypecode.BookingType, "REQ_ADDRESS_FL"), "Address Required", BookingTypecode.AddressRequired);
            Settings.Logger.Info("Verified Booking Type Code and Checkbox Status Successfully for : " + BookingTypecode.BookingType);
        }

        /// <summary>
        /// Delete Booking Type
        /// </summary>
        /// <param name="BookingTypecode"></param>
        public void DeleteBookingType(BookingCodeDetails BookingTypecode)
        {
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _bookingCodeTable, "Code", BookingTypecode.BookingType, "BOOKING_TYPE").Click();
            _extendedPage.DeleteAndSave();
            Settings.Logger.Info("Deleted Booking Code Successfully");
        }
        /// <summary>
        /// Verify Delete Booking Type
        /// </summary>
        /// <param name="BookingTypecode"></param>
        public void VerifyDeleteBookingType(BookingCodeDetails BookingTypecode)
        {
            Driver.SwitchToFrame(_frameBookingTypeCodes, "Table frame");
            _extendedPage.VerifyTableColumnDoesNotContainValue(_bookingCodeTable, "Code", BookingTypecode.BookingType);
            Settings.Logger.Info("Verify Deleted Booking Code Successfully");
        }

    }

}   
