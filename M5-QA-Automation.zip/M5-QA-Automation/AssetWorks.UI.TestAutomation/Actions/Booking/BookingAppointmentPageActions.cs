﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Collections.Generic;


namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class BookingAppointmentPageActions : BookingAppointmentPage
    {
        public BookingAppointmentPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Booking Apointment
        /// </summary>
        /// <param name="DataObjectKey"></param>
        /// <returns></returns>
        public string CreateBookingAppointment(BookingAppointment DataObject)
        {
            Settings.Logger.Info(" Creating New Booking Apointment");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            FillBookingData(DataObject);
            if (DataObject.JobInfo != null)
            { FillJobInformationDetails(DataObject.JobInfo); }
            FillCustomerInfo(DataObject);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            BillingAppointmentObjects.RequestedDate = _requestDt1.GetAttribute("ovalue");
            DataObject.BookingNumber = _BookingNo.GetAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info($"Booking Apointment :{ DataObject.BookingNumber} created successfully");
            return DataObject.BookingNumber;
        }

        /// <summary>
        /// Filling Booking Data
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillBookingData(BookingAppointment DataObject)
        {
            Settings.Logger.Info("Filling Booking and Booking Details");
            Driver.WaitForClickable(_newBooking,"New Booking");
            _unitNo.SetText(DataObject.UnitNO, "Unit NO");
            Driver.WaitForReady();
            _bookingStatus.SelectFilterValueHavingEqualValue(DataObject.BookingStatus);
            if (DataObject.NewBooking)
            {
                _newBooking.ClickElement("New booking", Driver);
            }
            Driver.WaitForReady();
            _customerNo.SetText(DataObject.CustNO, "Customer No");
            _BookingNo.SetText(DataObject.BookingNumber, "Booking Number");
            _location.SetText(DataObject.Location, "Location");
            _equipProfile.SetText(DataObject.EquipProfile, "Equipmentprofile");
            _bookingRef.SetText(DataObject.BookingReference, "Booking Reference");
            _bookingSource.SetText(DataObject.BookingSource, "Booking Source");
            Driver.WaitForReady();
            _bookingType.SetText(DataObject.BookingType, "Booking Type");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Filling Job Information Table
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillJobInformationDetails(List<JobInfo> DataObject)
        {
            Settings.Logger.Info("Filling Job Information Table");
            Driver.SwitchToFrame(_jobInfoFrame, "Job Info Frame");
            Driver.WaitForReady();
            for (int i = 0; i < DataObject.Count; i++)
            {
                _extendedPage.GetElementForInput($"{BillingAppointmentObjects.JobCode}{i}").SetText(DataObject[i].JobCode, "JobCode");
                Driver.WaitForReady();
                _extendedPage.GetElementForInput($"{BillingAppointmentObjects.JobReason}{i}").SetText(DataObject[i].Reason, "Reason");
                Driver.WaitForReady();
                _extendedPage.GetElementForInput($"{BillingAppointmentObjects.JobQty}{i}").SetText(DataObject[i].JobQuantity, "JobQuantity");
                Driver.WaitForReady();
                _extendedPage.GetElementForInput($"{BillingAppointmentObjects.LaborTime}{i}").SetText(DataObject[i].LaborTime, "LaborTime");
                Driver.WaitForReady();
                _extendedPage.GetElementForInput($"{BillingAppointmentObjects.LaborCost}{i}").SetText(DataObject[i].LaborCost, "LaborCost");
                Driver.WaitForReady();
                _extendedPage.GetElementForInput($"{BillingAppointmentObjects.PartCost}{i}").SetText(DataObject[i].PartCost, "PartCost");
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
        }

        /// <summary>
        /// Filling Customer Information section
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillCustomerInfo(BookingAppointment DataObject)
        {
            Settings.Logger.Info("Filling Job Information Table");
            _requestDt1.SetText(DataObject.RequestedDate, "Request Date1");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verifying Booking Appointment
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyBookingAppointment(BookingAppointment DataObject)
        {
            Settings.Logger.Info(" Verify Booking Appointment");
            _extendedPage.RefreshAndSetText(_unitNo, DataObject.UnitNO, "Unit No");
            Driver.WaitForReady();
            _BookingNo.SetText(DataObject.BookingNumber, "Booking Number");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_unitNo, "Unit No", DataObject.UnitNO);
            CommonUtil.VerifyElementValue(_unitDesc, "Unit Description", DataObject.UnitDesc);
            CommonUtil.VerifyElementValue(_bookingStatus, "Booking Status", DataObject.BookingStatus,true);
            CommonUtil.VerifyElementValue(_customerNo, "Customer No", DataObject.CustNO);
            CommonUtil.VerifyElementValue(_customerDesc, "Customer Description", DataObject.CustDesc);
            CommonUtil.VerifyElementValue(_BookingNo, "Booking Number", DataObject.BookingNumber);
            CommonUtil.VerifyElementValue(_location, "Customer Description", DataObject.Location);
            CommonUtil.VerifyElementValue(_equipProfile, "Equipment Profile", DataObject.EquipProfile);
            CommonUtil.VerifyElementValue(_bookingRef, "Booking Reference", DataObject.BookingReference);
            CommonUtil.VerifyElementValue(_bookingSource, "Booking Source", DataObject.BookingSource);
            CommonUtil.VerifyElementValue(_bookingType, "Booking Type", DataObject.BookingType);
            if (DataObject.JobInfo != null)
            {
                VerfiyJobInformationDetails(DataObject.JobInfo);
            }            
            CommonUtil.VerifyElementValue(_requestDt1, "Requested Date1", BillingAppointmentObjects.RequestedDate);
            CommonUtil.VerifyElementValue(_bookingDate, "Booking Date", BillingAppointmentObjects.RequestedDate);
            CommonUtil.VerifyElementValue(_bookingPrd, "Booking Period", DataObject.BookingPeriod);
            CommonUtil.VerifyElementValue(_requestPrd1, "Request Period", DataObject.RequestPeriod);
            Settings.Logger.Info($"Booking Appointment :{ DataObject.BookingNumber} verified successfully");
        }

        /// <summary>
        /// Verify Job Information Table
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerfiyJobInformationDetails(List<JobInfo> DataObject)
        {
            Settings.Logger.Info("Verifing Job Information Table");
            Driver.SwitchToFrame(_jobInfoFrame, "Job Info Frame");
            for (int i = 0; i < DataObject.Count; i++)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetElementForInput($"{BillingAppointmentObjects.JobCode}{i}"), "Job Code", DataObject[i].JobCode, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetElementForInput($"{BillingAppointmentObjects.JobDesc}{i}"), "Job Desc", DataObject[i].JobDesc, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetElementForInput($"{BillingAppointmentObjects.JobReason}{i}"), "Reason", DataObject[i].Reason, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetElementForInput($"{BillingAppointmentObjects.JobQty}{i}"), "Job Quantity", DataObject[i].JobQuantity, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetElementForInput($"{BillingAppointmentObjects.LaborTime}{i}"), "Labor Time", DataObject[i].LaborTime, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetElementForInput($"{BillingAppointmentObjects.ShopTime}{i}"), "Shop Time", DataObject[i].ShopTime, false, "value");
                CommonUtil.VerifyCheckboxState(_extendedPage.GetElementForInput($"{BillingAppointmentObjects.BillFixed}{i}"), "Bill Fixed", DataObject[i].BillFixed);
                CommonUtil.VerifyElementValue(_extendedPage.GetElementForInput($"{BillingAppointmentObjects.TotalCost}{i}"), "Total Cost", DataObject[i].TotalCost, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetElementForInput($"{BillingAppointmentObjects.LaborCost}{i}"), "Labor Cost", DataObject[i].LaborCost, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetElementForInput($"{BillingAppointmentObjects.PartCost}{i}"), "Date Added", DataObject[i].PartCost, false, "value");
            
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
        }
    }
}


