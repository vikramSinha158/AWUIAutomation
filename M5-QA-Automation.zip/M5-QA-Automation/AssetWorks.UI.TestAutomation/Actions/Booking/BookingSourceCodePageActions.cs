﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Booking;
using NUnit.Framework;
using OpenQA.Selenium;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.BookingSourceCodeObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Booking
{
    internal class BookingSourceCodePageActions : BookingSourceCodesPage
    {
        public BookingSourceCodePageActions(IWebDriver Driver) : base(Driver) { }


        /// <summary>
        /// Create Booking Source Code
        /// </summary>
        /// <param name="DataObject"></param>
        /// <returns></returns>
        public string CreateBookingSourceCode(BookingSourceCode DataObject)
        {
            string BookingCode = string.Empty;            
            if (!_extendpage.CheckDataExistenceAndGetActionCode(DataObject.BookingCode, ref BookingCode, "BookingSourceCodeQuery", 5))
            {
                _extendpage.SwitchToContentFrame();
                Driver.SwitchToFrame(_iframebookingecode, "Table frame");
                Settings.Logger.Info("Create Booking Source Code");
                DataObject.BookingCode = BookingCode;
                _bookingSourcecode.SetText(DataObject.BookingCode, "Booking Source Code");
                Settings.Logger.Info("Select Disable Checkbox Booking Source Code");
                _Checkboxbookingecode.SelectCheckBox("Disable", DataObject.Disable);
                _extendpage.Save();
                Driver.WaitForReady();
                Assert.IsTrue(_extendpage.CheckDataExistenceAndGetActionCode(DataObject.BookingCode, ref BookingCode, "BookingSourceCodeQuery", 5)); 
            }
            return DataObject.BookingCode;
        }

        /// <summary>
        /// Verify Booking Source Code
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyBookingSourceCode(BookingSourceCode DataObject)
        {
            Settings.Logger.Info("Verify Booking Source Code");
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_iframebookingecode, "Table frame");
            IWebElement Code = _extendpage.GetTableActionElementByRelatedColumnValue(_Tablebookingecode, "Code", DataObject.BookingCode, "BOOKING_SOURCE");
            CommonUtil.VerifyElementValue(Code, "Booking Code", DataObject.BookingCode, false, "value");
            Settings.Logger.Info("Verify Booking Source Code Disable Checkbox Status");
            CommonUtil.VerifyCheckboxState(_extendpage.GetTableActionElementByRelatedColumnValue(
                    _Tablebookingecode, "Code", DataObject.BookingCode, "DISABLED_FL"), "Disable", DataObject.Disable);
           
        }
       
        /// <summary>
        /// Update Booking Source Code
        /// </summary>
        /// <param name="Bookingstatus"></param>
        /// <returns></returns>
        public void UpdateBookingSourceCode(BookingSourceCode Bookingstatus)
        {
            Settings.Logger.Info("Updated Booking Source Code Disable Checkbox");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_iframebookingecode, "Table frame");
            if(!Bookingstatus.Disable)
            _extendpage.GetTableActionElementByRelatedColumnValue(
                _Tablebookingecode,"Code",Bookingstatus.BookingCode, "DISABLED_FL").DeSelectCheckBox("DISABLED_FL");
            _extendpage.GetTableActionElementByRelatedColumnValue(
                _Tablebookingecode, "Code", Bookingstatus.BookingCode, "DISABLED_FL").SelectCheckBox("DISABLED_FL",Bookingstatus.Disable);
            Driver.WaitForReady();
            _extendpage.Save();
        }

        /// <summary>
        /// Delete Booking Source Code
        /// </summary>
        /// <param name="BookingSourceCode"></param>
        public void DeleteBookingSourceCode(BookingSourceCode BookingSourceCode)
        {
            Settings.Logger.Info(" Delete Booking Source Code");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_iframebookingecode, "Table frame");
            _extendpage.GetTableActionElementByRelatedColumnValue(
                _Tablebookingecode,"Code", BookingSourceCode.BookingCode, "BOOKING_SOURCE").Click();
            _extendpage.DeleteAndSave();
        }
        /// <summary>
        /// Verify Delete Booking Source Code
        /// </summary>
        /// <param name="BookingSourceCode"></param>
        public void VerifyDeleteBookingSourceCode(BookingSourceCode BookingSourceCode)
        {
            Settings.Logger.Info("Verify Deleted Booking Code");
            Driver.SwitchToFrame(_iframebookingecode, "Table frame");
            _extendpage.VerifyTableColumnDoesNotContainValue(_Tablebookingecode, "Code", BookingSourceCode.BookingCode);

        }
    }
}
