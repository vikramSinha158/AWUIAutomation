﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using System;
using System.Diagnostics.Contracts;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.Booking.CustomerMainObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Booking
{
    internal class CustomerContractPageActions : CustomerContractPage
    {
        public CustomerContractPageActions(IWebDriver Driver) : base(Driver) { }
        string ContractNumber = string.Empty;
        string StartDate = string.Empty;
        string AwardDate = string.Empty;
        /// <summary>
        /// Create Customer Contract
        /// </summary>
        /// <param name="CustNo"></param>
        /// <param name="DataObjectKey"></param>
        /// <returns></returns>
        public string CreateCustomerContract(string CustNo, string DataObjectKey)
        {
            CreateCustomerContract createCustContractObjectValues = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<CreateCustomerContract>();
            Settings.Logger.Info(" Creating New Customer Contract");
            _extendpage.SwitchToContentFrame();
            _newContract.ClickElement("New Contract", Driver);
            _custNumber.SetText(CustNo, "Customer");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow("Create");
            _extendpage.SwitchToContentFrame();
            FillContractInfo(createCustContractObjectValues);
            if (createCustContractObjectValues.JobsTab!=null)
            { 
                for (int i = 0; i < createCustContractObjectValues.JobsTab.Count; i++)
                {
                    FillJObTab(createCustContractObjectValues.JobsTab[i]);
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendpage.SwitchToContentFrame();
            ContractNumber = _contractNo.GetAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            return ContractNumber;
        }

        /// <summary>
        /// Fill Contract Info
        /// </summary>
        /// <param name="createCustContractObjectValues"></param>
        public void FillContractInfo(CreateCustomerContract createCustContractObjectValues)
        {
            if (!string.IsNullOrEmpty(createCustContractObjectValues.StartDate))
                StartDate = createCustContractObjectValues.StartDate.ToLower() == "now" ? DateTime.Now.ToString("MM/dd/yyyy") : DateTime.Now.AddDays(Convert.ToDouble(createCustContractObjectValues.StartDate)).ToString("MM/dd/yyyy");
            _startDate.SetText(StartDate, "Start Date");
            Driver.WaitForReady();
            _status.SelectFilterValueHavingEqualValue(createCustContractObjectValues.Status);
            Driver.WaitForReady();
            if(!string.IsNullOrEmpty(createCustContractObjectValues.AwardDate))
             AwardDate = createCustContractObjectValues.AwardDate.ToLower() == "now" ? DateTime.Now.ToString("MM/dd/yyyy") : DateTime.Now.AddDays(Convert.ToDouble(createCustContractObjectValues.AwardDate)).ToString("MM/dd/yyyy");
            _awardDate.SetText(createCustContractObjectValues.AwardDate,"Award Date");
            _awardAmount.SetText(createCustContractObjectValues.AwardAmount, "Award Amount");
        }

        /// <summary>
        /// Fill Job Tab Data
        /// </summary>
        /// <param name="DataObjectValue"></param>
        public void FillJObTab(JobsTabData DataObjectValue)
        {
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Jobs"), "Jobs");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameJob, "Job Table");
            _newJob.SetText(DataObjectValue.Job, "Job");
            Driver.WaitForReady();
            _newFixedPrice.SetText(DataObjectValue.FixedPrice, "Fixed Price");
        }

        /// <summary>
        /// Verify Customer Contract
        /// </summary>
        /// <param name="ContractNo"></param>
        /// <param name="CustNo"></param>
        /// <param name="CustDesc"></param>
        /// <param name="DataObjectKey"></param>
        public void VerifyCustomerContract(string ContractNo, string CustNo, string CustDesc, string DataObjectKey)
        {
            CreateCustomerContract verifyCustContractObjectValues = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<CreateCustomerContract>();
            _extendpage.RefreshAndSetText(_contractNo, ContractNo, "Contract No");
            CommonUtil.VerifyElementValue(_custNumber, "Customer Number", CustNo);
            CommonUtil.VerifyElementValue(_custDescription, "Customer Description", CustDesc);
            CommonUtil.VerifyElementValue(_status, "Status", verifyCustContractObjectValues.Status, true);
            CommonUtil.VerifyElementValue(_statusDate, "Status Date",DateTime.Now.ToString("MM/dd/yyyy"));
            Settings.Logger.Info(" Verify Job Tab Data");
            if (verifyCustContractObjectValues.JobsTab != null)
            {
                for (int i = 0; i < verifyCustContractObjectValues.JobsTab.Count; i++)
                {
                    VerifyJobTabData(verifyCustContractObjectValues.JobsTab[i], i);
                }
            }
            Settings.Logger.Info(" Verify Parts Matrix Tab Data");
            if (verifyCustContractObjectValues.PartsMatrixTab != null)
            {
                for (int i = 0; i < verifyCustContractObjectValues.PartsMatrixTab.Count; i++)
                {
                    VerifyPartsMatrixData(verifyCustContractObjectValues.PartsMatrixTab[i]);
                }
            }
            Settings.Logger.Info(" Verify Labor Matrix Tab Data");
            if (verifyCustContractObjectValues.LaborMatrixTab != null)
             {
                 for (int i = 0; i < verifyCustContractObjectValues.LaborMatrixTab.Count; i++)
                 {
                     VerifyLaborMatrixData(verifyCustContractObjectValues.LaborMatrixTab[i]);
                 }
             }
            Settings.Logger.Info(" Verify Fluids Matrix Tab Data");
            if (verifyCustContractObjectValues.Fluids != null)
            {
                for (int i = 0; i < verifyCustContractObjectValues.Fluids.Count; i++)
                {
                    VerifyFluidsData(verifyCustContractObjectValues.Fluids[i]);
                }
            }
            Settings.Logger.Info(" Verify Fixed Price Parts Matrix Tab Data");
            if (verifyCustContractObjectValues.FixedPriceParts != null)
            {
                for (int i = 0; i < verifyCustContractObjectValues.FixedPriceParts.Count; i++)
                {
                    VerifyFixedPricePartsData(verifyCustContractObjectValues.FixedPriceParts[i]);
                }
            }
            Settings.Logger.Info(" Verify Contract Notes Data");
            if (verifyCustContractObjectValues.ContractNotes != null)
            {
                VerifyContractNotesData(verifyCustContractObjectValues);
            }
            Settings.Logger.Info(" Verify Booking Notes Data");
            if (verifyCustContractObjectValues.ContractNotes != null)
            {
                VerifyBookingNotesData(verifyCustContractObjectValues);
            }
            Driver.SwitchTo().DefaultContent();
        }
        /// <summary>
        /// Verify Job Tab Data
        /// </summary>
        /// <param name="DataObjectValue"></param>
        /// <param name="RowNO"></param>
        public void VerifyJobTabData(JobsTabData DataObjectValue, int RowNO)
        {
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Jobs"), "Jobs");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameJob, "Job Table");
            string jobDesc = _extendpage.GetTableActionElementByRelatedColumnValue(
                _tableJob, "Job", DataObjectValue.Job, "Job_Desc").GetAttribute("value");
            CommonUtil.AssertTrue(DataObjectValue.JobDescription, jobDesc);
            string fixedPrice = _extendpage.GetTableActionElementByRelatedColumnValue(
               _tableJob, "Job", DataObjectValue.Job, "Fixed_Price").GetAttribute("value");
            CommonUtil.AssertTrue(DataObjectValue.FixedPrice, fixedPrice);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
        }

        /// <summary>
        /// Verify Parts Matrix Data
        /// </summary>
        /// <param name="DataObjectValue"></param>
        /// <param name="RowNO"></param>
        public void VerifyPartsMatrixData(PartsMatrixData DataObjectValue)
        {           
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Parts Matrix"), "Parts");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_framePartsMatrix, "PartsMatrix Table");
            string manufacturer = _extendpage.GetTableActionElementByRelatedColumnValue(
                _tablePartsMatrix, "Manufacturer", DataObjectValue.Manufacturer, "mfg").GetAttribute("value");
            CommonUtil.AssertTrue(DataObjectValue.Manufacturer, manufacturer);
            string vendor = _extendpage.GetTableActionElementByRelatedColumnValue(
               _tablePartsMatrix, "Vendor", DataObjectValue.Vendor, "vendor").GetAttribute("value");
            CommonUtil.AssertTrue(DataObjectValue.Vendor, vendor);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
        }

        /// <summary>
        /// Verify Labor Matrix Data
        /// </summary>
        /// <param name="DataObjectValue"></param>
        /// <param name="RowNO"></param>
        public void VerifyLaborMatrixData(LaborMatrixData DataObjectValue)
        {
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Labor Matrix"), "Labor");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameLaborMatrix, "LaborMatrix Table");
            CommonUtil.VerifyElementValue(_extendpage.GetElementFromTable("location$0"),
                "Location", DataObjectValue.Location, false, "value");
            CommonUtil.VerifyElementValue(_extendpage.GetElementFromTable("assetClass$0"),
                "Asset Class", DataObjectValue.AssetClass, false, "value");
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
        }

        /// <summary>
        /// Verify Fluids Data
        /// </summary>
        /// <param name="DataObjectValue"></param>
        /// <param name="RowNO"></param>
        public void VerifyFluidsData(Fluids DataObjectValue)
        {
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Fluids"), "Fluids");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameFluidMatrix, "FluidsMatrix Table");
            string product = _extendpage.GetTableActionElementByRelatedColumnValue(
                _tableFluidMatrix, "Product", DataObjectValue.Product, "product_no").GetAttribute("value");
            CommonUtil.AssertTrue(DataObjectValue.Product, product);
            string description = _extendpage.GetTableActionElementByRelatedColumnValue(
               _tableFluidMatrix, "Description", DataObjectValue.Description, "prod_Desc").GetAttribute("value");
            CommonUtil.AssertTrue(DataObjectValue.Description, description);
            string markup = _extendpage.GetTableActionElementByRelatedColumnValue(
               _tableFluidMatrix, "Markup %", DataObjectValue.Markup, "fMarkupPct").GetAttribute("value");
            CommonUtil.AssertTrue(DataObjectValue.Markup, markup);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
        }


        /// Verify Fixed Price Parts Data
        /// </summary>
        /// <param name="DataObjectValue"></param>
        /// <param name="RowNO"></param>
        public void VerifyFixedPricePartsData(FixedPriceParts DataObjectValue)
        {
            //_extendpage.RefreshAndSetText(_contractNo, ContractNo, "Contract No");
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Fixed Price Parts"), "FixedPrice");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameFixedPricePart, "FixedPricePart Table");
            string part = _extendpage.GetTableActionElementByRelatedColumnValue(
                _tableFixedPricePart, "Part", DataObjectValue.Part, "Part_No").GetAttribute("value");
            CommonUtil.AssertTrue(DataObjectValue.Part, part);
            string manufacturer = _extendpage.GetTableActionElementByRelatedColumnValue(
               _tableFixedPricePart, "Manufacturer", DataObjectValue.Manufacturer, "Manufacturer").GetAttribute("value");
            CommonUtil.AssertTrue(DataObjectValue.Manufacturer, manufacturer);
            string description = _extendpage.GetTableActionElementByRelatedColumnValue(
               _tableFixedPricePart, "Description", DataObjectValue.Description, "Part_Desc").GetAttribute("value");
            CommonUtil.AssertTrue(DataObjectValue.Description, description);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
        }
        /// <summary>
        /// Verify Contract Notes Data
        /// </summary>
        /// <param name="DataObjectValue"></param>
        /// <param name="RowNO"></param>
        public void VerifyContractNotesData(CreateCustomerContract ContractNotes)
        {
            //_extendpage.RefreshAndSetText(_contractNo, ContractNo, "Contract No");
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Contract Notes"), "ContractNotes");
            Driver.WaitForReady();
            string contractNotes = _contractNotes.GetAttribute("ovalue");
            CommonUtil.AssertTrue(ContractNotes.ContractNotes, contractNotes);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
        }
        /// <summary>
        /// Verify Booking Notes Data
        /// </summary>
        /// <param name="DataObjectValue"></param>
        /// <param name="RowNO"></param>
        public void VerifyBookingNotesData(CreateCustomerContract BookingNotes)
        {
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Booking Notes"), "ContractNotes");
            Driver.WaitForReady();
            string bookingNotes = _bookingNotes.GetAttribute("ovalue");
            CommonUtil.AssertTrue(BookingNotes.BookingNotes, bookingNotes);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
        }


            /// <summary>
            /// Delete Contract
            /// </summary>
            /// <param name="ContractNo"></param>
            public void DeleteContract(string ContractNo)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_contractNo, ContractNo, "Contract No");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnDeleteButton();
            _extendpage.ActionRequiredWindow("Delete");
            Driver.WaitForReady();
            Settings.Logger.Info($" Deleted Contract:{ContractNo}  ");
        }

        /// <summary>
        /// Verify Contract Deletion
        /// </summary>
        /// <param name="ContractNo"></param>
        public void VeriftContractDeletion(string ContractNo)
        {
            _extendpage.RefreshAndSetText(_contractNo, ContractNo, "Contract No");
            Driver.WaitForSomeTime();
            IAlert Alert = Driver.SwitchTo().Alert();
            Alert.Accept();
            Settings.Logger.Info($" Verified Contract: {ContractNo} Deleted Successfully ");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Edit Contract
        /// </summary>
        /// <param name="ContractNo"></param>
        /// <param name="DataKey"></param>
        public void EditContract(string ContractNo,string DataKey)
        {
            CreateCustomerContract editContractObjectValues = CommonUtil.DataObjectForKey(DataKey).ToObject<CreateCustomerContract>();
            _extendpage.RefreshAndSetText(_contractNo, ContractNo, "Contract No");
            Driver.WaitForSomeTime();
            FillContractInfo(editContractObjectValues);
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnSaveButton();
            Driver.WaitForReady();
        }
       
    }
}
