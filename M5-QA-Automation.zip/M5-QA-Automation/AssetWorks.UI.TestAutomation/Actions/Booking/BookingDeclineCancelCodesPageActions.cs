﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Booking;
using OpenQA.Selenium;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.BookingDeclineCancelCodes;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Booking
{
    internal class BookingDeclineCancelCodesPageActions : BookingDeclineCancelCodesPage
    {
        public BookingDeclineCancelCodesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Booking Decline Cancel Code
        /// </summary>
        /// <param name="bookingCodeDetails"></param>
        /// <returns></returns>        
        public string CreateBookingDeclineCancelCode(BookingCodeDetails bookingCodeDetails)
        {
           
            if (bookingCodeDetails.BookingCode == "Random")
            {
                bookingCodeDetails.BookingCode = CommonUtil.GetRandomStringWithSpecialChars(1);
            }
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_frameBookingDeclineCode, "Table frame");
                Settings.Logger.Info("Create Booking Code");
                _bookingCode.SetText(bookingCodeDetails.BookingCode, "New Booking Decline  Code");
                Settings.Logger.Info("Create Booking Code Description");
                _bookingDescriptionCode.SetText(bookingCodeDetails.BookingDescription, "New Booking Decline Description Code");
                _bokingCodeCancelcheckbox.SelectCheckBox("Cancel CheckBox", bookingCodeDetails.Cancelflag);
                _bokingCodeDeclinecheckbox.SelectCheckBox("Decline CheckBox",bookingCodeDetails.Declineflag);
                _bokingCodeDisablecheckbox.SelectCheckBox("Disable CheckBox",bookingCodeDetails.Disableflag);
                _extendedPage.Save();
                return bookingCodeDetails.BookingCode;
        }

        /// <summary>
        /// Verify Booking Code
        /// </summary>
        /// <param name="bookingCodeDetails"></param>        
        public void VerifyBookingCode(BookingCodeDetails bookingCodeDetails)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameBookingDeclineCode, "Table frame");
            Settings.Logger.Info("Verify Booking Code");
            IWebElement Code= _extendedPage.GetTableActionElementByRelatedColumnValue(_bookingDeclineCodeTable, "Code", bookingCodeDetails.BookingCode, "REASON");
            CommonUtil.VerifyElementValue(Code, "Booking Code", bookingCodeDetails.BookingCode,false,"value");
            Settings.Logger.Info("Verify Booking Code Description");
            IWebElement Description = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _bookingDeclineCodeTable, "Description", bookingCodeDetails.BookingDescription, "DESCRIPTION");
            CommonUtil.VerifyElementValue(Description,"Booking Description", bookingCodeDetails.BookingDescription,false,"value");
            Settings.Logger.Info("Verify Booking Code Cancel Checkbox");
            CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _bookingDeclineCodeTable, "Code", bookingCodeDetails.BookingCode, "CANCEL_FL"), "Cancel CheckBox", bookingCodeDetails.Cancelflag);
            Settings.Logger.Info("Verify Booking Code Decline Checkbox");
            CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _bookingDeclineCodeTable, "Code", bookingCodeDetails.BookingCode, "DECLINE_FL"), "Decline CheckBox", bookingCodeDetails.Declineflag);
            Settings.Logger.Info("Verify Booking Code Decline Checkbox");
            CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _bookingDeclineCodeTable, "Code", bookingCodeDetails.BookingCode, "DISABLED_FL"), "Disable CheckBox", bookingCodeDetails.Disableflag);  
        }

        /// <summary>
        /// Delete Booking Code
        /// </summary>
        /// <param name="bookingDclnCnclCodeTC1"></param>        
        public void DeleteBookingCode(BookingCodeDetails bookingDclnCnclCodeTC1)
        {
            Settings.Logger.Info("Delete Booking Code");
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _bookingDeclineCodeTable, "Code", bookingDclnCnclCodeTC1.BookingCode, "REASON").Click();
            _extendedPage.DeleteAndSave();
        }
        /// <summary>
        /// VerifyDeleteBookingCode
        /// </summary>
        /// <param name="bookingDclnCnclCodeTC2"></param>
        public void VerifyDeleteBookingCode(BookingCodeDetails bookingDclnCnclCodeTC2)
        {
            Settings.Logger.Info("Verify Deleted Booking Code");
            Driver.SwitchToFrame(_frameBookingDeclineCode, "Table frame");
            _extendedPage.VerifyTableColumnDoesNotContainValue(_bookingDeclineCodeTable, "Code", bookingDclnCnclCodeTC2.BookingCode);

        }
    }
}
