﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;


namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class CustomerTypeCodesPageActions : CustomerTypeCodesPage
    {
        public CustomerTypeCodesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Customer Type Code
        /// </summary>
        /// <param name="CustomerTypeData"></param>
        /// <returns></returns>
        public string CreateCustomerTypeCode(CustomerTypeCode CustomerTypeData)
        {
            if (CustomerTypeData.CustomerType == "Random")
            {
                CustomerTypeData.CustomerType = CommonUtil.GetRandomStringWithSpecialChars(5);
            }
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameCustomerTypeCodes, "Table frame");
            _customerTypeCode.SetText(CustomerTypeData.CustomerType, "New Customer Type  Code");
            _customerTypeDescription.SetText(CustomerTypeData.CustomerDescription, "New Customer Type Code Description ");
            _DisableCheckboxCustomer.SelectCheckBox("Disable CheckBox", CustomerTypeData.Disable);
            _extendedPage.Save();
            Settings.Logger.Info("Created Customer Type Code Successfully");
            return CustomerTypeData.CustomerType;
        }
        /// <summary>
        /// Edit Customer Type Code
        /// </summary>
        /// <param name="CustomerTypeData"></param>
        public void EditCustomerTypeCode(CustomerTypeCode CustomerTypeData)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSwitchToTable(_frameCustomerTypeCodes, "Table Frame");
            Settings.Logger.Info("Edit Booking Type Code : " + CustomerTypeData.CustomerType);
            if (!CustomerTypeData.Disable)
                _extendedPage.GetTableActionElementByRelatedColumnValue(
               _customerCodeTable, "Code", CustomerTypeData.CustomerType, "DISABLED_FL").DeSelectCheckBox("Disabled");
            _extendedPage.GetTableActionElementByRelatedColumnValue(
             _customerCodeTable, "Code", CustomerTypeData.CustomerType, "DISABLED_FL").SelectCheckBox("Disabled", CustomerTypeData.Disable);
            _extendedPage.Save();
            Settings.Logger.Info("Edit Customer type Successfully");
        }

        /// <summary>
        /// Verify Customer Type Code
        /// </summary>
        /// <param name="CustomerTypeData"></param>
        public void VerifyCustomerTypeCode(CustomerTypeCode CustomerTypeData)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameCustomerTypeCodes, "Table frame");
            IWebElement Code = _extendedPage.GetTableActionElementByRelatedColumnValue(_customerCodeTable, "Code", CustomerTypeData.CustomerType, "CUSTOMER_TYPE");
            CommonUtil.VerifyElementValue(Code, "Booking Code", CustomerTypeData.CustomerType, false, "value");
            IWebElement Description = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _customerCodeTable, "Description", CustomerTypeData.CustomerDescription, "DESCRIPTION");
            CommonUtil.VerifyElementValue(Description, "Booking Description", CustomerTypeData.CustomerDescription, false, "value");
            CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _customerCodeTable, "Code", CustomerTypeData.CustomerType, "DISABLED_FL"), "Disable CheckBox", CustomerTypeData.Disable);
            Settings.Logger.Info("Verified Customer Type Code Successfully");

        }

        /// <summary>
        /// DeleteCustomerTypeCodes
        /// </summary>
        /// <param name="CustomerTypeData"></param>
        public void DeleteCustomerTypeCodes(CustomerTypeCode CustomerTypeData)
        {
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _customerCodeTable, "Code", CustomerTypeData.CustomerType, "CUSTOMER_TYPE").Click();
            _extendedPage.DeleteAndSave();
            Settings.Logger.Info("Deleted Customer Type Code Successfully");
        }

        /// <summary>
        ///Verify Deleted Customer Code
        /// </summary>
        /// <param name="CustomerTypeData"></param>
        public void VerifyDeletedCustomerCode(CustomerTypeCode CustomerTypeData)
        {
            Driver.SwitchToFrame(_frameCustomerTypeCodes, "Table frame");
            _extendedPage.VerifyTableColumnDoesNotContainValue(_customerCodeTable, "Code", CustomerTypeData.CustomerType);
            Settings.Logger.Info(" Verify Deleted Customer Type Code Successfully");
        }
    }


}   
