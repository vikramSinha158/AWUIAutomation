﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class CostCategoryCodesPageActions : CostCategoryCodesPage
    {
        public CostCategoryCodesPageActions(IWebDriver? Driver) : base(Driver) { }

        /// <summary>
        /// Create new Cost Category Code
        /// </summary>
        /// <param name="costCategoryCode"></param>
        /// <returns></returns>
        public string CreateCostCategoryCode(CostCategoryCodeObjects costCategoryCode)
        {
            string Code = string.Empty;
            if (!ExtendedPage.CheckDataExistenceAndGetActionCode(costCategoryCode.Code, ref Code, "CostCategoryCodesQuery", 2))
            {
                Settings.Logger.Info(" Create new Cost Category Code ");
                ExtendedPage.SwitchToTableFrame(_frameCostCatCodes);
                _inputCode.SetText(Code, "Code");
                _inputDescription.SetText(costCategoryCode.Description, "Description");
                _checkboxDisabled.SelectCheckBox("Disabled", costCategoryCode.Disabled);
                Driver.SwitchTo().DefaultContent();
                ExtendedPage.ClickOnSaveButton();
                Driver.WaitForReady();
                VerifyCostCategoryCode(Code);
            }
            return Code;
        }

        /// <summary>
        /// Verify Cost Category Code
        /// </summary>
        /// <param name="code"></param>
        public void VerifyCostCategoryCode(string code)
        {
            Settings.Logger.Info(" Verify Cost Category Code ");
            ExtendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            ExtendedPage.SwitchToTableFrame(_frameCostCatCodes);
            ExtendedPage.VerifyTableColumnContainValue(_tableCostCatCodes, "Code", code);
            Driver.SwitchTo().DefaultContent();
        }
    }
}
