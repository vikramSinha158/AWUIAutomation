﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool;

namespace AssetWorks.UI.M5.TestAutomation.Actions.MotorPool
{
    internal class MotorPoolApprovalPageActions : MotorPoolApprovalPage
    {
        public MotorPoolApprovalPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Retrieve Motor Pool Reservations
        /// </summary>
        /// <param name="mpApproval"></param>
        public void RetrieveMotorPoolApprovalReservations(MPApproval mpApproval)
        {
            Settings.Logger.Info("Retrieve Motor Pool Reservations");
            _extendedPage.SwitchToContentFrame();
            _inputReservedFor.SetText(mpApproval.ReservedFor, "Reserved For");
            Driver.WaitForReady();
            _inputRequestDept.SetText(mpApproval.RequestDept, "Request Dept");
            Driver.WaitForReady();
            _inputPickupLocation.SetText(mpApproval.PickupLocation, "Pickup Location");
            Driver.WaitForReady();
            _inputRentalClass.SetText(mpApproval.RentalClass, "Rental Class");
            Driver.WaitForReady();
            _inputMpTicketNo.SetText(mpApproval.MpTicketNo, "Mp Ticket No");
            Driver.WaitForReady();
            _btnRetrieve.Click();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Approve Motor Pool Reservations
        /// </summary>
        /// <param name="mpApproval"></param>
        public void ApproveMotorPoolReservations(MPApproval mpApproval)
        {
            Settings.Logger.Info("Approve Motor Pool Reservations");
            RetrieveMotorPoolApprovalReservations(mpApproval);
            if(mpApproval.Reservations != null)
            {
                Driver.SwitchToFrame(_frameMPApproval, "MP Approval");
                foreach(MPReservations reservation in mpApproval.Reservations)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableMPApproval, _headerTicketNo, reservation.MpTicketNo,
                        "approveFl", "value", "div").SetCheckBox("Approve");
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Approved Motor Pool Reservations
        /// </summary>
        /// <param name="mpApproval"></param>
        public void VerifyApprovedMotorPoolReservations(MPApproval mpApproval)
        {
            Settings.Logger.Info("Verify Approved Motor Pool Reservations");
            RetrieveMotorPoolApprovalReservations(mpApproval);
            if (mpApproval.Reservations != null)
            {
                Driver.SwitchToFrame(_frameMPApproval, "MP Approval");
                foreach (MPReservations reservation in mpApproval.Reservations)
                {
                    _extendedPage.VerifyTableColumnDoesNotContainValue(_tableMPApproval, _headerTicketNo, 
                        reservation.MpTicketNo, "value", "div");
                }
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
