﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool;

namespace AssetWorks.UI.M5.TestAutomation.Actions.MotorPool
{
    internal class MotorPoolReservationPageActions : MotorPoolReservationPage
    {
        public MotorPoolReservationPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Motor Pool Reservation
        /// </summary>
        /// <param name="reservationInfo"></param>
        /// <returns></returns>
        public string CreateMotorPoolReservation(MPReservationInfo reservationInfo)
        {
            Settings.Logger.Info("Creating Motor Pool Reservation");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _buttonNewTicket.ClickElement("New Ticket", Driver);
            Driver.WaitForReady();
            _selectPickupLocation.SelectFilterValueHavingEqualValue(reservationInfo.PickupLocation);
            Driver.WaitForReady();
            _inputPickupDateTime.SetText(reservationInfo.PickupDateTime, "PickupDateTime");
            Driver.WaitForReady();
            _selectReturnLocation.SelectFilterValueHavingEqualValue(reservationInfo.ReturnLocation);
            Driver.WaitForReady();
            _inputReturnDateTime.SetText(reservationInfo.ReturnDateTime, "ReturnDateTime");
            Driver.WaitForReady();
            _selectRentalClass.SelectFilterValueHavingEqualValue(reservationInfo.RentalClass);
            Driver.WaitForReady();
            _inputReservedFor.SetText(reservationInfo.ReservedFor, "Reserved For");
            Driver.WaitForReady();
            _selectDepartment.SelectFilterValueHavingEqualValue(reservationInfo.Department);
            Driver.WaitForReady();
            _inputPhoneNo.SetText(reservationInfo.PhoneNo, "Phone No");
            Driver.WaitForReady();
            _inputRefNo.SetText(reservationInfo.RefNo, "Ref No");
            Driver.WaitForReady();
            _inputDestination.SetText(reservationInfo.Destination, "Destination");
            Driver.WaitForReady();
            _inputRequestedBy.SetText(reservationInfo.RequestedBy, "Requested By");
            Driver.WaitForReady();
            _inputReason.SetText(reservationInfo.Reason, "Reason");
            Driver.WaitForReady();
            _inputAccountNo.SetText(reservationInfo.AccountNo, "Account No");
            Driver.WaitForReady();
            _inputReserveNotes.SetText(reservationInfo.ReserveNotes, "Reserve Notes");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage._buttonSave.ClickElement("Save", Driver);
            Driver.WaitForSomeTime();
            Driver.AcceptAlert();
            _extendedPage.SwitchToContentFrame();
            reservationInfo.MPTicketNo = _inputTicketNo.GetElementValueByAttribute("ovalue");
            reservationInfo.ConfirmationCode = _inputConfirmationCode.GetElementValueByAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info($"Created Motor Pool Reservation Ticket - {reservationInfo.MPTicketNo}");
            return reservationInfo.MPTicketNo;
        }

        /// <summary>
        /// Verify Motor Pool Reservation Info
        /// </summary>
        /// <param name="reservationInfo"></param>
        public void VerifyMotorPoolReservation(MPReservationInfo reservationInfo)
        {
            Settings.Logger.Info("Verify Motor Pool Reservation Info");
            _extendedPage.RefreshAndSetText(_inputTicketNo, reservationInfo.MPTicketNo, "Ticket No");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputMPStatus, "Status", reservationInfo.MPStatus);
            CommonUtil.VerifyElementValue(_selectPickupLocation, "Pickup Location", reservationInfo.PickupLocation, true);
            CommonUtil.VerifyElementValue(_selectReturnLocation, "Return Location", reservationInfo.ReturnLocation, true);
            CommonUtil.VerifyElementValue(_inputConfirmationCode, "Confirmation Code", reservationInfo.ConfirmationCode);
            CommonUtil.VerifyElementValue(_selectRentalClass, "Rental Class", reservationInfo.RentalClass, true);
            CommonUtil.VerifyElementValue(_inputReservedFor, "Reserved For", reservationInfo.ReservedFor);
            CommonUtil.VerifyElementValue(_inputRefNo, "Ref No", reservationInfo.RefNo);
            CommonUtil.VerifyElementValue(_inputDestination, "Destination", reservationInfo.Destination);
            CommonUtil.VerifyElementValue(_inputRequestedBy, "Requested By", reservationInfo.RequestedBy);
            CommonUtil.VerifyElementValue(_inputReason, "Reason", reservationInfo.Reason);
            CommonUtil.VerifyElementValue(_inputAccountNo, "Account No", reservationInfo.AccountNo);
            CommonUtil.VerifyElementValue(_inputReserveNotes, "Reserve Notes", reservationInfo.ReserveNotes);
            CommonUtil.VerifyElementValue(_inputTicketApprover, "Ticket Approver", reservationInfo.TicketApprover);
            CommonUtil.VerifyElementValue(_inputApproverName, "Approver Name", reservationInfo.ApproverName);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Successfully Verified Motor Pool Reservation Info");
        }

        /// <summary>
        /// Delete Motor Pool Reservation
        /// </summary>
        /// <param name="MPTicketNo"></param>
        public void DeleteMotorPoolReservation(string MPTicketNo)
        {
            Settings.Logger.Info("Delete Motor Pool Reservation");
            _extendedPage.DeleteActionCode(_inputTicketNo, MPTicketNo, "Ticket No");
            MPReservationInfo reservation = new MPReservationInfo();
            reservation.MPTicketNo = MPTicketNo;
            reservation.MPStatus = "Cancelled";
            VerifyMotorPoolReservation(reservation);
        }
    }
}
