﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool;

namespace AssetWorks.UI.M5.TestAutomation.Actions.MotorPool
{
    internal class MotorPoolReservationAssignmentPageActions : MotorPoolReservationAssignmentPage
    {
        public MotorPoolReservationAssignmentPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Assign Motor Pool Reservations
        /// </summary>
        /// <param name="assignment"></param>
        public void AssignMotorPoolReservations(MPReservationAssignment assignment)
        {
            Settings.Logger.Info("Creating Motor Pool Reservation Assignment");
            ExtendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputPickupLocation.SetText(assignment.PickupLocation, "Pickup Location");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameMPAssign, "MPAssign");
            foreach(Reservation reservation in assignment.Reservations)
            {
                ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableMotorPool, headerTicket, reservation.Ticket, "unit").SetText(reservation.Unit, "Unit");
                Driver.WaitForReady();
            }
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Remove Motor Pool Reservations
        /// </summary>
        /// <param name="assignment"></param>
        public void RemoveMotorPoolReservations(MPReservationAssignment assignment)
        {
            Settings.Logger.Info("Removing Motor Pool Reservation Assignment");
            ExtendedPage.RefreshAndSetText(_inputPickupLocation, assignment.PickupLocation, "Pickup Location");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameMPAssign, "MPAssign");
            foreach (Reservation reservation in assignment.Reservations)
            {
                ExtendedPage.SelectAllAndClearField(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableMotorPool, headerTicket, reservation.Ticket, "unit"));
                Driver.WaitForReady();
            }
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Verify Motor Pool Reservation Details
        /// </summary>
        /// <param name="assignment"></param>
        public void VerifyMotorPoolReservationDetails(MPReservationAssignment assignment)
        {
            Settings.Logger.Info("Verify Motor Pool Reservation Assignment Details");
            Driver.WaitForReady();
            ExtendedPage.SwitchToTableFrame(_frameMPAssign);
            foreach (MPReservationInfo reservation in assignment.ReservationDetails)
            {
                ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableMotorPool, headerTicket, reservation.MPTicketNo, "unit").Click();
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                ExtendedPage.SwitchToContentFrame();
                CommonUtil.VerifyElementValue(_inputReservedFor, "Reserved For", reservation.ReservedFor);
                CommonUtil.VerifyElementValue(_inputReservedForDesc, "Reserved For Desc", reservation.ReservedForDesc);
                Driver.SwitchToFrame(_frameMPAssign, "MPAssign");
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
