﻿using OpenQA.Selenium;
using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool;

namespace AssetWorks.UI.M5.TestAutomation.Actions.MotorPool
{
    internal class MotorpoolPortalPageActions : MotorpoolPortalPage
    {
        public MotorpoolPortalPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Verify Motorpool Portal Options
        /// </summary>
        public void VerifyMotorpoolPortalOptions()
        {
            Settings.Logger.Info("Verify Motorpool Portal Options Display");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            CommonUtil.AssertTrue(_ViewYourProfile.GetText("Profile"), "View your profile");
            CommonUtil.AssertTrue(_ViewOrCancelCurrentReservations.GetText("Current Reservations"), "View or cancel current reservations");
            CommonUtil.AssertTrue(_MakeaNewReservation.GetText("New Reservation"), "Make a new reservation");
            CommonUtil.AssertTrue(_Logoff.GetText("Logoff"), "Logoff");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update User Profile
        /// </summary>
        /// <param name="profile"></param>
        public void UpdateYourProfile(MpPortalProfile profile)
        {
            Settings.Logger.Info("Update User Profile");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _ViewYourProfile.ClickElement("View your profile", Driver);
            Driver.WaitForSomeTime();
            CommonUtil.VerifyElementValue(_inputDriverNo, "Driver No", profile.DriverNo);
            _inputEmail.SetText(profile.Email, "Email");
            Driver.WaitForReady();
            _inputPhoneNo.SetText(profile.PhoneNo, "Phone No");
            Driver.WaitForReady();
            _inputAddress1.SetText(profile.Address1, "Address1");
            Driver.WaitForReady();
            _inputAddress2.SetText(CommonUtil.GetRandomStringWithSpecialChars(), "Address2");
            Driver.WaitForReady();
            if (profile.CancelChanges)
                _btnCancel.ClickElement("Cancel Changes", Driver);
            else
                _btnSave.ClickElement("Save Changes", Driver);
            Driver.WaitForSomeTime();
            Driver.ScrollIntoViewAndClick(_ReturnToMainScreen, "Return To Main Screen");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify User Profile
        /// </summary>
        /// <param name="profile"></param>
        public void VerifyYourProfile(MpPortalProfile profile)
        {
            Settings.Logger.Info("Verify User Profile");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _ViewYourProfile.ClickElement("View your profile", Driver);
            Driver.WaitForSomeTime();
            CommonUtil.VerifyElementValue(_inputDriverNo, "Driver No", profile.DriverNo);
            CommonUtil.VerifyElementValue(_inputEmail, "Email", profile.Email);
            CommonUtil.VerifyElementValue(_inputPhoneNo, "Phone No", profile.PhoneNo);
            CommonUtil.VerifyElementValue(_inputAddress1, "Address1", profile.Address1);
            CommonUtil.VerifyElementValue(_inputAddress2, "Address2", profile.Address2);
            Driver.ScrollIntoViewAndClick(_ReturnToMainScreen, "Return To Main Screen");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Current Reservations
        /// </summary>
        /// <param name="reservations"></param>
        public void VerifyCurrentReservations(List<MpReservations> reservations)
        {
            Settings.Logger.Info("Verify Current Reservations");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _ViewOrCancelCurrentReservations.ClickElement("Current Reservations", Driver);
            Driver.WaitForSomeTime();
            if (reservations != null)
            {
                Driver.SwitchToFrame(_framemrData, "Table");
                foreach(MpReservations reservation in reservations)
                {
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablemrData, "Ticket",
                        reservation.Ticket, "CRstatus", "ovalue"), "Status", reservation.Status);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablemrData, "Ticket",
                        reservation.Ticket, "CRpickLoc", "ovalue"), "Pickup Loc", reservation.PickupLocation);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablemrData, "Ticket",
                        reservation.Ticket, "CRretLoc", "ovalue"), "Return Loc", reservation.ReturnLocation);
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablemrData, "Ticket",
                        reservation.Ticket, "CRrClass", "ovalue"), "Rental Class", reservation.RentalClass);
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
            }
            Driver.ScrollIntoViewAndClick(_ReturnToMainScreen, "Return To Main Screen");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Current Reservations
        /// </summary>
        /// <param name="TicketNo"></param>
        public void VerifyEmailCurrentReservation(string TicketNo)
        {
            Settings.Logger.Info("Verify Current Reservations");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _ViewOrCancelCurrentReservations.ClickElement("Current Reservations", Driver);
            Driver.WaitForSomeTime();
            Driver.SwitchToFrame(_framemrData, "Table");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tablemrData, "Ticket", TicketNo, "CRticket", "ovalue").Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollInView(_btnEmailTicket);
            _btnEmailTicket.Click();
            Driver.WaitForSomeTime();
            string msg = Driver.GetAlertText();
            Driver.AcceptAlert();
            Assert.IsTrue(msg.Contains("You will receive an email containing the ticket information"));
            Driver.ScrollIntoViewAndClick(_ReturnToMainScreen, "Return To Main Screen");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Cancel Reservations
        /// </summary>
        /// <param name="TicketNo"></param>
        public void VerifyCancelReservation(string TicketNo)
        {
            Settings.Logger.Info("Verify Cancel Reservations");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _ViewOrCancelCurrentReservations.ClickElement("Current Reservations", Driver);
            Driver.WaitForSomeTime();
            Driver.SwitchToFrame(_framemrData, "Table");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tablemrData, "Ticket", TicketNo, "CRticket", "ovalue").Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            _btnCancelReservation.Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ActionRequiredWindow("No");
            _extendedPage.SwitchToContentFrame();
            _btnCancelReservation.Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ActionRequiredWindow("Yes");
            Driver.WaitForSomeTime();
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_ReturnToMainScreen, "Return To Main Screen");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Make A New Reservation
        /// </summary>
        /// <param name="reservation"></param>
        /// <returns></returns>
        public string MakeANewReservation(MpReservations reservation)
        {
            Settings.Logger.Info("Make A New Reservation");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _MakeaNewReservation.ClickElement("New Reservation", Driver);
            Driver.WaitForSomeTime();
            _inputPickupDate.SetText(reservation.PickupDate, "Pickup Date");
            Driver.WaitForReady();
            _inputReturnDate.SetText(reservation.ReturnDate, "Return Date");
            Driver.WaitForReady();
            _selectPickupLoc.SelectDropdownUsingValue("Pickup Location", reservation.PickupLocation);
            Driver.WaitForReady();
            if (reservation.ReturnLocation != null)
            {
                _extendedPage.SetCheckBox(_chkboxSame, "Same Return Loc", false);
                Driver.WaitForReady();
                _selectReturnLoc.SelectDropdownUsingValue("Return Location", reservation.ReturnLocation);
            }
            else
                _extendedPage.SetCheckBox(_chkboxSame, "Same Return Loc");
            Driver.WaitForReady();
            _btnRentalClass.ClickElement("Rental Class", Driver);
            Driver.WaitForReady();
            Driver.ScrollIntoViewAndClick(_btnCreateReservation, "Create Reservation");
            Driver.WaitForSomeTime();
            Assert.IsTrue(_txtConfMsg.GetText("confirmation Msg").Contains("Reservation created."));
            _btnEmailTicket.Click();
            Driver.WaitForSomeTime();
            string msg = Driver.GetAlertText();
            Driver.AcceptAlert();
            Assert.IsTrue(msg.Contains("You will receive an email containing the ticket information"));
            string newTicket = _inputNewTicket.GetAttribute("ovalue");
            Driver.ScrollIntoViewAndClick(_ReturnToMainScreen, "Return To Main Screen");
            Driver.SwitchTo().DefaultContent();
            return newTicket;
        }

        /// <summary>
        /// Perform Logoff
        /// </summary>
        public void PerformLogoff()
        {
            Settings.Logger.Info("Logoff from Motorpool Portal");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _Logoff.Click();
            Driver.WaitForSomeTime();
            Driver.SwitchTo().DefaultContent();
            CommonUtil.VerifyElementText(_txtLogoff, "Logoff Msg", "Logoff complete");
        }
    }
}
