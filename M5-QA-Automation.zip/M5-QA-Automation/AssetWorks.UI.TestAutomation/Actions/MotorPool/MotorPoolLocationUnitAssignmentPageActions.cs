﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool;

namespace AssetWorks.UI.M5.TestAutomation.Actions.MotorPool
{
    internal class MotorPoolLocationUnitAssignmentPageActions : MotorPoolLocationUnitAssignmentPage
    {
        public MotorPoolLocationUnitAssignmentPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Verify MP Location Unit Assignment
        /// </summary>
        /// <param name="mpLocationUnits"></param>
        public void VerifyMPLocationUnitAssignment(MPLocationUnits mpLocationUnits)
        {
            Settings.Logger.Info(" Verify MP Location Unit Assignment ");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputNoClass, "No Class", mpLocationUnits.NoClass);
            CommonUtil.VerifyElementValue(_inputNoLocation, "No Location", mpLocationUnits.NoLocation);
            CommonUtil.VerifyElementValue(_inputNoLocationClass, "No Location Class", mpLocationUnits.NoLocationClass);
            Driver.SwitchToFrame(_frameMPLocUnits, "MP Location Units");
            foreach (LocationUnits location in mpLocationUnits.LocationUnits)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMPLocUnits, "Location", location.Location,
                    "unitAssigned"), "Units Assigned", location.UnitsAssigned, false, "value");
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
