﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool;

namespace AssetWorks.UI.M5.TestAutomation.Actions.MotorPool
{
    internal class MotorPoolRentalClassPageActions : MotorPoolRentalClassPage
    {
        public MotorPoolRentalClassPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create New Motor Pool Rental Class
        /// </summary>
        /// <param name="rentalClass"></param>
        public string CreateNewMotorPoolRentalClass(MPRentalClass rentalClass)
        {
            Settings.Logger.Info("Create Motor Pool Rental Class");
            string mpClass = string.Empty;
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(rentalClass.Class, ref mpClass, "MPRentalClassQuery", 5))
            {
                _extendedPage.SwitchToTableFrame(_frameMPRentalClass);
                _inputNewClass.SetText(mpClass, "New Class");
                Driver.WaitForReady();
                _inputNewDesc.SetText(rentalClass.Description, "New Description");
                Driver.WaitForReady();
                _inputNewPrepDuration.SetText(rentalClass.PrepDurationHours, "New Prep Duration");
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
                Driver.WaitForReady();
                _extendedPage.SwitchToTableFrame(_frameMPRentalClass);
                _extendedPage.VerifyTableColumnContainValue(_tableMotorPool, "Class", mpClass, "value", "div");
                Driver.SwitchTo().DefaultContent();
            }
            return mpClass;
        }

        /// <summary>
        /// Verify Table Updated With Class
        /// </summary>
        /// <param name="rentalClass"></param>
        public void VerifyTableUpdatedWithClass(MPRentalClass rentalClass)
        {
            Settings.Logger.Info($"Verify Motor Pool Rental Class for : " + rentalClass.Class);
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_frameMPRentalClass);
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMotorPool, "Class", rentalClass.Class, "description",
                "value", "div"), "Description", rentalClass.Description, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMotorPool, "Class", rentalClass.Class, "prep_duration",
                "value", "div"), "Prep Duration Hours", rentalClass.PrepDurationHours, false, "value");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Motor Pool Rental Class
        /// </summary>
        /// <param name="rentalClass"></param>
        public void UpdateMotorPoolRentalClass(MPRentalClass rentalClass)
        {
            Settings.Logger.Info($"Update Motor Pool Rental Class for : " + rentalClass.Class);
            _extendedPage.SwitchToTableFrame(_frameMPRentalClass);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableMotorPool, "Class", rentalClass.Class, "description", 
                "value", "div").SetText(rentalClass.Description, "Description");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableMotorPool, "Class", rentalClass.Class, "prep_duration", 
                "value", "div").SetText(rentalClass.PrepDurationHours, "Prep Duration Hours");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Delete Motor Pool Rental Class
        /// </summary>
        /// <param name="Class"></param>
        public void DeleteMotorPoolRentalClass(string Class)
        {
            Settings.Logger.Info($"Deleting Motor Pool Rental Class for : " + Class);
            _extendedPage.SwitchToTableFrame(_frameMPRentalClass);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableMotorPool, "Class", Class, "description", "value", "div").Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToTableFrame(_frameMPRentalClass);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_tableMotorPool, "Class", Class, "value", "div");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Motor Pool Confirmation Codes
        /// </summary>
        /// <param name="confirmationCodes"></param>
        public void VerifyMotorPoolConfirmationCodes(MPConfirmationCodes confirmationCodes)
        {
            Settings.Logger.Info($"Verify Motor Pool Confirmation Codes for : " + confirmationCodes.RentalClass);
            _extendedPage.SwitchToTableFrame(_frameMPRentalClass);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableMotorPool, "Class", confirmationCodes.RentalClass, "class", "value", "div").Click();
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            Driver.SwitchToFrame(_extendedPage._contentFrame2, "Content Frame 2");
            CommonUtil.VerifyElementValue(_inputRentalClass, "Rental Class", confirmationCodes.RentalClass);
            CommonUtil.VerifyElementValue(_inputRentalClassDesc, "Rental Class Desc", confirmationCodes.RentalClassDesc);
            Driver.SwitchToFrame(_frameMPConfirmCode, "MP Confirm Code");
            foreach(Reservation confirmationCode in confirmationCodes.Reservations)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMPConfirmCode, "MP Ticket", confirmationCode.Ticket,
                    "cUNIT_NO"), "Unit", confirmationCode.Unit, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMPConfirmCode, "MP Ticket", confirmationCode.Ticket,
                    "cCONFIRMATION_CODE"), "Confirmation Code", confirmationCode.ConfirmationCode, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMPConfirmCode, "MP Ticket", confirmationCode.Ticket,
                    "cLOCATION"), "Pickup Location", confirmationCode.PickupLocation, false, "value");
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage._closeShowAttachmentsBtn.Click();
        }
    }
}
