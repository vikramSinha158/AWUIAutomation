﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool;

namespace AssetWorks.UI.M5.TestAutomation.Actions.MotorPool
{
    internal class MotorpoolUnitsListedByLocationPageActions : MotorpoolUnitsListedByLocationPage
    {
        public MotorpoolUnitsListedByLocationPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Verify MPUnits Listed By Location
        /// </summary>
        /// <param name="unitsList"></param>
        public void VerifyMPUnitsListedByLocation(MPUnitsList unitsList)
        {
            Settings.Logger.Info(" Verify MPUnits Listed By Location ");
            _extendedPage.SwitchToContentFrame();
            _inputMPLocation.SetText(unitsList.MPLocation, "MP Location");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputMPLocationDesc, "Location Desc", unitsList.MPLocationDesc);
            Driver.SwitchToFrame(_frameMPUnitLocation, "MP Unit Location");
            foreach(UnitListed unitListed in unitsList.UnitListed)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMPUnitLocation, "Unit", unitListed.Unit,
                    "Class"), "Class", unitListed.Class, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMPUnitLocation, "Unit", unitListed.Unit,
                    "YMM"), "Year Make Model", unitListed.YearMakeModel, false, "value");
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
