﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.MotorPool;

namespace AssetWorks.UI.M5.TestAutomation.Actions.MotorPool
{
    internal class MotorPoolAssignUnitPageActions : MotorPoolAssignUnitPage
    {
        public MotorPoolAssignUnitPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Retrieve Motor Pool Assign Unit
        /// </summary>
        /// <param name="unitNo"></param>
        public void RetrieveMotorPoolAssignUnit(string unitNo)
        {
            Settings.Logger.Info(" Retrieve Motor Pool Assign Unit ");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputUnitNo.SetText(unitNo, "Unit No");
            Driver.WaitForReady();
            _buttonRetrieve.ClickElement("Retrieve", Driver);
        }

        /// <summary>
        /// Update Motor Pool Assignments With Unit Info
        /// </summary>
        /// <param name="assignUnit"></param>
        public void UpdateMotorPoolAssignmentsWithUnitInfo(AssignUnitDetails assignUnit)
        {
            Settings.Logger.Info(" Updating Motor Pool Assign Unit");
            RetrieveMotorPoolAssignUnit(assignUnit.AssignUnitNo);
            if (assignUnit.UnitAssignments != null)
            {
                Driver.SwitchToFrame(_frameAssignUnit, "Assign Unit");
                foreach (UnitAssignments assignment in assignUnit.UnitAssignments)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssignUnit, "Unit", assignment.UnitNo,
                        "Class").SetText(assignment.Class, "Class");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssignUnit, "Unit", assignment.UnitNo,
                        "Location").SetText(assignment.Location, "Location");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssignUnit, "Unit", assignment.UnitNo,
                        "BodyColor").SetText(assignment.BodyColor, "Body Color");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssignUnit, "Unit", assignment.UnitNo,
                        "WhereNow").SetText(assignment.WhereNow, "Where Now");
                    Driver.WaitForReady();
                }
            }
            else
                Settings.Logger.Info(" No Assignments With Unit Info to update.!");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Motor Pool Assign Unit Info
        /// </summary>
        /// <param name="assignUnit"></param>
        public void VerifyMotorPoolAssignUnitInfo(AssignUnitDetails assignUnit)
        {
            Settings.Logger.Info(" Verify Motor Pool Assign Unit");
            _extendedPage.ClickOnRefreshButton();
            RetrieveMotorPoolAssignUnit(assignUnit.AssignUnitNo);
            if (assignUnit.UnitAssignments != null)
            {
                Driver.SwitchToFrame(_frameAssignUnit, "Assign Unit");
                foreach (UnitAssignments assignment in assignUnit.UnitAssignments)
                {
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssignUnit, "Unit",
                        assignment.UnitNo, "Class"), "Class", assignment.Class, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssignUnit, "Unit",
                        assignment.UnitNo, "Location"), "Location", assignment.Location, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssignUnit, "Unit",
                        assignment.UnitNo, "BodyColor"), "Body Color", assignment.BodyColor, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssignUnit, "Unit",
                        assignment.UnitNo, "WhereNow"), "Where Now", assignment.WhereNow, false, "value");
                }
            }
            else
                Settings.Logger.Info(" No Assignments With Unit Info to verify.!");
            Driver.SwitchTo().DefaultContent();
        }
    }
}
