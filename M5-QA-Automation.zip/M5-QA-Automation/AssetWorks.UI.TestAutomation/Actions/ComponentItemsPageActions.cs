﻿using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class ComponentItemsPageActions : ComponentItemsPage
    {
        public ComponentItemsPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Add Component Item
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <param name="ComponentNo"></param>
        public void AddComponentItem(string ObjectKey,string ComponentNo)
        {
            Settings.Logger.Info(" Adding ComponentItem");
            ComponentItem ComponentItems = CommonUtil.DataObjectForKey(ObjectKey).ToObject<ComponentItem>();
            _extendpage.SwitchToContentFrame();
            _componenNotInput.SetText(ComponentNo, "ComponentNo");
            Driver.SwitchToFrame(_compItemFrame, "compItemFrame");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_compItemTable, _itemHeaderName, "", _itemId).SetText(ComponentItems.Item, "Item");
            FillItemInformation(ComponentItems);
        }

        /// <summary>
        /// Fill Item Information
        /// </summary>
        /// <param name="ComponentItems"></param>
        public void FillItemInformation(ComponentItem ComponentItems)
        {           
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_compItemTable, _itemHeaderName, ComponentItems.Item, _valueId).SetText(ComponentItems.Value, "value");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClicKSave();
        }

        /// <summary>
        /// Verify Component Item
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <param name="ComponentNo"></param>
        public void VerifyComponentItem(string ObjectKey, string ComponentNo)
        {
            ComponentItem ComponentItems = CommonUtil.DataObjectForKey(ObjectKey).ToObject<ComponentItem>();
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_componenNotInput, ComponentNo, "ComponentNo");  
            Driver.SwitchToFrame(_compItemFrame, "compItemFrame");
            Driver.WaitForReady();
            IWebElement Item = _extendpage.GetTableActionElementByRelatedColumnValue(_compItemTable, _itemHeaderName, ComponentItems.Item, _itemId);
            CommonUtil.VerifyElementValue(Item, "ComponentItems", ComponentItems.Item,false, "value");
            Driver.WaitForReady();
            IWebElement ComponentItemsVlaue = _extendpage.GetTableActionElementByRelatedColumnValue(_compItemTable, _itemHeaderName, ComponentItems.Item, _valueId);
            CommonUtil.VerifyElementValue(ComponentItemsVlaue, "ComponentItemsVlaue", ComponentItems.Value, false, "value");
        }

        /// <summary>
        /// Verify Component ItemDeletion
        /// </summary>
        /// <param name="ComponentNo"></param>
        /// <param name="ObjectKey"></param>
        public void VerifyComponentItemDeletion(string ObjectKey,string ComponentNo)
        {
            ComponentItem ComponentItems = CommonUtil.DataObjectForKey(ObjectKey).ToObject<ComponentItem>();
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_compItemTable, _itemHeaderName, ComponentItems.Item, _itemId).Click();
            _extendpage.DeleteAndVerifySingleTableRowDeletion(_componenNotInput, ComponentNo, _compItemFrame, _compItemTableRows);
            Settings.Logger.Info(" Successfully Verified Component Item Deletion ");
        }
    }
}
