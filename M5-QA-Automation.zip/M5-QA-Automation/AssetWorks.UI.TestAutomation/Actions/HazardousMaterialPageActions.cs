﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class HazardousMaterialPageActions : HazardousMaterialPage
    {
        public HazardousMaterialPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create New Hazardous Material Code
        /// </summary>
        /// <param name="dataObjects"></param>
        /// <returns></returns>
        public string CreateHazardousMaterialCode(HazardousMaterialCodeObjects dataObjects)
        {
            string[] queryparam = { dataObjects.ShipName, dataObjects.IdNumber };
            if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection,
                "HazardousMaterialQuery", queryparam, Settings.DBType))
            {
                Settings.Logger.Info(" Create New Hazardous Material Code ");
                ExtendedPage.SwitchToTableFrame(_frameHazardCodes);
                _inputShipName.SetText(dataObjects.ShipName, "Ship Name");
                _inputClassDivision.SetText(dataObjects.ClassDivision, "Class Division");
                _inputIdNumber.SetText(dataObjects.IdNumber, "Id Number");
                _selectPackGroup.SelectFilterValueHavingEqualValue(dataObjects.PackGroup);
                _inputDescription.SetText(dataObjects.Description, "Description");
                Driver.SwitchTo().DefaultContent();
                ExtendedPage.ClickOnSaveButton();
                Driver.WaitForReady();
                VerifyHazardousMaterialCode(dataObjects.ShipName);
            }
            return dataObjects.ShipName;
        }

        /// <summary>
        /// Verify Hazardous Material Code
        /// </summary>
        /// <param name="code"></param>
        public void VerifyHazardousMaterialCode(string code)
        {
            Settings.Logger.Info(" Verify Hazardous Material Code ");
            ExtendedPage.SwitchToTableFrame(_frameHazardCodes);
            ExtendedPage.VerifyTableColumnContainValue(_tableHazardCodes, "Proper\r\nShip Name", code);
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.ClickOnRefreshButton();
        }


        // Hazardous Material Setup
        /// <summary>
        /// Perform Hazardous Material Setup
        /// </summary>
        /// <param name="dataObjects"></param>
        public void PerformHazardousMaterialSetup(HazardousMaterialCodeObjects dataObjects)
        {
            Settings.Logger.Info(" Perform Hazardous Material Setup ");
            Driver.SwitchTo().DefaultContent();
            Driver.SwitchToFrame(ExtendedPage._contentFrame2, "Content Frame");
            _inputProperShippingName.SetText(dataObjects.ShipName, "Shipping Name");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }
    }
}
