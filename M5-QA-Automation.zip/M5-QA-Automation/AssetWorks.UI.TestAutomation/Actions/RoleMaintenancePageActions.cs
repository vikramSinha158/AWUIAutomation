﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class RoleMaintenancePageActions : RoleMaintenancePage
    {
        public RoleMaintenancePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Maintenance Role
        /// </summary>
        /// <param name="DataObjectKey"></param>
        /// <returns></returns>
        public string CreateMaintenanceRole(string DataObjectKey)
        {
            Settings.Logger.Info(" Creating Maintenance Role  ");
            var DataObject = CommonUtil.DataObjectForKey(DataObjectKey);
            string RoleName = CommonUtil.GetRandomStringWithSpecialChars(8);
            _extendpage.SwitchToContentFrame();
            _roleInput.SetText(RoleName, "Maintenance Role Name ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow("Create");
            _extendpage.SwitchToContentFrame();
            SystemAdminObjects.MaintenanceRoleDesc = _extendpage.EnterDescription(_roleDescInput);
            FillGeneralTab(DataObject);
            if (CommonUtil.DataForKey(SystemAdminObjects.FillLocationsOperational, DataObject) == "Yes")
            { FillLocationsOperational(); }
            if (CommonUtil.DataForKey(SystemAdminObjects.FillMenusKpi, DataObject) == "Yes")
            { FillMenusKPI(); }
            if (CommonUtil.DataForKey(SystemAdminObjects.FillPrivileges, DataObject) == "Yes")
            { FillPrivileges(); }
            if (CommonUtil.DataForKey(SystemAdminObjects.FillReporting, DataObject) == "Yes")
            { FillReporting(); }
            if (CommonUtil.DataForKey(SystemAdminObjects.FillDepartmentsAndChatGrp, DataObject) == "Yes")
            { FillDepartmentsAndChatGroup(); }
            if (CommonUtil.DataForKey(SystemAdminObjects.FillvGState, DataObject) == "Yes")
            { FillvGState(); }
            if (CommonUtil.DataForKey(SystemAdminObjects.FillIndiractAccounts, DataObject) == "Yes")
            { FillIndiractAccounts(); }
            SaveRoleMaintenance();
            return RoleName;
        }

        /// <summary>
        /// Fill General Tab
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillGeneralTab(dynamic DataObject)
        {
            Settings.Logger.Info(" Filling General Tab Maintenance Role  ");
            _extendpage.EnterDescription(_roleNoteInput);
            Driver.DoubleClick(_roleHomePageInput, "Restricted Home Page");         
            _lov.SelectCode();
            _extendpage.SwitchToContentFrame();
            _roleOutsideUserCheckBox.SelectCheckBox("Outside User");
            _roleTwoFactorCheckBox.SelectCheckBox("	Two Factor Authentication");
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollDown();
            _extendpage.SwitchToContentFrame();
            _databaseUserId = CommonUtil.DataForKey(SystemAdminObjects.DatabaseUserId, DataObject).ToString().Trim();
            Driver.WaitForReady();
            _roleDbUIDInput.SetText(_databaseUserId, "Database User Id");
            _pOLineValue = CommonUtil.DataForKey(SystemAdminObjects.POLineValue, DataObject).ToString().Trim();
            Driver.WaitForReady();
            _maxPOLineItemCostInput.SetText(_pOLineValue, "Maximum Allowable PO Line Value:");
            _pOLiTotalPOValueneValue = CommonUtil.DataForKey(SystemAdminObjects.TotalPOValue, DataObject).ToString().Trim();
            Driver.WaitForReady();
            _maxPOTotalCostInput.SetText(_pOLiTotalPOValueneValue, "Maximum Allowable Total PO Value");
            _commWOAuthAmountValue = CommonUtil.DataForKey(SystemAdminObjects.CommWOAuthAmount, DataObject).ToString().Trim();
            Driver.WaitForReady();
            _maxCommWOAuthAmtInput.SetText(_commWOAuthAmountValue, "Maximum Comm WO Auth Amount::");
            _approvalAmountValue = CommonUtil.DataForKey(SystemAdminObjects.ApprovalAmount, DataObject).ToString().Trim();
            Driver.WaitForReady();
            _partReqApprAmtInput.SetText(_approvalAmountValue, " Part Request Approval Amount");
            _serviceApprovalAmount = CommonUtil.DataForKey(SystemAdminObjects.ServiceApprovalAmount, DataObject).ToString().Trim();
            Driver.WaitForReady();
            _servReqApprAmtInput.SetText(_serviceApprovalAmount, " Commercial Request for Service Approval Amount:");
        }

        /// <summary>
        /// Verify Role Maintenance Detail
        /// </summary>
        /// <param name="DataObjectKey"></param>
        /// <param name="RoleMaintenanceName"></param>
        public void VerifyRoleMaintenanceDetail(String DataObjectKey,String RoleMaintenanceName)
        {
            _extendpage.RefreshAndSetText(_roleInput, RoleMaintenanceName, " Role Maintenance Name ");
            Driver.WaitForReady();  
            var DataObject = CommonUtil.DataObjectForKey(DataObjectKey);
            if (DataObject != null)
            {
                Settings.Logger.Info(" verifying added Role Maintenance ");            
                string ActualHomePageInputValue = _roleHomePageInput.GetElementValueByAttribute("ovalue");
                Assert.True(!String.IsNullOrEmpty(ActualHomePageInputValue),"Restricted Home Page value found null ");
                _databaseUserId = CommonUtil.DataForKey(SystemAdminObjects.DatabaseUserId, DataObject).ToString().Trim();
                string ActualDatabaseUserIdcValue = _roleDbUIDInput.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(_databaseUserId, ActualDatabaseUserIdcValue);
                _pOLineValue = CommonUtil.DataForKey(SystemAdminObjects.POLineValue, DataObject).ToString().Trim();
                string ActualPOLineValue = _maxPOLineItemCostInput.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(_pOLineValue, ActualPOLineValue);
                _pOLiTotalPOValueneValue = CommonUtil.DataForKey(SystemAdminObjects.TotalPOValue, DataObject).ToString().Trim();
                string ActualPOLiTotalPOValue = _maxPOTotalCostInput.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(_pOLiTotalPOValueneValue, ActualPOLiTotalPOValue);
                _commWOAuthAmountValue = CommonUtil.DataForKey(SystemAdminObjects.CommWOAuthAmount, DataObject).ToString().Trim();
                string ActualCommWOAutValue = _maxCommWOAuthAmtInput.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(_commWOAuthAmountValue , ActualCommWOAutValue);
                _approvalAmountValue = CommonUtil.DataForKey(SystemAdminObjects.ApprovalAmount, DataObject).ToString().Trim();
                string ActualApprovalAmountValue = _partReqApprAmtInput.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(_approvalAmountValue, ActualApprovalAmountValue);
                string ActualServiceApprovalValue = _servReqApprAmtInput.GetElementValueByAttribute("ovalue");
                _serviceApprovalAmount = CommonUtil.DataForKey(SystemAdminObjects.ServiceApprovalAmount, DataObject).ToString().Trim();
                CommonUtil.AssertTrue<string>( _serviceApprovalAmount, ActualServiceApprovalValue);
                Settings.Logger.Info(" Successfully Verified  Role Maintenance Information");
            }
            else { Assert.Fail("Data not vailable for Role aintenance "); }
        }

        /// <summary>
        /// Edit Role Maintenance Detail
        /// </summary>
        /// <param name="DataObjectKey"></param>
        public void EditRoleMaintenanceDetail(String DataObjectKey)
        {
            Settings.Logger.Info(" Edit Maintenance Role  ");
            var DataObject = CommonUtil.DataObjectForKey(DataObjectKey);
            if (DataObject != null)
            {
                FillGeneralTab(DataObject);
                SaveRoleMaintenance();
            }
            else { Assert.Fail("Data not vailable for Role Maintenancet "); }
        }

        /// <summary>
        /// Verify Maintenance Role Deletion
        /// </summary>
        public void VerifyMaintenanceRoleDeletion()
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.VerifyCodeDeletion(_roleInput, SystemAdminObjects.MaintenanceRole, "Maintenance Role");
        }

        /// <summary>
        /// Fill Locations Operational
        /// </summary>
        public void FillLocationsOperational()
        {
            Settings.Logger.Info(" Filling Locations or Operational Entities ");
            ClickOnMaintenanceRoleTab(_locationsOperationalTab, "Locations Operational");
            _leftLocListCnt = _extendpage.SelectAllGroupList(_locFrame,_locListLeft, _locListMoveRight,_locListRight,ref _rightLocListCnt);
            _rightLocListCnt = _rightLocListCnt + _leftLocListCnt;
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _leftOperationalListCnt = _extendpage.SelectAllGroupList(_operEntityFrame,_openterLeft,_openterMoveRight, _openterRight, ref _rightOperationalListCnt);
            _rightOperationalListCnt= _rightOperationalListCnt + _leftOperationalListCnt;
        }

        /// <summary>
        /// Verify Locations Operational
        /// </summary>
        /// <param name="RoleNmae"></param>
        public void VerifyLocationsOperational(string RoleNmae)
        {           
            _extendpage.RefreshAndSetText(_roleInput, RoleNmae, "Role Name Input ");
            _locationsOperationalTab.ClickElement("LocationsOperational", Driver);
            _extendpage.verifyGroupListCount(_locFrame,_locListRight,_rightLocListCnt);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _extendpage.verifyGroupListCount(_operEntityFrame, _openterRight, _rightOperationalListCnt);
            Settings.Logger.Info(" Successfully Verified  Adding Locations or Operational Entities ");
        }

        /// <summary>
        /// Move Locations Operational Left
        /// </summary>
        public void MoveLocationsOperationalLeft()
        {
            Settings.Logger.Info(" Move Authorized Privileges Locations and  Operational Entities To Left ");
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _extendpage.SelectAllAndMoveGroupListElements(_locFrame, _locListRight, _locListMoveLeft);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _extendpage.SelectAllAndMoveGroupListElements(_operEntityFrame, _openterRight, _openterMoveLeft);
            SaveRoleMaintenance();
        }

        /// <summary>
        /// Verify Removing  Locations Operational Entities
        /// </summary>
        /// <param name="RoleNmae"></param>
        public void VerifyRemovingLocationsOperational(string RoleNmae)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_roleInput, RoleNmae, "Role Name Input ");
            _locationsOperationalTab.ClickElement("LocationsOperational", Driver);
            VerifyRemovingAllItemFromGroupList(_locFrame, _locListRight);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            VerifyRemovingAllItemFromGroupList(_operEntityFrame, _openterRight);
            Settings.Logger.Info(" Successfully Verified  Locations Operational Entities  ");
        }

        /// <summary>
        /// Fill Menus KPI
        /// </summary>
        public void FillMenusKPI()
        {
            Settings.Logger.Info(" Filling Menus or KPIs Entities ");
            ClickOnMaintenanceRoleTab(_menusKPITab, "Menus or KPIs");
            _lefMenusListCnt = _extendpage.SelectAllGroupList(_menusFrame, _menusListLeft, _menusMoveRight, _menusListRight, ref _rightMenusListCnt);
            _rightMenusListCnt = _rightMenusListCnt + _lefMenusListCnt;
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _leftKpiListCnt = _extendpage.SelectAllGroupList(_kpiFrame, _kpiListLeft, _kpiMoveRight, _kpiListRight, ref _rightKpiListCnt);
            _rightKpiListCnt = _rightKpiListCnt + _leftKpiListCnt;
        }

        /// <summary>
        /// Verify MenusKPI
        /// </summary>
        /// <param name="RoleNmae"></param>
        public void VerifyMenusKPI(string RoleNmae)
        {
            _extendpage.RefreshAndSetText(_roleInput, RoleNmae, "Role Name Input ");
            _menusKPITab.ClickElement("Menus or KPI", Driver);
            _extendpage.verifyGroupListCount(_menusFrame, _menusListRight, _rightMenusListCnt);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _extendpage.verifyGroupListCount(_kpiFrame, _kpiListRight, _rightKpiListCnt);
            Settings.Logger.Info(" Successfully Verified  Adding Menus or KPI ");
        }

        /// <summary>
        /// Click On Mantenancele
        /// </summary>
        /// <param name="TabName"></param>
        public void ClickOnMaintenanceRoleTab(IWebElement TabName,string TabNameDesc)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            TabName.ClickElement(TabNameDesc, Driver);
        }

        /// <summary>
        /// Select All And Move Authorized Menus
        /// </summary>
        public void SelectAllAndMoveAuthorizedMenus()
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _extendpage.SelectAllAndMoveGroupListElements(_menusFrame, _menusListRight, _menusMoveLeft);
        }

        /// <summary>
        /// Select All And Move Authorized KPI Group
        /// </summary>
        public void SelectAllAndMoveAuthorizedKPIGroup()
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _extendpage.SelectAllAndMoveGroupListElements(_kpiFrame, _kpiListRight, _kpiMoveLeft);
        }

        /// <summary>
        /// Move Authorized Menus And KPI To Left
        /// </summary>
        public void MoveAuthorizedMenusAndKPIToLeft()
        {
            Settings.Logger.Info(" Move Authorized Menus And KPI To Left ");
            SelectAllAndMoveAuthorizedMenus();
            SelectAllAndMoveAuthorizedKPIGroup();
            SaveRoleMaintenance();
        }

        /// <summary>
        /// Verify Removing Menus KPI
        /// </summary>
        /// <param name="RoleNmae"></param>
        public void VerifyRemovingMenusKPI(string RoleNmae)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_roleInput, RoleNmae, "Role Name Input ");
            _menusKPITab.ClickElement("Menus or KPI", Driver);
            VerifyRemovingAllItemFromGroupList(_menusFrame, _menusListRight);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            VerifyRemovingAllItemFromGroupList(_kpiFrame, _kpiListRight);
            Settings.Logger.Info(" Successfully Verified  Removing Menus or KPI ");
        }

        /// <summary>
        /// Verify Removing All Item From Group List
        /// </summary>
        /// <param name="Frame"></param>
        /// <param name="GroupListElement"></param>
        public void VerifyRemovingAllItemFromGroupList(IWebElement Frame, IWebElement GroupListElement)
        {
            int ItemCount = 0;
            Driver.SwitchToFrame(Frame, "Group List Frame");
            Driver.ScrollInView(GroupListElement);
            ItemCount = GroupListElement.GetDropdownListTotalCount();
            CommonUtil.AssertTrue<int>(0, ItemCount);
        }

        /// <summary>
        /// Save Role Maintenance
        /// </summary>
        public void SaveRoleMaintenance()
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClicKSave();
            _extendpage.ActionRequiredWindow("Continue?");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Fill Privileges
        /// </summary>
        public void FillPrivileges()
        {
            Settings.Logger.Info(" Filling Privileges Entities ");
            ClickOnMaintenanceRoleTab(_privilegesTab, "Privileges");
            _leftPrivilegesListCnt = _extendpage.SelectAllGroupList(_privFrame, _privListLeft, _privListMoveRight, _privListRight, ref _rightPrivilegesListCnt);
            _rightPrivilegesListCnt = _rightPrivilegesListCnt + _leftPrivilegesListCnt;
        }

        /// <summary>
        /// Verify Privileges
        /// </summary>
        /// <param name="RoleNmae"></param>
        public void VerifyPrivileges(string RoleNmae)
        {
            _extendpage.RefreshAndSetText(_roleInput, RoleNmae, "Role Name Input ");
            _privilegesTab.ClickElement("Privileges", Driver);
            _extendpage.verifyGroupListCount(_privFrame, _privListRight, _rightPrivilegesListCnt);
            Settings.Logger.Info(" Successfully Verified  Adding Locations or Operational Entities ");
        }

        /// <summary>
        /// Move Authorized Privileges Left
        /// </summary>
        public void MoveAuthorizedPrivilegesLeft()
        {
            Settings.Logger.Info(" Move Authorized Privileges To Left ");
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _extendpage.SelectAllAndMoveGroupListElements(_privFrame, _privListRight, _privListMoveLeft);
            SaveRoleMaintenance();
        }

        /// <summary>
        /// Verify Removing Privileges
        /// </summary>
        /// <param name="RoleNmae"></param>
        public void VerifyRemovingPrivileges(string RoleNmae)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_roleInput, RoleNmae, "Role Name Input ");
            _privilegesTab.ClickElement("Privileges", Driver);
            VerifyRemovingAllItemFromGroupList(_privFrame, _privListRight);
            Settings.Logger.Info(" Successfully Verified  Removing Privileges ");
        }

        /// <summary>
        /// Fill Reporting
        /// </summary>
        public void FillReporting()
        {
            Settings.Logger.Info(" Filling Reporting ");
            ClickOnMaintenanceRoleTab(_reportingTab, "Reporting");
            _leftPrinterListCnt = _extendpage.SelectAllGroupList(_printerFrame, _printerListLeft, _printerListMoveRight, _printerListRight, ref _rightPrinterListCnt);
            _rightPrinterListCnt = _rightPrinterListCnt + _leftPrinterListCnt;
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _leftReportListCnt = _extendpage.SelectAllGroupList(_reportFrame, _reportListLeft, _reportListMoveRight, _reportListRight, ref _rightReportListCnt);
            _rightReportListCnt = _rightReportListCnt + _leftReportListCnt;
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _leftAdhocListCnt = _extendpage.SelectAllGroupList(_adhocFrame, _adhocListLeft, _adhocListMoveRight, _adhocListRight, ref _rightAdhocListCnt);
            _rightAdhocListCnt = _leftAdhocListCnt + _rightAdhocListCnt;
        }

        /// <summary>
        /// Verify Reporting
        /// </summary>
        /// <param name="RoleNmae"></param>
        public void VerifyReporting(string RoleNmae)
        {
            _extendpage.RefreshAndSetText(_roleInput, RoleNmae, "Role Name Input ");
            _reportingTab.ClickElement("LocationsOperational", Driver);
            _extendpage.verifyGroupListCount(_printerFrame, _printerListRight, _rightPrinterListCnt);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _extendpage.verifyGroupListCount(_reportFrame, _reportListRight, _rightReportListCnt);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _extendpage.verifyGroupListCount(_adhocFrame, _adhocListRight, _rightAdhocListCnt);
            Settings.Logger.Info(" Successfully Verified  Adding Reporting");
        }

        /// <summary>
        /// Select All And Move Authorize Printer List
        /// </summary>
        public void SelectAllAndMoveAuthorizedPrinterList()
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _extendpage.SelectAllAndMoveGroupListElements(_printerFrame, _printerListRight, _printerListMoveLeft);
        }

        /// <summary>
        /// Select All And Move Authorize ReportList
        /// </summary>
        public void SelectAllAndMoveAuthorizedReportList()
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _extendpage.SelectAllAndMoveGroupListElements(_reportFrame, _reportListRight, _reportListMoveLeft);
        }

        /// <summary>
        /// Select All And Move Authorize AdhocList
        /// </summary>
        public void SelectAllAndMoveAuthorizedAdhocList()
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _extendpage.SelectAllAndMoveGroupListElements(_adhocFrame, _adhocListRight, _adhocListMoveLeft);
        }

        /// <summary>
        /// Move All Authorized Reporting groups To Left
        /// </summary>
        public void MoveAllAuthorizedReportingGroupsToLeft()
        {
            Settings.Logger.Info(" Move Authorized Reporting Group To Left ");
            SelectAllAndMoveAuthorizedPrinterList();
            SelectAllAndMoveAuthorizedReportList();
            SelectAllAndMoveAuthorizedAdhocList();
            SaveRoleMaintenance();
        }

        /// <summary>
        /// Verify Removing Reporting
        /// </summary>
        /// <param name="RoleNmae"></param>
        public void VerifyRemovingReportingGroupsList(string RoleNmae)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_roleInput, RoleNmae, "Role Name Input ");
            _reportingTab.ClickElement("Reporting", Driver);
            VerifyRemovingAllItemFromGroupList(_printerFrame, _printerListRight);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            VerifyRemovingAllItemFromGroupList(_reportFrame, _reportListRight);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            VerifyRemovingAllItemFromGroupList(_adhocFrame, _adhocListRight);
            Settings.Logger.Info(" Successfully Verified  Removing ReportingH ");
        }

        /// <summary>
        /// Fill Departments And Chat Groupp
        /// </summary>
        public void FillDepartmentsAndChatGroup()
        {
            Settings.Logger.Info(" Filling Departments And Chat Grp ");
            ClickOnMaintenanceRoleTab(_departmentsChatTab, "Departments And Chat");
            _leftDeptLisCnt = _extendpage.SelectAllGroupList(_deptFrame, _deptListLeft, _deptListMoveRight, _deptListRight, ref _rightDeptLisCnt);
            _rightDeptLisCnt = _rightDeptLisCnt + _leftDeptLisCnt;
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _leftChatListCnt = _extendpage.SelectAllGroupList(_chatFrame, _chatListLeft, _chatListMoveRight, _chatListRight, ref _rightChatListCnt);
            _rightChatListCnt = _rightChatListCnt + _leftChatListCnt;
        }

        /// <summary>
        /// Verify Departments And Chat Grp
        /// </summary>
        /// <param name="RoleNmae"></param>
        public void VerifyDepartmentsAndChatGroup(string RoleNmae)
        {
            _extendpage.RefreshAndSetText(_roleInput, RoleNmae, "Role Name Input ");
            _departmentsChatTab.ClickElement("Departments And Chat Grp", Driver);
            _extendpage.verifyGroupListCount(_deptFrame, _deptListRight, _rightDeptLisCnt);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _extendpage.verifyGroupListCount(_chatFrame, _chatListRight, _rightChatListCnt);
            Settings.Logger.Info(" Successfully Verified Departments And Chat Grp");
        }

        /// <summary>
        /// Select All And Move  Authorize Department
        /// </summary>
        public void SelectAllAndMoveAuthorizedDepartment()
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _extendpage.SelectAllAndMoveGroupListElements(_deptFrame, _deptListRight, _deptListMoveLeft);
        }

        /// <summary>
        /// Select All And Move Authorize Chat Group
        /// </summary>
        public void SelectAllAndMoveAuthorizedChatGroup()
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _extendpage.SelectAllAndMoveGroupListElements(_chatFrame, _chatListRight, _chatListMoveLeft);
        }

        /// <summary>
        /// Move Authorized Departments And Chat Grp To Left
        /// </summary>
        public void MoveAuthorizedDepartmentsAndChatToLeft()
        {
            Settings.Logger.Info(" Move Authorized Departments And Chat Grp To Left ");
            SelectAllAndMoveAuthorizedDepartment();
            SelectAllAndMoveAuthorizedChatGroup();
            SaveRoleMaintenance();
        }

        /// <summary>
        /// Verify Removing Departments And Chat Grp
        /// </summary>
        /// <param name="RoleNmae"></param>
        public void VerifyRemovingDepartmentsAndChat(string RoleNmae)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_roleInput, RoleNmae, "Role Name Input ");
            _departmentsChatTab.ClickElement(" Departments And Chat Grp", Driver);
            VerifyRemovingAllItemFromGroupList(_deptFrame, _deptListRight);
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            VerifyRemovingAllItemFromGroupList(_chatFrame, _chatListRight);
            Settings.Logger.Info(" Successfully Verified  Removing  Departments And Chat Grp ");
        }

        /// <summary>
        /// Fill Vendor Gateway
        /// </summary>
        public void FillvGState()
        {
            Settings.Logger.Info(" Filling Vendor Gateway ");
            ClickOnMaintenanceRoleTab(_vendorGatewayTab, "Vendor Gateway");
            Driver.WaitForReady();
            _vendorFrame.VerifyElementDisplay("vendorFrame");
            if (_vendorFrame.VerifyElementDisplay("vendorFrame"))
            { _leftvGStateListCnt = _extendpage.SelectAllGroupList(_vendorFrame, _vGStateListLeft, _vGStateListMoveRight, _vGStateListRight, ref _rightvGStateListCnt); }
            else { Assert.Fail("vendor Geteway Frame not found"); }
            _rightvGStateListCnt = _rightvGStateListCnt + _leftvGStateListCnt;
        }


        /// <summary>
        /// Verify Vendor Gateway
        /// </summary>
        /// <param name="RoleNmae"></param>
        public void VerifyvGState(string RoleNmae)
        {
            _extendpage.RefreshAndSetText(_roleInput, RoleNmae, "Role Name Input ");
            _vendorGatewayTab.ClickElement("Vendor Gateway", Driver);
            _extendpage.verifyGroupListCount(_vendorFrame, _vGStateListRight, _rightvGStateListCnt);
            Settings.Logger.Info(" Successfully Verified  Adding Vendor Gateway Entities ");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Move Authorized vGState List Left
        /// </summary>
        public void MoveAuthorizedvGStateListLeft()
        {
            Settings.Logger.Info(" Move Authorized Vendor Gateway To Left ");
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _extendpage.SelectAllAndMoveGroupListElements(_vendorFrame, _vGStateListRight, _vGStateListMoveLeft);
            SaveRoleMaintenance();
        }

        /// <summary>
        /// Verify Removing Vendor Gateway
        /// </summary>
        /// <param name="RoleNmae"></param>
        public void VerifyRemovingvGState(string RoleNmae)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_roleInput, RoleNmae, "Role Name Input ");
            _vendorGatewayTab.ClickElement("Vendor Gateway", Driver);
            VerifyRemovingAllItemFromGroupList(_vendorFrame, _vGStateListRight);
            Settings.Logger.Info(" Successfully Verified  Removing Vendor Gateway ");
        }

        /// <summary>
        /// Fill Indiract Accounts
        /// </summary>
        public void FillIndiractAccounts()
        {
            Settings.Logger.Info(" Filling Indiract Accounts ");
            ClickOnMaintenanceRoleTab(_accountsTab, "Privileges");
            _leftIndAccountsListCnt = _extendpage.SelectAllGroupList(_indAcctFrame, _indAccountsListLeft, _indAccountsListMoveRight, _indAccountsListRight, ref _rightIndAccountsListCnt);
            _rightIndAccountsListCnt = _rightIndAccountsListCnt + _leftIndAccountsListCnt;
        }

        /// <summary>
        /// Verify Indiract Accounts
        /// </summary>
        /// <param name="RoleNmae"></param>
        public void VerifyIndiractAccounts(string RoleNmae)
        {
            _extendpage.RefreshAndSetText(_roleInput, RoleNmae, "Role Name Input ");
            _accountsTab.ClickElement("Indiract Accounts ", Driver);
            _extendpage.verifyGroupListCount(_indAcctFrame, _indAccountsListRight, _rightIndAccountsListCnt);
            Settings.Logger.Info(" Successfully Verified  Adding Indiract Accounts  ");
        }

        /// <summary> 
        /// Move Authorized Indiract Accounts List Left
        /// </summary>
        public void MoveAuthorizedIndiractAccountsListLeft()
        {
            Settings.Logger.Info(" Move Authorized Indiract Accounts To Left ");
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _extendpage.SelectAllAndMoveGroupListElements(_indAcctFrame, _indAccountsListRight, _indAccountsListMoveLeft);
            SaveRoleMaintenance();
        }

        /// <summary>
        /// Verify Removing Indiract Accounts
        /// </summary>
        /// <param name="RoleNmae"></param>
        public void VerifyRemovingIndiractAccounts(string RoleNmae)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_roleInput, RoleNmae, "Role Name Input ");
            _accountsTab.ClickElement("Indiract Accounts", Driver);
            VerifyRemovingAllItemFromGroupList(_indAcctFrame, _indAccountsListRight);
            Settings.Logger.Info(" Successfully Verified  Removing Indiract Accounts ");
        }

        /// <summary>
        /// Verify Copy Role Maintenance
        /// </summary>
        /// <param name="DataObjectKey"></param>
        /// <param name="CopyRoleName"></param>
        public void VerifyCopyRoleMaintenance(string DataObjectKey,string CopyRoleName)
        {
            VerifyRoleMaintenanceDetail(DataObjectKey, CopyRoleName);
            _vendorGatewayTab.ClickElement("Vendor Gateway", Driver);
            _extendpage.verifyGroupListCount(_vendorFrame, _vGStateListRight, _rightvGStateListCnt);
        }

        /// <summary>
        /// Move Privileges List
        /// </summary>
        /// <param name="RoleMaintenancePrivilege"></param>
        public void MovePrivilegesList(RoleMaintenancePrivilege RoleMaintenancePrivilege)
        {
            Settings.Logger.Info("Moving Privileges List ");
            Settings.Logger.Info(" Moving  Test Suit List  Group ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_roleInput, RoleMaintenancePrivilege.RoleMaintenanceName, "RoleMaintenanceName");
            Driver.WaitForReady();
            _privilegesTab.ClickElement("_privilegesTab", Driver);
            Driver.SwitchToFrame(_privFrame, "Test suit Group List Frame");
            if (RoleMaintenancePrivilege.LeftPrivilegeMaintenance != null)
            {
                if (_privListLeft.GetDropdownListTotalCount() > 0)
                {
                    Driver.WaitForReady();
                    _extendpage.SelectMultipleItemFromList(_privListLeft, _privListMoveRight, RoleMaintenancePrivilege.LeftPrivilegeMaintenance);
                    Settings.Logger.Info("Moved Privileges List from Unauthorized Printer Groups to Authorized Printer Groups ");
                }             
            }
            if (RoleMaintenancePrivilege.RightPrivilegeMaintenance != null)
            {
                if (_privListRight.GetDropdownListTotalCount() > 0)
                {
                    Driver.WaitForReady();
                    _extendpage.SelectMultipleItemFromList(_privListRight, _privListMoveLeft, RoleMaintenancePrivilege.RightPrivilegeMaintenance);
                    Settings.Logger.Info("Moved Privileges List from Authorized Printer Groups to Unauthorized Printer Groups ");
                }
            }
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendpage.Save();
        }

        /// <summary>
        /// Create New Maintenance Role
        /// </summary>
        /// <param name="information"></param>
        /// <returns>Role</returns>
        public string CreateNewMaintenanceRole(RoleInformation information)
        {
            string Role = string.Empty;
            if (!_extendpage.CheckDataExistenceAndGetActionCode(information.Role, ref Role, "RoleMaintenanceQuery", 8))
            {
                Settings.Logger.Info($" Creating new Maintenance Role - {Role}");
                _roleInput.SetText(Role, " Maintenance Role ", Driver, _extendpage._contentFrame, "content frame");
                Driver.WaitForReady();
                _extendpage.ActionRequiredWindow("Create");
                _extendpage.SwitchToContentFrame();
                _roleDescInput.SetText(information.Description, "Description");
                Driver.WaitForReady();
                _roleNoteInput.SetText(information.Notes, "Notes");
                Driver.WaitForReady();
                _roleHomePageInput.SetText(information.RestrictedHomePage, "Restricted Home Page");
                Driver.WaitForReady();
                _roleDbUIDInput.SetText(information.DatabaseUserId, "Database User Id");
                Driver.WaitForReady();
                if (information.LocationOperationalEntities)
                    FillLocationsOperational();
                if (information.MenuKPIAccess)
                    FillMenusKPI();
                if (information.PrivilegeMaintenance)
                    FillPrivileges();
                SaveRoleMaintenance();
                if (information.UnauthorizedPrivileges != null)
                {
                    RoleMaintenancePrivilege maintenancePrivilege = new RoleMaintenancePrivilege();
                    maintenancePrivilege.RoleMaintenanceName = Role;
                    maintenancePrivilege.RightPrivilegeMaintenance = information.UnauthorizedPrivileges;
                    MovePrivilegesList(maintenancePrivilege);
                }
            }
            return Role;
        }
    }
}
