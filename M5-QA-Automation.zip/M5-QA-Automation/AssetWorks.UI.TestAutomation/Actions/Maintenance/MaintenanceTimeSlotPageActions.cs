﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Maintenance;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Maintenance
{
    internal class MaintenanceTimeSlotPageActions : MaintenanceTimeSlotPage
    {
        public MaintenanceTimeSlotPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// create Maintenance TimeSlot
        /// </summary>
        /// <param name="MaintenanceTimeSlot"></param>
        public void CreateOrUpdateMaintenanceTimeSlot(MaintenanceTimeSlot MaintenanceTimeSlot)
        {          
            _extendpage.SwitchToContentFrame();
            _location.SelectFilterValueHavingEqualValue(MaintenanceTimeSlot.MaintenanceLocation);
            Driver.WaitForReady();
            if (MaintenanceTimeSlot.RescheduleTimeAllowance != null) _reschedTimeAllow.Clear();
            Driver.WaitForReady();
            _reschedTimeAllow.SendKeys(MaintenanceTimeSlot.RescheduleTimeAllowance);
            Driver.WaitForReady();
            Driver.SwitchToFrame(_timeSlotFrame, "timeSlotFrame");
            if (MaintenanceTimeSlot.WeeklyTimeSlots != null)
            {
                foreach (WeeklyTimeSlot slot in MaintenanceTimeSlot.WeeklyTimeSlots)
                {                
                    _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_timeSlotTable, "Day", slot.DayName, "SelectDay"), "SelectDay", slot.SelectDay);
                    Driver.WaitForReady();
                    _extendpage.GetTableActionElementByRelatedColumnValue(_timeSlotTable, "Day", slot.DayName, "StartTime").SelectFilterValueHavingEqualValue(slot.StartTime);
                    Driver.WaitForReady();
                    _extendpage.GetTableActionElementByRelatedColumnValue(_timeSlotTable, "Day", slot.DayName, "EndTime").SelectFilterValueHavingEqualValue(slot.EndTime);
                    Driver.WaitForReady();
                    _extendpage.GetTableActionElementByRelatedColumnValue(_timeSlotTable, "Day", slot.DayName, "AppointmentLength").SelectFilterValueHavingEqualValue(slot.AppointmentLength);
                    Driver.WaitForReady();
                    _extendpage.GetTableActionElementByRelatedColumnValue(_timeSlotTable, "Day", slot.DayName, "AdvanceCancelHours").SetText(slot.AdvanceCancelHours, "AdvanceCancelHours");
                    Driver.WaitForReady();
                }
            }
            _extendpage.Save();
            Settings.Logger.Info(" created Maintenance Time Slot ");
        }

        /// <summary>
        /// Verify Maintenance Time Slot
        /// </summary>
        /// <param name="MaintenanceTimeSlot"></param>
        public void VerifyMaintenanceTimeSlot(MaintenanceTimeSlot MaintenanceTimeSlot)
        {        
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            CommonUtil.VerifyElementValue(_location, "Location", MaintenanceTimeSlot.MaintenanceLocation,true);
            Driver.WaitForSomeTime();
            Driver.SwitchToFrame(_timeSlotFrame, "timeSlotFrame");
            if (MaintenanceTimeSlot.WeeklyTimeSlots != null)
            {
                foreach (WeeklyTimeSlot slot in MaintenanceTimeSlot.WeeklyTimeSlots)
                {                 
                    CommonUtil.VerifyCheckboxState(_extendpage.GetTableActionElementByRelatedColumnValue(_timeSlotTable, "Day", slot.DayName, "SelectDay"), "SelectDay", slot.SelectDay);
                    Driver.WaitForReady();
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_timeSlotTable, "Day", slot.DayName, "StartTime"), "StartTime", slot.StartTime, true);
                    Driver.WaitForReady();
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_timeSlotTable, "Day", slot.DayName, "EndTime"), "EndTime", slot.EndTime, true);
                    Driver.WaitForReady();
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_timeSlotTable, "Day", slot.DayName, "AppointmentLength"), "AppointmentLength", slot.AppointmentLength, true);
                    Driver.WaitForReady();
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_timeSlotTable, "Day", slot.DayName, "AdvanceCancelHours"), "AdvanceCancelHours", slot.AdvanceCancelHours,false, "value");
                    Driver.WaitForReady();
                }
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Verified Maintenance Time Slot ");
        }

        /// <summary>
        /// Reset Maintenance Time Slot
        /// </summary>
        /// <param name="MaintenanceTimeSlot"></param>
        public void ResetMaintenanceTimeSlot(MaintenanceTimeSlot MaintenanceTimeSlot)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _reschedTimeAllow.Clear(); 
            Driver.WaitForReady();
            Driver.SwitchToFrame(_timeSlotFrame, "timeSlotFrame");
            if (MaintenanceTimeSlot.WeeklyTimeSlots != null)
            {
                foreach (WeeklyTimeSlot slot in MaintenanceTimeSlot.WeeklyTimeSlots)
                {                 
                    _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_timeSlotTable, "Day", slot.DayName, "SelectDay"), "SelectDay", false);
                    Driver.WaitForReady();
                }
            }
            _extendpage.Save();
            Settings.Logger.Info("Done Reset Maintenance Time Slot ");
        }

        /// <summary>
        /// Verify Maintenance Time Slot Deletion
        /// </summary>
        /// <param name="MaintenanceTimeSlot"></param>
        public void VerifyMaintenanceTimeSlotDeletion(MaintenanceTimeSlot MaintenanceTimeSlot)
        {         
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _reschedTimeAllow.Clear();
            Driver.WaitForReady();
            Driver.SwitchToFrame(_timeSlotFrame, "timeSlotFrame");
            if (MaintenanceTimeSlot.WeeklyTimeSlots != null)
            {
                foreach (WeeklyTimeSlot slot in MaintenanceTimeSlot.WeeklyTimeSlots)
                {
                    CommonUtil.VerifyCheckboxState(_extendpage.GetTableActionElementByRelatedColumnValue(_timeSlotTable, "Day", slot.DayName, "SelectDay"), "SelectDay", false);
                    Driver.WaitForReady();
                }
            }
            Settings.Logger.Info(" Verified Maintenance Time Slot deletion ");
        }
    }
}
