﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class BillingDepartmentAccountsPageActions : BillingDepartmentAccountsPage
    {
        public BillingDepartmentAccountsPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Add Billing Account Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void AddBillingAccountInformation(BillingDepartment DataObject)
        {
            MoveToDepartmentAccountFrameAndSetDepartment(DataObject.DepartmentNo);
            if (DataObject.BillingAccountInfoTable != null)
            {
                FillBillItemExpenseAccount(DataObject);
            }
            if (DataObject.BillingAccountRevTable != null)
            {
                FillBillItemRevenueAccount(DataObject);
            }
            _extendedPage.Save();
            Settings.Logger.Info(" Add Billing Department Accounts Details ");
        }

        /// <summary>
        /// Fill BillItem Expense Account
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillBillItemExpenseAccount(BillingDepartment DataObject)
        {
            int RowNum = 0;
            foreach (BillingAccountInfoTable BillingAccountInfoTable in DataObject.BillingAccountInfoTable)
            {
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_billingAccountTable, "Item", DataObject.BillItemlist[RowNum], "USE_ACCT_NO").
                    SetText(BillingAccountInfoTable.ExpenseAccounts, "Expense Account");
                Driver.WaitForReady();
                RowNum++;
            }
            Settings.Logger.Info(" Fill Billing Item Expense Account ");
        }

        /// <summary>
        /// Fill BillItem Revenue Account
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillBillItemRevenueAccount(BillingDepartment DataObject)
        {
            int RowNum = 0;
            foreach (BillingAccountRevTable BillingAccountRevTable in DataObject.BillingAccountRevTable)
            {
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_billingAccountTable, "Item", DataObject.BillItemlist[RowNum], "OWN_ACCT_NO").
                    SetText(BillingAccountRevTable.RevenueAccounts, "Rev Account");
                Driver.WaitForReady();
                RowNum++;
            }
            Settings.Logger.Info(" Fill Billing Item Revenue Account ");
        }

        /// <summary>
        /// Verify Billing Account Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyBillingAccountInformation(BillingDepartment DataObject)
        {
            _extendedPage.RefreshAndSetText(_departmentNumber, DataObject.DepartmentNo,"Department Number");
            Driver.SwitchToFrame(_iframebillingAccount, "Billing Account Information");
            if (DataObject.BillingAccountInfoTable != null)
            {
                VerifyBillItemExpenseAccount(DataObject);
            }
            if (DataObject.BillingAccountRevTable != null)
            {
                VerifyBillItemRevenueAccount(DataObject);
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Verified Billing Department Accounts Details ");
        }

        /// <summary>
        /// Verify BillItem Expense Account
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyBillItemExpenseAccount(BillingDepartment DataObject)
        {
            int RowNum = 0;
            foreach (BillingAccountInfoTable BillingAccountInfoTable in DataObject.BillingAccountInfoTable)
            {
                Driver.WaitForReady();
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                    _billingAccountTable, "Item", DataObject.BillItemlist[RowNum], "USE_ACCT_NO"),
                    "Expense Account", BillingAccountInfoTable.ExpenseAccounts, false ,"value");
                Driver.WaitForReady();
                RowNum++;
            }
            Settings.Logger.Info(" Verified Billing Item Expense Account ");
        }
        /// <summary>
        /// Verify BillItem Revenue Account
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyBillItemRevenueAccount(BillingDepartment DataObject)
        {
            int RowNum = 0;
            foreach (BillingAccountRevTable BillingAccountRevTable in DataObject.BillingAccountRevTable)
            {
                Driver.WaitForReady();
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                    _billingAccountTable, "Item", DataObject.BillItemlist[RowNum], "OWN_ACCT_NO"),
                    "Expense Account", BillingAccountRevTable.RevenueAccounts, false, "value");
                Driver.WaitForReady();
                RowNum++;
            }
            Settings.Logger.Info(" Verified Billing Item Revenue Account ");
        }

        /// <summary>
        /// Delete Bill Item Department Account
        /// </summary>
        /// <param name="Department"></param>
        /// <param name="BillItem"></param>
        public void DeleteBillItemDepartmentAccount(string Department,string BillItem)
        {
            MoveToDepartmentAccountFrameAndSetDepartment(Department);
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_billingAccountTable, "Item", BillItem, "BILL_ITEM").Click();
            Driver.WaitForReady();
            _extendedPage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            Settings.Logger.Info(" Delete Billing Item Account ");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Department"></param>
        /// <param name="BillItem"></param>
        public void VerifyDeletionBillItemDepartmentAccount(string Department, string BillItem)
        {
            MoveToDepartmentAccountFrameAndSetDepartment(Department);
            Driver.WaitForReady();
            IWebElement ExpenseAccount= _extendedPage.GetTableActionElementByRelatedColumnValue(_billingAccountTable, "Item", BillItem, "USE_ACCT_NO");
            _extendedPage.VerifyEmptyField(ExpenseAccount, "ExpenseAccount");
            Driver.WaitForReady();
            IWebElement RevenueAccount= _extendedPage.GetTableActionElementByRelatedColumnValue(_billingAccountTable, "Item", BillItem, "OWN_ACCT_NO");
            _extendedPage.VerifyEmptyField(RevenueAccount, "RevenueAccount");
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Successfully verified Deletion Department Billing Accounts - Delete Accounts for Item ");
        }

        /// <summary>
        /// Move To Department Account Frame And Set Department
        /// </summary>
        /// <param name="Department"></param>
        public void MoveToDepartmentAccountFrameAndSetDepartment(string Department)
        {
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _departmentNumber.SetText(Department, "Department Number");
            Driver.SwitchToFrame(_iframebillingAccount, "Billing Account Information");
        }
    }
}
