﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class PurchaseOrderQueryPageActions : PurchaseOrderQueryPage
    {
        public PurchaseOrderQueryPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Retrieve Purchase Orders
        /// </summary>
        /// <param name="queryObject"></param>
        public void RetrievePurchaseOrders(POQueryObject queryObject)
        {
            Settings.Logger.Info(" Retrieve Purchase Orders ");
            ExtendedPage.SwitchToContentFrame();
            _inputLocation.SetText(queryObject.Location, "Location");
            Driver.WaitForReady();
            _selectStatus.SelectFilterValueHavingEqualValue(queryObject.Status);
            Driver.WaitForReady();
            _inputDepartment.SetText(queryObject.Department, "Department");
            _inputRequisitionNo.SetText(queryObject.RequisitionNo, "Requisition No");
            _inputVendor.SetText(queryObject.Vendor, "Vendor");
            Driver.WaitForReady();
            _inputPartNo.SetText(queryObject.PartNo, "Part No");
            Driver.WaitForReady();
            _inputPoNo.SetText(queryObject.PoNo, "Po No");
            Driver.WaitForReady();
            _inputPoFromDt.SetText(queryObject.PoFromDate, "Po From Date");
            Driver.WaitForReady();
            _inputPoToDt.SetText(queryObject.PoToDate, "Po To Date");
            Driver.WaitForReady();
            _buttonRetrieve.Click();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Update Purchase Orders
        /// </summary>
        /// <param name="queryObject"></param>
        public void UpdatePurchaseOrdersPOQuery(POQueryObject queryObject)
        {
            Settings.Logger.Info(" Update Purchase Orders ");
            RetrievePurchaseOrders(queryObject);
            if (queryObject.POList != null)
            {
                Driver.SwitchToFrame(_framePOList, "PO List");
                foreach(PurchaseOrderList po in queryObject.POList)
                {
                    if (po.Notes != null)
                    {
                        ExtendedPage.AddNotes(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePOList, "PO No",
                            queryObject.PoNo, "Notes", "value", "div"), po.Notes);
                        Driver.WaitForReady();
                        ExtendedPage.ClickOnSaveButton();
                        Driver.WaitForReady();
                        ExtendedPage.SwitchToTableFrame(_framePOList);
                    }
                    if (po.PODetails != null)
                    {
                        ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePOList, "PO No", queryObject.PoNo, "PONo", "value", "div").Click();
                        Driver.WaitForReady();
                        Driver.SwitchTo().DefaultContent();
                        Driver.SwitchToFrame(ExtendedPage._contentFrame2, "Content Frame");
                        Driver.SwitchToFrame(_framePODetail, "PODetail");
                        foreach(PODetailObject detail in po.PODetails)
                        {
                            ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePODetail, "Part No", 
                                detail.PartNo, "close").SelectCheckBox("Close Line", detail.CloseLine);
                            Driver.WaitForReady();
                        }
                        Driver.SwitchTo().DefaultContent();
                        ExtendedPage.ClickOnSaveButton();
                        Driver.WaitForReady();
                    }
                }
            }
        }

        /// <summary>
        /// Verify Purchase Orders
        /// </summary>
        /// <param name="queryObject"></param>
        public void VerifyPurchaseOrdersPOQuery(POQueryObject queryObject)
        {
            Settings.Logger.Info(" Verify Purchase Orders ");
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.ClickOnRefreshButton();
            RetrievePurchaseOrders(queryObject);
            if (queryObject.POList != null)
            {
                Driver.SwitchToFrame(_framePOList, "PO List");
                foreach (PurchaseOrderList po in queryObject.POList)
                {
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePOList, "PO No",
                            queryObject.PoNo, "poamt", "value", "div"), "PoAmt", po.PoAmt, false, "value");
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePOList, "PO No",
                            queryObject.PoNo, "PORef", "value", "div"), "PoRef", po.PoRef, false, "value");
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePOList, "PO No",
                            queryObject.PoNo, "status", "value", "div"), "Status", po.Status, false, "value");
                    if (po.Notes != null)
                    {
                        ExtendedPage.VerifyAddedNotes(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePOList, "PO No",
                            queryObject.PoNo, "Notes", "value", "div"), po.Notes);
                        Driver.WaitForReady();
                        ExtendedPage.SwitchToTableFrame(_framePOList);
                    }
                    if (po.PODetails != null)
                    {
                        ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePOList, "PO No", queryObject.PoNo, "PONo", "value", "div").Click();
                        Driver.WaitForReady();
                        Driver.SwitchTo().DefaultContent();
                        Driver.SwitchToFrame(ExtendedPage._contentFrame2, "Content Frame");
                        Driver.SwitchToFrame(_framePODetail, "PODetail");
                        foreach (PODetailObject detail in po.PODetails)
                        {
                            CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePODetail, "Part No",
                                detail.PartNo, "status"), "Status", detail.PartStatus, false, "value");
                        }
                        Driver.SwitchTo().DefaultContent();
                    }
                }
            }
        }
    }
}
