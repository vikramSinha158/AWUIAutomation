﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class ComponentDisposalPageActions : ComponentDisposalPage
    {
        public ComponentDisposalPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Component Disposal
        /// </summary>
        /// <param name="ComponentDisposal"></param>
        public void CreateComponentDisposal(ComponentDisposal ComponentDisposal)
        { 
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _compNoInput.SetText(ComponentDisposal.ComponentNo, "ComponentNo");
            if (ComponentDisposal.Disposal != null)
            {
                Driver.WaitForReady();
                _extendpage.GetTabLinkByText("Disposal").ClickElement("Disposal", Driver);
                Driver.WaitForSomeTime();
                _disposalStatusDd.SelectDropdownUsingValue("DisposalStatus",ComponentDisposal.Disposal.DisposalStatus);
                Driver.WaitForReady();
                _disposalreason.SetText(ComponentDisposal.Disposal.DisposalReason, "DisposalReason");
                if (String.IsNullOrEmpty(_disposalreason.GetElementValueByAttribute("ovalue")))
                    { _disposalreason.SetText(ComponentDisposal.Disposal.DisposalReason, "DisposalReason"); }
                Driver.WaitForReady();
                _estimatedDate.SetText(ComponentDisposal.Disposal.EstimatedDate, "EstimatedDate");
            }
            if (ComponentDisposal.NoteTab != null)
            {
                Driver.SwitchTo().DefaultContent();
                Driver.PageScrollUp();
                _extendpage.SwitchToContentFrame();
                Driver.WaitForReady();
                _extendpage.GetTabLinkByText("Notes").ClickElement("Notes", Driver);
                Driver.WaitForReady();
                _note.SetText(ComponentDisposal.NoteTab.Note, "Note");
            }
            if (ComponentDisposal.SalesTab != null)
            {
                Driver.SwitchTo().DefaultContent();
                Driver.PageScrollUp();
                _extendpage.SwitchToContentFrame();
                Driver.PageScrollUp();
                _extendpage.GetTabLinkByText("Sales").ClickElement("Sales", Driver);
                Driver.WaitForReady();
                _disposalDate.SetText(ComponentDisposal.SalesTab.DisposalDate, "DisposalDate");
            }
            _extendpage.Save();
            Settings.Logger.Info($" Created  Component Disposal for Component {ComponentDisposal.ComponentNo} ");
        }

        /// <summary>
        /// Verify Component Disposal
        /// </summary>
        /// <param name="ComponentDisposal"></param>
        public void VerifyComponentDisposal(ComponentDisposal ComponentDisposal)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_compNoInput, "ComponentNo", ComponentDisposal.ComponentNo);
            CommonUtil.VerifyElementValue(_status, "Status", ComponentDisposal.Status);
            if (ComponentDisposal.Disposal != null)
            {
                Driver.WaitForReady();
                _extendpage.GetTabLinkByText("Disposal").ClickElement("Disposal", Driver);
                CommonUtil.VerifyElementValue(_disposalStatusDd, "DisposalStatus", ComponentDisposal.Disposal.ExpactedDisposalStatus, true);
                CommonUtil.VerifyElementValue(_disposalreason, "DisposalReason", ComponentDisposal.Disposal.DisposalReason);
                _extendpage.VerifySystemDateContainAppdate(_estimatedDate, "EstimatedDate", 0);
            }
            if (ComponentDisposal.NoteTab != null)
            {
                Driver.WaitForReady();
                _extendpage.GetTabLinkByText("Notes").ClickElement("Notes", Driver);
                Driver.WaitForReady();
                CommonUtil.VerifyElementValue(_note, "Note", ComponentDisposal.NoteTab.Note);
            }
            if (ComponentDisposal.SalesTab != null)
            {
                Driver.PageScrollUp();
                _extendpage.GetTabLinkByText("Sales").ClickElement("Sales", Driver);
                Driver.WaitForReady();
                _extendpage.VerifySystemDateContainAppdate(_disposalDate, "DisposalDate", 0);
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Successfully Verified  Component Disposal  ");
        }
    }

}
