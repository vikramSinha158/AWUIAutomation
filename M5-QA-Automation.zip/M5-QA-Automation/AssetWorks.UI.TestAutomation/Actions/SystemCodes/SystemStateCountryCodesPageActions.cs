﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes;

namespace AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes
{
    internal class SystemStateCountryCodesPageActions : SystemStateCountryCodesPage
    {
        public SystemStateCountryCodesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create System State Country Codes
        /// </summary>
        /// <param name="codes"></param>
        /// <returns>CountryCode</returns>
        public string CreateSystemStateCountryCodes(StateCountryCodes codes)
        {
            Settings.Logger.Info("Create Country Code");
            if (string.IsNullOrEmpty(codes.CountryCode) || codes.CountryCode.ToLower().Equals("random"))
                codes.CountryCode = CommonUtil.GetRandomStringWithSpecialChars(3, false);
            _extendedPage.SwitchToTableFrame(_frameCountry);
            _inputNewCountryCode.SetText(codes.CountryCode, "Code");
            _inputNewCountryDesc.SetText(codes.CountryName, "Desc");
            _inputNewStateCodeLeng.SetText(codes.StateCodeLength, "State Code Length");
            Driver.WaitForReady();
            if (codes.StateCodes != null)
            {
                Settings.Logger.Info("Create State Code");
                _inputNewCountryCode.Click();
                Driver.SwitchTo().DefaultContent();
                int row = 0;
                _extendedPage.SwitchToTableFrame(_frameState);
                foreach (StateCodes code in codes.StateCodes)
                {
                    _inputNewStateCode(row.ToString()).SetText(code.StateCode, "State Code");
                    Driver.WaitForReady();
                    _inputNewStateDesc(row.ToString()).SetText(code.Description, "Description");
                    row++;
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            return codes.CountryCode;
        }

        /// <summary>
        /// Verify System State Country Codes
        /// </summary>
        /// <param name="codes"></param>
        public void VerifySystemStateCountryCodes(StateCountryCodes codes)
        {
            Settings.Logger.Info("Verify System Country Code");
            _extendedPage.RefreshAndSwitchToTable(_frameCountry, "Country");
            Driver.WaitForSomeTime();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableCountry, "Code", codes.CountryCode, "code").Click();
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCountry, "Code",
                codes.CountryCode, "desc"), "Country Name", codes.CountryName, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCountry, "Code",
                codes.CountryCode, "stcodeleng"), "State Code Length", codes.StateCodeLength, false, "value");
            if (codes.StateCodes != null)
            {
                Settings.Logger.Info("Verify State Codes");
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToTableFrame(_frameState);
                foreach (StateCodes code in codes.StateCodes)
                {
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableState, "State Code",
                        code.StateCode, "stdesc"), "Description", code.Description, false, "value");
                    Driver.WaitForReady();
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update System State Country Codes
        /// </summary>
        /// <param name="codes"></param>
        public void UpdateSystemStateCountryCodes(StateCountryCodes codes)
        {
            Settings.Logger.Info("Update System Country Code");
            _extendedPage.RefreshAndSwitchToTable(_frameCountry, "Country");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableCountry, "Code", codes.CountryCode, "code").Click();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableCountry, "Code", codes.CountryCode,
                "desc").SetText(codes.CountryName, "Desc");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableCountry, "Code", codes.CountryCode,
                "stcodeleng").SetText(codes.StateCodeLength, "State Code Length");
            if (codes.StateCodes != null)
            {
                Settings.Logger.Info("Update State Codes");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableCountry, "Code", codes.CountryCode, "code").Click();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToTableFrame(_frameState);
                foreach (StateCodes code in codes.StateCodes)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableState, "State Code", code.StateCode,
                        "stdesc").SetText(code.Description, "Description");
                    Driver.WaitForReady();
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Delete Country State Codes
        /// </summary>
        /// <param name="codes"></param>
        public void DeleteCountryStateCodes(StateCountryCodes codes)
        {
            _extendedPage.ClickOnRefreshButton();
            if (codes.StateCodes != null)
            {
                foreach (var code in codes.StateCodes)
                {
                    SelectCountryCode(codes.CountryCode);
                    DeleteStateCode(code.StateCode);
                }
                DeleteCountryCode(codes.CountryCode);
            }
            else
                Settings.Logger.Info("Test data not found for Delete Country State Codes");
        }

        /// <summary>
        /// Select Country Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void SelectCountryCode(string CodeVal)
        {
            _extendedPage.SwitchToTableFrame(_frameCountry);
            Settings.Logger.Info("Select Country Code : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableCountry, "Code", CodeVal, "code").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete State Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteStateCode(string CodeVal)
        {
            _extendedPage.SwitchToTableFrame(_frameState);
            Settings.Logger.Info("Delete State Code : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableState, "State Code", CodeVal, "stdesc").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Delete Country Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteCountryCode(string CodeVal)
        {
            _extendedPage.SwitchToTableFrame(_frameCountry);
            Settings.Logger.Info("Delete Country Code : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableCountry, "Code", CodeVal, "code").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Verify Deleted Country Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedCountryCode(string CodeVal)
        {
            _extendedPage.RefreshAndSwitchToTable(_frameCountry, "Country");
            Settings.Logger.Info("Verify Country Code is Deleted for : " + CodeVal);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_tableCountry, "Code", CodeVal);
            Driver.SwitchTo().DefaultContent();
        }
    }
}
