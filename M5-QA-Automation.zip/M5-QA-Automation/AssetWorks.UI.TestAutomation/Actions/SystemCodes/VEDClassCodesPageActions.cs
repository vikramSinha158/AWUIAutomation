﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes
{
    internal class VEDClassCodesPageActions : VEDClassCodesPage
    {
        public VEDClassCodesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create VED Class Codes
        /// </summary>
        /// <param name="VEDClassCodes"></param>
        /// <returns></returns>
        public string CreateVEDClassCodes(VEDClassCodes VEDClassCodes)
        {
            string VEDClassCodeValue = string.Empty;
            _extendpage.SwitchToContentFrame();
            if (!_extendpage.CheckDataExistenceAndGetActionCode(VEDClassCodes.VEDClassCode, ref VEDClassCodeValue, "VEDClassCodeQuery"))
            {
                VEDClassCodes.VEDClassCode = VEDClassCodeValue;
                FillVEDClassCodeTable(VEDClassCodes);

            }
            _extendpage.Save();
            Settings.Logger.Info($" Successfully Creatted VED Class Code { VEDClassCodes.VEDClassCode} ");
            return VEDClassCodes.VEDClassCode;
        }

        /// <summary>
        /// Fill VED Class Code Table
        /// </summary>
        /// <param name="VEDClassCodes"></param>
        public void FillVEDClassCodeTable(VEDClassCodes VEDClassCodes)
        {
            Driver.SwitchToFrame(_vEDClassCodesFrame, "vEDClassCodesFrame");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_vEDClassCodesTable, "Code", "", "VED_CLASS").SetText(VEDClassCodes.VEDClassCode, "VEDClassCode");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_vEDClassCodesTable, "Code", VEDClassCodes.VEDClassCode, "DESCRIPTION").SetText(VEDClassCodes.Description, "VEDClassCode Description");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_vEDClassCodesTable, "Code", VEDClassCodes.VEDClassCode, "VED_FEE").SetText(VEDClassCodes.AnnualFee, "AnnualFee");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_vEDClassCodesTable, "Code", VEDClassCodes.VEDClassCode, "VED_6FEE").SetText(VEDClassCodes.SixMonthFee, "SixMonthFee");
            _extendpage.Save();
            Settings.Logger.Info(" Added VED Class Code ");
        }

        /// <summary>
        /// Verify VED Class Code
        /// </summary>
        /// <param name="VEDClassCodes"></param>
        public void VerifyVEDClassCode(VEDClassCodes VEDClassCodes)
        {
            RefreshAndMoveToVEDClassCodes();
            string ActualVEDClassCodeValue = _extendpage.GetTableActionElementByRelatedColumnValue(_vEDClassCodesTable, "Code", VEDClassCodes.VEDClassCode, "VED_CLASS").GetAttribute("value");
            CommonUtil.AssertTrue<string>(VEDClassCodes.VEDClassCode, ActualVEDClassCodeValue);
            string ActualDescriptionValue = _extendpage.GetTableActionElementByRelatedColumnValue(_vEDClassCodesTable, "Code", VEDClassCodes.VEDClassCode, "DESCRIPTION").GetAttribute("value");
            CommonUtil.AssertTrue<string>(VEDClassCodes.Description, ActualDescriptionValue);
            string ActualAnnualFeeValue = _extendpage.GetTableActionElementByRelatedColumnValue(_vEDClassCodesTable, "Code", VEDClassCodes.VEDClassCode, "VED_FEE").GetAttribute("value"); ;
            CommonUtil.AssertTrue<string>(VEDClassCodes.AnnualFee, ActualAnnualFeeValue);
            string ActualSixMonthFeeValue = _extendpage.GetTableActionElementByRelatedColumnValue(_vEDClassCodesTable, "Code", VEDClassCodes.VEDClassCode, "VED_6FEE").GetAttribute("value"); ;
            CommonUtil.AssertTrue<string>(VEDClassCodes.SixMonthFee, ActualSixMonthFeeValue);
            Settings.Logger.Info(" Successfully Verified VED Class Code ");
        }

        /// <summary>
        /// Delete New Added VED Class Code
        /// </summary>
        /// <param name="VEDClassCodeValue"></param>
        public void DeleteNewAddedVEDClassCode(string VEDClassCodeValue)
        {
            RefreshAndMoveToVEDClassCodes();
            _extendpage.GetTableActionElementByRelatedColumnValue(_vEDClassCodesTable, "Code", VEDClassCodeValue, "VED_CLASS").Click();
            _extendpage.DeleteAndSave();
            Settings.Logger.Info($" Successfully Deleted New added VEDClassCodeValue-- { VEDClassCodeValue } ");
        }

        /// <summary>
        /// Refresh And Move To VED Class Code Value
        /// </summary>
        private void RefreshAndMoveToVEDClassCodes()
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_vEDClassCodesFrame, "vEDClassCodesFrame");
            Settings.Logger.Info(" Refresh VEDClassCodes ");
        }

        /// <summary>
        /// Update VED Class Codes
        /// </summary>
        /// <param name="VEDClassCodes"></param>
        public void UpdateVEDClassCodes(VEDClassCodes VEDClassCodes)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            FillVEDClassCodeTable(VEDClassCodes);
            _extendpage.Save();
            Driver.WaitForReady();
            Settings.Logger.Info($" Update for VED Class Codes -- {VEDClassCodes}  ");
        }

        /// <summary>
        /// Verify VED Class Codes Deletion
        /// </summary>
        /// <param name="VEDClassCodes"></param>
        public void VerifyVEDClassCodesDeletion(string VEDClassCodes)
        {
            RefreshAndMoveToVEDClassCodes();
            _extendpage.VerifyTableColumnDoesNotContainValue(_vEDClassCodesTable, "Code", VEDClassCodes);
            Settings.Logger.Info($" Successfully Verified VED Class Codes Deletion {VEDClassCodes}  ");
        }
    }
}
