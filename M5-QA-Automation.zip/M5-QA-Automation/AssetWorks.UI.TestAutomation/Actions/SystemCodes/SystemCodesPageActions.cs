﻿using OpenQA.Selenium;
using Newtonsoft.Json.Linq;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes;

namespace AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes
{
    internal class SystemCodesPageActions : SystemCodesPage
    {
        public SystemCodesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create System Code
        /// </summary>
        /// <param name="Code"></param>
        public string CreateSystemCode(JObject DataObject)
        {
            _extendedPage.SwitchToTableFrame(_frameSystemCodes);
            Settings.Logger.Info("Create System Code");
            _sysCode = CommonUtil.GetRandomStringWithSpecialChars(2);
            _sysDesc = CommonUtil.DataForKey("SDesc", DataObject) + _sysCode;
            _inputNewCode.SetText(_sysCode, "New Code");
            _inputNewDesc.SetText(_sysDesc, "New Desc");
            _inputNewCrossRef.SetText(CommonUtil.DataForKey("SCrossRef", DataObject), "New Cross Ref");
            _inputNewPartCharge.SetText(CommonUtil.DataForKey("SPartCharge", DataObject), "New Part Charge");
            _inputNewPriority.SetText(CommonUtil.DataForKey("SPriority", DataObject), "New Priority");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            VerifyTableUpdatedWithCode(_sysCode, "desc", _sysDesc);
            return _sysCode;
        }

        /// <summary>
        /// Verify Table Updated With System Code
        /// </summary>
        /// <param name="Code"></param>
        /// <param name="Column"></param>
        /// <param name="Value"></param>
        public void VerifyTableUpdatedWithCode(string Code, string Column, string Value)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_frameSystemCodes);
            Settings.Logger.Info($"Verify system code '{Column}' for : " + Code);
            string cellVal = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableSystemCodes, "Code", Code, Column).GetAttribute("value");
            CommonUtil.AssertTrue(Value, cellVal);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update System Code Value
        /// </summary>
        /// <param name="Code"></param>
        /// <param name="Column"></param>
        /// <param name="Value"></param>
        public void UpdateSystemCodeValue(string Code, string Column, string Value)
        {
            _extendedPage.SwitchToTableFrame(_frameSystemCodes);
            Settings.Logger.Info($"Update system code '{Column}' for : " + Code);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableSystemCodes, "Code", Code, Column).SetText(Value, Column);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Disable System Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DisableSystemCode(string CodeVal)
        {
            _extendedPage.SwitchToTableFrame(_frameSystemCodes);
            Settings.Logger.Info("Disable System Code : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableSystemCodes, "Code", CodeVal, "disable").Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Delete System Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteSystemCode(string CodeVal)
        {
            _extendedPage.SwitchToTableFrame(_frameSystemCodes);
            Settings.Logger.Info("Delete System Code : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableSystemCodes, "Code", CodeVal, "desc").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// 
        /// </summary>
        public string CreateNewSystemCode()
        {
            JObject data = CommonUtil.DataObjectForKey("CreateSC").ToObject<object>();
            return CreateSystemCode(data);
        }

        /// <summary>
        /// Edit System Code
        /// </summary>
        /// <param name="code"></param>
        /// <param name="column"></param>
        public void EditSystemCode(string code, string column)
        {
            string _colId, _colVal;
            var _records = CommonUtil.DataObjectForKey("UpdateSC");
            if (column.ToLower().Contains("partcharge"))
            {
                _colId = "part_charge";
                _colVal = CommonUtil.DataForKey("SPartCharge", _records);
            }
            else if (column.ToLower().Contains("laborcharge"))
            {
                _colId = "labor_charge";
                _colVal = CommonUtil.DataForKey("SLaborCharge", _records);
            }
            else if (column.ToLower().Contains("commcharge"))
            {
                _colId = "comm_charge";
                _colVal = CommonUtil.DataForKey("SCommCharge", _records);
            }
            else if (column.ToLower().Contains("unitassoc"))
            {
                _colId = "association";
                _colVal = CommonUtil.DataForKey("SUnitAssoc", _records);
            }
            else
            {
                _colId = "priority";
                _colVal = CommonUtil.DataForKey("SPriority", _records);
            }
            UpdateSystemCodeValue(code, _colId, _colVal);
            VerifyTableUpdatedWithCode(code, _colId, _colVal);
        }
    }
}
