﻿using OpenQA.Selenium;
using NUnit.Framework;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes;

namespace AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes
{
    internal class ClaimCategoryDefinitionPageActions : ClaimCategoryDefinitionPage
    {
        public ClaimCategoryDefinitionPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Warranty Category Code
        /// </summary>
        /// <param name="codes"></param>
        /// <returns>Code</returns>
        public string CreateWarrantyCategoryCode(WarrantyCategoryCodes codes)
        {
            string Code = string.Empty;
            Settings.Logger.Info("Create Warranty Category Code");
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(codes.WarrantyCategory, ref Code, "WarrantyCategoryCodeQuery", 3))
            {
                _extendedPage.SwitchToTableFrame(_frameWarrCategory);
                _inputWarrCategory.SetText(Code, "Warranty Category");
                Driver.WaitForReady();
                _inputWarrCategoryDesc.SetText(codes.Description, "Description");
                Driver.WaitForReady();
                _extendedPage.SetCheckBox(_checkboxClaimAmtProhibitied, "Claim Amt Prohibitied", codes.ClaimAmtProhibitied);
                _extendedPage.SetCheckBox(_checkboxSaveAmtProhibitied, "Save Amt Prohibitied", codes.SaveAmtProhibitied);
                _extendedPage.SetCheckBox(_checkboxDisabled, "Disabled", codes.Disabled);
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
                Driver.WaitForReady();
                _extendedPage.ClickOnRefreshButton();
                _extendedPage.SwitchToTableFrame(_frameWarrCategory);
                _extendedPage.VerifyTableColumnContainValue(_tableWarrCategory, _headerWarrCategory, Code);
                Driver.SwitchTo().DefaultContent();
            }
            return Code;
        }
    }
}
