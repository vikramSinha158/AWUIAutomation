﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes;

namespace AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes
{
    internal class IndirectAccountGroupsPageActions : IndirectAccountGroupsPage
    {
        public IndirectAccountGroupsPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Update Indirect Account in Group
        /// </summary>
        /// <param name="accountGroup"></param>
        public void UpdateIndirectAccountsInGroup(IndirectAccountGroup accountGroup)
        {
            string[] queryparam = { accountGroup.GroupName, "Account" };
            Settings.Logger.Info(" Updating Indirect Account in Group ");
            _extendedPage.SwitchToContentFrame();
            _inputGroupName.SetText(accountGroup.GroupName, "Group Name");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameIndAcctGroup, "Indirect Account Group");
            if (accountGroup.AssignIndAcctList != null)
            {
                foreach (string indAcctA in accountGroup.AssignIndAcctList)
                {
                    queryparam[1] = indAcctA;
                    if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection,
                        "IndirectAccountGroupQuery", queryparam, Settings.DBType))
                    {
                        _selectIndAcctListLeft.SelectDropdownUsingValue("Indirect Account list", indAcctA);
                        _buttonIndAcctListMoveRight.Click();
                        Driver.WaitForReady();
                    }
                }
            }
            if (accountGroup.UnassignIndAcctList != null)
            {
                foreach (string indAcctU in accountGroup.UnassignIndAcctList)
                {
                    queryparam[1] = indAcctU;
                    if (Settings.connection != null && !CommonUtil.CheckDataExistWithMultipleParams(Settings.connection,
                        "IndirectAccountGroupQuery", queryparam, Settings.DBType))
                    {
                        _selectIndAcctListRight.SelectDropdownUsingValue("Indirect Account list", indAcctU);
                        _buttonIndAcctListMoveLeft.Click();
                        Driver.WaitForReady();
                    }
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }
    }
}
