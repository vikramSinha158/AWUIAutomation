﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes;


namespace AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes
{
    internal class SystemPositionPageActions : SystemPositionPage
    {
        public SystemPositionPageActions(IWebDriver Driver) : base(Driver) { }

        internal string _locRightElement = "//select[@name='Choice1Right']/optiom[@value ='{itemvalue}']";
       
        /// <summary>
        /// Add Position Code to System Position
        /// </summary>
        /// <param name="systemCode"></param>
        /// <param name="PosCode"></param>
        public void AddValidPositionCode(string systemCode, string PosCode)
        {
            Settings.Logger.Info("Adding System Position Code");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputSystemCode.SetText(systemCode, "PosiSystemtion Code");
            Driver.WaitForReady();
            string locRightElement =$"//select[@name='Choice1Right']/option[@value ='{PosCode}']";
            Driver.SwitchToFrame(_frameSystemPositionCodes, "Table frame");
            Driver.WaitForReady();
            IWebElement ActionListItem = Driver.FindElement(By.XPath(locRightElement));
             _extendedPage.SelectValueAndMoveToDestination( ActionListItem,_btnMoveLeft);
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Remove Position Code from System Position
        /// </summary>
        /// <param name="systemCode"></param>
        /// <param name="PosCode"></param>
        public void RemovedPositionCode(string systemCode, string PosCode)
        {
            Settings.Logger.Info("Removing System Position Code");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputSystemCode.SetText(systemCode, "PosiSystemtion Code");
            Driver.WaitForReady();
            string locRightElement = $"//select[@name='Choice1Left']/option[@value ='{PosCode}']";
            Driver.SwitchToFrame(_frameSystemPositionCodes, "Table frame");
            IWebElement ActionListItem = Driver.FindElement(By.XPath(locRightElement));
            _extendedPage.SelectValueAndMoveToDestination(ActionListItem, _btnMoveRight);
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
        }
    }
    }

