﻿using OpenQA.Selenium;
using System.Collections.Generic;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes
{
    internal class AssetClassCodesPageActions : AssetClassCodesPage
    {
        public AssetClassCodesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Asset Class Code
        /// </summary>
        /// <param name="Codes"></param>
        /// <returns>Code</returns>
        public string CreateAssetClassCode(AssetClassCode Codes)
        {
            string AssetCode=string.Empty;
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(Codes.Code, ref AssetCode, "AssetClassQuery", 5))
            {
                Codes.Code = AssetCode;
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_frameAssetClassCodes, "Table frame");
                Settings.Logger.Info($"Creating Asset Class:{Codes.Code}");              
                _inputNewCode.SetText(Codes.Code, "New code");
                _inputNewDesc.SetText(Codes.Desc, "New code desc");
                _inputNewSmoothShift.SetText(Codes.SmoothShift, "New smooth shift");
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
                _extendedPage.ClickOnRefreshButton();
                Driver.WaitForReady();
                Assert.IsTrue(_extendedPage.CheckDataExistenceAndGetActionCode(Codes.Code, ref AssetCode, "AssetClassQuery", 5));
                Settings.Logger.Info($"Create Asset Class:{Codes.Code} created Successfully.");
            }
            else
            {
                Settings.Logger.Info($"Asset Class:{Codes.Code} already exists");
            }
            return Codes.Code;
        }

        /// <summary>
        /// Verify Asset Class Code Details
        /// </summary>
        /// <param name="Codes"></param>
        public void VerifyAssetClassCodeDetails(AssetClassCode Codes)
        {
            _extendedPage.RefreshAndSwitchToTable(_frameAssetClassCodes, "Table frame");
            Settings.Logger.Info("Verify Asset Class Code Details for : " + Codes.Code);
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssetClassCodes, "Code",
                Codes.Code, "desc"), "Desc", Codes.Desc, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssetClassCodes, "Code",
                Codes.Code, "smooth_shift"), "SmoothShift", Codes.SmoothShift, false, "value");
            CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssetClassCodes, "Code",
                Codes.Code, "disabled"), "Disabled", Codes.Disabled);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Asset Class Code Details
        /// </summary>
        /// <param name="Codes"></param>
        public void UpdateAssetClassCodeDetails(AssetClassCode Codes)
        {
            _extendedPage.RefreshAndSwitchToTable(_frameAssetClassCodes, "Table frame");
            Settings.Logger.Info("Update Asset Class Code Details for : " + Codes.Code);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssetClassCodes, "Code", 
                Codes.Code, "desc").SetText(Codes.Desc, "Code Description");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssetClassCodes, "Code", 
                Codes.Code, "smooth_shift").SetText(Codes.SmoothShift, "Smooth Shift");
            if (Codes.Disabled)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssetClassCodes, "Code",
                    Codes.Code, "disabled").SelectCheckBox("Disabled");
            else
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableAssetClassCodes, "Code",
                    Codes.Code, "disabled").DeSelectCheckBox("Disabled");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Get Assect code List
        /// </summary>
        /// <param name="DatObjectKey"></param>
        /// <returns>AssetCodeList</returns>
        public List<string> GetAssectcodeList(string DatObjectKey)
        {
            List<string> AssetCodeList = new List<string>();
            ACCodes DataObject = CommonUtil.DataObjectForKey(DatObjectKey).ToObject<ACCodes>();
            if (DataObject.Codes != null)
            {
                foreach (AssetClassCode Codedetail in DataObject.Codes)
                {
                    AssetCodeList.Add(CreateAssetClassCode(Codedetail));
                }
            }
            return AssetCodeList;
        }

        /// <summary>
        /// Delete Asset Class Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteAssetClassCode(string CodeVal)
        {
            _extendedPage.SwitchToTableFrame(_frameAssetClassCodes);
            Settings.Logger.Info("Delete Asset Class Code : " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableAssetClassCodes, "Code", CodeVal, "desc").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Verify Deleted Asset Class Code
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedAssetClassCode(string CodeVal)
        {
            _extendedPage.RefreshAndSwitchToTable(_frameAssetClassCodes, "Table frame");
            Settings.Logger.Info("Verify Asset Class Code is Deleted for : " + CodeVal);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_tableAssetClassCodes, "Code", CodeVal);
            Driver.SwitchTo().DefaultContent();
        }
    }
}
