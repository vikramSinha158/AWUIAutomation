﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class MCCUnitDisplayPageActions : MCCUnitDisplayPage
    {
        public MCCUnitDisplayPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Verify MCC Unit Display
        /// </summary>
        /// <param name="MCCKey"></param>
        /// <param name="UnitNo"></param>
        /// <param name="ComponentNo"></param>
        public void VerifyMCCUnitDisplay(string MCCKey,string UnitNo,string ComponentNo)
        {
            _extendPage.SwitchToContentFrame();
            _mCCKeyinput.SetText(MCCKey, "MCCKey for UnitDisplay ");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_unitsFrame, "unitsFrame");
            _extendPage.VerifyTableColumnContainValue(_unitsTable, _unitMoHeader, UnitNo);
            Driver.SwitchTo().DefaultContent();
            _extendPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_componentsFrame, "componentsFrame");
            _extendPage.VerifyTableColumnContainValue(_componentsTable, _componentNoHeader, ComponentNo);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info($" Successfully Verified UnitNo : { UnitNo } and ComponentNo : { ComponentNo } in  MCCUnitDispla");
        }
    }
}
