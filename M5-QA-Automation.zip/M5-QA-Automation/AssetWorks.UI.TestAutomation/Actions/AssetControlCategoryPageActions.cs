﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class AssetControlCategoryPageActions : AssetControlCategoryPage
    {
        public AssetControlCategoryPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Update Asset Control Category Budget Options
        /// </summary>
        /// <param name="categoryItems"></param>
        public void UpdateAssetControlCategory(AssetControlCategory categoryItems)
        {
            string code = string.Empty;
            if (ExtendedPage.CheckDataExistenceAndGetActionCode(categoryItems.Category, ref code, "CategoryCodeQuery"))
            {
                Settings.Logger.Info(" Updating Asset Control Category Budget Options ");
                ExtendedPage.SwitchToContentFrame();
                _inputCategory.SetText(categoryItems.Category, "Category");
                Driver.WaitForReady();
                if (categoryItems.Items != null)
                {
                    Driver.SwitchToFrame(_frameOptions, "Options");
                    foreach (ItemsBudget option in categoryItems.Items)
                    {
                        ExtendedPage.SetCheckBox(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableOptions, "Item", option.Item,
                            "Used"), "Disable", option.Disable);
                        Driver.WaitForReady();
                        ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableOptions, "Item", option.Item,
                            "Budget_Amt").SetText(option.ActualBudgetAmount, "Actual Budget Amount");
                        Driver.WaitForReady();
                        ExtendedPage.SetCheckBox(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableOptions, "Item", option.Item,
                            "non_std_flag"), "Non Standard Flag", option.NonStandardFlag);
                    }
                }
                Driver.SwitchTo().DefaultContent();
                ExtendedPage.ClickOnSaveButton();
                Driver.WaitForReady();
            }
            else
                Assert.Fail($" Category code not available {categoryItems.Category}");
        }

        /// <summary>
        /// Verify Asset Control Category Budget Options
        /// </summary>
        /// <param name="categoryItems"></param>
        public void VerifyAssetControlCategory(AssetControlCategory categoryItems)
        {
            Settings.Logger.Info(" Verifying Asset Control Category Budget Options ");
            ExtendedPage.SwitchToContentFrame();
            _inputCategory.SetText(categoryItems.Category, "Category");
            Driver.WaitForReady();
            if (categoryItems.Items != null)
            {
                Driver.SwitchToFrame(_frameOptions, "Options");
                foreach (ItemsBudget option in categoryItems.Items)
                {
                    CommonUtil.VerifyCheckboxState(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableOptions, "Item", option.Item,
                        "Used"), "Disable", option.Disable);
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableOptions, "Item", option.Item, 
                        "Budget_Amt"), "Actual Budget Amount", option.ActualBudgetAmount, false, "value");
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableOptions, "Item", option.Item,
                        "Default_Amt"), "Default Budget Amount", option.DefaultBudgetAmount, false, "value");
                    CommonUtil.VerifyCheckboxState(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableOptions, "Item", option.Item,
                        "non_std_flag"), "Non Standard Flag", option.NonStandardFlag);
                }
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
