﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class CommercialWorkOrderPageActions : CommercialWorkOrderPage
    {
        public CommercialWorkOrderPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Commercial WorkOrder
        /// </summary>
        /// <param name="CommercialWorkOrder"></param>
        public void CreateCommercialWorkOrder(CommercialWorkOrder CommercialWorkOrder)
        {
            _extendpage.SwitchToContentFrame();
            _unitNoInput.SetText(CommercialWorkOrder.UnitNumber, "Unit");
            Driver.WaitForReady();
            _newWOBtn.ClickElement("New work order", Driver);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow("Continue");
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _visitReason.SetText(CommercialWorkOrder.VisitRaason, "WOReason");
            Driver.WaitForReady();
            _openDate.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            CommercialWorkOrder.WorkOrderNo = _wonumber.GetElementValueByAttribute("ovalue");
            if (CommercialWorkOrder.VendorInformation != null)
            { FillVendorInformation(CommercialWorkOrder); }
            if (CommercialWorkOrder.JobList != null)
            { FillVendorJobList(CommercialWorkOrder); }
            Driver.WaitForReady();
            _extendpage.Save();
            Driver.WaitForReady();        
            FillInvoiceDetail(CommercialWorkOrder);
            Settings.Logger.Info($"Created Commercial Work Order {CommercialWorkOrder.WorkOrderNo} ");
        }

        /// <summary>
        /// Fill Invoice Detail
        /// </summary>
        /// <param name="CommercialWorkOrder"></param>
        public void FillInvoiceDetail(CommercialWorkOrder CommercialWorkOrder)
        {
            Settings.Logger.Info($"Filling InvoiceDetail for Commercial Work Order {CommercialWorkOrder.WorkOrderNo} ");
            if (CommercialWorkOrder.InvoiceNo != null)
            {
                _extendpage.SwitchToContentFrame();
                Driver.ScrollInView(_invoiceNo);
                _invoiceNo.SetText(CommercialWorkOrder.InvoiceNo, "InvoiceNo");
                Driver.WaitForReady();
                _invoiceDate.SetText(CommercialWorkOrder.InvoiceDate, "InvoiceDate");
                Driver.WaitForReady();
                _invoiceChangeWODate.SetText(CommercialWorkOrder.ChargeWODate, "ChargeWODate");
                Driver.WaitForReady();
                _extendpage.Save();
            }
        }

        /// <summary>
        /// Fill Vendor Information
        /// </summary>
        /// <param name="CommercialWorkOrder"></param>
        public void FillVendorInformation(CommercialWorkOrder CommercialWorkOrder)
        {
            Settings.Logger.Info($"Filling VendorInformation for Commercial Work Order {CommercialWorkOrder.WorkOrderNo} ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_wOCommVendFrame, "job frame ");
            List<VendorInformation> VendorInformation = CommercialWorkOrder.VendorInformation;
            foreach (VendorInformation VendorInfo in VendorInformation)
            {

                if(!VendorInfo.UpdateRequired) _extendpage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor No", "", "VendorNo").SetText(VendorInfo.VendorCode, "VendorCode");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor No", VendorInfo.VendorCode, "aAuthAmt").SetText(VendorInfo.AuthAmt, "AuthAmt");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor No", VendorInfo.VendorCode, "aCONTACT").SetText(VendorInfo.Contact, "Contact");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor No", VendorInfo.VendorCode, "aPHONE").SetText(VendorInfo.Phone, "Phone");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor No", VendorInfo.VendorCode, "aPHONE_EXT").SetText(VendorInfo.Ext, "Ext");
            }          
        }

        /// <summary>
        /// Fill Vendor Job List
        /// </summary>
        /// <param name="CommercialWorkOrder"></param>
        public void FillVendorJobList(CommercialWorkOrder CommercialWorkOrder)
        {
            Settings.Logger.Info($"Filling Vendor Job List for Commercial Work Order {CommercialWorkOrder.WorkOrderNo} ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_WOCommJobFrame, "job frame ");
            List<JobList> JobList = CommercialWorkOrder.JobList;
            foreach (JobList VendorJoblist in JobList)
            {
                if (!VendorJoblist.UpdateRequired) _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", "", "JobCode").SetText(VendorJoblist.JobCode, "JobCode");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bReason").SetText(VendorJoblist.Raason, "Raason");
                Driver.WaitForReady();
                if (String.IsNullOrEmpty(_extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bReason").GetAttribute("value")))
                {
                    IWebElement JobElement = _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bReason");
                    Driver.WaitForReady();
                    JobElement.SendKeys(VendorJoblist.Raason);
                    Driver.WaitForReady();
                    JobElement.SendKeys(Keys.Tab);
                }
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bCostEst").SetText(VendorJoblist.CostAmount, "CostAmount");
                Driver.WaitForReady();
               _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bLaborHrs").SetText(VendorJoblist.PlanTime, "PlanTime");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bBookTime").SetText(VendorJoblist.BookTime, "BookTime");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bLaborAmt").SetText(VendorJoblist.LaborCose, "LaborCose");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bMiscAmt").SetText(VendorJoblist.MiscAmt, "MiscAmt");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bTaxAmt").SetText(VendorJoblist.TaxAmt, "TaxAmt");
                Driver.WaitForReady();
                if (!VendorJoblist.UpdateRequired) _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bReqNo").SetText(VendorJoblist.AddRequest, "AddRequest");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bStatus").SetText(VendorJoblist.Status, "Status");
                Driver.WaitForReady();
            }
        }

        /// <summary>
        /// Verify Commercial WorkOrder
        /// </summary>
        /// <param name="CommercialWorkOrder"></param>
        public void VerifyCommercialWorkOrder(CommercialWorkOrder CommercialWorkOrder)
        {
            Settings.Logger.Info($"Verifying Commercial WorkOrder {CommercialWorkOrder.UnitNumber}");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendpage.RefreshAndSetText(_unitNoInput, CommercialWorkOrder.UnitNumber, "UnitNumber");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_unitNoInput, "UnitNumber", CommercialWorkOrder.UnitNumber);
            CommonUtil.VerifyElementValue(_visitReason, "VisitRaason", CommercialWorkOrder.VisitRaason);
            if (CommercialWorkOrder.VendorInformation != null)
            { VerifyVendorInformation(CommercialWorkOrder); }
            if (CommercialWorkOrder.JobList != null)
            { VerifyVendorJobList(CommercialWorkOrder); }
            Driver.WaitForReady();
            Settings.Logger.Info($"Successfully verified Commercial Work Order {CommercialWorkOrder.WorkOrderNo} ");
        }

        /// <summary>
        /// Verify Vendor Information
        /// </summary>
        /// <param name="CommercialWorkOrder"></param>
        public void VerifyVendorInformation(CommercialWorkOrder CommercialWorkOrder)
        {
            Settings.Logger.Info($"Verifying VendorInformation for Commercial Work Order {CommercialWorkOrder.WorkOrderNo} ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_wOCommVendFrame, "job frame ");
            List<VendorInformation> VendorInformation = CommercialWorkOrder.VendorInformation;
            foreach (VendorInformation VendorInfo in VendorInformation)
            {
                IWebElement VendorCode = _extendpage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor No", VendorInfo.VendorCode, "VendorNo");
                CommonUtil.VerifyElementValue(VendorCode, "VendorCode", VendorInfo.VendorCode,false, "value");
                IWebElement AuthAmte = _extendpage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor No", VendorInfo.VendorCode, "aAuthAmt");
                CommonUtil.VerifyElementValue(AuthAmte, "AuthAmte", VendorInfo.AuthAmt, false, "value");
                IWebElement Contact= _extendpage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor No", VendorInfo.VendorCode, "aCONTACT");
                CommonUtil.VerifyElementValue(Contact, "Contact", VendorInfo.Contact, false, "value");
                IWebElement Phone=_extendpage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor No", VendorInfo.VendorCode, "aPHONE");
                CommonUtil.VerifyElementValue(Phone, "Phone", VendorInfo.Phone, false, "value");
                IWebElement Ext= _extendpage.GetTableActionElementByRelatedColumnValue(_vendorTable, "Vendor No", VendorInfo.VendorCode, "aPHONE_EXT");
                CommonUtil.VerifyElementValue(Ext, "Ext", VendorInfo.Ext, false, "value");
            }
        }

        /// <summary>
        /// Verify Vendor Job List
        /// </summary>
        /// <param name="CommercialWorkOrder"></param>
        public void VerifyVendorJobList(CommercialWorkOrder CommercialWorkOrder)
        {
            Settings.Logger.Info($"Verifying Vendor Job List for Commercial Work Order {CommercialWorkOrder.WorkOrderNo} ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_WOCommJobFrame, "job frame ");
            List<JobList> JobList = CommercialWorkOrder.JobList;
            foreach (JobList VendorJoblist in JobList)
            {
                 IWebElement JobCode= _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "JobCode");
                CommonUtil.VerifyElementValue(JobCode, "JobCode", VendorJoblist.JobCode, false, "value");
                IWebElement Raason= _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bReason");
                CommonUtil.VerifyElementValue(Raason, "Raason", VendorJoblist.Raason, false, "value");
                IWebElement CostAmount= _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bCostEst");
                CommonUtil.VerifyElementValue(CostAmount, "CostAmount", VendorJoblist.CostAmount, false, "value");
                IWebElement PlanTime= _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bLaborHrs");
                CommonUtil.VerifyElementValue(PlanTime, "PlanTime", VendorJoblist.PlanTime, false, "value");
                IWebElement BookTime =_extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bBookTime");
                CommonUtil.VerifyElementValue(BookTime, "PlanTime", VendorJoblist.BookTime, false, "value");
                IWebElement LaborCose= _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bLaborAmt");
                CommonUtil.VerifyElementValue(LaborCose, "LaborCose", VendorJoblist.LaborCose, false, "value");
                IWebElement MiscAmt= _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bMiscAmt");
                CommonUtil.VerifyElementValue(MiscAmt, "MiscAmt", VendorJoblist.MiscAmt, false, "value");
                IWebElement TaxAmt= _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bTaxAmt");
                CommonUtil.VerifyElementValue(TaxAmt, "TaxAmt", VendorJoblist.TaxAmt, false, "value");
                IWebElement Status = _extendpage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", VendorJoblist.JobCode, "bStatus");
                CommonUtil.VerifyElementValue(Status, "Status", VendorJoblist.Status, false, "value");
            }
        }

        /// <summary>
        /// Complete And Close Commercial WorkOrder
        /// </summary>
        /// <param name="CommercialWorkOrder"></param>
        public void CompleteAndCloseCommercialWorkOrder(CommercialWorkOrder CommercialWorkOrder)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_unitNoInput, CommercialWorkOrder.UnitNumber, "UnitNumber");
            Driver.WaitForReady();
            _completeDate.SendKeys(CommercialWorkOrder.CompleteDate);
            Driver.WaitForReady();
            _coloseDate.SendKeys(CommercialWorkOrder.CloseDate);
            Driver.WaitForReady();
            _extendpage.Save();
            Driver.WaitForReady();
            Settings.Logger.Info($"Successfully Closed Commercial Work Order {CommercialWorkOrder.WorkOrderNo} ");
        }

        /// <summary>
        /// Verify CommercialWorkOrder Closed
        /// </summary>
        /// <param name="CommercialWorkOrder"></param>
        public void VerifyCommercialWorkOrderClosed(CommercialWorkOrder CommercialWorkOrder)
        {
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_woStatus, "WOStatus", CommercialWorkOrder.WOStatus);
            _extendpage.VerifySystemDateContainAppdate(_completeDate, "WO Complete Date", 0);
            _extendpage.VerifySystemDateContainAppdate(_coloseDate, "WO Close Date", 0);
            Driver.WaitForReady();
            Settings.Logger.Info($"Successfully Verified Commercial Work Order Closed Status {CommercialWorkOrder.WorkOrderNo} ");
        }

        /// <summary>
        /// Update Commercial WorkOrder
        /// </summary>
        /// <param name="CommercialWorkOrder"></param>
        public void UpdateCommercialWorkOrder(CommercialWorkOrder CommercialWorkOrder)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_unitNoInput, CommercialWorkOrder.UnitNumber, "UnitNumber");
            Driver.WaitForReady();
            CommercialWorkOrder.WorkOrderNo = _wonumber.GetElementValueByAttribute("ovalue");
            if (CommercialWorkOrder.VendorInformation != null)
            { FillVendorInformation(CommercialWorkOrder); }
            if (CommercialWorkOrder.JobList != null)
            { FillVendorJobList(CommercialWorkOrder); }
            Driver.WaitForReady();
            _extendpage.Save();
            Driver.WaitForReady();
            FillInvoiceDetail(CommercialWorkOrder);
            Settings.Logger.Info($" Successfully Updated Commercial Work Order {CommercialWorkOrder.WorkOrderNo} ");
        }

        /// <summary>
        /// Complete Commercial WorkOrder
        /// </summary>
        /// <param name="CommercialWorkOrder"></param>
        public void CompleteCommercialWorkOrder(CommercialWorkOrder CommercialWorkOrder)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_unitNoInput, CommercialWorkOrder.UnitNumber, "UnitNumber");
            Driver.WaitForReady();
            _completeDate.SendKeys(CommercialWorkOrder.CompleteDate);
             Driver.WaitForReady();
            _extendpage.Save();
            Driver.WaitForReady();
            Settings.Logger.Info($" Complete Commercial Work Order {CommercialWorkOrder.WorkOrderNo} ");
        }

        /// <summary>
        /// Close Commercial WorkOrder
        /// </summary>
        /// <param name="CommercialWorkOrder"></param>
        public void CloseCommercialWorkOrder(CommercialWorkOrder CommercialWorkOrder)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_unitNoInput, CommercialWorkOrder.UnitNumber, "UnitNumber");
            Driver.WaitForReady();
            _wonumber.SetText(CommercialWorkOrder.WorkOrderNo, "WorkOrderNo");
            Driver.WaitForReady();
            _coloseDate.SendKeys(CommercialWorkOrder.CloseDate);
            Driver.WaitForReady();
            _extendpage.Save();
            Driver.WaitForReady();
            Settings.Logger.Info($" Closed Commercial Work Order {CommercialWorkOrder.WorkOrderNo} ");
        }
    }
}
