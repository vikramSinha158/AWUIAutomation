﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    //Define all actions for ComponentMain Page 
    internal class ComponentMainPageActions: ComponentMainPage
    {
        public ComponentMainPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Component
        /// </summary>
        /// <returns></returns>
        public string CreateComponent(string ObjectKey)
        {
            _comp = CommonUtil.DataObjectForKey(ObjectKey).ToObject<ComponentMain>();
            Settings.Logger.Info(" Creating Component ");
            if(_comp.ComponentNumber==null)
            {
                _comp.ComponentNumber = CommonUtil.GetRandomStringWithSpecialChars();
            }            
            _extendpage.SwitchToContentFrame();
            _componentInput.SetText(_comp.ComponentNumber, "Component Number");
            Settings.Logger.Info("Giving component number  as:" + Settings.ComponentNumber);
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow("Create");
            _extendpage.SwitchToContentFrame();
            if (_comp.FillOtherComponentFields == "Yes")
            {
                FillOtherComponentFields(_comp);
            }
            return _comp.ComponentNumber;
        }

        /// <summary>
        /// Fill Other ComponentFields
        /// </summary>
        public void FillOtherComponentFields(ComponentMain DataObject)
        {
            _componentDesc.SetText(DataObject.ComponentDesc, " Component Desc ");
            Driver.WaitForReady();
            _componenTechSpec.SetText(DataObject.TechSpecnumber, "Component Tech Spec ");
            Driver.WaitForReady();
            _serialNo.SetText(DataObject.SerialNumber, "SerialNo");
            Driver.WaitForReady();
            _mcc.SetText(DataObject.MCC, "MCC");
            Driver.WaitForReady();
            _systemCode.SetText(DataObject.SystemCode, "System Code ");
            Driver.WaitForReady();
            _locationCode.SetText(DataObject.Location, "Location ");
            Driver.WaitForReady();
            _binNo.SetText(DataObject.BinNumber, "Bin Number ");
            Driver.WaitForReady();
            _maintLoc.SetText(DataObject.Maintenance, "Maintenance Loc ");
            Driver.WaitForReady();
            _extendpage.SelectAllAndClearField(_partNo);
            Driver.WaitForReady();
            _partNo.SetText(DataObject.PartNumber, "Part Number ");
            Driver.WaitForReady();
            _owningDept.SetText(DataObject.OwningDepartment, "owning Dept ");
            Driver.WaitForReady();
            _serviceDate.SetText(DataObject.ServiceDate, "serviceDate");
            Driver.WaitForReady();
            _primaryMeter.SetText(DataObject.PrimaryMeterValue, "primary Meter");
            Driver.WaitForReady();
            _secondaryMeter.SetText(DataObject.SecondaryMeterValue, "secondary Meter");
            Driver.WaitForReady();
            _componentNotes.SetText(DataObject.ComponentNoteDesc, "Component Tech Spec ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClicKSave();
        }

        /// <summary>
        /// Verify Component Fields
        /// </summary>
        /// <param name="ComponentNumber"></param>
         public void VerifyComponentFields(string ObjectKey,string ComponentNumber)
        {
            ComponentMain? DataObject = CommonUtil.DataObjectForKey(ObjectKey).ToObject<ComponentMain>();
             Settings.Logger.Info(" Verifying Component Main Fields  ");
            _extendpage.RefreshAndSetText(_componentInput, ComponentNumber, "Component Number ");
            CommonUtil.VerifyElementValue(_componentDesc, "component Desc", DataObject.ComponentDesc);
            CommonUtil.VerifyElementValue(_componenTechSpec, "componen Tech Spec", DataObject.TechSpecnumber);
            CommonUtil.VerifyElementValue(_serialNo, "serial No", DataObject.SerialNumber);
            CommonUtil.VerifyElementValue(_mcc, "MCC", DataObject.MCC);
            CommonUtil.VerifyElementValue(_systemCode, "systemCode", DataObject.SystemCode);
            CommonUtil.VerifyElementValue(_locationCode, "locationCode", DataObject.Location);
            CommonUtil.VerifyElementValue(_binNo, "binNo", DataObject.BinNumber);
            CommonUtil.VerifyElementValue(_maintLoc, "maintLoc", DataObject.Maintenance);
            CommonUtil.VerifyElementValue(_partNo, "partNo", DataObject.PartNumber);
            CommonUtil.VerifyElementValue(_owningDept, "owningDept", DataObject.OwningDepartment);
            CommonUtil.VerifyElementValue(_serviceDate, "owningDept", DataObject.ServiceDate);
            CommonUtil.VerifyElementValue(_primaryMeter, "primaryMeter", DataObject.PrimaryMeterValue);
            CommonUtil.VerifyElementValue(_secondaryMeter, "secondaryMeter", DataObject.SecondaryMeterValue);
            CommonUtil.VerifyElementValue(_componentNotes, "componentNotes", DataObject.ComponentNoteDesc);
            Settings.Logger.Info(" Successfully Verified  Component Main Fields  ");         
        }

        /// <summary>
        /// Verify Component Deletion
        /// </summary>
        public void VerifyComponentDeletion(string ComponentNumber)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.VerifyCodeDeletion(_componentInput, ComponentNumber, "Component");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Get Component Number
        /// </summary>
        /// <returns></returns>
        public string GetComponentNumber()
        {
            return _componentInput.GetElementValueByAttribute("ovalue");
        }
    }
 }
