﻿using OpenQA.Selenium;
using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Location;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Location
{
    internal class LocationGroupsPageActions : LocationGroupsPage
    {
        public LocationGroupsPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Assign Locations in Group
        /// </summary>
        /// <param name="groups"></param>
        public void AssignLocationsInGroup(LocationGroups groups)
        {
            Settings.Logger.Info(" Check if Locations already in Group ");
            List<string> LocationsNeedToAdd = new();
            if (groups.LocationsNotIncluded != null)
            {
                string[] queryparam = { groups.GroupName, "location"};
                foreach (string location in groups.LocationsNotIncluded)
                {
                    queryparam[1] = location;
                    if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection, 
                        "LocationGroupQuery", queryparam, Settings.DBType))
                        LocationsNeedToAdd.Add(location);
                }
            }

            if (LocationsNeedToAdd.Count > 0)
            {
                Settings.Logger.Info(" Assign Locations in Group ");
                Extendedpage.SwitchToContentFrame();
                _inputName.SetText(groups.GroupName, "Name");
                Driver.WaitForReady();
                Driver.SwitchToFrame(_frameLocationGroup, "Location Group Main Frame");
                foreach (string location in LocationsNeedToAdd)
                {
                    _selectLocationsNotIncluded.SelectDropdownUsingValue("Location", location);
                    Driver.WaitForReady();
                }
                _buttonMoveRight.ClickElement("Move Right", Driver);
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                Extendedpage.ClickOnSaveButton();
                VerifyLocationsInGroup(groups);
            }
        }

        /// <summary>
        /// Unassign Locations from Group
        /// </summary>
        /// <param name="groups"></param>
        public void UnassignLocationsFromGroup(LocationGroups groups)
        {
            Settings.Logger.Info(" Unassign Locations from Group ");
            Extendedpage.SwitchToContentFrame();
            _inputName.SetText(groups.GroupName, "Name");
            Driver.WaitForReady();
            if (groups.LocationsIncluded != null)
            {
                Driver.SwitchToFrame(_frameLocationGroup, "Location Group Main Frame");
                foreach (string location in groups.LocationsIncluded)
                {
                    _selectLocationsInGroup.SelectDropdownUsingValue("Location", location);
                    Driver.WaitForReady();
                }
                _buttonMoveLeft.ClickElement("Move Left", Driver);
            }
            Driver.SwitchTo().DefaultContent();
            Extendedpage.ClickOnSaveButton();
        }

        /// <summary>
        /// Verify Locations in Group
        /// </summary>
        /// <param name="groups"></param>
        public void VerifyLocationsInGroup(LocationGroups groups)
        {
            Settings.Logger.Info(" Verify Locations in Group ");
            Extendedpage.ClickOnRefreshButton();
            Extendedpage.SwitchToContentFrame();
            _inputName.SetText(groups.GroupName, "Name");
            Driver.WaitForReady();
            if (groups.LocationsInGroup != null)
            {
                Driver.SwitchToFrame(_frameLocationGroup, "Location Group Main Frame");
                IList<string> LocIncluded = _selectLocationsInGroup.GetDropdownValueList();
                foreach (string location in groups.LocationsInGroup)
                {
                    Assert.True(LocIncluded.Contains(location));
                }
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
