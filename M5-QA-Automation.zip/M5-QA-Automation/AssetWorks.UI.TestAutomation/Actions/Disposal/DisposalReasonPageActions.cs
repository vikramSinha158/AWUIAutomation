﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Disposal;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Dispoal
{
    internal class DisposalReasonPageActions : DisposalReasonPage
    {
        public DisposalReasonPageActions(IWebDriver Driver) : base(Driver) { }

       /// <summary>
       /// Create Disposal Reason
       /// </summary>
       /// <param name="DataObject"></param>
       /// <returns></returns>
        public DisposalReasonCodeObjects CreateDisposalReason(DisposalReasonCodeObjects DataObject)
        {
            string DisposalReason = string.Empty;
            if (!_extendpage.CheckDataExistenceAndGetActionCode(DataObject.Reason, ref DisposalReason, "DisposalReasonQuery"))
            {
                _extendpage.SwitchToContentFrame();
                Driver.SwitchToFrame(_iframeDisposal, "Table frame");
                Settings.Logger.Info($"Create Disposal Reason: {DataObject.Reason} ");
                _dispoalReason.SetText(DataObject.Reason, "Disposal reason");
                 Driver.WaitForReady();
                _discription.SetText(DataObject.Description, "Description");
                _disabledCheckbox.SelectCheckBox("Disable", DataObject.Disable);
                _extendpage.Save();
                Assert.IsTrue(_extendpage.CheckDataExistenceAndGetActionCode(DataObject.Reason, ref DisposalReason, "DisposalReasonQuery"));
                Settings.Logger.Info($" Disposal Reason: {DataObject.Reason} created successfully");
            }
            else
            {
                Settings.Logger.Info($"Disposal Reason: {DataObject.Reason} already Exists ");
            }
            return DataObject;
        }

       
    }
}
