﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Disposal;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Disposal
{
    internal class DisposalMethodPageActions : DisposalMethodPage
    {
        public DisposalMethodPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Disposal Method
        /// </summary>
        /// <param name="DisposalMethodDetail"></param>
        /// <returns></returns>
        public string CreateDisposalMethod(DisposalMethod DisposalMethodDetail)
        {          
            _extendpage.SwitchToContentFrame();
            string DisposalMethod = string.Empty;
            Driver.SwitchToFrame(_disposalMethodFrame, "disposalMethodFrame");
            if (!_extendpage.CheckDataExistenceAndGetActionCode(DisposalMethodDetail.DisposalMethodName, ref DisposalMethod, "Query", 5))
            {
                DisposalMethodDetail.DisposalMethodName = DisposalMethod;
                _extendpage.GetTableActionElementByRelatedColumnValue(_dispMethodTable, "Disposal\r\nMethod", "", "dispMethod").SetText(DisposalMethodDetail.DisposalMethodName, "DisposalMethodName");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_dispMethodTable, "Disposal\r\nMethod", DisposalMethodDetail.DisposalMethodName, "desc").SetText(DisposalMethodDetail.DisposalMethodDesc, "DisposalMethodDesc");
                Driver.WaitForReady();
                _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_dispMethodTable, "Disposal\r\nMethod", DisposalMethodDetail.DisposalMethodName, "disabled"), "DisposalMethodFlag", DisposalMethodDetail.DisposalMethodFlag);
                _extendpage.Save();
                Driver.WaitForSomeTime();
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Created Disposal Method");
            return DisposalMethodDetail.DisposalMethodName;
        }

        /// <summary>
        /// Verify Disposal Method
        /// </summary>
        /// <param name="DisposalMethodDetail"></param>
        public void VerifyDisposalMethod(DisposalMethod DisposalMethodDetail)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_disposalMethodFrame, "Table frame");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_dispMethodTable, "Disposal\r\nMethod", DisposalMethodDetail.DisposalMethodName, "dispMethod"), "DisposalMethodName",DisposalMethodDetail.DisposalMethodName, false, "value");
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_dispMethodTable, "Disposal\r\nMethod", DisposalMethodDetail.DisposalMethodName, "desc"), "DisposalMethodDesc",DisposalMethodDetail.DisposalMethodDesc, false, "value");
            CommonUtil.VerifyCheckboxState(_extendpage.GetTableActionElementByRelatedColumnValue(_dispMethodTable, "Disposal\r\nMethod", DisposalMethodDetail.DisposalMethodName, "disabled"), "DisposalMethodFlag", DisposalMethodDetail.DisposalMethodFlag);
            Settings.Logger.Info("verified Disposal Method Details for : " + DisposalMethodDetail.DisposalMethodName);
        }

        /// <summary>
        /// Update Disposal Method
        /// </summary>
        /// <param name="DisposalMethodDetail"></param>
        public void UpdateDisposalMethod(DisposalMethod DisposalMethodDetail)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_disposalMethodFrame, "Table frame");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_dispMethodTable, "Disposal\r\nMethod", DisposalMethodDetail.DisposalMethodName, "desc").SetText(DisposalMethodDetail.DisposalMethodDesc, "DisposalMethodDesc");
            Driver.WaitForReady();
            _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_dispMethodTable, "Disposal\r\nMethod", DisposalMethodDetail.DisposalMethodName, "disabled"), "DisposalMethodFlag", DisposalMethodDetail.DisposalMethodFlag);
            _extendpage.Save();
            Driver.WaitForReady();
            Settings.Logger.Info(" Updated Disposal Method");
        }

        /// <summary>
        /// Delete Disposal Method
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteDisposalMethod(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_disposalMethodFrame, "Table frame");
            _extendpage.GetTableActionElementByRelatedColumnValue(_dispMethodTable, "Disposal\r\nMethod", CodeVal, "dispMethod").Click();
            Driver.WaitForReady();
            _extendpage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Deleted Disposal Method : " + CodeVal);
        }

        /// <summary>
        /// Verify Deleted Disposal Method
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedDisposalMethod(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_disposalMethodFrame, "Table frame");
            _extendpage.VerifyTableColumnDoesNotContainValue(_dispMethodTable, "Disposal\r\nMethod", CodeVal);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verified Disposal Method Deletetion : " + CodeVal);
        }
    }
}
