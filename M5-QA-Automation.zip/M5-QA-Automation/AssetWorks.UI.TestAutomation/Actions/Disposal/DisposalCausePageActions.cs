﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Disposal;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Disposal
{
    internal class DisposalCausePageActions : DisposalCausePage
    {
        public DisposalCausePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Disposal Cause 
        /// </summary>
        /// <param name="DisposalCauseDetail"></param>
        /// <returns></returns>
        public string CreateDisposalCause(DisposalCause DisposalCauseDetail)
        {
            _extendpage.SwitchToContentFrame();
            string DisposalCause = string.Empty;
            Driver.SwitchToFrame(_disposalCauseFrame, "disposalMethodFrame");
            if (!_extendpage.CheckDataExistenceAndGetActionCode(DisposalCauseDetail.DisposalCauseName, ref DisposalCause, "Query", 1))
            {
                DisposalCauseDetail.DisposalCauseName = DisposalCause;
                _extendpage.GetTableActionElementByRelatedColumnValue(_dispCauseTable, "Disposal\r\nCause", "", "dispCause").SetText(DisposalCauseDetail.DisposalCauseName, "DisposalCauseName");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_dispCauseTable, "Disposal\r\nCause", DisposalCauseDetail.DisposalCauseName, "desc").SetText(DisposalCauseDetail.DisposalCauseDesc, "DisposalCauseDesc");
                Driver.WaitForReady();
                _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_dispCauseTable, "Disposal\r\nCause", DisposalCauseDetail.DisposalCauseName, "disabled"), "DisposalCauseFlag", DisposalCauseDetail.DisposalCauseFlag);
                _extendpage.Save();
                Driver.WaitForSomeTime();
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Created Disposal Cause");
            return DisposalCauseDetail.DisposalCauseName;
        }

        /// <summary>
        /// Verify Disposal Cause 
        /// </summary>
        /// <param name="DisposalMethodDetail"></param>
        public void VerifyDisposalCause(DisposalCause DisposalCauseDetail)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_disposalCauseFrame, "Table frame");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_dispCauseTable, "Disposal\r\nCause", DisposalCauseDetail.DisposalCauseName, "dispCause"), "DisposalCauseName", DisposalCauseDetail.DisposalCauseName, false, "value");
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_dispCauseTable, "Disposal\r\nCause", DisposalCauseDetail.DisposalCauseName, "desc"), "DisposalCauseDesc", DisposalCauseDetail.DisposalCauseDesc, false, "value");
            CommonUtil.VerifyCheckboxState(_extendpage.GetTableActionElementByRelatedColumnValue(_dispCauseTable, "Disposal\r\nCause", DisposalCauseDetail.DisposalCauseName, "disabled"), "DisposalCauseFlag", DisposalCauseDetail.DisposalCauseFlag);
            Settings.Logger.Info("verified Disposal Cause Details for : " + DisposalCauseDetail.DisposalCauseName);
        }

        /// <summary>
        /// UpdateDisposal Cause 
        /// </summary>
        /// <param name="DisposalMethodDetail"></param>
        public void UpdateDisposalCause(DisposalCause DisposalCauseDetail)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_disposalCauseFrame, "Table frame");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_dispCauseTable, "Disposal\r\nCause", DisposalCauseDetail.DisposalCauseName, "desc").SetText(DisposalCauseDetail.DisposalCauseDesc, "DisposalCauseDesc");
            Driver.WaitForReady();
            _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_dispCauseTable, "Disposal\r\nCause", DisposalCauseDetail.DisposalCauseName, "disabled"), "DisposalCauseFlag", DisposalCauseDetail.DisposalCauseFlag);
            _extendpage.Save();
            Driver.WaitForReady();
            Settings.Logger.Info(" Updated Disposal Cause");
        }

        /// <summary>
        /// Delete Disposal Cause 
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteDisposalCause(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_disposalCauseFrame, "Table frame");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_dispCauseTable, "Disposal\r\nCause", CodeVal, "dispCause").Click();
            Driver.WaitForReady();
            _extendpage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Deleted Disposal Cause : " + CodeVal);
        }

        /// <summary>
        /// Verify Disposal Cause 
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedDisposalCause(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_disposalCauseFrame, "Table frame");
            _extendpage.VerifyTableColumnDoesNotContainValue(_dispCauseTable, "Disposal\r\nCause", CodeVal);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verified Disposal Cause Deletetion : " + CodeVal);
        }
    }
}
