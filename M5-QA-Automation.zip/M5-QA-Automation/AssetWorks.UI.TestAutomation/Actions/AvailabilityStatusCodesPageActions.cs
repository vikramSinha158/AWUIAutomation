﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class AvailabilityStatusCodesPageActions : AvailabilityStatusCodesPage
    {
        public AvailabilityStatusCodesPageActions(IWebDriver? Driver) : base(Driver) { }

        /// <summary>
        /// Create new Availability Status Code
        /// </summary>
        /// <param name="statusCode"></param>
        /// <returns></returns>
        public string CreateAvailabilityStatusCode(AvailabilityStatusCode statusCode)
        {
            string Status = string.Empty;
            Settings.Logger.Info($" Create new Availability Status Code  - {statusCode.Status}");
            if (!ExtendedPage.CheckDataExistenceAndGetActionCode(statusCode.Status, ref Status, "AvailabilityStatusCodeQuery", 3))
            {
                ExtendedPage.SwitchToTableFrame(_frameStatusCode);
                _inputStatus.SetText(statusCode.Status, "Status");
                Driver.WaitForReady();
                _inputDispositionCode.SetText(statusCode.DispositionCode, "Disposition Code");
                Driver.WaitForReady();
                _inputDescription.SetText(statusCode.Description, "Description");
                Driver.WaitForReady();
                _checkboxWaitForMateFlag.SelectCheckBox("Wait For Mate Flag", statusCode.WaitForMateFlag);
                Driver.WaitForReady();
                _checkboxDisabled.SelectCheckBox("Disabled", statusCode.Disabled);
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                ExtendedPage.ClickOnSaveButton();
                Driver.WaitForReady();
            }
            else
            {
                if (statusCode.WaitForMateFlag)
                {
                    string[] dataParams = { statusCode.Status, "Y" };
                    if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection,
                        "AvailabilityStatusFlagQuery", dataParams, Settings.DBType))
                    {
                        ExtendedPage.SwitchToTableFrame(_frameStatusCode);
                        ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableStatusCode, "Status",
                            statusCode.Status, "waitformatefl").SelectCheckBox("Wait For Mate Flag", statusCode.WaitForMateFlag);
                        Driver.WaitForReady();
                        Driver.SwitchTo().DefaultContent();
                        ExtendedPage.ClickOnSaveButton();
                        Driver.WaitForReady();
                    }
                }
            }
            VerifyStatusWaitForMateFlag(statusCode);
            return statusCode.Status;
        }

        /// <summary>
        /// Verify Status Wait For Mate Flag
        /// </summary>
        /// <param name="statusCode"></param>
        public void VerifyStatusWaitForMateFlag(AvailabilityStatusCode statusCode)
        {
            Settings.Logger.Info($" Verify Status Wait For Mate Flag Status Code  - {statusCode.Status}");
            ExtendedPage.ClickOnRefreshButton();
            ExtendedPage.SwitchToTableFrame(_frameStatusCode);
            string state = ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableStatusCode, "Status", statusCode.Status, "waitformatefl").GetAttribute("value");
            if (statusCode.WaitForMateFlag)
                CommonUtil.AssertTrue<string>("Y", state.Trim().ToUpper());
            else
                Assert.IsTrue(string.IsNullOrEmpty(state));
            Driver.SwitchTo().DefaultContent();
        }
    }
}
