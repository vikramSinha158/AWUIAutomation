﻿using OpenQA.Selenium;
using NUnit.Framework;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class PartListDisposalPageActions : PartListDisposalPage
    {
        public PartListDisposalPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Load Department Information
        /// </summary>
        /// <param name="DeptNo"></param>
        public void LoadDepartmentInformation(string DeptNo)
        {
            _extendedPage.SwitchToContentFrame();
            _selectSearchType.SelectFilterValueHavingEqualValue("Department");
            _inputUnitDeptNo.SetText(DeptNo, "Department");
            Settings.Logger.Info(" Clicked on Show All checkbox ");
            _inputShowAll.VerifyElementDisplay(" Show All checkbox ");
            _inputShowAll.Click();
            Settings.Logger.Info(" Clicked on Show All checkbox ");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Install New Part For Disposal
        /// </summary>
        /// <param name="disposal"></param>
        public void InstallNewPartForDisposal(PartDisposal disposal)
        {
            Settings.Logger.Info("Install New Part For Disposal");
            _extendedPage.SwitchToTableFrame(_frameDisposalParts);
            _inputNewReason.SetText(disposal.DisReason, "Reason");
            Driver.WaitForReady();
            _inputNewPart.SetText(disposal.DisPart, "Part");
            Driver.WaitForReady();
            _inputNewQuantity.SetText(disposal.DisQuantity, "Quantity");
            _inputNewIssueValue.SetText(disposal.DisIssueValue, "Issue Value");
            _extendedPage.AddNotes(_buttonNewNotes);
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            VerifyPartInstalled(disposal.DisPart);
        }

        /// <summary>
        ///Verify Part Installed
        /// </summary>
        /// <param name="Part"></param>
        public void VerifyPartInstalled(string Part)
        {
            Settings.Logger.Info("Verify Part Installed");
            _extendedPage.SwitchToTableFrame(_frameDisposalParts);
            string partDesc = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _tableDisposalParts, "Part", Part, "qty").GetAttribute("value");
            Driver.SwitchTo().DefaultContent();
            Assert.IsFalse(string.IsNullOrEmpty(partDesc), "Part not installed successfully.");
            Settings.Logger.Info("Part Installed successfully");
        }
    }
}
