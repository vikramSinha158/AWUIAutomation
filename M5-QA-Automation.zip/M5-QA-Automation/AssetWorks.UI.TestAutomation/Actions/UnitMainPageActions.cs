﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class UnitMainPageActions: UnitMainPage
    {
        public UnitMainPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Method to create unit
        /// </summary>
        public void CreateUnit()
        {
            Settings.Logger.Info(" Creating new unit ");
            Settings.UnitNumber = CommonUtil.GetRandomStringWithSpecialChars();
            _extendedPage.SwitchToContentFrame();
            _unitNoInput.SendKeys(Settings.UnitNumber);
            Settings.Logger.Info($"Enter unir number as : {Settings.UnitNumber} ");
            _unitNoInput.SendKeys(Keys.Enter);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ActionRequiredWindow("Create");
            _extendedPage.SwitchToContentFrame();
            _extendedPage.EnterDescription(_descriptionInput);
            EnterBillingCode();
            ClickDeptLocation();
            FillDeptInformation();
            FillUnitLocation();
            ClickMetereAccounting();
            FillAccountMeterInfo();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.VerifyCreatedActionNumber(_unitNoInput, Settings.UnitNumber);
        }

        /// <summary>
        /// Enter Billing Code
        /// </summary>
        public void EnterBillingCode()
        {
            Settings.Logger.Info(" Clicked on Billing Code  ");
            Driver.ScrollIntoViewAndClick(_billingCode," Billing Code ");
            _billingCode.SendKeys(Keys.Enter);
        }

        /// <summary>
        /// Click Dept Location
        /// </summary>
        public void ClickDeptLocation()
        {
            Driver.ScrollIntoViewAndClick(_deptLocations,"Dept location tab ");
        }

        /// <summary>
        /// Fill Dept Information
        /// </summary>
        public void FillDeptInformation()
        {
            Settings.Logger.Info(" Filling Department Information  ");
            Driver.WaitForReady();
            _deptOwner.Click();
            _deptOwner.SendKeys(Settings.Department);         
            _unitNoInput.SendKeys(Keys.Enter);
            Settings.Logger.Info($" Entered Department owner {Settings.Department} ");
            Driver.WaitForReady();
            _deptUsing.Click();
            _deptUsing.SendKeys(Settings.Department);         
            _deptUsing.SendKeys(Keys.Enter);
            Settings.Logger.Info($" Entered Department Using {Settings.Department} ");
            _unitNoInput.SendKeys(Keys.Enter);
            Driver.WaitForReady();
        }

        /// <summary>
        /// Fill Unit Location
        /// </summary>
        public void FillUnitLocation()
        {
            Settings.Logger.Info(" Filling Unit location Information  ");
            Driver.WaitForReady();
            Driver.PageScrollDown();
            _parkingLoc.Click();
            _parkingLoc.SendKeys(Settings.Location);
            _parkingLoc.SendKeys(Keys.Tab);
            Settings.Logger.Info($" Entered Parking location  {Settings.Location} ");
            Driver.WaitForReady();
            _maintLoc.Click();
            _maintLoc.SendKeys(Settings.Location);
            _maintLoc.SendKeys(Keys.Tab);
            Settings.Logger.Info($" Entered maintemance location  {Settings.Location} ");
            Driver.WaitForReady();
            _fuelingLoc.Click();
            _fuelingLoc.SendKeys(Settings.Location);
            _fuelingLoc.SendKeys(Keys.Tab);
            Settings.Logger.Info($" Entered Pueling location  {Settings.Location} ");
            Driver.WaitForReady();
            _deliveryLoc.Click();
            _deliveryLoc.SendKeys(Settings.Location);
            Settings.Logger.Info($" Entered Delivery location  {Settings.Location} ");
            _deliveryLoc.SendKeys(Keys.Tab);
        }

        /// <summary>
        /// Click Metere Accounting
        /// </summary>
        public void ClickMetereAccounting()
        {
            Driver.ScrollIntoViewAndClick(_meterAccounting,"Meter  Accounting ");
        }

        /// <summary>
        /// Fill Account MeterInfo
        /// </summary>
        public void FillAccountMeterInfo()
        {
            Settings.Logger.Info(" Filling Account Meter Info ");
            Driver.WaitForReady();
            _acquisitionDate.SendKeys(CommonUtil.GenerateRandomDateString(-1));
            Settings.Logger.Info(" Entered acquisition Date ");        
            Driver.WaitForReady();
            _acquisitionDate.SendKeys(Keys.Tab);
            _serviceDate.SendKeys(CommonUtil.GenerateRandomDateString(-1));
            _unitNoInput.SendKeys(Keys.Enter);
            Settings.Logger.Info(" Entered service Date ");
            Driver.WaitForReady();
        }

        //-------------------------------------------------------------------//

        /// <summary>
        /// Load Unit And Open Dept/Locations Tab
        /// </summary>
        /// <param name="UnitNo"></param>
        public void LoadUnitAndOpenDeptLocTab(string UnitNo)
        {
            _extendedPage.SwitchToContentFrame();
            _unitNoInput.SetText(UnitNo, "Unit No");
            Settings.Logger.Info($"Clicking on Dept/Locations Tab");
            _extendedPage.GetTabLinkByText("Dept/Locations").Click();
        }

        /// <summary>
        /// Verify Department Details
        /// </summary>
        /// <param name="Owning"></param>
        /// <param name="Using"></param>
        /// <exception cref="Exception"></exception>
        public void VerifyDepartmentDetails(string Owning, string Using)
        {
            Settings.Logger.Info("Verify Unit Department Number Details ");
            string _deptOwn = _deptOwner.GetElementValueByAttribute("ovalue");
            string _deptUse = _deptUsing.GetElementValueByAttribute("ovalue");
            if (_deptOwn != null && _deptUse != null)
            {
                Assert.AreEqual(_deptOwn, CommonUtil.DataForKey(Owning), "Department owner doesn't mached.");
                Assert.AreEqual(_deptUse, CommonUtil.DataForKey(Using), "Department using doesn't mached.");
                Settings.Logger.Info($" Matched Actual dept owner : {_deptOwn} with expacted {_deptOwn}");
                Settings.Logger.Info($" Matched Actual dept using : {_deptUse} with expacted {_deptUse}");
            }
            else
                throw new Exception("Department Details not found.!");
        }

        /// <summary>
        /// Verify Unit Deletion
        /// </summary>
        /// <param name="UnitNo"></param>
        public void VerifyUnitDeletion(string UnitNo)
        {
            Driver.WaitForReady();
            _extendedPage.VerifyCodeDeletion(_unitNoInput, UnitNo, "Unit No");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Create Unit
        /// </summary>
        /// <param name="unit"></param>
        /// <returns>UnitNo</returns>
        public string CreateUnit(UnitMain unit)
        {
            string UnitNo = String.Empty;
            if (unit.IsAddNew)
                UnitNo = CreateNewUnit(unit);
            else
            {
                if (!_extendedPage.CheckDataExistenceAndGetActionCode(unit.UnitNo, ref UnitNo, "UnitQuery", 12))
                {
                    unit.UnitNo = UnitNo;
                    UnitNo = CreateNewUnit(unit);
                }
            }
            return UnitNo;
        }

        /// <summary>
        /// Create New Unit
        /// </summary>
        /// <param name="unit"></param>
        /// <returns>UnitNo</returns>
        public string CreateNewUnit(UnitMain unit)
        {
            Settings.Logger.Info(" Create a new Unit ");
            if (unit.IsAddNew)
            {
                _extendedPage.SwitchToContentFrame();
                _buttonAddNew.ClickElement("Add New", Driver);
            }
            else
            {
                _unitNoInput.SetText(unit.UnitNo, "Unit No", Driver, _extendedPage._contentFrame, "content frame");
                if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                    _extendedPage.ClickOnDialogBoxButton("Create");
                _extendedPage.SwitchToContentFrame();
            }
            unit.AlternateUnitNo = CommonUtil.GetRandomStringWithSpecialChars().ToUpper();
            _descriptionInput.SetText(unit.UnitDescription, "Unit Description");
            _inputAlternateUnitNo.SetText(unit.AlternateUnitNo, "Alternate Unit No");
            Driver.SwitchTo().DefaultContent();
            if (unit.AssetCodesTab != null)
                FillAssetCodesTabInformation(unit.AssetCodesTab);
            if (unit.DeptLocationsTab != null)
                FillDeptLocationsTabInformation(unit.DeptLocationsTab);
            if (unit.ClassTab != null)
                FillClassTabInformation(unit.ClassTab);
            if (unit.MeterAccountingTab != null)
                FillMeterAccountingTabInformation(unit.MeterAccountingTab);
            if (unit.LicenseNotesTab != null)
                FillLicenseNotesTabInformation(unit.LicenseNotesTab);
            if (unit.IsAddNew)
            {
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
                unit.UnitNo = _unitNoInput.GetElementValueByAttribute("ovalue");
            }
            _extendedPage.VerifyRecordCreatedSuccess(_unitNoInput, _inputStatus, unit.UnitNo, "Unit No");
            return unit.UnitNo;
        }

        /// <summary>
        /// Update Unit Info
        /// </summary>
        /// <param name="unit"></param>
        public void UpdateUnitInfo(UnitMain unit)
        {
            Settings.Logger.Info($" Update Unit - {unit.UnitNo}");
            _extendedPage.RefreshAndSetText(_unitNoInput, unit.UnitNo, "Unit No");
            Driver.WaitForReady();
            _descriptionInput.SetText(unit.UnitDescription, "Unit Description");
            _inputAlternateUnitNo.SetText(unit.AlternateUnitNo, "Alternate Unit No");
            Driver.SwitchTo().DefaultContent();
            if (unit.AssetCodesTab != null)
                FillAssetCodesTabInformation(unit.AssetCodesTab);
            if (unit.DeptLocationsTab != null)
                FillDeptLocationsTabInformation(unit.DeptLocationsTab);
            if (unit.ClassTab != null)
                FillClassTabInformation(unit.ClassTab);
            if (unit.MeterAccountingTab != null)
                FillMeterAccountingTabInformation(unit.MeterAccountingTab);
            if (unit.LicenseNotesTab != null)
                FillLicenseNotesTabInformation(unit.LicenseNotesTab);
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Validate Disable MCC in Unit
        /// </summary>
        /// <param name="unit"></param>
        public void ValidateDisableMCCinUnit(UnitMain unit)
        {
            Settings.Logger.Info($" Validating Disable MCC in Unit NO:: - {unit.UnitNo}");
            Settings.Logger.Info($" Update Unit - {unit.UnitNo}");
            _extendedPage.RefreshAndSetText(_unitNoInput, unit.UnitNo, "Unit No");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            _extendedPage.GetTabLinkByText("Asset/Codes").Click();
            Settings.Logger.Info("Clicked on Asset/Codes Tab");
            Driver.WaitForReady();
            _inputMCC.SetText(unit.AssetCodesTab.MCC, "MCC");
            Driver.WaitForSomeTime(2);
            String alertText = Driver.GetAlertText();
            Driver.AcceptAlert();
            CommonUtil.AssertTrue<string>(alertText, $"Value {unit.AssetCodesTab.MCC} not found on file");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Operational Class for Unit
        /// </summary>
        /// <param name="unitNo"></param>
        /// <param name="opClass"></param>
        public void UpdateOperationalClass(string unitNo, string opClass)
        {
            Settings.Logger.Info($" Update Operational Class for Unit - {unitNo}");
            _extendedPage.RefreshAndSetText(_unitNoInput, unitNo, "Unit No");
            Driver.WaitForReady();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Class"), "Class Tab");
            Settings.Logger.Info("Clicked on Class Tab");
            Driver.WaitForReady();
            _inputOperationalClass.SetText(opClass, "Operational Class");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage._buttonSave.ClickElement("Save", Driver);
            Driver.WaitForSomeTime();
            Driver.AcceptAlert();
            VerifyOperationalClass(unitNo, opClass);
        }

        /// <summary>
        /// Verify Operational Class for Unit
        /// </summary>
        /// <param name="unitNo"></param>
        /// <param name="opClass"></param>
        public void VerifyOperationalClass(string unitNo, string opClass)
        {
            Settings.Logger.Info($" Verify Operational Class for Unit - {unitNo}");
            _extendedPage.RefreshAndSetText(_unitNoInput, unitNo, "Unit No");
            Driver.WaitForReady();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Class"), "Class Tab");
            Settings.Logger.Info("Clicked on Class Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputOperationalClass, "Operational Class", opClass);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Fill Asset Codes Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillAssetCodesTabInformation(AssetCodesTab DataObject)
        {
            Settings.Logger.Info(" Update Unit Asset/Codes Information");
            _extendedPage.SwitchToContentFrame();
            _extendedPage.GetTabLinkByText("Asset/Codes").Click();
            Settings.Logger.Info("Clicked on Asset/Codes Tab");
            Driver.WaitForReady();
            _inputSerialNo.SetText(CommonUtil.GetRandomStringWithSpecialChars(12).ToUpper(), "Serial No");
            Driver.WaitForReady();
            _inputMCC.SetText(DataObject.MCC, "MCC");
            Driver.WaitForReady();
            _inputActivityCode.SetText(DataObject.ActivityCode, "Activity Code");
            Driver.WaitForReady();
            _inputTechSpecNo.SetText(DataObject.TechSpecNo, "Tech Spec No");
            Driver.WaitForReady();
            _inputAssetType.SetText(DataObject.AssetType, "Asset Type");
            Driver.WaitForReady();
            _inputEquipmentType.SetText(DataObject.EquipmentType, "Equipment Type");
            Driver.WaitForReady();
            _inputLicenseClassCode.SetText(DataObject.LicenseClassCode, "License Class Code");
            Driver.WaitForReady();
            if (DataObject.Retrofitted != null && DataObject.Retrofitted.ToLower().Equals("yes"))
                _checkboxRetrofitted.Click();
            _inputRetrofittedDesc.SetText(DataObject.RetrofittedDesc, "Retrofitted Desc");
            if (DataObject.BillingCode != null)
            {
                _extendedPage.SelectAllAndClearField(_billingCode);
                _billingCode.SetText(DataObject.BillingCode, "Billing Code");
            }
            else
                _billingCode.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            if (DataObject.HighPriority != null && DataObject.HighPriority.ToLower().Equals("yes"))
                _checkboxHighPriority.Click();
            if (DataObject.Telematics != null && DataObject.Telematics.ToLower().Equals("yes"))
                _checkboxTelematics.Click();
            if (DataObject.TelematicsMeter != null && DataObject.TelematicsMeter.ToLower().Equals("yes"))
                _checkboxTelematicsMeter.Click();
            Driver.WaitForReady();
            _inputCalibrationDate.SetText(DataObject.CalibrationDate, "Calibration Date");
            Driver.WaitForReady();
            _inputCalibrationExpiresDate.SetText(DataObject.CalibrationExpiresDate, "Calibration Expires Date");
            Driver.WaitForReady();
            _inputConditionCode.SetText(DataObject.ConditionCode, "Condition Code");
            if (DataObject.EmployeeOwned != null && DataObject.EmployeeOwned.ToLower().Equals("yes"))
                _checkboxEmployeeOwned.Click();
            Driver.WaitForReady();
            _inputEmployeeNumber.SetText(DataObject.EmployeeNumber, "Employee Number");
            Driver.WaitForReady();
            _inputAttSerialNo.SetText(DataObject.AttSerialNo, "Att Serial No");
            Driver.WaitForReady();
            _inputAttTechSpecNo.SetText(DataObject.AttTechSpecNo, "Att Tech Spec No");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Fill Dept Locations Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillDeptLocationsTabInformation(DeptLocationsTab DataObject)
        {
            Settings.Logger.Info(" Update Unit Dept/Locations Information");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Dept/Locations"), "Dept/Locations Tab");
            Settings.Logger.Info("Clicked on Dept/Locations Tab");
            Driver.WaitForReady();
            if (DataObject.Customer != null)
            {
                Driver.DoubleClick(_inputCustomer, "Customer");
                _lov.SearchAndSelectFirstRowData(DataObject.Customer);
                _extendedPage.SwitchToContentFrame();
                Driver.WaitForReady();
            }
            _deptOwner.SetText(DataObject.Owning, "Owning");
            Driver.WaitForReady();
            _deptUsing.SetText(DataObject.Using, "Using");
            Driver.WaitForReady();
            _parkingLoc.SetText(DataObject.Parking, "Parking");
            Driver.WaitForReady();
            _maintLoc.SetText(DataObject.Maintenance, "Maintenance");
            Driver.WaitForReady();
            _fuelingLoc.SetText(DataObject.Fueling, "Fueling");
            Driver.WaitForReady();
            _deliveryLoc.SetText(DataObject.Delivery, "Delivery");
            Driver.WaitForReady();
            _currentLoc.SetText(DataObject.Current, "Current");
            Driver.WaitForReady();
            _binNo.SetText(DataObject.BinNo, "BinNo");
            Driver.WaitForReady();
            _inputOperator.SetText(DataObject.Operator, "Operator");
            Driver.WaitForReady();
            if (DataObject.SharePool != null && DataObject.SharePool.ToLower().Equals("yes"))
                _checkboxSharePool.Click();
            Driver.WaitForReady();
            _inputMotorPoolClass.SetText(DataObject.MotorPoolClass, "Motor Pool Class");
            Driver.WaitForReady();
            _inputMotorPoolLocation.SetText(DataObject.MotorPoolLocation, "Motor Pool Location");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Fill Class Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillClassTabInformation(ClassTab DataObject)
        {
            Settings.Logger.Info(" Update Unit Class Information");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Class"), "Class Tab");
            Settings.Logger.Info("Clicked on Class Tab");
            Driver.WaitForReady();
            _inputShiftCode1.SetText(DataObject.ShiftCode1, "ShiftCode1");
            Driver.WaitForReady();
            _inputShiftCode2.SetText(DataObject.ShiftCode2, "ShiftCode2");
            Driver.WaitForReady();
            _inputShiftCode3.SetText(DataObject.ShiftCode3, "ShiftCode3");
            Driver.WaitForReady();
            _inputShiftCode4.SetText(DataObject.ShiftCode4, "ShiftCode4");
            Driver.WaitForReady();
            _inputShiftCode5.SetText(DataObject.ShiftCode5, "ShiftCode5");
            Driver.WaitForReady();
            _inputClass1.SetText(DataObject.Class1, "Class1");
            Driver.WaitForReady();
            _inputClass2.SetText(DataObject.Class2, "Class2");
            Driver.WaitForReady();
            _inputClass3.SetText(DataObject.Class3, "Class3");
            Driver.WaitForReady();
            _inputClass4.SetText(DataObject.Class4, "Class4");
            Driver.WaitForReady();
            _inputClass5.SetText(DataObject.Class5, "Class5");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Fill Meter Accounting Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillMeterAccountingTabInformation(MeterAccountingTab DataObject)
        {
            Settings.Logger.Info(" Update Unit Meter/Accounting Information");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Meter/Accounting"), "Meter/Accounting Tab");
            Settings.Logger.Info("Clicked on Meter/Accounting Tab");
            Driver.WaitForReady();
            _inputAcquisitionMeter.SetText(DataObject.AcqPrimaryMeter, "Acq Primary Meter");
            Driver.WaitForReady();
            _acquisitionDate.SetText(DataObject.AcquisitionDate, "Acquisition Date");
            Driver.WaitForReady();
            _inputInSecondaryMeterAcquis.SetText(DataObject.AcqSecondaryMeter, "SecondarMeteAcquis");
            Driver.WaitForReady();
            _inputAcquisitionArrivalDate.SetText(DataObject.ArrivalDate, "Acquisition Arrival Date");
            Driver.WaitForReady();
            _inputInServiceMeter.SetText(DataObject.SerPrimaryMeter, "In-Service Primary Meter");
            Driver.WaitForReady();
            _serviceDate.SetText(DataObject.InServiceDate, "In-Service Date");
            Driver.WaitForReady();
            _inputInSecondaryMeterService.SetText(DataObject.SerSecondaryMeter, "Secondary Meter Service");
            Driver.WaitForReady();
            _inputManufactureDate.SetText(DataObject.ManufactureDate, "Manufacture Date");
            Driver.WaitForReady();
            _inputMarkupScheme.SetText(DataObject.MarkupScheme, "Markup Scheme");
            Driver.WaitForReady();
            _inputPONumber.SetText(DataObject.PONumber, "PO Number");
            Driver.WaitForReady();
            _inputTotalPurchasePrice.SetText(DataObject.TotalPurchasePrice, "Total Purchase Price");
            Driver.WaitForReady();
            if (DataObject.TaxExemption != null && DataObject.TaxExemption.ToLower().Equals("yes"))
                _checkboxTaxExempt.Click();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Fill License Notes Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillLicenseNotesTabInformation(LicenseNotesTab DataObject)
        {
            Settings.Logger.Info(" Update Unit License/Notes Information");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("License/Notes"), "License/Notes Tab");
            Settings.Logger.Info("Clicked on License/Notes Tab");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameLicensePermit, "License Permit frame");
            _inputNewLicenseNo.SetText(DataObject.LicenseNo, "License No");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            _inputVEDClass.SetText( DataObject.VEDClass, "VED Class");
            Driver.WaitForReady();
            _inputTitleNo.SetText(CommonUtil.GetRandomStringWithSpecialChars().ToUpper(), "Title Number");
            Driver.WaitForReady();
            _inputAssetNo.SetText(CommonUtil.GetRandomStringWithSpecialChars().ToUpper(), "Asset Number");
            Driver.WaitForReady();
            _inputUnitNotes.SetText(DataObject.UnitNotes, "Unit Notes");
            Driver.WaitForReady();
            _inputUnitWONotes.SetText( DataObject.UnitWONotes, "Unit WO Notes");
            Driver.WaitForReady();
            _inputCustomerNotes.SetText(DataObject.CustomerNotes, "Customer Notes");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Unit Information
        /// </summary>
        /// <param name="UnitNo"></param>
        /// <param name="unit"></param>
        public void VerifyUnitInformation(string UnitNo, UnitMain unit)
        {
            Settings.Logger.Info(" Verify Unit Information");
            _extendedPage.RefreshAndSetText(_unitNoInput, UnitNo, "Unit No");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_descriptionInput, "Unit Desc", unit.UnitDescription);
            CommonUtil.VerifyElementValue(_inputStatus, "Unit Status", unit.UnitStatus);
            CommonUtil.VerifyElementValue(_inputAlternateUnitNo, "Alternate Unit No", unit.AlternateUnitNo);
            if (unit.AssetCodesTab != null)
                VerifyAssetCodesTabInformation(unit.AssetCodesTab);
            if (unit.DeptLocationsTab != null)
                VerifyDeptLocationsTabInformation(unit.DeptLocationsTab);
            if (unit.ClassTab != null)
                VerifyClassTabInformation(unit.ClassTab);
            if (unit.MeterAccountingTab != null)
                VerifyMeterAccountingTabInformation(unit.MeterAccountingTab);
            if (unit.LicenseNotesTab != null)
                VerifyLicenseNotesTabInformation(unit.LicenseNotesTab);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Asset Codes Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyAssetCodesTabInformation(AssetCodesTab DataObject)
        {
            Settings.Logger.Info(" Verify Department General Information");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Asset/Codes"), "Asset/Codes Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputMCC, "MCC", DataObject.MCC);
            CommonUtil.VerifyElementValue(_inputActivityCode, "Activity Code", DataObject.ActivityCode);
            CommonUtil.VerifyElementValue(_inputTechSpecNo, "Tech Spec No", DataObject.TechSpecNo);
            CommonUtil.VerifyElementValue(_inputAssetType, "Asset Type", DataObject.AssetType);
            CommonUtil.VerifyElementValue(_inputEquipmentType, "Equipment Type", DataObject.EquipmentType);
            CommonUtil.VerifyElementValue(_inputLicenseClassCode, "License Class Code", DataObject.LicenseClassCode);
            CommonUtil.VerifyElementValue(_inputRetrofittedDesc, "Retrofitted Desc", DataObject.RetrofittedDesc);
            CommonUtil.VerifyElementValue(_inputConditionCode, "Condition Code", DataObject.ConditionCode);
            CommonUtil.VerifyElementValue(_inputEmployeeNumber, "Employee Number", DataObject.EmployeeNumber);
            CommonUtil.VerifyElementValue(_inputAttSerialNo, "Att Serial No", DataObject.AttSerialNo);
            CommonUtil.VerifyElementValue(_inputAttTechSpecNo, "Att Tech Spec No", DataObject.AttTechSpecNo);
        }

        /// <summary>
        /// Verify Dept Locations Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyDeptLocationsTabInformation(DeptLocationsTab DataObject)
        {
            Settings.Logger.Info(" Verify Unit Dept/Locations Information");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Dept/Locations"), "Dept/Locations Tab");
            Settings.Logger.Info("Clicked on Dept/Locations Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputCustomer, "Customer", DataObject.Customer);
            CommonUtil.VerifyElementValue(_deptOwner, "Owning", DataObject.Owning);
            CommonUtil.VerifyElementValue(_deptUsing, "Using", DataObject.Using);
            CommonUtil.VerifyElementValue(_parkingLoc, "Parking", DataObject.Parking);
            CommonUtil.VerifyElementValue(_maintLoc, "Maintenance", DataObject.Maintenance);
            CommonUtil.VerifyElementValue(_fuelingLoc, "Fueling", DataObject.Fueling);
            CommonUtil.VerifyElementValue(_deliveryLoc, "Delivery", DataObject.Delivery);
            CommonUtil.VerifyElementValue(_currentLoc, "Current", DataObject.Current);
            CommonUtil.VerifyElementValue(_binNo, "BinNo", DataObject.BinNo);
            CommonUtil.VerifyElementValue(_inputOperator, "Operator", DataObject.Operator);
            CommonUtil.VerifyElementValue(_inputMotorPoolClass, "Motor Pool Class", DataObject.MotorPoolClass);
            CommonUtil.VerifyElementValue(_inputMotorPoolLocation, "Motor Pool Location", DataObject.MotorPoolLocation);
        }

        /// <summary>
        /// Verify Class Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyClassTabInformation(ClassTab DataObject)
        {
            Settings.Logger.Info(" Verify Unit Class Information");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Class"), "Class Tab");
            Settings.Logger.Info("Clicked on Class Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputShiftCode1, "Shift Code 1", DataObject.ShiftCode1);
            CommonUtil.VerifyElementValue(_inputShiftCode2, "Shift Code 2", DataObject.ShiftCode2);
            CommonUtil.VerifyElementValue(_inputShiftCode3, "Shift Code 3", DataObject.ShiftCode3);
            CommonUtil.VerifyElementValue(_inputShiftCode4, "Shift Code 4", DataObject.ShiftCode4);
            CommonUtil.VerifyElementValue(_inputShiftCode5, "Shift Code 5", DataObject.ShiftCode5);
            CommonUtil.VerifyElementValue(_inputClass1, "Class 1", DataObject.Class1);
            CommonUtil.VerifyElementValue(_inputClass2, "Class 2", DataObject.Class2);
            CommonUtil.VerifyElementValue(_inputClass3, "Class 3", DataObject.Class3);
            CommonUtil.VerifyElementValue(_inputClass4, "Class 4", DataObject.Class4);
            CommonUtil.VerifyElementValue(_inputClass5, "Class 5", DataObject.Class5);
        }

        /// <summary>
        /// Verify Meter Accounting Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyMeterAccountingTabInformation(MeterAccountingTab DataObject)
        {
            Settings.Logger.Info(" Verify Unit Meter/Accounting Information");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Meter/Accounting"), "Meter/Accounting Tab");
            Settings.Logger.Info("Clicked on Meter/Accounting Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputAcquisitionMeter, "Acquisition Meter", DataObject.AcqPrimaryMeter);
            if (DataObject.AcquisitionDate != null && DataObject.AcquisitionDate.ToLower() == "now")
                _extendedPage.VerifySystemDateContainAppdate(_acquisitionDate, "Acquisition Date");
            else
                CommonUtil.VerifyElementValue(_acquisitionDate, "Acquisition Date", DataObject.AcquisitionDate);
            if (DataObject.ArrivalDate != null && DataObject.ArrivalDate.ToLower() == "now")
                _extendedPage.VerifySystemDateContainAppdate(_inputAcquisitionArrivalDate, "Arrival Date");
            else
                CommonUtil.VerifyElementValue(_inputAcquisitionArrivalDate, "Arrival Date", DataObject.ArrivalDate);
            if (DataObject.InServiceDate != null && DataObject.InServiceDate.ToLower() == "now")
                _extendedPage.VerifySystemDateContainAppdate(_serviceDate, "InService Date");
            else
                CommonUtil.VerifyElementValue(_serviceDate, "InService Date", DataObject.InServiceDate);
            CommonUtil.VerifyElementValue(_inputInServiceMeter, "InService Meter", DataObject.SerPrimaryMeter);
            CommonUtil.VerifyElementValue(_inputMarkupScheme, "Markup Scheme", DataObject.MarkupScheme);
            CommonUtil.VerifyElementValue(_inputPONumber, "PO Number", DataObject.PONumber);
            CommonUtil.VerifyElementValue(_inputTotalPurchasePrice, "Total Purchase Price", DataObject.TotalPurchasePrice);
        }

        /// <summary>
        /// Verify License Notes Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyLicenseNotesTabInformation(LicenseNotesTab DataObject)
        {
            Settings.Logger.Info(" Verify Unit License/Notes Information ");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("License/Notes"), "License/Notes Tab");
            Settings.Logger.Info(" Clicked on License/Notes Tab ");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputVEDClass, "VED Class", DataObject.VEDClass);
            CommonUtil.VerifyElementValue(_inputUnitNotes, "Unit Notes", DataObject.UnitNotes);
            CommonUtil.VerifyElementValue(_inputUnitWONotes, "Unit WO Notes", DataObject.UnitWONotes);
            CommonUtil.VerifyElementValue(_inputCustomerNotes, "Customer Notes", DataObject.CustomerNotes);
        }

        /// <summary>
        /// Verify Copy Unit Information
        /// </summary>
        /// <param name="UnitNo"></param>
        public void VerifyCopyUnitInformation(string UnitNo)
        {
            Settings.Logger.Info(" Verify Copied Unit Information");
            UnitMain unitInfo = CommonUtil.DataObjectForKey("UnitInfo").ToObject<UnitMain>();
            _extendedPage.SwitchToContentFrame();
            string ActualUnitNo = _unitNoInput.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue(UnitNo, ActualUnitNo);
            string ActualUnitDesc = _descriptionInput.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(unitInfo.UnitDescription, ActualUnitDesc);
            string ActualStatus = _inputStatus.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(unitInfo.UnitStatus, ActualStatus);
            if (unitInfo.AssetCodesTab != null)
            {
                Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Asset/Codes"), "Asset/Codes Tab");
                Driver.WaitForReady();
                string ActualAssetType = _inputAssetType.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(unitInfo.AssetCodesTab.AssetType, ActualAssetType);
                string ActualAttTechSpecNo = _inputAttTechSpecNo.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(unitInfo.AssetCodesTab.AttTechSpecNo, ActualAttTechSpecNo);
            }
            if (unitInfo.DeptLocationsTab != null)
            {
                Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Dept/Locations"), "Dept/Locations Tab");
                Settings.Logger.Info("Clicked on Dept/Locations Tab");
                Driver.WaitForReady();
                string ActualCustomer = _inputCustomer.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(unitInfo.DeptLocationsTab.Customer, ActualCustomer);
                string ActualUsing = _deptUsing.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(unitInfo.DeptLocationsTab.Using, ActualUsing);
            }
            if (unitInfo.MeterAccountingTab != null)
            {
                Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Meter/Accounting"), "Meter/Accounting Tab");
                Settings.Logger.Info("Clicked on Meter/Accounting Tab");
                Driver.WaitForReady();
                string ActualTotalPurchasePrice = _inputTotalPurchasePrice.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(unitInfo.MeterAccountingTab.TotalPurchasePrice, ActualTotalPurchasePrice);
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Motor Pool Details
        /// </summary>
        /// <param name="unitNo"></param>
        /// <param name="mpClass"></param>
        /// <param name="mpLocation"></param>
        public void UpdateMotorPoolDetails(string unitNo, string mpClass, string mpLocation)
        {
            Settings.Logger.Info($" Update Motor Pool Details for Unit - {unitNo}");
            _extendedPage.RefreshAndSetText(_unitNoInput, unitNo, "Unit No");
            Driver.WaitForReady();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Dept/Locations"), "Dept/Locations Tab");
            Settings.Logger.Info("Clicked on Dept/Locations Tab");
            Driver.WaitForReady();
            _checkboxSharePool.SelectCheckBox("Share Pool", true);
            _inputMotorPoolClass.SetText(mpClass, "Motor Pool Class");
            Driver.WaitForReady();
            _inputMotorPoolLocation.SetText(mpLocation, "Motor Pool Location");
            Driver.SwitchTo().DefaultContent();
            _extendedPage._buttonSave.ClickElement("Save", Driver);
            Driver.WaitForReady();
            VerifyMotorPoolDetails(unitNo, mpClass, mpLocation);
        }

        /// <summary>
        /// Verify Motor Pool Details
        /// </summary>
        /// <param name="unitNo"></param>
        /// <param name="mpClass"></param>
        /// <param name="mpLocation"></param>
        public void VerifyMotorPoolDetails(string unitNo, string mpClass, string mpLocation)
        {
            Settings.Logger.Info($" Verify Motor Pool Details for Unit - {unitNo}");
            _extendedPage.RefreshAndSetText(_unitNoInput, unitNo, "Unit No");
            Driver.WaitForReady();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Dept/Locations"), "Dept/Locations Tab");
            Settings.Logger.Info("Clicked on Dept/Locations Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputMotorPoolClass, "Motor Pool Class", mpClass);
            CommonUtil.VerifyElementValue(_inputMotorPoolLocation, "Motor Pool Location", mpLocation);
            Driver.SwitchTo().DefaultContent();
        }

    }
}
