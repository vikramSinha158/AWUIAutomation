using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.Actions.Units;
using AssetWorks.UI.M5.TestAutomation.Actions.Employee;
using AssetWorks.UI.M5.TestAutomation.Actions.MotorPool;
using AssetWorks.UI.M5.TestAutomation.Actions.Equipment;
using AssetWorks.UI.M5.TestAutomation.Actions.Department;
using AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes;
using AssetWorks.UI.M5.TestAutomation.Actions.Booking;
using AssetWorks.UI.M5.TestAutomation.Actions.MarkUp;
using AssetWorks.UI.M5.TestAutomation.Actions.Accidents;
using AssetWorks.UI.M5.TestAutomation.Actions.BasicUserFunctionality;
using AssetWorks.UI.M5.TestAutomation.Actions.Parts;
using AssetWorks.UI.M5.TestAutomation.Actions.WorkRequest;
using AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.Actions.Labor;
using AssetWorks.UI.M5.TestAutomation.Actions.Driver;
using AssetWorks.UI.M5.TestAutomation.Actions.ServiceOrder;
using AssetWorks.UI.M5.TestAutomation.Actions.ProductOrder;
using AssetWorks.UI.M5.TestAutomation.Actions.ProductLocationReceive;
using AssetWorks.UI.M5.TestAutomation.Actions.Location;
using AssetWorks.UI.M5.TestAutomation.Actions.TestSuite;
using AssetWorks.UI.M5.TestAutomation.Actions.Dashboard;
using AssetWorks.UI.M5.TestAutomation.Actions.Dispoal;
using AssetWorks.UI.M5.TestAutomation.Actions.ShipmentTerm;
using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Actions.PayRoll;
using AssetWorks.UI.M5.TestAutomation.Actions.Maintenance;
using AssetWorks.UI.M5.TestAutomation.Actions.Zone;
using AssetWorks.UI.M5.TestAutomation.Actions.DAFCode;
using AssetWorks.UI.M5.TestAutomation.Actions.ShopPlanning;
using AssetWorks.UI.M5.TestAutomation.Actions.Disposal;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class HomePageActions : HomePage
    {
        public HomePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Change Location
        /// </summary>
        /// <param name="location"></param>
        public void ChangeLocation(string location)
        {
            Driver.WaitForVisibility(By.XPath(locatorHome), " Home page tab ");
            _enteredLocation.SelectDropdownUsingValue("Entered Location", location);
            Driver.WaitForReady();
            _homeTab.Click();
        }

        /// <summary>
        /// Verify Home Page Message
        /// </summary>
        /// <param name="expectedMsg"></param>
        public void VerifyHomePageMessage(string header, string expectedMsg)
        {
            Settings.Logger.Info("Verify Home Page Message");
            ExtendedPageActions _extendedPage = new ExtendedPageActions(Driver);
            _extendedPage.SwitchToContentFrame();
            Assert.True(_extendedPage._menuBarOptionsHeader.GetText("Page Header").Contains(header));
            CommonUtil.VerifyElementText(_mvMessageArea, "Message Area", expectedMsg);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Wait till Fram Menu is Visible
        /// </summary>
        public void WaitForFrameMenu()
        {
            Driver.WaitForVisibility(By.XPath("//select[@id='menuReduce']"), "Frame Menu",60);
        }

        /// <summary>
        /// Navigate WorkOrderMain Page
        /// </summary>
        /// <returns></returns>
        public WorkOrderMainPageActions NavigateWorkOrderMainPage()
        {
            Settings.Logger.Info("Navigating to Work Order Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Work Order Main Page", ScreensUrl.WorkOrderMain);
            return new WorkOrderMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Department Main Page
        /// </summary>
        /// <returns></returns>
        public DepartmentMainPageActions NavigateToDepartmentMainPage()
        {
            Settings.Logger.Info("Navigating to Department Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Department Main Page", ScreensUrl.DepartmentMain);
            return new DepartmentMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate Unit Main Page
        /// </summary>
        /// <returns></returns>
        public UnitMainPageActions NavigateUnitMainPage()
        {
            Settings.Logger.Info("Navigating to Unit Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Main Page", ScreensUrl.UnitMain);
            return new UnitMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate Component Main Page
        /// </summary>
        /// <returns></returns>
        public ComponentMainPageActions NavigateComponentMainPage()
        {
            Settings.Logger.Info("Navigating to Component Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Component Main Page", ScreensUrl.ComponentMain);
            return new ComponentMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Work Order Department Requisitions Page
        /// </summary>
        /// <returns></returns>
        public WODepartmentRequisitionsPageActions NavigateToWODepartmentRequisitionsMainPage()
        {
            Settings.Logger.Info("Navigating to Department Requisitions Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Department Requisitions Main Page", ScreensUrl.WorkOrderDepartmentRequisitions);
            return new WODepartmentRequisitionsPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Department Number Change Page
        /// </summary>
        /// <returns></returns>
        public DepartmentNumberChangePageActions NavigateToDepartmentNumberChangePage()
        {
            Settings.Logger.Info("Navigating to Department Number Change Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Department Number Change Page", ScreensUrl.DepartmentNumberChange);
            return new DepartmentNumberChangePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Work Request Main Page
        /// </summary>
        /// <returns></returns>
        public WorkRequestMainPageActions NavigateToWorkRequestMainPage()
        {
            Settings.Logger.Info("Navigating to work request page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("work request page", ScreensUrl.WorkRequestMain);
            return new WorkRequestMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Department Copy Page
        /// </summary>
        /// <returns>DepartmentCopyPageActions</returns>
        public DepartmentCopyPageActions NavigateToDepartmentCopyPage()
        {
            Settings.Logger.Info("Navigating to Department Copy Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Department Copy Page", ScreensUrl.DepartmentCopy);
            return new DepartmentCopyPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Unit Department Change Page
        /// </summary>
        /// <returns>UnitDepartmentChangePageActions</returns>
        public UnitDepartmentChangePageActions NavigateToUnitDepartmentChangePage()
        {
            Settings.Logger.Info("Navigating to Unit Department Change Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Department Change Page", ScreensUrl.UnitDepartmentChange);
            return new UnitDepartmentChangePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Department Groups Page
        /// </summary>
        /// <returns>DepartmentGroupsPageActions</returns>
        public DepartmentGroupsPageActions NavigateToDepartmentGroupsPage()
        {
            Settings.Logger.Info("Navigating to Department Groups Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Department Groups Page", ScreensUrl.DepartmentGroups);
            return new DepartmentGroupsPageActions(Driver);
        }

        /// <summary>
        /// Navigate to billing Code  Page
        /// </summary>
        /// <returns>BillingCodePageActions</returns>
        public BillingPageActions NavigateToBillingCodePage()
        {
            Settings.Logger.Info("Navigating to Billing Code page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Billing Code page", ScreensUrl.BillingCodes);
            return new BillingPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Asset Class Codes Page
        /// </summary>
        /// <returns>AssetClassCodesPageActions</returns>
        public AssetClassCodesPageActions NavigateToAssetClassCodesPage()
        {
            Settings.Logger.Info("Navigating to Asset Class Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Asset Class Codes Page", ScreensUrl.AssetClassCodes);
            return new AssetClassCodesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to System State/Country Codes Page
        /// </summary>
        /// <returns>SystemStateCountryCodesPageActions</returns>
        public SystemStateCountryCodesPageActions NavigateToSystemStateCountryCodesPage()
        {
            Settings.Logger.Info("Navigating to System State/Country Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("System State/Country Codes Page", ScreensUrl.SystemStateCountryCodes);
            return new SystemStateCountryCodesPageActions(Driver);
        }

        /// <summary>
        /// Navigate MCC Main Page 
        /// </summary>
        /// <returns></returns>
        public MCCMainPageActions NavigateToMCCMainPage()
        {
            Settings.Logger.Info("Navigating to MCC Main  page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("MCC Main page", ScreensUrl.MCCMain);
            return new MCCMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate Direct Account Codes Page 
        /// </summary>
        /// <returns>DirectAccountCodesPageActions</returns>
        public DirectAccountCodesPageActions NavigateToDirectAccountCodesPage()
        {
            Settings.Logger.Info("Navigating to Direct Account Codes page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Direct Account Codes page", ScreensUrl.DirectAccountCodes);
            return new DirectAccountCodesPageActions(Driver);
        }

        /// Navigate To Standard Job MCC Page
        /// </summary>
        /// <returns>StandardJobMCCActions</returns>
        public StandardJobMCCActions NavigateToStandardJobMCCPage()
        {
            Settings.Logger.Info("Navigating to Standard Job MCC page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Standard Job MCC page", ScreensUrl.StandardJobMCC);
            return new StandardJobMCCActions(Driver);
        }

        /// <summary>
        /// Navigate to System Codes Page
        /// </summary>
        /// <returns>SystemCodesPageActions</returns>
        public SystemCodesPageActions NavigateToSystemCodesPage()
        {
            Settings.Logger.Info("Navigating to System Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("System Codes Page", ScreensUrl.SystemCodes);
            return new SystemCodesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Part Main Catalog Page
        /// </summary>
        /// <returns>PartMainCatalogPageActions</returns>
        public Parts.PartMainCatalogPageActions NavigateToPartMainCatalogPage()
        {
            Settings.Logger.Info("Navigating to Part Main Catalog Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Main Catalog Page", ScreensUrl.PartMainCatalog);
            return new Parts.PartMainCatalogPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Employee Main Page
        /// </summary>
        /// <returns></returns>
        public EmployeeMainPageActions NavigateToEmployeeMainPage()
        {
            Settings.Logger.Info("Navigating to Employee Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Main Page", ScreensUrl.EmployeeMain);
            return new EmployeeMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Motor Pool Rental Class Page
        /// </summary>
        /// <returns>MotorPoolRentalClassPageActions</returns>
        public MotorPoolRentalClassPageActions NavigateToMotorPoolRentalClassPage()
        {
            Settings.Logger.Info("Navigating to Motor Pool Rental Class Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Motor Pool Rental Class Page", ScreensUrl.MotorPoolRentalClass);
            return new MotorPoolRentalClassPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Role Maintenance Page
        /// </summary>
        /// <returns>PartMainCatalogPageActions</returns>
        public RoleMaintenancePageActions NavigateToRoleMaintenancePage()
        {
            Settings.Logger.Info("Navigating to Role Maintenance Page Actions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Role Maintenance Page", ScreensUrl.RoleMaintenance);
            return new RoleMaintenancePageActions(Driver);
        }

        /// <summary>
        /// Navigate Vendor Main Page 
        /// </summary>
        /// <returns>VendorMainPageActions</returns>
        public VendorMainPageActions NavigateToVendorMainPage()
        {
            Settings.Logger.Info("Navigating to Vendor Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Vendor Main Page", ScreensUrl.VendorMain);
            return new VendorMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate Vendor Main Page 
        /// </summary>
        /// <returns>VendorMainPageActions</returns>
        public VendorMainPageActions NavigateToCopyVendorPage()
        {
            Settings.Logger.Info("Navigating to Copy Vendor Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Vendor Copy Page", ScreensUrl.VendorCopy);
            return new VendorMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate Vendor Number Change Page 
        /// </summary>
        /// <returns>VendorMainPageActions</returns>
        public VendorMainPageActions NavigateToVendorNumberChangePage()
        {
            Settings.Logger.Info("Navigating to Vendor Number Change Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Vendor Number Change Page", ScreensUrl.VendorNumberChange);
            return new VendorMainPageActions(Driver);
        }

        /// <summary>
        /// Naigate to Customer Main Page
        /// </summary>
        /// <returns></returns>
        public CustomerMainPageActions NavigateToCustomerMainPage()
        {
            Settings.Logger.Info("Navigating to Customer Main  page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Customer Main  page", ScreensUrl.CustomerMain);
            return new CustomerMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate Application User Maintenance Page 
        /// </summary>
        /// <returns></returns>
        public AppUserMaintenancePageActions NavigateToApplicationUserMaintenancePage()
        {
            Settings.Logger.Info("Navigating to Application User Maintenance Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Application User Maintenance Page", ScreensUrl.ApplicationUserMaintenance);
            return new AppUserMaintenancePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Unit Request Page
        /// </summary>
        /// <returns>UnitRequestPageActions</returns>
        public Units.UnitRequestPageActions NavigateToUnitRequestPage()
        {
            Settings.Logger.Info("Navigating to Unit Request Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Request Page", ScreensUrl.UnitRequest);
            return new Units.UnitRequestPageActions(Driver);
        }

        /// <summary>
        ///Navigate to Customer Type Codes     
        /// </summary>
        /// <returns></returns>
        public CustomerTypeCodesPageActions NavigateToCustomerTypeCodesPage()
        {
            Settings.Logger.Info("Navigating to Customer Type Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Customer Type Codes Page", ScreensUrl.CustomerTypeCodes);
            return new CustomerTypeCodesPageActions(Driver);
        }

        /// <summary>
        ///Navigate to Booking Type Codes     
        /// </summary>
        /// <returns></returns>
        public BookingTypeCodesPageActions NavigateToBookingTypeCodesPage()
        {
            Settings.Logger.Info("Navigating to Booking Type Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Booking Type Codes Page", ScreensUrl.BookingTypeCodes);
            return new BookingTypeCodesPageActions(Driver);
        }
        /// <summary>
        /// Navigate to Application user page
        /// </summary>
        /// <returns></returns>
        public AppUserCopyPageActions NavigateToApplicationUserCopyPage()
        {
            Settings.Logger.Info("Navigating to Application User Copy Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Application User Copy Page", ScreensUrl.ApplicationUserCopy);
            return new AppUserCopyPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Equipment Profile Type page
        /// </summary>
        /// <returns></returns>
        public EqipProfileTypesPageActions NavigateToEquipmentProfileTypePage()
        {
            Settings.Logger.Info("Navigating to Equipment Profile Type Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Equipment Profile Types", ScreensUrl.EquipmentProfileTypes);
            return new EqipProfileTypesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Tax Type page
        /// </summary>
        /// <returns></returns>
        public TaxTypePageActions NavigateToTaxTypePage()
        {
            Settings.Logger.Info("Navigating to Tax Type Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Tax Type", ScreensUrl.TaxType);
            return new TaxTypePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Application user page
        /// </summary>
        /// <returns>EquipmentTypesSKUPageActions</returns>
        public EquipmentTypesSKUPageActions NavigateToEquipmentTypesSKUPage()
        {
            Settings.Logger.Info("Navigating to Equipment Types SKU Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Equipment Types SKU", ScreensUrl.EquipmentTypesSKU);
            return new EquipmentTypesSKUPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Equipment Reassign Page
        /// </summary>
        /// <returns></returns>
        public EquipmentReassignPageActions NavigateToEquipmentReassignPage()
        {
            Settings.Logger.Info("Navigating to Equipment Reassign Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Equipment Reassign", ScreensUrl.EquipmentReassign);
            return new EquipmentReassignPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Tech Spec Main Page
        /// </summary>
        /// <returns></returns>
        public TechSpecMainPageActions NavigateToTechSpecMainPage()
        {
            Settings.Logger.Info("Navigating to Tech Spec Main Page ");
            _mainMain.SelectFilterValueHavingEqualValue(Screens.TechSpecMain);
            return new TechSpecMainPageActions(Driver);
        }

        /// <summary>
        /// Tech Spec Copy Page Actions
        /// </summary>
        /// <returns></returns>
        public TechSpecCopyPageActions NavigateToTechSpecCopyPage()
        {
            Settings.Logger.Info("Navigating to Tech Spec Copy Page ");
            _mainMain.SelectFilterValueHavingEqualValue(Screens.TechSpecCopy);
            return new TechSpecCopyPageActions(Driver);
        }

        /// <summary>
        /// Standard Job Tech Specs
        /// </summary>
        /// <returns></returns>
        public StandardJobTechSpecPageActions NavigateToStandardJobTechSpecPage()
        {
            Settings.Logger.Info("Navigating to Standard Job Tech Spec Page Actions ");
            _mainMain.SelectFilterValueHavingEqualValue(Screens.StandardJobTechSpec);
            return new StandardJobTechSpecPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Unit Request Copy Page
        /// </summary>
        /// <returns>UnitRequestCopyPageActions</returns>
        public Units.UnitRequestCopyPageActions NavigateToUnitRequestCopyPage()
        {
            Settings.Logger.Info("Navigating to Unit Request Copy Page");
            _mainMain.SelectFilterValueHavingEqualValue(Screens.UnitRequestCopy);
            return new Units.UnitRequestCopyPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Unit Group Page
        /// </summary>
        /// <returns>UnitGroupPageActions</returns>
        public Units.UnitGroupPageActions NavigateToUnitGroupPage()
        {
            Settings.Logger.Info("Navigating to Unit Group Page");
            _mainMain.SelectFilterValueHavingEqualValue(Screens.UnitGroup);
            return new Units.UnitGroupPageActions(Driver);
        }

        /// <summary>
        /// Component Items Page Actions
        /// </summary>
        /// <returns></returns>
        public ComponentItemsPageActions NavigateToComponentItemsPage()
        {
            Settings.Logger.Info("Navigating to Component Items");
            _mainMain.SelectFilterValueHavingEqualValue(Screens.ComponentItems);
            return new ComponentItemsPageActions(Driver);
        }

        /// <summary>
        /// Chat Group Maintenance Page Actions
        /// </summary>
        /// <returns></returns>
        public ChatGroupMaintenancePageActions NavigateToChatGroupMaintenancePage()
        {
            Settings.Logger.Info("Navigating to Chat Group Maintenance Page");
            _mainMain.SelectFilterValueHavingEqualValue(Screens.ChatGroupMaintenance);
            return new ChatGroupMaintenancePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Equipment Conditions page
        /// </summary>
        /// <returns>EquipmentConditionsPageActions</returns>
        public EquipmentConditionsPageActions NavigateToEquipmentConditionsPage()
        {
            Settings.Logger.Info("Navigating to Equipment Conditions Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Equipment Conditions", ScreensUrl.EquipmentConditions);
            return new EquipmentConditionsPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Part Main Catalog Page
        /// </summary>
        /// <returns>PartMainCatalogPageActions</returns>
        public PartBinPageActions NavigateToPartBinPage()
        {
            Settings.Logger.Info("Navigating to Part Bin Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Bin Page", ScreensUrl.PartBinPage);
            return new PartBinPageActions(Driver);
        }

        /// Navigate to Unit Purchase Orders page
        /// </summary>
        /// <returns>UnitPurchaseOrdersPageActions</returns>
        public UnitPurchaseOrdersPageActions NavigateToUnitPurchaseOrdersPage()
        {
            Settings.Logger.Info("Navigating to Unit Purchase Orders Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Purchase Orders", ScreensUrl.UnitPurchaseOrders);
            return new UnitPurchaseOrdersPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Unit Copy page
        /// </summary>
        /// <returns>UnitCopyPageActions</returns>
        public UnitCopyPageActions NavigateToUnitCopyPage()
        {
            Settings.Logger.Info("Navigating to Unit Copy Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Copy", ScreensUrl.UnitCopy);
            return new UnitCopyPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Position Code Page
        /// </summary>
        /// <returns></returns>
        public PositionCodesPageActions NavigateToPositionCodePage()
        {
            Settings.Logger.Info("Navigating to Position Code Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Position Code", ScreensUrl.PositionCode);
            return new PositionCodesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to System Position Page"
        /// </summary>
        public SystemPositionPageActions NavigateToSystemPositionPage()
        {
            Settings.Logger.Info("Navigating to System Position Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Position Code", ScreensUrl.SystemPosition);
            return new SystemPositionPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Employee Title page
        /// </summary>
        /// <returns>UnitCopyPageActions</returns>
        public EmployeeTitlePageActions NavigateToEmployeeTitlePage()
        {
            Settings.Logger.Info("Navigating to EmployeeTitle Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Title", ScreensUrl.EmployeeTitle);
            return new EmployeeTitlePageActions(Driver);
        }

        /// Navigate to System Flag Page
        /// </summary>
        /// <returns>UnitCopyPageActions</returns>
        public SystemFlagsPageActions NavigateToSystemFlagPage()
        {
            Settings.Logger.Info("Navigating to System Flag Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("System Flag", ScreensUrl.SystemFlag);
            return new SystemFlagsPageActions(Driver);
        }

        /// Navigate to Non Company Unit Main page
        /// </summary>
        /// <returns>NonCompanyUnitMainPageActions</returns>
        public NonCompanyUnitMainPageActions NavigateToNonCompanyUnitMainPage()
        {
            Settings.Logger.Info("Navigating to Non Company Unit Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Non Company Unit Main", ScreensUrl.NonCompanyUnitMain);
            return new NonCompanyUnitMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Unit Purchase Requisitions Page
        /// </summary>
        /// <returns>UnitPurchaseRequisitionsPageActions</returns>
        public Units.UnitPurchaseRequisitionsPageActions NavigateToUnitPurchaseRequisitionsPage()
        {
            Settings.Logger.Info("Navigating to Unit Purchase Requisitions Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Purchase Requisitions", ScreensUrl.UnitPurchaseRequisitions);
            return new Units.UnitPurchaseRequisitionsPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Role Copy Page
        /// </summary>
        /// <returns></returns>
        public RoleCopyPageActions NavigateToRoleCopyPage()
        {
            Settings.Logger.Info("Navigating to Role Copy Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("RoleCopy", ScreensUrl.RoleCopy);
            return new RoleCopyPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Tax Scheme page
        /// </summary>
        /// <returns></returns>
        public TaxSchemePageActions NavigateToTaxSchemePage()
        {
            Settings.Logger.Info("Navigating to Tax Scheme Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Tax Scheme", ScreensUrl.TaxScheme);
            return new TaxSchemePageActions(Driver);
        }

        /// <summary>
        /// Billing Fixed Charge Page Actions
        /// </summary>
        /// <returns></returns>
        public BillingFixedChargePageActions NavigateToBillingFixedCharges()
        {
            Settings.Logger.Info("Navigating to Billing Fixed Charges");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("BillingFixedCharges", ScreensUrl.BillingFixedCharges);
            return new BillingFixedChargePageActions(Driver);
        }

        /// <summary>
        /// Navigate To Employee Group Page
        /// </summary>
        /// <returns>EmployeeGroupPageActions</returns>
        public EmployeeGroupPageActions NavigateToEmployeeGroupPage()
        {
            Settings.Logger.Info("Navigating to Employee Group Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Group", ScreensUrl.EmployeeGroup);
            return new EmployeeGroupPageActions(Driver);
        }

        /// <summary>
        ///Employee Transfers Page Actions
        /// </summary>
        /// <returns></returns>
        public EmployeeTransfersPageActions NavigateToEmployeeTransfersPage()
        {
            Settings.Logger.Info("Navigating to Employee Transfers Page Actions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("EmployeeTransfersPage", ScreensUrl.EmployeeTransfer);
            return new EmployeeTransfersPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Employee Shift Assignment
        /// </summary>
        /// <returns></returns>
        public EmployeeShiftAssignPageActions NavigateToEmployeeShiftAssignmentPage()
        {
            Settings.Logger.Info("Navigating to Employee Shift Assignment Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Shift Assignment", ScreensUrl.EmployeeShiftAssignment);
            return new EmployeeShiftAssignPageActions(Driver);
        }


        /// Navigate To Customer Contract Page
        /// </summary>
        /// <returns></returns>
        public CustomerContractPageActions NavigateToCustomerContractPage()
        {
            Settings.Logger.Info("Navigating to Customer Contract Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("EmployeeTransfersPage", ScreensUrl.CustomerContract);
            return new CustomerContractPageActions(Driver);
        }

        /// Navigate To Customer Contract Copy Page
        /// </summary>
        /// <returns></returns>
        public CustomerContractCopyPageActions NavigateToCustomerContractCopyPage()
        {
            Settings.Logger.Info("Navigating to Customer Contract Copy Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("EmployeeTransfersPage", ScreensUrl.CustomerContractCopy);
            return new CustomerContractCopyPageActions(Driver);
        }

        /// <summary>
        ///Employee Copy Page Actions
        /// </summary>
        /// <returns></returns>
        public EmployeeMainPageActions NavigateToEmployeeCopyPage()
        {
            Settings.Logger.Info("Navigating to Employee Copy Page Actions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("EmployeeCopyPage", ScreensUrl.EmployeeCopy);
            return new EmployeeMainPageActions(Driver);
        }

        /// Purchase Requisitions Page Actions
        /// </summary>
        /// <returns></returns>
        public PurchaseRequisitionsPageActions NavigateToPurchaseRequisitions()
        {
            Settings.Logger.Info("Navigating to Purchase Requisitions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("EmployeeTransfersPage", ScreensUrl.PurchaseRequisitions);
            return new PurchaseRequisitionsPageActions(Driver);
        }
        /// <summary>
        /// Navigate to Purchase Order
        /// </summary>
        /// <returns></returns>
        public PurchaseOrderPageActions NavigateToPurchaseOrder()
        {
            Settings.Logger.Info("Navigating to Purchase Order");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Purchase Order", ScreensUrl.PurchaseOrder);
            return new PurchaseOrderPageActions(Driver);
        }

        /// <summary>
        /// Equipment Profile Maintenance Page Actions
        /// </summary>
        /// <returns></returns>
        public EquipmentProfileMaintenancePageActions NavigateToPurcEquipmentProfile()
        {
            Settings.Logger.Info("Navigating to Equipment Profile Maintenance");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Equipment Profile Maintenancee", ScreensUrl.EquipmentProfile);
            return new EquipmentProfileMaintenancePageActions(Driver);
        }

        /// <summary>
        /// Navigate To Item Master Definition Page
        /// </summary>
        /// <returns>ItemMasterDefinitionPageActions</returns>
        public ItemMasterDefinitionPageActions NavigateToItemMasterDefinitionPage()
        {
            Settings.Logger.Info("Navigating to Item Master Definition Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Item Master DefinitionPage", ScreensUrl.ItemMasterDefinition);
            return new ItemMasterDefinitionPageActions(Driver);
        }

        /// <summary>
        /// MCC Copy Page Actions
        /// </summary>
        /// <returns></returns>
        public MCCCopyPageActions NavigateToMCCCopy()
        {
            Settings.Logger.Info("Navigating to MCC Copy");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("MCC Copye", ScreensUrl.MCCCopy);
            return new MCCCopyPageActions(Driver);
        }

        /// <summary>
        /// Navigate To MarkUp Scheme Page
        /// </summary>
        /// <returns></returns>
        public MarkUpSchemePageActions NavigateToMarkUpScheme()
        {
            Settings.Logger.Info("Navigate To MarkUp Scheme Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" MarkUp Scheme Page", ScreensUrl.MarkUpScheme);
            return new MarkUpSchemePageActions(Driver);
        }

        /// <summary>
        /// Navigate To Markup Types Page
        /// </summary>
        /// <returns></returns>
        public MarkupTypesPageActions NavigateToMarkupTypesPage()
        {
            Settings.Logger.Info("Navigate To Markup Types Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" Markup Types", ScreensUrl.MarkupTypes);
            return new MarkupTypesPageActions(Driver);
        }


        /// <summary>
        /// Navigate To Copy MarkUp Scheme Page
        /// </summary>
        /// <returns></returns>
        public MarkUpSchemePageActions NavigateToCopyMarkUpScheme()
        {
            Settings.Logger.Info("Navigate To Copy MarkUp Scheme Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" Copy MarkUp Scheme Page", ScreensUrl.CopyMarkUpScheme);
            return new MarkUpSchemePageActions(Driver);
        }

        /// MCC Unit Display Page Actions
        /// </summary>
        /// <returns></returns>
        public MCCUnitDisplayPageActions NavigateToMCCUnitDisplay()
        {
            Settings.Logger.Info("Navigating to MCC Unit Display");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("MCC Unit Display", ScreensUrl.MCCUnitDisplay);
            return new MCCUnitDisplayPageActions(Driver);
        }

        /// <summary>
        /// MCC Query Page Actions
        /// </summary>
        /// <returns></returns>
        public MCCQueryPageActions NavigateToMCCQuery()
        {
            Settings.Logger.Info("Navigating to MCC Query");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("MCC MCC Query", ScreensUrl.MCCQuery);
            return new MCCQueryPageActions(Driver);

        }

        /// <summary>
        /// Employee number change actions
        /// </summary>
        /// <returns></returns>
        public EmployeeNumberChangeActions NavigateToEmployeeNumberChange()
        {
            Settings.Logger.Info("Navigating to Employee number change Page Actions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Number Change", ScreensUrl.EmployeeNumberChange);
            return new EmployeeNumberChangeActions(Driver);
        }

        /// Navigate To Accident Type Page
        /// </summary>
        /// <returns></returns>
        public AccidentsTypePageActions NavigateToAccidentTypePage()
        {
            Settings.Logger.Info("Navigating to Accident Type Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Accident Type", ScreensUrl.AccidentType);
            return new AccidentsTypePageActions(Driver);
        }

        /// Navigate To Accident Category Page
        /// </summary>
        /// <returns></returns>
        public AccidentCategoryPageActions NavigateToAccidentCategoryPage()
        {
            Settings.Logger.Info("Navigating to Accident Category Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Accident Type", ScreensUrl.AccidentCategory);
            return new AccidentCategoryPageActions(Driver);
        }

        /// Navigate To Fuel Product main
        /// </summary>
        /// <returns></returns>
        public FuelProductPageActions NavigateToFuelProductsMain()
        {
            Settings.Logger.Info("Navigating to Fuel Product ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Fuels Product", ScreensUrl.FuelProducts);
            return new FuelProductPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Product Setup Tanks
        /// </summary>
        /// <returns></returns>
        public ProductSetupTanksPageActions NavigateToProductSetupTanksPage()
        {
            Settings.Logger.Info("Navigating to Product Setup Tanks Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Product Setup Tanks", ScreensUrl.ProductSetupTanks);
            return new ProductSetupTanksPageActions(Driver);
        }

        /// <summary>
        /// Navigating to System Active User Display
        /// </summary>
        /// <returns></returns>
        public SystemActiveUserDisplayAction NavigateToSystemActiveUserDsiplay()
        {
            Settings.Logger.Info("Navigating to System Active User Display");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("System Active User Display", ScreensUrl.ActiveUserDisplay);
            return new SystemActiveUserDisplayAction(Driver);
        }
        /// Navigate To Accident Entry Page
        /// </summary>
        /// <returns></returns>
        public AccidentEntryPageActions NavigateToAccidentEntryPage()
        {
            Settings.Logger.Info("Navigating to Accident Entry Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Accident Entry", ScreensUrl.AccidentEntry);
            return new AccidentEntryPageActions(Driver);
        }


        /// <summary>
        /// Navigate To Vendor Contract Page
        /// </summary>
        /// <returns></returns>
        public VendorContractPageActions NavigateToVendorContractPage()
        {
            Settings.Logger.Info("Navigating to Vendor Contract Page Actions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Vendor Contract ", ScreensUrl.VendorContract);
            return new VendorContractPageActions(Driver);
        }

        /// <summary>
        /// Component Copy Actions
        /// </summary>
        /// <returns></returns>
        public ComponentCopyActions NavigateToComponentCopy()
        {
            Settings.Logger.Info("Navigating to Component Copy Page Actions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Component Copy", ScreensUrl.ComponentCopy);
            return new ComponentCopyActions(Driver);
        }

        /// <summary>
        /// Navigate To Component Number Change
        /// </summary>
        /// <returns></returns>
        public ComponentNumberChangePageActions NavigateToComponentNumberChange()
        {
            Settings.Logger.Info("Navigating to Component Number Change Page Actions");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Component Number Change", ScreensUrl.ComponentNumberChange);
            return new ComponentNumberChangePageActions(Driver);
        }

        /// <summary>
        /// Navigate To Billing Adjustment
        /// </summary>
        /// <returns></returns>
        public BillingAdjustmentPageActions NavigateToBillingAdjustment()
        {
            Settings.Logger.Info("Navigating to Billing Adjustment");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Billing Adjustment", ScreensUrl.BillingAdjustment);
            return new BillingAdjustmentPageActions(Driver);
        }

        /// <summary>
        ///Navigate to Booking Decline/Cancel Codes     
        /// </summary>
        /// <returns></returns>
        public BookingDeclineCancelCodesPageActions NavigateToBookingDeclineCancelCodesPage()
        {
            Settings.Logger.Info("Navigating to Booking Decline Cancel Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Booking Decline Cancel Codes Page", ScreensUrl.BookingDeclineCancelCodes);
            return new BookingDeclineCancelCodesPageActions(Driver);
        }
        /// <summary>
        /// Navigating to Unit Request Approve Page
        /// </summary>
        /// <returns></returns>
        public UnitRequestApprovePageActions NavigateUnitRequestApprovePage()
        {
            Settings.Logger.Info("Navigating to Unit Request Approve Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Request Approve", ScreensUrl.UnitRequestApprove);
            return new UnitRequestApprovePageActions(Driver);
        }
        /// <summary>
        /// Naigate to Booking Source Code Page
        /// </summary>
        /// <returns></returns>
        public BookingSourceCodePageActions NavigateToBookingSourceCodesPage()
        {
            Settings.Logger.Info("Navigate to Booking Source Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Booking Source Codes", ScreensUrl.BookingSourceCodes);
            return new BookingSourceCodePageActions(Driver);
        }

        ///Navigate to Booking Appointment   
        /// </summary>
        /// <returns></returns>
        public BookingAppointmentPageActions NavigateToBookingAppointmentPage()
        {
            Settings.Logger.Info("Navigating to Booking Appointment Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Booking Appointment Page", ScreensUrl.BookingAppointment);
            return new BookingAppointmentPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Employee Main Page
        /// </summary>
        /// <returns></returns>
        public EmployeeTrainingTransciptPageActions NavigateToEmpTrainingTransciptPage()
        {
            Settings.Logger.Info("Navigating to Employee Training Transcipt Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Training Transcipt Page", ScreensUrl.EmployeeTrainingTranscipt);
            return new EmployeeTrainingTransciptPageActions(Driver);
        }

        /// Navigating to Employee Training Course SetUp Page
        /// </summary>
        /// <returns></returns>
        public EmpCoureSetUpPageActions NavigateToEmpCourseSetUpPage()
        {
            Settings.Logger.Info("Navigating to Employee Training Course SetUp Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Training Course SetUp Page", ScreensUrl.EmpTrainingCourseSetUp);
            return new EmpCoureSetUpPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Billing Unit Accounts Page
        /// </summary>
        /// <returns></returns>
        public BillingUnitAccountsPageActions NavigateToBillingUnitAccountsPage()
        {
            Settings.Logger.Info("NavigateToBillingUnitAccountsPage");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("NavigateToBillingUnitAccountsPage", ScreensUrl.BillingUnitAccounts);
            return new BillingUnitAccountsPageActions(Driver);
        }
        /// Booking Change Dates Reasons Page
        /// </summary>
        /// <returns></returns>
        public BookingChangeDatesReasonsPageActions NavigateToBookingChangeDateReasonsPage()
        {
            Settings.Logger.Info("Navigate to Booking ChangeDate Reasons Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Navigate to Booking ChangeDate Reasons Page", ScreensUrl.BookingChangeDateReason);
            return new BookingChangeDatesReasonsPageActions(Driver);
        }

        /// Navigate to Employee Course Query Page
        /// </summary>
        /// <returns></returns>
        public EmployeeCourseQueryPageActions NavigateToEmpCourseQueryPage()
        {
            Settings.Logger.Info("Navigating to Employee Course Query Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Course Query Page", ScreensUrl.EmpCourseQuery);
            return new EmployeeCourseQueryPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Resource Type Page
        /// </summary>
        /// <returns></returns>
        public ResourceTypePageActions NavigateToResourceTypePage()
        {
            Settings.Logger.Info("Navigating to Resource Type Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Resource Type", ScreensUrl.ResourceType);
            return new ResourceTypePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Parts Inventory Location Manager
        /// </summary>
        public PartInventoryLocationPageActions NavigateToPartInventoryLocationManager()
        {
            Settings.Logger.Info("Navigating to Parts Inventory Location Manager");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Parts Inventory Location Manager setup page", ScreensUrl.PartInventoryLocManager);
            return new PartInventoryLocationPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Part Adjustment
        /// </summary>
        /// <returns></returns>
        public PartsAdjustmentPageActions NavigateToPartAdjustment()
        {
            Settings.Logger.Info("Navigating to Parts Adjustment");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Parts Adjustment Page", ScreensUrl.PartInventoryAdjustment);
            return new PartsAdjustmentPageActions(Driver);
        }

        /// <summary>
        /// Employee Items Page Actions
        /// </summary>
        /// <returns></returns>
        public EmployeeItemsPageActions NavigateToEmployeeItems()
        {
            Settings.Logger.Info("Navigating to Employee Items");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Items", ScreensUrl.EmployeeItems);
            return new EmployeeItemsPageActions(Driver);
        }

        /// Navigate To Accident Cause Page
        /// </summary>
        /// <returns></returns>
        public AccidentCausePageActions NavigateToAccidentCausePage()
        {
            Settings.Logger.Info("Navigating to Accident Cause Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Accident Cause", ScreensUrl.AccidentCause);
            return new AccidentCausePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Work Request Campaign Page
        /// </summary>
        /// <returns></returns>
        public WorkRequestCampaignPageActions NavigateToWorkRequestCampaignPage()
        {
            Settings.Logger.Info("Navigating to Work Request Campaign Manager page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Work Request Campaign Manager page", ScreensUrl.WorkRequestCampaignManager);
            return new WorkRequestCampaignPageActions(Driver);
        }

        /// <summary>
        /// Navigating to Location Main Page
        /// </summary>
        /// <returns></returns>
        public LocationMainPageActions NavigateToLocationMain()
        {
            Settings.Logger.Info("Navigating to Location Main");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Location Main Page", ScreensUrl.LocationMain);
            return new LocationMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate Warranty TechSpec
        /// </summary>
        /// <returns></returns>
        public TechSpecWarrantyPageActions NavigateWarrantyTechSpec()
        {
            Settings.Logger.Info("Navigating to WarrantyTechSpec Approve Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("TechSpecWarrantyPageActions", ScreensUrl.WarrantyTechSpec);
            return new TechSpecWarrantyPageActions(Driver);
        }

        /// <summary>
        /// Company Definition Page Actions
        /// </summary>
        /// <returns></returns>
        public CompanyDefinitionPageActions NavigateCompanyDefinition()
        {
            Settings.Logger.Info("Navigating to Company Definition");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("CompanyDefinition", ScreensUrl.CompanyDefinition);
            return new CompanyDefinitionPageActions(Driver);
        }

        /// <summary>
        /// BillingCodeCopyPageActions
        /// </summary>
        /// <returns></returns>
        public BillingCodeCopyPageActions NavigateBillingCodeCopy()
        {
            Settings.Logger.Info("Navigating to Billing Code Copy");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Billing Code Copy", ScreensUrl.BillingCodeCopy);
            return new BillingCodeCopyPageActions(Driver);
        }

        /// <summary>
        /// Billing Items Page Actions
        /// </summary>
        /// <returns></returns>
        public BillingItemsPageActions NavigateBillingItems()
        {
            Settings.Logger.Info("Navigating to Billing Items");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Billing Items", ScreensUrl.BillingItems);
            return new BillingItemsPageActions(Driver);
        }

        /// <summary>
        /// Billing Items Page Actions
        /// </summary>
        /// <returns></returns>
        public BillingItemSourcePageActions NavigateBillingItemSources()
        {
            Settings.Logger.Info("Navigating to Billing Item Source");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Billing Item Source", ScreensUrl.BillingItemSource);
            return new BillingItemSourcePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Employee Planned Absences Page
        /// </summary>
        /// <returns>EmployeePlannedAbsencesPageActions</returns>
        public EmployeePlannedAbsencesPageActions NavigateToEmployeePlannedAbsences()
        {
            Settings.Logger.Info("Navigating to Employee Planned Absences");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Planned Absences", ScreensUrl.EmployeePlannedAbsences);
            return new EmployeePlannedAbsencesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Labor Wedge Page
        /// </summary>
        /// <returns>LaborWedgePageActions</returns>
        public LaborWedgePageActions NavigateToLaborWedgePage()
        {
            Settings.Logger.Info("Navigating to Labor Wedge Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Labor Wedge", ScreensUrl.LaborWedge);
            return new LaborWedgePageActions(Driver);
        }

        /// <summary>
        /// Navigate To Equipment Request Page
        /// </summary>
        /// <returns></returns>
        public EquipmentRequestPageActions NavigateEquipmentRequest()
        {
            Settings.Logger.Info("Navigating to Equipment Request");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("EquipmentRequest", ScreensUrl.EquipmentRequest);
            return new EquipmentRequestPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Menu Maintenance Page
        /// </summary>
        /// <returns>MenuMaintenancePageActions</returns>
        public MenuMaintenancePageActions NavigateToMenuMaintenancePage()
        {
            Settings.Logger.Info("Navigating to Menu Maintenance Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Menu Maintenance Page", ScreensUrl.MenuMaintenance);
            return new MenuMaintenancePageActions(Driver);
        }

        /// <summary>
        /// Billing Indirect Items Page Actions
        /// </summary>
        /// <returns></returns>
        public BillingIndirectItemsPageActions NavigateBillingIndirectItems()
        {
            Settings.Logger.Info("Navigating to Billing Indirect Items");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Billing Indirect Items", ScreensUrl.BillingIndirectItems);
            return new BillingIndirectItemsPageActions(Driver);
        }

        /// <summary>
        /// Navigating to Motor Pool Manager Page
        /// </summary>
        /// <returns>MotorPoolManagerPageActions</returns>
        public MotorPoolManagerPageActions NavigateToMotorPoolManager()
        {
            Settings.Logger.Info("Navigating to Motor Pool Manager");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Motor Pool Manager", ScreensUrl.MotorPoolManager);
            return new MotorPoolManagerPageActions(Driver);
        }

        /// <summary>
        /// Driver Status Code Page Actions
        /// </summary>
        /// <returns></returns>
        public DriverStatusCodePageActions NavigateToDriverStatusCodeScreen()
        {
            Settings.Logger.Info("Navigate To Driver Status Code Screen");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Status Codes", ScreensUrl.DriverStatusCodes);
            return new DriverStatusCodePageActions(Driver);
        }

        /// <summary>
        /// Driver Allocation Reasons Page Actions
        /// </summary>
        /// <returns></returns>
        public DriverAllocationReasonsPageActions NavigateToDriverAllocationReasonsScreen()
        {
            Settings.Logger.Info("Navigate To Driver Allocation Reasons Screen");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Allocation Reasons", ScreensUrl.DriverAllocationReasons);
            return new DriverAllocationReasonsPageActions(Driver);
        }

        /// <summary>
        /// Driver Types Page Actions
        /// </summary>
        /// <returns></returns>
        public DriverTypesPageActions NavigateToDriverTypesScreen()
        {
            Settings.Logger.Info("Navigate To Driver Allocation Reasons Screen");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Types", ScreensUrl.DriverTypes);
            return new DriverTypesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Work Request Incident Page
        /// </summary>
        /// <returns></returns>
        public WorkRequestIncidentPageActions NavigateToWorkRequestIncidentPage()
        {
            Settings.Logger.Info("Navigating to Work Request Incident page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Work Request Incident page", ScreensUrl.WorkRequestIncident);
            return new WorkRequestIncidentPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Service Order Page
        /// </summary>
        /// <returns></returns>
        public ServiceOrderPageActions NavigateToServiceOrderPage()
        {
            Settings.Logger.Info("Navigating to Service Order page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Service Order page", ScreensUrl.ServiceOrder);
            return new ServiceOrderPageActions(Driver);
        }

        /// <summary>
        /// Billing Department Account
        /// </summary>
        /// <returns></returns>
        public BillingDepartmentAccountsPageActions NavigateBillingDepartmentAccount()
        {
            Settings.Logger.Info("NavigateBillingDepartmentAccount");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Billing Department Accounts", ScreensUrl.BillingDepartmentAccounts);
            return new BillingDepartmentAccountsPageActions(Driver);
        }

        /// <summary>
        /// Navigate Bill Single Department Account
        /// </summary>
        /// <returns></returns>
        public BillSingleDepartmentAccountPageActions NavigateBillSingleDepartmentAccount()
        {
            Settings.Logger.Info("Navigating to Bill Single Department Account");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("BillSingleDepartmentAccount", ScreensUrl.BillSingleDepartmentAccount);
            return new BillSingleDepartmentAccountPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Booking Billing Single Unit Account Page
        /// </summary>
        /// <returns></returns>
        public BillingSingleUnitAccountPageActions NavigateToBookingBillingSingleUnitAccountPage()
        {
            Settings.Logger.Info("Navigating to  Bill Single Unit Account Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Bill Single Unit Account Page", ScreensUrl.BillSingleUnitAccount);
            return new BillingSingleUnitAccountPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Part Class Codes
        /// </summary>
        /// <returns>PartClassCodesPageActions</returns>
        public PartClassCodesPageActions NavigateToPartClassCodesPage()
        {
            Settings.Logger.Info("Navigating to Part Class Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Class Codes Page", ScreensUrl.PartClassCodes);
            return new PartClassCodesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Motor Pool Assign Unit
        /// </summary>
        /// <returns>MotorPoolAssignUnitPageActions</returns>
        public MotorPoolAssignUnitPageActions NavigateToMotorPoolAssignUnitPage()
        {
            Settings.Logger.Info("Navigating to Motor Pool Assign Unit Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Motor Pool Assign Unit Page", ScreensUrl.MotorPoolAssignUnit);
            return new MotorPoolAssignUnitPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Indirect Account Codes Page
        /// </summary>
        /// <returns>IndirectAccountCodesPageActions</returns>
        public IndirectAccountCodesPageActions NavigateToIndirectAccountCodesPage()
        {
            Settings.Logger.Info("Navigating to Indirect Account Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Indirect Account Codes Page", ScreensUrl.IndirectAccountCodes);
            return new IndirectAccountCodesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Equipment Return Reason Page
        /// </summary>
        /// <returns></returns>
        public EqipRetReasonsPageActions NavigateToEquipmentReturnReasonPage()
        {
            Settings.Logger.Info("Navigating to Equipment Return Reason Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Equipment Return Reason Page", ScreensUrl.EquipRetReasons);
            return new EqipRetReasonsPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Motor Pool Reservation Page
        /// </summary>
        /// <returns></returns>
        public MotorPoolReservationPageActions NavigateToMotorPoolReservationPage()
        {
            Settings.Logger.Info("Navigating to Motor Pool Reservation Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Motor Pool Reservation", ScreensUrl.MotorPoolReservation);
            return new MotorPoolReservationPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Motor Pool Reservation Assignment Page
        /// </summary>
        /// <returns></returns>
        public MotorPoolReservationAssignmentPageActions NavigateToMotorPoolReservationAssignmentPage()
        {
            Settings.Logger.Info("Navigating to Motor Pool Reservation Assignment Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Motor Pool Reservation Assignment", ScreensUrl.MotorPoolReservationAssignment);
            return new MotorPoolReservationAssignmentPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Driver Event Class
        /// </summary>
        /// <returns></returns>
        public DriverEventClassesPageActions NavigateToDriverEventClasses()
        {
            Settings.Logger.Info("Navigating to Driver Event Class Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Event Classses", ScreensUrl.DriverEventClasses);
            return new DriverEventClassesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Driver Event Types
        /// </summary>
        /// <returns>DriverEventTypesPageActions</returns>
        public DriverEventTypesPageActions NavigateToDriverEventTypes()
        {
            Settings.Logger.Info("Navigating to Driver Event Types Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Event Types", ScreensUrl.DriverEventTypes);
            return new DriverEventTypesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Equipment Return Reason Page
        /// </summary>
        /// <returns>DriverEventTypesPageActions</returns>
        public DriverEventItemPageActions NavigateToDriverEventItem()
        {
            Settings.Logger.Info("Navigating to Driver Event Item Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Event Item", ScreensUrl.DriverEventItem);
            return new DriverEventItemPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Driver Licence Classes
        /// </summary>
        /// <returns></returns>
        public DriverLicenceClassesPageActions NavigateToDriverLicenseClasses()
        {
            Settings.Logger.Info("Navigating to Driver License Classes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver License Classses", ScreensUrl.DriverLicenseClasses);
            return new DriverLicenceClassesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Product Orders
        /// </summary>
        /// <returns>ProductOrderActions</returns>
        public ProductOrderActions NavigateToProductOrderPage()
        {
            Settings.Logger.Info("Navigating to Product Order Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Product Order Page", ScreensUrl.ProductOrder);
            return new ProductOrderActions(Driver);
        }

        /// <summary>
        /// Navigate to Product Location Receive Page
        /// </summary>
        /// <returns>ProductLocationReceiveActions</returns>
        public ProductLocationReceiveActions NavigateToProductReceivePage()
        {
            Settings.Logger.Info("Navigating to Product Receive Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Product Receive Page", ScreensUrl.ProductReceive);
            return new ProductLocationReceiveActions(Driver);
        }

        /// <summary>
        /// Navigate To Equipment CheckOut Page
        /// </summary>
        /// <returns></returns>
        public EquipCheckOutPageActions NavigateToEquipmentCheckOutPage()
        {
            Settings.Logger.Info("Navigating to Equipment CheckOut Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Equipment CheckOut Page", ScreensUrl.EquipMentCheckOut);
            return new EquipCheckOutPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Equipment CheckIN Page
        /// </summary>
        /// <returns></returns>
        public EquipCheckINPageActions NavigateToEquipmentCheckINPage()
        {
            Settings.Logger.Info("Navigating to Equipment CheckIN Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Equipment CheckIN Page", ScreensUrl.EquipMentCheckIN);
            return new EquipCheckINPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Equipment Check Query Page
        /// </summary>
        /// <returns></returns>
        public EquipCheckQueryActions NavigateToEquipmentCheckQueryPage()
        {
            Settings.Logger.Info("Navigating to Equipment Check QueryPage");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Equipment Check Query Page", ScreensUrl.EquipMentCheckQuery);
            return new EquipCheckQueryActions(Driver);
        }
        
        /// Navigate to Driver Main Screen
        /// </summary>
        /// <returns></returns>
        public DriverMainPageActions NavigateToDriverMainScreen()
        {
            Settings.Logger.Info("Navigating to Driver Main Screen");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Main", ScreensUrl.DriverMain);
            return new DriverMainPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Service Order Query Page
        /// </summary>
        /// <returns>ServiceOrderQueryPageActions</returns>
        public ServiceOrderQueryPageActions NavigateToServiceOrderQueryPage()
        {
            Settings.Logger.Info("Navigating to Service Order Query Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Service Order Query Page", ScreensUrl.ServiceOrderQuery);
            return new ServiceOrderQueryPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Service Order Receipt Page
        /// </summary>
        /// <returns>ServiceOrderReceiptPageActions</returns>
        public ServiceOrderReceiptPageActions NavigateToServiceOrderReceiptPage()
        {
            Settings.Logger.Info("Navigating to Service Order Receipt Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Service Order Receipt Page", ScreensUrl.ServiceOrderReceipt);
            return new ServiceOrderReceiptPageActions(Driver);
        }

        /// Navigate To Product SetUp Locatio
        /// </summary>
        /// <returns></returns>
        public ProductSetUpLocationPageActions NavigateToProductSetupLocationPage()
        {
            Settings.Logger.Info("Navigating to Product Setup Location Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Product Setup Location", ScreensUrl.ProductSetupLocation);
            return new ProductSetUpLocationPageActions(Driver);
        }

        /// Navigate To Product Setup Employees
        /// </summary>
        /// <returns></returns>
        public ProductSetupEmployee NavigateToProductSetUpEmployee()
        {
            Settings.Logger.Info("Navigating to Product Setup Employee Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Product Setup Employees", ScreensUrl.ProductSetUpEmployees);
            return new ProductSetupEmployee(Driver);
        }

        /// <summary>
        /// Navigate to Unit Of Measure Page
        /// </summary>
        /// <returns>UnitOfMeasureActions</returns>
        public UnitOfMeasureActions NavigateToUnitOfMeasurePage()
        {
            Settings.Logger.Info("Navigating to Unit Of Measure Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Of Measure Page", ScreensUrl.UnitOfMeasure);
            return new UnitOfMeasureActions(Driver);
        }
        /// <summary>
        /// Navigate to Product SetUp Tank Hose Page
        /// </summary>
        /// <returns>ProductSetupTanksHosePageActions</returns>
        public ProductSetupTanksHosePageActions NavigateToProductSetupTanksHosePage()
        {
            Settings.Logger.Info("Navigating to Product Setup Tanks Hose Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Product Setup Tanks Hose", ScreensUrl.ProductSetupTanksHose);
            return new ProductSetupTanksHosePageActions(Driver);
        }

        /// <summary>
        /// Navigate To Product Setup Department
        /// </summary>
        /// <returns></returns>
        public ProductSetupDepartmentActions NavigateToProductSetupDepartmentPage()
        {
            Settings.Logger.Info("Navigating to Product Setup Department Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Product Setup Department", ScreensUrl.ProductSetupDepartment);
            return new ProductSetupDepartmentActions(Driver);
        }

        /// <summary>
        /// Navigate to Part Merge Page
        /// </summary>
        /// <returns>PartMergePageActions</returns>
        public PartMergePageActions NavigateToPartMergePage()
        {
            Settings.Logger.Info("Navigating to Part Merge Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Merge Page", ScreensUrl.PartMerge);
            return new PartMergePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Part Number Change
        /// </summary>
        /// <returns>PartMergePageActions</returns>
        public PartNumberChangePageActions NavigateToPartNumberChange()
        {
            Settings.Logger.Info("Navigating to Part Number Change Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Number Change Page", ScreensUrl.PartNumberChange);
            return new PartNumberChangePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Part Inquiry Page
        /// </summary>
        /// <returns>PartInquiryPageActions</returns>
        public PartLocInquiryPageActions NavigateToPartLocInquiryPage()
        {
            Settings.Logger.Info("Navigating to Part Inquiry Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Inquiry Page", ScreensUrl.PartLocInquiry);
            return new PartLocInquiryPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Part Request Page
        /// </summary>
        /// <returns></returns>
        public PartRequestPageActions NavigateToPartRequestPage()
        {
            Settings.Logger.Info("Navigating to Part Request Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Request Page", ScreensUrl.PartRequest);
            return new PartRequestPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Location Groups Page
        /// </summary>
        /// <returns></returns>
        public LocationGroupsPageActions NavigateToLocationGroupsPage()
        {
            Settings.Logger.Info("Navigating to Location Groups Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Location Groups Page", ScreensUrl.LocationGroups);
            return new LocationGroupsPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Test Suite Page
        /// </summary>
        /// <returns></returns>
        public TestSuitePageActions NavigateToTestSuitePage()
        {
            Settings.Logger.Info("Navigating to TestSuite Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("TestSuite Page", ScreensUrl.TestSuite);
            return new TestSuitePageActions(Driver);
        }

        /// <summary>
        /// Navigate To Hazardous Material Page
        /// </summary>
        /// <returns></returns>
        public HazardousMaterialPageActions NavigateToHazardousMaterialPage()
        {
            Settings.Logger.Info("Navigating to Hazardous Material Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Hazardous Material", ScreensUrl.HazardousMaterial);
            return new HazardousMaterialPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Part Charge Code Page
        /// </summary>
        /// <returns></returns>
        public PartChargeCodePageActions NavigateToPartChargeCodePage()
        {
            Settings.Logger.Info("Navigating to Part Charge Code Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Charge Code", ScreensUrl.PartChargeCode);
            return new PartChargeCodePageActions(Driver);
        }

        /// <summary>
        /// Navigate To Cost Category Codes Page
        /// </summary>
        /// <returns></returns>
        public CostCategoryCodesPageActions NavigateToCostCategoryCodesPage()
        {
            Settings.Logger.Info("Navigating to Cost Category Codes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Cost Category Codes", ScreensUrl.CostCategoryCodes);
            return new CostCategoryCodesPageActions(Driver);
        }

        /// <summary>
        /// Direct Test Suite Result Page Actions
        /// </summary>
        /// <returns></returns>
        public DirectTestSuiteResultPageActions NavigateToDirectTestSuiteResultPage()
        {
            Settings.Logger.Info("Navigating to DirectTestSuiteResult Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("DirectTestSuiteResult Page", ScreensUrl.DirectTestSuiteResult);
            return new DirectTestSuiteResultPageActions(Driver);
        }

        /// <summary>
        /// Test History Query Page Actions
        /// </summary>
        /// <returns></returns>
        public TestHistoryQueryPageActions NavigateToTestHistoryQuery()
        {
            Settings.Logger.Info("Navigating to TestHistoryQuery Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Test History Query Page", ScreensUrl.TestHistoryQuery);
            return new TestHistoryQueryPageActions(Driver);
        }

        /// <summary>
        /// Shift Maintenance Page Actions
        /// </summary>
        /// <returns></returns>
        public ShiftMaintenancePageActions NavigateToShiftMaintenance()
        {
            Settings.Logger.Info("Navigating to ShiftMaintenance Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("ShiftMaintenance Page", ScreensUrl.ShiftMaintenance);
            return new ShiftMaintenancePageActions(Driver);
        }

        /// <summary>
        /// Emissions Rating Page Actions
        /// </summary>
        /// <returns></returns>
        public EmissionsRatingPageActions NavigateToEmissionsRating()
        {
            Settings.Logger.Info("Navigating to EmissionsRating Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("EmissionsRating Page", ScreensUrl.EmissionsRating);
            return new EmissionsRatingPageActions(Driver);
        }

        /// <summary>
        /// VED Class Codes Page Actions
        /// </summary>
        /// <returns></returns>
        public VEDClassCodesPageActions NavigateToVEDClassCodes()
        {
            Settings.Logger.Info("Navigating to VED ClassCodes Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Test VEDClass Codes Page", ScreensUrl.VEDClassCodes);
            return new VEDClassCodesPageActions(Driver);
        }

        /// <summary>
        /// Navigate to PayRoll Pay Classes And Steps Page
        /// </summary>
        /// <returns></returns>
        public PayRollClassStepsPageActions NavigateToPayRollClassesAndSteps()
        {
            Settings.Logger.Info("Navigating to PayRoll Pay Classes And Steps Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Test VEDClass Codes Page", ScreensUrl.PayrollPayClassStep);
            return new PayRollClassStepsPageActions(Driver);
        }
        
        /// Navigate to Distributor Main Page
        /// </summary>
        /// <returns></returns>
        public DistributorMainPageActions NavigateToDistributorMain()
        {
            Settings.Logger.Info("Navigating to Distributor Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Distributor Main Page", ScreensUrl.DistributorMain);
            return new DistributorMainPageActions(Driver);
        }
        
        /// Navigate To Category Main Page
        /// </summary>
        /// <returns></returns>
        public CategoryMainPageActions NavigateToCategoryMainPage()
        {
            Settings.Logger.Info("Navigating to Category Main Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Category Main", ScreensUrl.CategoryMain);
            return new CategoryMainPageActions(Driver);
        }

        /// <summary>
        /// Vision Rating Page Actions
        /// </summary>
        /// <returns></returns>
        public VisionRatingPageActions NavigateToVisionRating()
        {
            Settings.Logger.Info("Navigating to Vision Rating Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Vision Rating Page", ScreensUrl.VisionRating);
            return new VisionRatingPageActions(Driver);
        }

        /// <summary>
        /// Availability Status Codes Page Actions
        /// </summary>
        /// <returns></returns>
        public AvailabilityStatusCodesPageActions NavigateToAvailabilityStatusCodes()
        {
            Settings.Logger.Info("Navigating to Availability Status Codes Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Availability Status Codes Page", ScreensUrl.AvailabilityStatusCodes);
            return new AvailabilityStatusCodesPageActions(Driver);
        }

        /// <summary>
        /// Navigating to Price Types Page
        /// </summary>
        /// <returns></returns>
        public PriceTypesPageActions NavigateToPriceTypesPage()
        {
            Settings.Logger.Info(" Navigating to Price Types Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Price Types", ScreensUrl.PriceTypes);
            return new PriceTypesPageActions(Driver);
        }

        /// <summary>
        /// Edit Dashboard Page
        /// </summary>
        /// <returns></returns>
        public EditDashboardPageActions NavigateToEditDashboardPage()
        {
            Settings.Logger.Info("Navigating to Edit Dashboard Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Edit Dashboard Page", ScreensUrl.EditDashboard);
            return new EditDashboardPageActions(Driver);
        }

        /// Disposal Reason Page Actions
        /// </summary>
        /// <returns></returns>
        public DisposalReasonPageActions NavigateToDisposalReasonPage()
        {
            Settings.Logger.Info("Navigating to Disposal Reason Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Disposal Reason Page", ScreensUrl.DisposalReason);
            return new DisposalReasonPageActions(Driver);
        }


        /// <summary>
        /// Navigate To Work Order Copy
        /// </summary>
        /// <returns></returns>
        public WorkOrderCopyPageActions NavigateToWorkOrderCopy()
        {
            Settings.Logger.Info("Navigating to Work Order Copy ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Work Order Copy Page", ScreensUrl.WorkOrderCopy);
            return new WorkOrderCopyPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Test Suite Group Page
        /// </summary>
        /// <returns></returns>
        public TestSuiteGroupPageActions NavigateToTestSuiteGroupPage()
        {
            Settings.Logger.Info("Navigating to TestSuiteGroup Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("TestSuiteGroup", ScreensUrl.TestSuiteGroup);
            return new TestSuiteGroupPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Warranty Part Setup Page
        /// </summary>
        /// <returns></returns>
        public WarrantyPartSetupPageActions NavigateToWarrantyPartSetupPage()
        {
            Settings.Logger.Info("Navigating to Warranty Part Setup Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Warranty Part Setup", ScreensUrl.WarrantyPartSetup);
            return new WarrantyPartSetupPageActions(Driver);
        }

        /// <summary>
        /// Work Order Express Page Actions
        /// </summary>
        /// <returns></returns>
        public WorkOrderExpressPageActions NavigateToWorkOrderExpresspPage()
        {
            Settings.Logger.Info("Navigating to Work Order Express Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Work Order Expres", ScreensUrl.WorkOrderExpress);
            return new WorkOrderExpressPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Work Order Labor Query Page Actions
        /// </summary>
        /// <returns></returns>
        public WorkOrderLaborQueryPageActions NavigateToWorkOrderLaborQueryPageActions()
        {
            Settings.Logger.Info("Navigating to WorkOrderLaborChargeQuery Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Work Order Labor Charge Query", ScreensUrl.WorkOrderLaborChargeQuery);
            return new WorkOrderLaborQueryPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Parts Kit Page
        /// </summary>
        /// <returns>PartsKitPageActions</returns>
        public PartsKitPageActions NavigateToPartsKitPage()
        {
            Settings.Logger.Info("Navigating to Parts Kit Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Kit Page", ScreensUrl.PartsKitPage);
            return new PartsKitPageActions(Driver);
        }

        /// Employee Assignment Page Actions
        /// </summary>
        /// <returns></returns>
        public EmployeeAssignmentPageActions NavigateToEmployeeAssignmentPage()
        {
            Settings.Logger.Info("Navigating toEmployee Assignment Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Employee Assignment", ScreensUrl.EmployeeAssignment);
            return new EmployeeAssignmentPageActions(Driver);
        }

        /// <summary>
        /// Navigate Component Assignment History Page
        /// </summary>
        /// <returns></returns>
        public ComponentAssignmentHistoryPageActions NavigateComponentAssignmentHistoryPage()
        {
            Settings.Logger.Info("Navigating to Component Assignment History Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Component Assignment History Page", ScreensUrl.ComponentAssignmentHistory);
            return new ComponentAssignmentHistoryPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Part Journal Query Page
        /// </summary>
        /// <returns></returns>
        public PartJournalQueryPageActions NavigateToPartJournalQueryPage()
        {
            Settings.Logger.Info("Navigating to Part Journal Query Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Journal Query", ScreensUrl.PartJournalQuery);
            return new PartJournalQueryPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Part Receive Page
        /// </summary>
        /// <returns></returns>
        public PartReceivePageActions NavigateToPartReceivePage()
        {
            Settings.Logger.Info("Navigating to Part Receive Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Receive", ScreensUrl.PartReceive);
            return new PartReceivePageActions(Driver);
        }

        /// <summary>
        /// Navigate to Driver License Issuing Authority
        /// </summary>
        /// <returns></returns>
        public DriverLicenseIssuingAuthorityPageActions NavigateToDriverLicenseIssuingAuthority()
        {
            Settings.Logger.Info("Navigating to Driver License Issuing Authority Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver License Issuing Authorities", ScreensUrl.DriverLicenseIssuingAuthority);
            return new DriverLicenseIssuingAuthorityPageActions(Driver);
        }

        /// <summary>
        /// Navigate to Driver License Type
        /// </summary>
        /// <returns></returns>
        public DriverLicenseTypePageActions NavigateToDriverLicenseType()
        {
            Settings.Logger.Info("Navigating to Driver License Type Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver License Type", ScreensUrl.DriverLicenseType);
            return new DriverLicenseTypePageActions(Driver);
        }

        /// <summary>
        /// Navigate To Driver Event Entry Page
        /// </summary>
        /// <returns></returns>
        public DriverEventEntryPageActions NavigateToDriverEventEntryPage()
        {
            Settings.Logger.Info("Navigate To Driver Event Entry Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Event Entry", ScreensUrl.DriverEventEntry);
            return new DriverEventEntryPageActions(Driver);
         }
         
        /// <summary>
        ///Navigate to Driver Class Code     
        /// </summary>
        /// <returns></returns>
        public DriverClassCodesPageActions NavigateToDriverClassCodePage()
        {
            Settings.Logger.Info("Navigating to Driver Class Code Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Class Code Page", ScreensUrl.DriverClassCode);
            return new DriverClassCodesPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Part Issue Page
        /// </summary>
        /// <returns></returns>
        public PartIssuePageActions NavigateToPartIssuePage()
        {
            Settings.Logger.Info("Navigating Part Issue Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Issue", ScreensUrl.PartIssue);
            return new PartIssuePageActions(Driver);
        }

        /// <summary>
        /// Navigate To Component Disposal Page
        /// </summary>
        /// <returns></returns>
        public ComponentDisposalPageActions NavigateToComponentDisposalPage()
        {
            Settings.Logger.Info("Navigating Component DisposalPage ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Component Disposal", ScreensUrl.ComponentDisposal);
            return new ComponentDisposalPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Driver Trip Entry Page
        /// </summary>
        /// <returns></returns>
        public DriverTripEntryPageActions NavigateToDriverTripEntryPage()
        {
            Settings.Logger.Info("Navigate To Driver Trip Entry Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Trip Entry", ScreensUrl.DriverTripEntry);
            return new DriverTripEntryPageActions(Driver);
        }

        /// <summary>
        /// Commercial Work Order Page Actions
        /// </summary>
        /// <returns></returns>
        public CommercialWorkOrderPageActions NavigateToCommercialWorkOrderPageActions()
        {
            Settings.Logger.Info("Navigating to Commercial Work Order Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Commercial Work Order", ScreensUrl.CommercialWorkOrder);
            return new CommercialWorkOrderPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Part Transfer Page
        /// </summary>
        /// <returns></returns>
        public PartTransferPageActions NavigateToPartTransferPage()
        {
            Settings.Logger.Info("Navigating to Part Transfer Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Transfer", ScreensUrl.PartTransfer);
            return new PartTransferPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Part Transfer Request Page
        /// </summary>
        /// <returns></returns>
        public PartTransferRequestPageActions NavigateToPartTransferRequestPage()
        {
            Settings.Logger.Info("Navigating to Part Transfer Request Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Transfer Request", ScreensUrl.PartTransferRequest);
            return new PartTransferRequestPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Part Request Handling Page
        /// </summary>
        /// <returns></returns>
        public PartRequestHandlingPageActions NavigateToPartRequestHandlingPage()
        {
            Settings.Logger.Info(" Navigating To Part Request Handling Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Request Handling", ScreensUrl.PartRequestHandling);
            return new PartRequestHandlingPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Part Requisition Approval Page
        /// </summary>
        /// <returns></returns>
        public PartRequisitionApprovalPageActions NavigateToPartRequisitionApprovalPage()
        {
            Settings.Logger.Info(" Navigating To Part Requisition Approval Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Requisition Approval", ScreensUrl.PartRequisitionApproval);
            return new PartRequisitionApprovalPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Purchase Order Query Page
        /// </summary>
        /// <returns></returns>
        public PurchaseOrderQueryPageActions NavigateToPurchaseOrderQueryPage()
        {
            Settings.Logger.Info(" Navigating To Purchase Order Query Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Purchase Order Query", ScreensUrl.PurchaseOrderQuery);
            return new PurchaseOrderQueryPageActions(Driver);
        }

        /// <summary>
        /// Driver Event Query Page Actions
        /// </summary>
        /// <returns></returns>
        public DriverEventQueryPageActions NavigateToDriverEventQueryPageActions()
        {
            Settings.Logger.Info("Navigating To Driver Event Query Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Driver Event Query", ScreensUrl.DriverEventQuery);
            return new DriverEventQueryPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Shipment Term Code Page
        /// </summary>
        /// <returns></returns>
        public ShipmentTermsPageActions NavigateToShipmentTermPage()
        {
            Settings.Logger.Info(" Navigating To Shipment Term Codeg Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Shipment Term Code", ScreensUrl.ShipmentTerms);
            return new ShipmentTermsPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Claim Category Definition Page
        /// </summary>
        /// <returns></returns>
        public ClaimCategoryDefinitionPageActions NavigateToClaimCategoryDefinitionPage()
        {
            Settings.Logger.Info(" Navigating To Claim Category Definition Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Claim Category Definition", ScreensUrl.ClaimCategoryDefinition);
            return new ClaimCategoryDefinitionPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Warranty Claim Manager Page
        /// </summary>
        /// <returns></returns>
        public WarrantyClaimManagerPageActions NavigateToWarrantyClaimManagerPage()
        {
            Settings.Logger.Info(" Navigating To Warranty Claim Manager Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Warranty Claim Manager", ScreensUrl.WarrantyClaimManager);
            return new WarrantyClaimManagerPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Motorpool Units Listed By Location Page
        /// </summary>
        /// <returns></returns>
        public MotorpoolUnitsListedByLocationPageActions NavigateToMotorpoolUnitsListedByLocationPage()
        {
            Settings.Logger.Info(" Navigating To Motorpool Units Listed By Location Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Motorpool Units Listed By Location", ScreensUrl.MotorpoolUnitsListedByLocation);
            return new MotorpoolUnitsListedByLocationPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Motor Pool Location Unit Assignment Page
        /// </summary>
        /// <returns></returns>
        public MotorPoolLocationUnitAssignmentPageActions NavigateToMotorPoolLocationUnitAssignmentPage()
        {
            Settings.Logger.Info(" Navigating To Motor Pool Location Unit Assignment Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Motor Pool Location Unit Assignment", ScreensUrl.MotorPoolLocationUnitAssignment);
            return new MotorPoolLocationUnitAssignmentPageActions(Driver);
        }

        /// <summary>
        /// Part Return Page Actions
        /// </summary>
        /// <returns></returns>
        public PartReturnPageActions NavigateToPartReturnPage()
        {
            Settings.Logger.Info(" Navigating To PartReturn Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Part Return Page", ScreensUrl.PartReturn);
            return new PartReturnPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Part Reserves Page
        /// </summary>
        /// <returns></returns>
        public PartReservesPageActions NavigateToPartReservesPage()
        {
            Settings.Logger.Info(" Navigating To Part Reserves Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" Part Reserves", ScreensUrl.PartReserves);
            return new PartReservesPageActions(Driver);
        }

        /// <summary>
        /// Navigate To WorkrequestPlanPage
        /// </summary>
        /// <returns></returns>
        public WorkRequestPlanPageActions NavigateToWorkrequestPlanPage()
        {
            Settings.Logger.Info(" Navigating To Shipment Term Codeg Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Shipment Term Code", ScreensUrl.WorkrequestPlan);
            return new WorkRequestPlanPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Asset Control Category Budget Options Page
        /// </summary>
        /// <returns></returns>
        public AssetControlCategoryPageActions NavigateToAssetControlCategoryBudgetOptionsPage()
        {
            Settings.Logger.Info(" Navigating To Asset Control Category Budget Options Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Asset Control Category Budget Options", ScreensUrl.AssetControlCategoryBudgetOptions);
            return new AssetControlCategoryPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Unit Disposal Page
        /// </summary>
        /// <returns></returns>
        public UnitDisposalPageActions NavigateToUnitDisposalPage()
        {
            Settings.Logger.Info(" Navigating To Unit Disposal Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Unit Disposal", ScreensUrl.UnitDisposal);
            return new UnitDisposalPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Payroll Time Types Page
        /// </summary>
        /// <returns></returns>
        public PayrollTimeTypesPageActions NavigateToPayrollTimeTypesPage()
        {
            Settings.Logger.Info(" Navigating To Payroll Time Types Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Payroll Time Types", ScreensUrl.PayrollTimeTypes);
            return new PayrollTimeTypesPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Payroll Time Type Matrix Page
        /// </summary>
        /// <returns></returns>
        public PayrollTimeTypeMatrixPageActions NavigateToPayrollTimeTypeMatrixPage()
        {
            Settings.Logger.Info(" Navigating To Payroll Time Type Matrix Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Payroll Time Type Matrix", ScreensUrl.PayrollTimeTypeMatrix);
            return new PayrollTimeTypeMatrixPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Holiday Calendar Page
        /// </summary>
        /// <returns></returns>
        public HolidayCalendarPageActions NavigateToHolidayCalendarPage()
        {
            Settings.Logger.Info(" Navigating To Holiday Calendar Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Holiday Calendar", ScreensUrl.HolidayCalendar);
            return new HolidayCalendarPageActions(Driver);
        }

        /// <summary>
        /// Product Setup Tank Types Page Actions
        /// </summary>
        /// <returns></returns>
        public ProductSetupTankTypesPageActions NavigateToProductSetupTankTypes()
        {
            Settings.Logger.Info(" Navigating To Product Setup Tank Types");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Product Setup Tank Types", ScreensUrl.ProductSetupTankTypes);
            return new ProductSetupTankTypesPageActions(Driver);
        }

        /// <summary>
        /// Product Setup Unit Page Action
        /// </summary>
        /// <returns></returns>
        public ProductSetupUnitPageAction NavigateToProductSetupUnits()
        {
            Settings.Logger.Info(" Navigating To Product Setup Units");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Product setup Units", ScreensUrl.ProductSetupUnits);
            return new ProductSetupUnitPageAction(Driver);
        }

        /// <summary>
        /// Navigate To Product Issue Vendor Indirect
        /// </summary>
        /// <returns></returns>
        public ProductIssueVendorIndirectPageActionss NavigateToProductIssueVendorIndirect()
        {
            Settings.Logger.Info(" Navigating To Product Issue Vendor Indirect");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Product Issue Vendor Indirect", ScreensUrl.ProductIssueVendorIndirect);
            return new ProductIssueVendorIndirectPageActionss(Driver);
        }

        /// <summary>
        /// Maintenance Time Slot
        /// </summary>
        /// <returns></returns>
        public MaintenanceTimeSlotPageActions NavigateToMaintenanceTimeSlot()
        {
            Settings.Logger.Info(" Navigating To Product Issue Vendor Indirect");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Maintenance Time Slot", ScreensUrl.MaintenanceTimeSlot);
            return new MaintenanceTimeSlotPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Indirect Account Groups Page
        /// </summary>
        /// <returns></returns>
        public IndirectAccountGroupsPageActions NavigateToIndirectAccountGroups()
        {
            Settings.Logger.Info(" Navigating To Indirect Account Groups Page");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Indirect Account Groups", ScreensUrl.IndirectAccountGroups);
            return new IndirectAccountGroupsPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Labor Time Card Page
        /// </summary>
        /// <returns></returns>
        public LaborTimeCardPageActions NavigateToLaborTimeCardPage()
        {
            Settings.Logger.Info(" Navigating To Labor Time Card Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Labor Time Card", ScreensUrl.LaborTimeCard);
            return new LaborTimeCardPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Payroll Labor Approval Page
        /// </summary>
        /// <returns></returns>
        public PayrollLaborApprovalPageActions NavigateToPayrollLaborApprovalPage()
        {
            Settings.Logger.Info(" Navigating To Payroll Labor Approval Page ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Payroll Labor Approval", ScreensUrl.PayrollLaborApproval);
            return new PayrollLaborApprovalPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Motor Pool Approval Frame
        /// </summary>
        /// <returns></returns>
        public MotorPoolApprovalPageActions NavigateToMotorPoolApprovalFrame()
        {
            Settings.Logger.Info(" Navigating To Motor Pool Approval Frame");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Motor Pool Approval Frame", ScreensUrl.MotorPoolApprovalFrame);
            return new MotorPoolApprovalPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Motorpool Portal Page
        /// </summary>
        /// <returns></returns>
        public MotorpoolPortalPageActions NavigateToMotorpoolPortalPage()
        {
            Settings.Logger.Info(" Navigating To Motorpool Portal Page");
            WaitForFrameMenu();
            //_mainMain.SelectDropdownUsingValue("Motorpool Portal", ScreensUrl.MotorpoolPortal);
            _mainMain.SelectFilterValueHavingEqualValue("Motorpool Portal");
            return new MotorpoolPortalPageActions(Driver);
        }

        /// <summary>
        /// Navigate To Zone Class Codes
        /// </summary>
        /// <returns></returns>
        public ZoneClassCodesPageActions NavigateToZoneClassCodes()
        {
            Settings.Logger.Info(" Navigating To Zone Class Codes");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Zone Class Codes", ScreensUrl.ZoneClassCodes);
            return new ZoneClassCodesPageActions(Driver);
        }


        /// <summary>
        /// Zone Class Maintenance
        /// </summary>
        /// <returns></returns>
        public ZoneClassMaintenancePageActions NavigateToZoneClassMaintenance()
        {
            Settings.Logger.Info(" Navigating To Zone Class Maintenance");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Zone Class Maintenance", ScreensUrl.ZoneClassMaintenance);
            return new ZoneClassMaintenancePageActions(Driver);
        }

        /// <summary>
        /// Zones Time Page Actions
        /// </summary>
        /// <returns></returns>
        public ZonesTimePageActions NavigateToTimeZones()
        {
            Settings.Logger.Info(" Navigating To Time Zones");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue("Time Zones", ScreensUrl.TimeZones);
            return new ZonesTimePageActions(Driver);
        }

        /// <summary>
        /// DAF Code Maintenance Page Actions
        /// </summary>
        /// <returns></returns>
        public DAFCodeMaintenancePageActions NavigateToDAFCodeMaintenance()
        {
            Settings.Logger.Info(" Navigating To DAF Code Maintenance");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" DAF Code Maintenance", ScreensUrl.DAFCodeMaintenance);
            return new DAFCodeMaintenancePageActions(Driver);
        }

        /// <summary>
        /// Navigating To Dept Group DAF Maintenance
        /// </summary>
        /// <returns></returns>
        public DeptGroupDAFMaintenancePageActions NavigateToDeptGroupDAFMaintenance()
        {
            Settings.Logger.Info(" Navigating To Dept Group DAF Maintenance");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" Dept Group DAF Maintenance", ScreensUrl.DeptGroupDAFMaintenance);
            return new DeptGroupDAFMaintenancePageActions(Driver);
        }

        /// <summary>
        /// Department Quote Rules Page Actions
        /// </summary>
        /// <returns></returns>
        public DepartmentQuoteRulesPageActions NavigateToDepartmentQuoteRules()
        {
            Settings.Logger.Info(" Navigating To Department Quote Rules");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" Department Quote Rules", ScreensUrl.DepartmentQuoteRules);
            return new DepartmentQuoteRulesPageActions(Driver);
        }

        /// <summary>
        /// Navigating To Zone Charge Codes
        /// </summary>
        /// <returns></returns>
        public ZoneChargeCodesPagecsActions NavigateToZoneChargeCodes()
        {
            Settings.Logger.Info(" Navigating To Zone Charge Codes");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" Zone Charge Codes", ScreensUrl.ZoneChargeCodes);
            return new ZoneChargeCodesPagecsActions(Driver);
        }

        /// <summary>
        /// Navigating To Zone
        /// </summary>
        /// <returns></returns>
        public ZonePageActions NavigateToZone()
        {
            Settings.Logger.Info(" Navigating To Zone ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" Zone ", ScreensUrl.Zones);
            return new ZonePageActions(Driver);
        }

        /// <summary>
        /// Navigate To Zones Copy
        /// </summary>
        /// <returns></returns>
        public ZoneCopyPageActions NavigateToZonesCopy()
        {
            Settings.Logger.Info(" Navigating To Zones Copy ");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" Zones Copy ", ScreensUrl.ZonesCopy);
            return new ZoneCopyPageActions(Driver);
        }

        /// <summary>
        /// Navigating To Zone Charge Query
        /// </summary>
        /// <returns></returns>
        public ZoneChargeQueryPageActions NavigateToZoneChargeQuery()
        {
            Settings.Logger.Info(" Navigating To Zone Charge Query");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" Zone Charge Query", ScreensUrl.ZoneChargeQuery);
            return new ZoneChargeQueryPageActions(Driver);
        }


        /// <summary>
        /// Shift Types Page Actions
        /// </summary>
        /// <returns></returns>
        public ShiftTypesPageActions NavigateToShiftTypes()
        {
            Settings.Logger.Info(" Navigating To Shift Types");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" Shift Types", ScreensUrl.ShiftTypes);
            return new ShiftTypesPageActions(Driver);
        }

        /// <summary>
        /// Shop Planning Schedule Page Actions
        /// </summary>
        /// <returns></returns>
        public ShopPlanningSchedulePageActions NavigateToShopPlanningSchedule()
        {
            Settings.Logger.Info(" Navigating To Shop Planning Schedule");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" Shop Planning Schedule", ScreensUrl.ShopPlanningSchedule);
            return new ShopPlanningSchedulePageActions(Driver);
        }

        /// <summary>
        /// Disposal Method Page Actions
        /// </summary>
        /// <returns></returns>
        public DisposalMethodPageActions NavigateToDisposalMethod()
        {
            Settings.Logger.Info(" Navigating To Disposal Method");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" Disposal Method", ScreensUrl.DisposalMethod);
            return new DisposalMethodPageActions(Driver);
        }

        /// <summary>
        /// Disposal Cause Page Actions
        /// </summary>
        /// <returns></returns>
        public DisposalCausePageActions NavigateToDisposalCause()
        {
            Settings.Logger.Info(" Navigating To Disposal Cause");
            WaitForFrameMenu();
            _mainMain.SelectDropdownUsingValue(" Disposal Cause", ScreensUrl.DisposalCause);
            return new DisposalCausePageActions(Driver);
        }
    }
}