﻿using OpenQA.Selenium;
using Newtonsoft.Json.Linq;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.SystemCodes;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes
{
    internal class SystemFlagsPageActions : SystemFlagsPage
    {
        public SystemFlagsPageActions(IWebDriver Driver) : base(Driver) { }

       /// <summary>
       /// Set System Flag Value
       /// </summary>
       /// <param name="FlagNo"></param>
       /// <param name="Value"></param>
        public string SetSystemFlagValueAndGetExistingValue(string FlagNo, string Value)
        {
            Settings.Logger.Info($"Setting {FlagNo} System Flag Value as {Value}");
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _flagNo.SetText(FlagNo, "Flag No");
            Driver.WaitForReady();
            string originalflagValue = GetSystemFlagValue(FlagNo);
            Driver.WaitForReady();
            if (!string.IsNullOrEmpty(Value)) { _uservalue.SetText(Value, "User Value");}
            else { _extendedPage.SelectAllAndClearField(_uservalue); }           
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();            
            return originalflagValue;
        }

        /// <summary>
        /// Get System Flag Value
        /// </summary>
        /// <param name="FlagNo"></param>
        public string GetSystemFlagValue(string FlagNo)
        {
            string? flagValue = _uservalue.GetElementValueByAttribute("ovalue");
            if (string.IsNullOrEmpty(flagValue))
                flagValue = "";
            Settings.Logger.Info($" {FlagNo} System Flag Value  is {flagValue}");
            return flagValue;
        }

        /// <summary>
        /// Update System Flags
        /// </summary>
        /// <param name="Flags"></param>
        /// <returns></returns>
        public Dictionary<string, string> UpdateSystemFlags(Dictionary<string, string> Flags)
        {
            string originalValue = string.Empty;
            Dictionary<string, string> originalFlags = new Dictionary<string, string>();
            if (Flags != null)
            {
                foreach (KeyValuePair<string, string> flagdata in Flags)
                {
                    originalValue = SetSystemFlagValueAndGetExistingValue(flagdata.Key, flagdata.Value);
                    originalFlags.Add(flagdata.Key, originalValue);
                }
            }     
            return originalFlags;
        }
    }
}
