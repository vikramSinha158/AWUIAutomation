﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Booking;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;

namespace AssetWorks.UI.M5.TestAutomation.Actions.ShipmentTerm
{
    internal class ShipmentTermsPageActions : ShipmentTermsPage
    {
        public ShipmentTermsPageActions(IWebDriver Driver) : base(Driver) { }


        /// <summary>
        /// Create Shipment Term Code
        /// </summary>
        /// <param name="DataObject"></param>
        /// <returns></returns>
        public string CreateShipmentTermCode(ShipmentTermsDetails DataObject)
        {
            string ShipCode = string.Empty;            
            if (!_extendpage.CheckDataExistenceAndGetActionCode(DataObject.Code, ref ShipCode, "ShipmentTermQuery"))
            {
                _extendpage.SwitchToContentFrame();
                Driver.SwitchToFrame(_iframeShipmentTerms, "Table frame");
                Settings.Logger.Info($"Creating Shipment Term Code :{DataObject.Code}");
                DataObject.Code = ShipCode;                
                _shipmentCode.SetText(DataObject.Code, "Shipment Term Code");
                _shipmentCodeDesc.SetText(DataObject.Description, "Description");
                _extendpage.Save();
                Driver.WaitForReady();
                Assert.IsTrue(_extendpage.CheckDataExistenceAndGetActionCode(DataObject.Code, ref ShipCode, "ShipmentTermQuery")); 
            }
            return DataObject.Code;
        }
    }
}
