﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Department;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Department
{
    internal class DepartmentCopyPageActions : DepartmentCopyPage
    {
        public DepartmentCopyPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Update New Department Number
        /// </summary>
        /// <param name="DeptNumber"></param>
        /// <returns>NewDeptNumber</returns>
        public (DepartmentMainPageActions, string) UpdateNewDepartmentNumber(string DeptNumber)
        {
            string NewDeptNumber = CommonUtil.GetRandomStringWithSpecialChars();
            _extendedPage.SwitchToContentFrame();
            _inputDeptNumber.SetText(DeptNumber, "Department No");
            Driver.WaitForReady();
            _inputNewDeptNumber.SetText(NewDeptNumber, "New Department No");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForInvisibility(By.Id("NewDeptNumber"), " New Department Number ");
            return (new DepartmentMainPageActions(Driver), NewDeptNumber);
        }
    }
}
