﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Department;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Department
{
    internal class DepartmentQuoteRulesPageActions : DepartmentQuoteRulesPage
    {
        public DepartmentQuoteRulesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Department Quote Rules
        /// </summary>
        /// <param name="DepartmentQuoteRules"></param>
        public void CreateDepartmentQuoteRules(DepartmentQuoteRules DepartmentQuoteRules)
        {
            _extendpage.SwitchToContentFrame();
            _deptNumber.SetText(DepartmentQuoteRules.DepartmentNo, "DepartmentNo");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_deptQuoteFrame, "deptQuoteFrame");
            foreach (QuotationRuleInformation QuotationRuleInformation in DepartmentQuoteRules.QuotationRuleInformation)
            {
                string[] queryparam = { QuotationRuleInformation.Reason, DepartmentQuoteRules.DepartmentNo };
                if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection, "DepartmentQuoteRulesQuery", queryparam, Settings.DBType))
                {
                    _extendpage.GetTableActionElementByRelatedColumnValue(_deptQuoteTable, "Reason", "", "reason").SetText(QuotationRuleInformation.Reason, "Reason");
                    Driver.WaitForReady();
                    _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_deptQuoteTable, "Reason", QuotationRuleInformation.Reason, "quote_req"), "Reason", QuotationRuleInformation.QuotRequired);
                    Driver.WaitForReady();
                    _extendpage.GetTableActionElementByRelatedColumnValue(_deptQuoteTable, "Reason", "", "auth_level").SetText(QuotationRuleInformation.SpendingLimit, "SpendingLimit");
                    Settings.Logger.Info($" DepartmentNo { DepartmentQuoteRules.DepartmentNo } created Department Quote Rules");
                }
                else
                {
                    Settings.Logger.Info($" DepartmentNo { DepartmentQuoteRules.DepartmentNo } already exists in Department Quote Rules ");
                }
               
                Driver.WaitForReady();
            }
            _extendpage.Save();
        }

        /// <summary>
        /// Verify Department Quote Rules
        /// </summary>
        /// <param name="DepartmentQuoteRules"></param>
        public void VerifyDepartmentQuoteRules(DepartmentQuoteRules DepartmentQuoteRules)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_deptNumber, DepartmentQuoteRules.DepartmentNo, "DepartmentNo");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_deptQuoteFrame, "deptQuoteFrame");
            foreach (QuotationRuleInformation QuotationRuleInformation in DepartmentQuoteRules.QuotationRuleInformation)
            {
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_deptQuoteTable, "Reason", QuotationRuleInformation.Reason, "reason"), "Reason",QuotationRuleInformation.Reason,false, "value");
                Driver.WaitForReady();
                CommonUtil.VerifyCheckboxState(_extendpage.GetTableActionElementByRelatedColumnValue(_deptQuoteTable, "Reason", QuotationRuleInformation.Reason, "quote_req"), "Reason", QuotationRuleInformation.QuotRequired);
                Driver.WaitForReady();
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_deptQuoteTable, "Reason", "", "auth_level"), "SpendingLimit",QuotationRuleInformation.SpendingLimit, false, "value");                   
            }
            Settings.Logger.Info($" verified DepartmentNo { DepartmentQuoteRules.DepartmentNo }  in Department Quote Rules");
        }

        /// <summary>
        /// Delete Quotation Rule InformationTable
        /// </summary>
        /// <param name="UnitdeptNo"></param>
        public void DeleteQuotationRuleInformationTable(string DepartmentNo)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_deptNumber, DepartmentNo, "DepartmentNo");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_deptQuoteFrame, "deptQuoteFrame");
            Driver.WaitForReady();
            _extendpage.DeleteTableRowsUsingColumnName(_deptQuoteTable, "Reason", "reason", _deptQuoteFrame);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Deleted Quotation Rule InformationTable  ");
        }

        /// <summary>
        /// Update Department Quote Rules
        /// </summary>
        /// <param name="DepartmentQuoteRules"></param>
        public void UpdateDepartmentQuoteRules(DepartmentQuoteRules DepartmentQuoteRules)
        {
            _extendpage.SwitchToContentFrame();
            _deptNumber.SetText(DepartmentQuoteRules.DepartmentNo, "DepartmentNo");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_deptQuoteFrame, "deptQuoteFrame");
            foreach (QuotationRuleInformation QuotationRuleInformation in DepartmentQuoteRules.QuotationRuleInformation)
            {
                string[] queryparam = { QuotationRuleInformation.Reason, DepartmentQuoteRules.DepartmentNo };
                if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection, "DepartmentQuoteRulesQuery", queryparam, Settings.DBType))
                {
                    _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_deptQuoteTable, "Reason", QuotationRuleInformation.Reason, "quote_req"), "Reason", QuotationRuleInformation.QuotRequired);
                    Driver.WaitForReady();
                    _extendpage.GetTableActionElementByRelatedColumnValue(_deptQuoteTable, "Reason", "", "auth_level").SetText(QuotationRuleInformation.SpendingLimit, "SpendingLimit");
                    Settings.Logger.Info($" DepartmentNo { DepartmentQuoteRules.DepartmentNo } Updated Department Quote Required Flag");
                }
                else
                {
                    Settings.Logger.Info($" DepartmentNo { DepartmentQuoteRules.DepartmentNo } Quote Required Flag is selected");
                }

                Driver.WaitForReady();
            }
            _extendpage.Save();

        }
    }
}
