﻿using System;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Department;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Department
{
    internal class DepartmentGroupsPageActions : DepartmentGroupsPage
    {
        internal DepartmentGroupsPageActions(IWebDriver Driver) : base(Driver) { }


        public void CreateNewDepartmentGroup()
        {
            Settings.Logger.Info(" Creating Department Group ");
            DepartmentObjects.DeptGroupNo = CommonUtil.GetRandomStringWithSpecialChars();
            _inputDeptGroup.SetText(DepartmentObjects.DeptGroupNo, "Department Group",
                Driver, _extendedPage._contentFrame, "content frame");
            _extendedPage.ActionRequiredWindow("Create");
            Driver.WaitForReady();
        }


        public void AssignDepartmentsInGroup(string Include)
        {
            Settings.Logger.Info(" Assign Departments in Group ");
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameDeptGroup, "Dept Group Main Frame");
            string[] deptList = CommonUtil.DataObjectForKey(Include).ToObject<string[]>();
            foreach (string dept in deptList)
            {
                _selectDeptListLeft.SelectDropdownUsingValue("Dept list", dept);
            }            
            _buttonDeptListMoveRight.Click();
            DeptInGroup = _selectDeptListRight.GetDropdownValueList();
            Driver.SwitchTo().DefaultContent();
        }


        public void UnassignDepartmentsFromGroup(string Exclude)
        {
            Settings.Logger.Info(" Unassign Departments from Group ");
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameDeptGroup, "Dept Group Main Frame");
            string[] deptList = CommonUtil.DataObjectForKey(Exclude).ToObject<string[]>();
            foreach (string dept in deptList)
            {
                _selectDeptListRight.SelectDropdownUsingValue("Dept list", dept);
            }
            _buttonDeptListMoveLeft.Click();
            DeptInGroup = _selectDeptListRight.GetDropdownValueList();
            Driver.SwitchTo().DefaultContent();
        }


        public void AssignRoleToDepartmentGroup(string RoleId)
        {
            Settings.Logger.Info(" Assigning Role To Department Group ");
            _extendedPage.SwitchToContentFrame();
            _tabRoles.Click();
            Settings.Logger.Info(" Clicked on Department Groups - Roles tab");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameDeptGroupUser, "Dept Group Main User Frame");
            Driver.DoubleClick(_inputNewRole, " Input New Role ");
            string roleName = CommonUtil.DataObjectForKey(RoleId).ToString();
            _lov.SearchAndSelectFirstRowData(roleName);
            Driver.WaitForReady();
        }

        public void SaveDepartmentGroupInfo()
        {
            Settings.Logger.Info(" Saving Department Group ");
            _extendedPage.ClickOnSaveButton();
        }

        public void VerifyAssignedDepartmentsInGroup(string Depts)
        {
            bool flag = true;
            Settings.Logger.Info(" Verify assign Departments in Group ");
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameDeptGroup, "Dept Group Main Frame");
            DeptInGroup = _selectDeptListRight.GetDropdownValueList();
            string[] deptList = CommonUtil.DataObjectForKey(Depts).ToObject<string[]>();
            foreach (string dept in deptList)
            {
                if (!DeptInGroup.Contains(dept))
                {
                    flag = false;
                    break;
                }
            }
            Assert.IsTrue(flag, "Assign Departments in Group doesn't matched with expected.");
        }

        public void RefreshAndVerifyDepartmentGroupDetails(string Departments)
        {
            Settings.Logger.Info(" Refresh Departments Group Page ");
            _extendedPage.ClickOnRefreshButton();
            _inputDeptGroup.SetText(DepartmentObjects.DeptGroupNo, "Department Group",
                Driver, _extendedPage._contentFrame, "content frame");
            Driver.WaitForReady();
            VerifyAssignedDepartmentsInGroup(Departments);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>	
        /// Delete open department group
        /// </summary>
        public void DeleteDepartmentGroup()
        {
            _extendedPage.SwitchToContentFrame();
            _inputDeptGroup.Click();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Delete Departments Group ");
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ActionRequiredWindow("Delete");
        }
    }
}
