﻿using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Department;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Department
{
    internal class DepartmentMainPageActions : DepartmentMainPage
    {
        internal DepartmentMainPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create New Department
        /// </summary>
        /// <param name="department"></param>
        /// <returns>DepartmentNo</returns>
        public string CreateNewDepartment(DepartmentMain department)
        {
            Settings.Logger.Info(" Create a new Department ");
            string DepartmentNo = string.Empty;
            if (department.DepartmentNo == null)
                department.DepartmentNo = "random";

            if (!_extendedPage.CheckDataExistenceAndGetActionCode(department.DepartmentNo, ref DepartmentNo, "DepartmentQuery", 10))
            {
                _inputDeptNumber.SetText(DepartmentNo, "Department No", Driver, _extendedPage._contentFrame, "content frame");
                Driver.WaitForReady();
                if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                    _extendedPage.ClickOnDialogBoxButton("Create");
                _extendedPage.SwitchToContentFrame();
                _inputDeptDesc.SetText(department.DeptDescription, "Department Desc");
                Driver.WaitForReady();
                _selectStatus.SelectFilterValueHavingEqualValue(department.DeptStatus);
                Driver.WaitForReady();
                _inputDeptBillingCode.SendKeys(Keys.Tab);
                Driver.SwitchTo().DefaultContent();

                if (department.GeneralTab != null)
                    FillGeneralTabInformation(department.GeneralTab);
                if (department.OrgHierarchyTab != null)
                    FillOrgHierarchyTabInformation(department.OrgHierarchyTab);
                if (department.QuoteRulesTab != null)
                    FillQuoteRulesTabInformation(department.QuoteRulesTab, DepartmentNo);
                if (department.MotorPoolTab != null)
                    FillMotorPoolTabInformation(department.MotorPoolTab);
                _extendedPage.VerifyRecordCreatedSuccess(_inputDeptNumber, _inputDeptDesc, DepartmentNo, "Department No");
            }
            return DepartmentNo;
        }

        /// <summary>
        /// Update Department Details
        /// </summary>
        /// <param name="department"></param>
        public void UpdateDepartmentInfo(DepartmentMain department)
        {
            Settings.Logger.Info(" Update Department Details ");
            _extendedPage.SwitchToContentFrame();
            _inputDeptNumber.SetText(department.DepartmentNo, "Department No");
            Driver.WaitForReady();
            _inputDeptDesc.SetText(department.DeptDescription, "Department Desc");
            Driver.WaitForReady(); 
            _selectStatus.SelectFilterValueHavingEqualValue(department.DeptStatus);
            Driver.WaitForReady();
            if (department.GeneralTab != null)
                FillGeneralTabInformation(department.GeneralTab);
            if (department.OrgHierarchyTab != null)
                FillOrgHierarchyTabInformation(department.OrgHierarchyTab);
            if (department.QuoteRulesTab != null)
                FillQuoteRulesTabInformation(department.QuoteRulesTab, department.DepartmentNo);
            if (department.MotorPoolTab != null)
                FillMotorPoolTabInformation(department.MotorPoolTab);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Fill General Tab Information
        /// </summary>
        /// <param name="dataObject"></param>
        public void FillGeneralTabInformation(GeneralTab dataObject)
        {
            Settings.Logger.Info(" Fill Department General Information");
            _extendedPage.SwitchToContentFrame();
            _extendedPage.GetTabLinkByText("General").Click();
            Driver.WaitForReady();
            if (dataObject.DeptBillingCode != null)
            {
                Driver.DoubleClick(_inputDeptBillingCode, "BillingCode");
                _lov.SearchAndSelectFirstRowData(dataObject.DeptBillingCode);
                _extendedPage.SwitchToContentFrame();
                Driver.WaitForReady();
            }
            _inputDeptContact.SetText(dataObject.DeptContact, "Dept Contact");
            Driver.WaitForReady();
            _inputDeptPhone.SetText(dataObject.DeptPhone, "Dept Phone");
            Driver.WaitForReady();
            _inputDeptPhoneEx.SetText(dataObject.DeptPhoneEx, "Dept Phone Ex");
            Driver.WaitForReady();
            _inputDeptEmail.SetText(dataObject.DeptEmail, "Dept Email");
            Driver.WaitForReady();
            _inputDeptMCC.SetText(dataObject.DeptMCC, "Dept MCC");
            Driver.WaitForReady();
            _inputDeptPriorityKick.SetText(dataObject.DeptPriorityKick, "Dept Priority Kick");
            Driver.WaitForReady();
            _inputDeptSpecNo.SetText(dataObject.DeptTechSpec, "Dept Tech Spec");
            Driver.WaitForReady();
            _inputDeptMaxWO.SetText(dataObject.DeptMaxWO, "Dept Max WO");
            Driver.WaitForReady();
            _inputDeptDeliveryLoc.SetText(dataObject.DeptDeliveryLoc, "Dept Delivery Loc");
            Driver.WaitForReady();
            _inputDeptMarkupScheme.SetText(dataObject.DeptMarkupScheme, "Dept Markup Scheme");
            Driver.WaitForReady();
            _inputDeptMaintLoc.SetText(dataObject.DeptMaintenanceLoc, "Dept Maintenance Loc");
            Driver.WaitForReady();
            _inputDeptInvLoc.SetText(dataObject.DeptInventoryLoc, "Dept Inventory Loc");
            Driver.WaitForReady();
            if (dataObject.DeptTaxExemption)
                _inputDeptTaxExempt.Click();
            if (dataObject.DeptOutsideOrg)
                _inputDeptOutsideOrg.Click();
            _inputDeptWONotes.SetText(dataObject.DeptWorkOrderNotes, "Dept Work Order Notes");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Fill Org Hierarchy Tab Information
        /// </summary>
        /// <param name="dataObject"></param>
        public void FillOrgHierarchyTabInformation(OrgHierarchyTab dataObject)
        {
            Settings.Logger.Info(" Fill Department Org Hierarchy Information");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Org Hierarchy"), "Org Hierarchy Tab");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameDeptOrgHier, "Dept Org Hier");
            foreach (OrganizationalHierarchy hierarchy in dataObject.OrganizationalHierarchy)
            {
                Settings.Logger.Info("Update Org Hierarchy 'Value' for : " + hierarchy.LevelTitle);
                _extendedPage.GetTableActionElementByRelatedColumnValue(
                    _tableDeptOrgHier, "Org Level Title", hierarchy.LevelTitle, "Label").SetText(hierarchy.LevelValue, "Org Level Value");
                Driver.WaitForReady();
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Fill Quote Rules Tab Information
        /// </summary>
        /// <param name="dataObject"></param>
        /// <param name="deptNo"></param>
        public void FillQuoteRulesTabInformation(QuoteRulesTab dataObject, string deptNo)
        {
            Settings.Logger.Info(" Update Quote Rules Information");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Quote Rules"), "Quote Rules Tab");
            Driver.WaitForReady();
            _inputDeptApproval1Title.SetText(dataObject.DeptApproval1, "Dept Approval1");
            _inputDeptApproval2Title.SetText(dataObject.DeptApproval2, "Dept Approval2");
            Driver.WaitForReady();
            if (dataObject.DeptQuotationRule.Count > 0)
            {
                int row = 0;
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
                Driver.WaitForReady(); 
                _extendedPage.RefreshAndSetText(_inputDeptNumber, deptNo, "Department No");
                _extendedPage.GetTabLinkByText("Quote Rules").Click();
                Driver.SwitchToFrame(_frameDeptQuote, "Quote Rules");
                Driver.WaitForReady();
                Settings.Logger.Info("Add Quote Rules Information");
                foreach (DeptQuotationRule rule in dataObject.DeptQuotationRule)
                {
                    _extendedPage.GetInputElementAndSetValue($"reason$new_{row}", rule.Reason);
                    _extendedPage.GetInputElementAndSetValue($"auth_level$new_{row}", rule.SpendingLimit);
                    Driver.WaitForReady();
                    row++;
                }
                Driver.SwitchTo().DefaultContent();
            }
        }

        /// <summary>
        /// Fill Motor Pool Tab Information
        /// </summary>
        /// <param name="dataObject"></param>
        public void FillMotorPoolTabInformation(MotorPoolTab dataObject)
        {
            Settings.Logger.Info(" Update Motor Pool Information");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Motor Pool"), "Motor Pool Tab");
            Driver.WaitForReady();
            if (dataObject.AssignedEmployees.Count > 0)
            {
                int row = 0;
                Driver.SwitchToFrame(_frameDeptMPApprover, "Dept Motor Pool");
                Settings.Logger.Info("Add Assigned Employees Information");
                foreach (AssignedEmployee emp in dataObject.AssignedEmployees)
                {
                    _extendedPage.GetInputElementAndSetValue($"e_no$new_{row}", emp.EmployeeNo);
                    Driver.WaitForReady();
                    row++;
                }
                Driver.SwitchTo().DefaultContent();
            }
        }

        /// <summary>
        /// Verify Department Information
        /// </summary>
        /// <param name="DeptNo"></param>
        public void VerifyDepartmentInformation(DepartmentMain department)
        {
            Settings.Logger.Info(" Verify Department Information");
            _extendedPage.RefreshAndSetText(_inputDeptNumber, department.DepartmentNo, "Department No");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputDeptDesc, "Description", department.DeptDescription);
            CommonUtil.VerifyElementValue(_selectStatus, "Status", department.DeptStatus, true);
            if (department.GeneralTab != null)
                VerifyGeneralTabInformation(department.GeneralTab);
            if (department.OrgHierarchyTab != null)
                VerifyOrgHierarchyTabInformation(department.OrgHierarchyTab);;
            if (department.QuoteRulesTab != null)
                VerifyQuoteRulesTabInformation(department.QuoteRulesTab);;
            if (department.MotorPoolTab != null)
                VerifyMotorPoolTabInformation(department.MotorPoolTab);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify General Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyGeneralTabInformation(GeneralTab dataObject)
        {
            Settings.Logger.Info(" Verify Department General Information");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("General"), "General Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputDeptBillingCode, "Billing Code", dataObject.DeptBillingCode);
            CommonUtil.VerifyElementValue(_inputDeptContact, "Contact", dataObject.DeptContact);
            CommonUtil.VerifyElementValue(_inputDeptPhone, "Phone", dataObject.DeptPhone);
            CommonUtil.VerifyElementValue(_inputDeptPhoneEx, "PhoneEx", dataObject.DeptPhoneEx);
            CommonUtil.VerifyElementValue(_inputDeptEmail, "Email", dataObject.DeptEmail);
            CommonUtil.VerifyElementValue(_inputDeptMCC, "MCC", dataObject.DeptMCC);
            CommonUtil.VerifyElementValue(_inputDeptPriorityKick, "Priority Kick", dataObject.DeptPriorityKick);
            CommonUtil.VerifyElementValue(_inputDeptSpecNo, "Spec No", dataObject.DeptTechSpec);
            CommonUtil.VerifyElementValue(_inputDeptMaxWO, "Max WO", dataObject.DeptMaxWO);
            CommonUtil.VerifyElementValue(_inputDeptDeliveryLoc, "Delivery Loc", dataObject.DeptDeliveryLoc);
            CommonUtil.VerifyElementValue(_inputDeptMarkupScheme, "Markup Scheme", dataObject.DeptMarkupScheme);
            CommonUtil.VerifyElementValue(_inputDeptMaintLoc, "Maintenance Loc", dataObject.DeptMaintenanceLoc);
            CommonUtil.VerifyElementValue(_inputDeptInvLoc, "Inventory Loc", dataObject.DeptInventoryLoc);
            CommonUtil.VerifyElementValue(_inputDeptWONotes, "Work Order Notes", dataObject.DeptWorkOrderNotes);
        }

        /// <summary>
        /// Verify Org Hierarchy Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyOrgHierarchyTabInformation(OrgHierarchyTab dataObject)
        {
            string ActualValue;
            Settings.Logger.Info(" Verify Department Org Hierarchy Information");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Org Hierarchy"), "Org Hierarchy Tab");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameDeptOrgHier, "Dept Org Hier");
            foreach (OrganizationalHierarchy hierarchy in dataObject.OrganizationalHierarchy)
            {
                Settings.Logger.Info($"Verify Org Hierarchy 'Level Value' for Title : " + hierarchy.LevelTitle);
                ActualValue = _extendedPage.GetTableActionElementByRelatedColumnValue(
                    _tableDeptOrgHier, "Org Level Title", hierarchy.LevelTitle, "Label").GetElementValueByAttribute("value");
                CommonUtil.AssertTrue(hierarchy.LevelValue, ActualValue);
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Quote Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyQuoteRulesTabInformation(QuoteRulesTab dataObject)
        {
            Settings.Logger.Info(" Verify Department Quote Information");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Quote Rules"), "Quote Rules Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputDeptApproval1Title, "Approval1", dataObject.DeptApproval1);
            CommonUtil.VerifyElementValue(_inputDeptApproval2Title, "Approval2", dataObject.DeptApproval2);
            if (dataObject.DeptQuotationRule != null)
            {
                Driver.SwitchToFrame(_frameDeptQuote, "Dept Quote Rule");
                string ActualValue;
                foreach (DeptQuotationRule rule in dataObject.DeptQuotationRule)
                {
                    Settings.Logger.Info($"Verify Quotation Rule 'Authorization' for reason : " + rule.Reason);
                    ActualValue = _extendedPage.GetTableActionElementByRelatedColumnValue(
                        _tableDeptQuote, "Reason", rule.Reason, "auth_level").GetElementValueByAttribute("value");
                    CommonUtil.AssertTrue(rule.SpendingLimit, ActualValue);
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Assigned Employees Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyMotorPoolTabInformation(MotorPoolTab dataObject)
        {
            string ActualValue;
            Settings.Logger.Info(" Verify Department Assigned Employees Information");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Motor Pool"), "Motor Pool Tab");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameDeptMPApprover, "Dept Approver");
            foreach (AssignedEmployee emp in dataObject.AssignedEmployees)
            {
                Settings.Logger.Info("Verify Assigned Employees 'Name' for No : " + emp.EmployeeNo);
                ActualValue = _extendedPage.GetTableActionElementByRelatedColumnValue(
                    _tableDeptApprover, "Employee No", emp.EmployeeNo, "e_name").GetElementValueByAttribute("value");
                CommonUtil.AssertTrue(emp.EmployeeName, ActualValue);
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Department Deletion
        /// </summary>
        /// <param name="DepartmentNo"></param>
        public void VerifyDepartmentDeletion(string DepartmentNo)
        {
            _extendedPage.VerifyCodeDeletion(_inputDeptNumber, DepartmentNo, "Department No");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Navigate To Part List Disposal
        /// </summary>
        /// <returns>PartListDisposalPageActions</returns>
        public PartListDisposalPageActions NavigateToPartListDisposal()
        {
            Settings.Logger.Info("Navigating to Part List Disposal Page");
            _extendedPage.NavigateToRelatedMenuPage(Screens.PartListDisposal);
            return new PartListDisposalPageActions(Driver);
        }
    }
}
