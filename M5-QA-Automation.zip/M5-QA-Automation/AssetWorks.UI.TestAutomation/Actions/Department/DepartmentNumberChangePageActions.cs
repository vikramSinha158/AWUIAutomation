﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Department;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Department
{

    internal class DepartmentNumberChangePageActions : DepartmentNumberChangePage
    {

        public DepartmentNumberChangePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Search for department number
        /// </summary>
        public void SearchForDepartmentNumber(string DeptNumber)
        {
            Settings.Logger.Info("Search For Department Number ");
            _extendedPage.SwitchToContentFrame();
            Driver.DoubleClick(_inputDepartmentNumber, " input department number ");
            Driver.SwitchTo().DefaultContent();
            _lov.SearchAndSelectFirstRowData(DeptNumber);
            Driver.WaitForReady();
        }

        /// <summary>
        /// Update New Department Number
        /// </summary>
        /// <returns>DepartmentMainPageActions</returns>
        public (DepartmentMainPageActions, string) UpdateNewDepartmentNumber()
        {
            string NewDeptNo = CommonUtil.GetRandomStringWithSpecialChars();
            _extendedPage.SwitchToContentFrame();
            _inputNewDepartmentNumber.SetText(NewDeptNo, "New Department Number");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForInvisibility(By.Id("NewDeptNumber"), " New Department Number ");
            return (new DepartmentMainPageActions(Driver), NewDeptNo);
        }
    }
}
