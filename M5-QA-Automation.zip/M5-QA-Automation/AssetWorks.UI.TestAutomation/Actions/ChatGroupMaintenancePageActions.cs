﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class ChatGroupMaintenancePageActions : ChatGroupMaintenancePage
    {
        public ChatGroupMaintenancePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Add Chat group
        /// </summary>
        /// <param name="RowNum"></param>
        public void AddChatgroup(int RowNum)
        {
            MoveToGroupChatFrame();
            int RowCoubt = _chatGroupRows.Count;
            if (RowCoubt>1)
            {
                _chatGroups.Clear();
                for (int i = 0; i < RowNum; i++)
                {
                    string GroupChat = CommonUtil.GetRandomStringWithSpecialChars(6).ToUpper();
                    _chatGroups.Add(GroupChat);
                    _extendpage.GetInputElementAndSetValue($"{_chatGroupName}{i}", GroupChat, "name");
                    _extendpage.Save();
                    _extendpage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_chatGroupMaintFrame, "chatGroupMaintFrame");
                }
                Settings.Logger.Info($" Successfully Added { RowNum } Chat Group Count ");
            }
        }

        /// <summary>
        /// Delete Chat Group
        /// </summary>
        public void DeleteChatGroup()
        {
            RefreshAndMoveToChatGroupFrame();
            _chatCountBeforeDeletion = _chatGroupRows.Count;
            foreach (string Chat in _chatGroups)
            {
                Driver.WaitForReady();
                 _extendpage.GetTableActionElementByRelatedColumnValue(_chatGroupTable, _groupChatHeader, Chat, _groupChatId).Click();
                _extendpage.DeleteAndSave();
                Driver.SwitchToFrame(_chatGroupMaintFrame, "chatGroupMaintFrame");
            }
            Settings.Logger.Info(" Successfully Deleted New added Chat Group ");
        }

        /// <summary>
        /// Verify Deletion Chat Group
        /// </summary>
        /// <param name="NewAddedChatCount"></param>
        public void VerifyDeletionChatGroup()
        {
            RefreshAndMoveToChatGroupFrame();
            int ExpactedCount = _chatCountBeforeDeletion - _chatGroups.Count;
            int ActualCount = _chatGroupRows.Count;
            CommonUtil.AssertTrue<int>(ExpactedCount, ActualCount);
            Settings.Logger.Info(" Successfully Verified Chat Group Count ");
            Driver.SwitchTo().DefaultContent();

        }

        /// <summary>
        /// Move To Group Chat Frame
        /// </summary>
        private void MoveToGroupChatFrame()
        {
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_chatGroupMaintFrame, "chatGroupMaintFrame");
        }

        /// <summary>
        /// Refresh And Move To Chat Group Frame
        /// </summary>
        private void RefreshAndMoveToChatGroupFrame()
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            MoveToGroupChatFrame();
        }

        /// <summary>
        /// Verify Added Chat Group Count
        /// </summary>
        /// <param name="ExpactedCount"></param>
        public void VerifyAddedChatGroup()
        {
            RefreshAndMoveToChatGroupFrame();
            foreach (string Chat in _chatGroups)
            {
                Driver.WaitForReady();
                string ChatValue = _extendpage.GetTableActionElementByRelatedColumnValue(_chatGroupTable, _groupChatHeader, Chat, _groupChatId).GetAttribute("value");;
                CommonUtil.AssertTrue<string>(Chat, ChatValue);
            }
            Settings.Logger.Info(" Successfully Verified Chat Group ");
        }
    }
}
