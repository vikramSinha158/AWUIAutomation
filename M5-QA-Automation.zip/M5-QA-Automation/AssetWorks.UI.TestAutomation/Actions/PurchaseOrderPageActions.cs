﻿using OpenQA.Selenium;
using System.Collections.Generic;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class PurchaseOrderPageActions : PurchaseOrderPage
    {
        public PurchaseOrderPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Part Purchase Order
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <returns></returns>
        public string CreatePartPurchaseOrder(PurchaseOrderObjects purchaseOrder)
        {
            Settings.Logger.Info(" Create Part Purchase Order");
            _extendpage.SwitchToContentFrame();
            _newPO.ClickElement(" New PO Button ", Driver);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow(purchaseOrder.POContractType);
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _vendorNumber.SetText(purchaseOrder.vendorNumber, "Vendor Number");
            Driver.WaitForReady();
            _poRefNo.SetText(purchaseOrder.POReferenceNumber, "PO Reference Number");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            if (purchaseOrder.OrderLinesTabData != null)
                FillOrderLinesTab(purchaseOrder.OrderLinesTabData);
            if (purchaseOrder.GetVendorReqs != null)
                FillGetVendorReqs(purchaseOrder.GetVendorReqs);
            if (purchaseOrder.GetOtherReqTab != null)
                FillGetOtherReqs(purchaseOrder.GetOtherReqTab);
            if (purchaseOrder.PartRequestTab != null)
                AddPartRequest(purchaseOrder);
            if (purchaseOrder.PONotes != null)
                FillPONoteData(purchaseOrder);
            if (purchaseOrder.DistributorTabData != null)
                FillDistributorTabData(purchaseOrder.DistributorTabData);
            if (purchaseOrder.PoItemsTab != null)
                FillPOItemsTab(purchaseOrder.PoItemsTab);
            _extendpage.SwitchToContentFrame();
            purchaseOrder.poNumber = _poNO.GetAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            return purchaseOrder.poNumber;
        }

        /// <summary>
        /// Fill Order Lines Tab Data
        /// </summary>
        /// <param name="orderLinesTabData"></param>
        public void FillOrderLinesTab(List<OrderLinesTab> orderLinesTabData)
        {
            Settings.Logger.Info("Fill Order Lines Tab Data ");
            Driver.WaitForReady();
            _extendpage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Order Lines"), "Order Lines");
            Driver.SwitchToFrame(_framePO, "Table frame");
            Driver.WaitForReady();
            int rowId = 0;
            foreach(OrderLinesTab orderLine in orderLinesTabData)
            {
                _inputNewPartNo(rowId.ToString()).Click();
                Driver.WaitForReady();
                _inputNewPartNo(rowId.ToString()).SetText(orderLine.PartNumber, "Part No");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber, 
                    "contract", "ovalue").SetText(orderLine.Contract, "Contract");
                Driver.WaitForReady();
                if (orderLine.RecvLocation != null)
                {
                    _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", 
                        orderLine.PartNumber, "ShipTo", "ovalue"));
                    _extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "ShipTo", "ovalue").SetText(orderLine.RecvLocation, "Recv Location");
                }
                else
                    _extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "ShipTo", "ovalue").SendKeys(Keys.Tab);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                    "Qty", "ovalue").SetText(orderLine.Qty, "Quantity");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                    "cpunitcost", "ovalue").SetText(orderLine.UnitCost, "Unit Cost");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                    "neededBy", "ovalue").SetText(orderLine.NeededBy, "Needed By");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                    "chargeCode", "ovalue").SelectFilterValueHavingEqualValue(orderLine.ResvCode);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                    "typeNum", "ovalue").SetText(orderLine.ResvRefNo, "Resv Ref No");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                    "lineRefNo", "ovalue").SetText(orderLine.RefNo, "Ref No");
                Driver.WaitForReady();
                if (orderLine.PNotes != null)
                {
                    _extendpage.AddNotes(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "noteBtn", "ovalue"), orderLine.PNotes);
                    Driver.WaitForReady();
                    _extendpage.SwitchToTableFrame(_framePO);
                }
                rowId++;
            }
            _extendpage.Save();
        }

        /// <summary>
        /// Fill Get Vendor Req tab data
        /// </summary>
        /// <param name="VendorReqs"></param>
        public void FillGetVendorReqs(List<GetVendorReqTab> VendorReqs)
        {
            Settings.Logger.Info("Fill Vendor Reqs Tab Data");
            Driver.WaitForReady();
            _extendpage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Get Vendor Reqs"), "Get Vendor Reqs");
            Driver.SwitchToFrame(_vendorReqFrame, "Get Vendor Req Frame");
            foreach (GetVendorReqTab requisition in VendorReqs)
            {
                if (requisition.Requisition != null)
                    _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_vendorReqsTable, "Requisition",
                        requisition.Requisition, "checkReq1", "req_id", "div"), "Select", requisition.Select);
                else
                    _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_vendorReqsTable, "Part Number",
                        requisition.PartNumber, "checkReq1"), "Select", requisition.Select);
                Driver.WaitForReady();
            }
            _extendpage.Save();
        }

        /// <summary>
        /// Fill Get Other Req tab data
        /// </summary>
        /// <param name="OtherReqs"></param>
        public void FillGetOtherReqs(List<GetOtherReqTab> OtherReqs)
        {
            Settings.Logger.Info("Fill Get Other Reqs Tab Data");
            Driver.WaitForReady();
            _extendpage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Get Other Reqs"), "Get Other Reqs");
            Driver.SwitchToFrame(_getOtherReqFrame, "Get Other Req Frame");
            foreach(GetOtherReqTab otherReq in OtherReqs)
            {
                if (otherReq.Requisition != null)
                    _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_getOtherReqTable, "Requisition",
                        otherReq.Requisition, "checkReq", "req_id", "div"), "Select", otherReq.Select);
                else
                    _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_getOtherReqTable, "Part Number",
                        otherReq.PartNumber, "checkReq"), "Select", otherReq.Select);
                Driver.WaitForReady();
            }
            _extendpage.Save();
        }

        /// <summary>
        /// Add Part Request
        /// </summary>
        /// <param name="purchaseOrder"></param>
        public void AddPartRequest(PurchaseOrderObjects purchaseOrder)
        {
            Settings.Logger.Info("Fill Part Request");
            Driver.WaitForReady();
            _extendpage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Part Request"), "Part Request");
            Driver.SwitchToFrame(_partRequestListFrame, "_partRequestListFrame");
            if (purchaseOrder.ResvRefNoFlag)
            {
                foreach (PartRequestTab PartRequest in purchaseOrder.PartRequestTab)
                {
                    Driver.WaitForReady();
                    _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_requestListTable, "Resv Ref No",
                        PartRequest.ResvRefNo, "rcheckReq"), "SelectPart", PartRequest.SelectPart);
                    _extendpage.Save();
                    _extendpage.SwitchToContentFrame();
                    Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Part Request"), "Part Request");
                    Driver.SwitchToFrame(_partRequestListFrame, "_partRequestListFrame");
                }
                Driver.SwitchTo().DefaultContent();
            }
            else {
                foreach (PartRequestTab PartRequest in purchaseOrder.PartRequestTab)
                {
                    Driver.WaitForReady();
                    _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_requestListTable, "Part No",
                        PartRequest.PartNumber, "rcheckReq"), "SelectPart", PartRequest.SelectPart);
                }
                _extendpage.Save();
            }       
        }

        /// <summary>
        /// Fill Distribution Tab Data
        /// </summary>
        /// <param name="distributorTabData"></param>
        public void FillDistributorTabData(DistributorTab distributorTabData)
        {
            Settings.Logger.Info("Fill Distributor Tab Data");
            Driver.WaitForReady();
            _extendpage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Shipping Addr"), "Shipping Address Distributor");
            Driver.WaitForReady();
            _shippingName.SetText(distributorTabData.ShippingName, "Shipping Name");
            Driver.WaitForReady();
            _shippingAddress1.SetText(distributorTabData.ShippingAddress1, "Shipping Address1");
            Driver.WaitForReady();
            _shippingAddress2.SetText(distributorTabData.ShippingAddress2, "Shipping Address2");
            Driver.WaitForReady();
            _shippingCity.SetText(distributorTabData.ShippingCity, "Shipping City");
            Driver.WaitForReady();
            _shippingState.SetText(distributorTabData.ShippingState, "Shipping State");
            Driver.WaitForReady();
            _shippingCountry.SetText(distributorTabData.ShippingCountry, "Shipping Country");
            Driver.WaitForReady();
            _shippingContact.SetText(distributorTabData.ShippingContact, "Shipping Contact");
            Driver.WaitForReady();
            _shippingPhone.SetText(distributorTabData.ShippingPhone, "Shipping Phone");
            Driver.WaitForReady();
            _shippingNotes.SetText(distributorTabData.ShippingNotes, "Shipping Notes");
            Driver.WaitForReady();
            _distName.SetText(distributorTabData.DistributorNumber, "Distributor Number");
            Driver.WaitForReady();
            _extendpage.Save();
        }

        /// <summary>
        /// Fill PO Note Data
        /// </summary>
        public void FillPONoteData(PurchaseOrderObjects purchaseOrder)
        {
            Settings.Logger.Info("Fill PO Note Tab Data");
            Driver.WaitForReady();
            _extendpage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("PO Note"), "Shipping Address Distributor");
            _poNotes.SetText(purchaseOrder.PONotes, "Purchase Order Notes");
            Driver.WaitForReady();
            _extendpage.Save();
        }

        /// <summary>
        /// Fill PO Items tab data
        /// </summary>
        /// <param name="PoItems"></param>
        public void FillPOItemsTab(List<PoItemsTab> PoItems)
        {
            Settings.Logger.Info("Fill PO Items tab data");
            _extendpage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("PO Items"), "PO Items");
            Driver.SwitchToFrame(_framePOItem, "PO Items");
            int rowId = 0;
            foreach (PoItemsTab PoItem in PoItems)
            {
                _inputNewItem(rowId.ToString()).SetText(PoItem.Item, "Item");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_tablePOItem, "Item", PoItem.Item, "value", "ovalue").SetText(PoItem.Value, "Value");
            }
            _extendpage.Save();
        }

        /// <summary>
        /// Verify Purchase Order Data
        /// </summary>
        public void VerifyPurchaseOrderData(PurchaseOrderObjects poObjects)
        {
            Settings.Logger.Info("Verify Purchase Data for : " + poObjects.poNumber);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_poNO, poObjects.poNumber, "Po Number");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_selectStatus, "Status", poObjects.PoStatus, true);
            CommonUtil.VerifyElementValue(_vendorNumber, "Vendor", poObjects.vendorNumber);
            CommonUtil.VerifyElementValue(_poRefNo, "PO Ref No", poObjects.POReferenceNumber);
            if ( poObjects.OrderLinesTabData != null )
                VerifyOrderLinesTabData(poObjects);
            if ( poObjects.DistributorTabData != null )
                VerifyDistributorTabData(poObjects.DistributorTabData);
            if ( poObjects.PONotes != null )
                VerifyPONoteTabData(poObjects);
            if ( poObjects.PoItemsTab != null )
                VerifyPOItemsTab(poObjects.PoItemsTab);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Order Lines Tab Data
        /// </summary>
        public void VerifyOrderLinesTabData(PurchaseOrderObjects purchaseOrderObjects)
        {
            Driver.SwitchToFrame(_framePO, "Order Line Frame");
            if (purchaseOrderObjects.GetVendorReqs != null)
            {
                foreach (OrderLinesTab orderLine in purchaseOrderObjects.OrderLinesTabData)
                {
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "contract"), "Contract", orderLine.Contract, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "ShipTo"), "Recv Location", orderLine.RecvLocation, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "Qty"), "Qty", orderLine.Qty, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "cpunitcost"), "Unit Cost", orderLine.UnitCost, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "lineSum"), "Lines Total", orderLine.LinesTotal, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "chargeCode"), "Resv Code", orderLine.ResvCode, true);
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "typeNum"), "Resv Ref No", orderLine.ResvRefNo, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "lineRefNo"), "RefNo", orderLine.RefNo, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "reqNo"), "ReqNo", orderLine.ReqNo, false, "req_id");
                    if (orderLine.PNotes != null)
                    {
                        _extendpage.VerifyAddedNotes(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                            "noteBtn"), orderLine.PNotes);
                        Driver.WaitForReady();
                        _extendpage.SwitchToTableFrame(_framePO);
                    }

                }
            }
            if (purchaseOrderObjects.GetVendorReqs != null)
            {
                foreach (GetVendorReqTab orderLine in purchaseOrderObjects.GetVendorReqs)
                {
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "contract"), "Contract", orderLine.Contract, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "ShipTo"), "Recv Location", orderLine.RecvLocation, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "Qty"), "Qty", orderLine.Qty, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "cpunitcost"), "Unit Cost", orderLine.UnitCost, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "chargeCode"), "Resv Code", orderLine.ResvCode, true);
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "typeNum"), "Resv Ref No", orderLine.ResvRefNo, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "reqNo"), "ReqNo", orderLine.Requisition, false, "req_id");
                }
            }
            if (purchaseOrderObjects.GetOtherReqTab != null)
            {
                foreach (GetOtherReqTab orderLine in purchaseOrderObjects.GetOtherReqTab)
                {
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "contract"), "Contract", orderLine.Contract, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "ShipTo"), "Recv Location", orderLine.RecvLocation, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "Qty"), "Qty", orderLine.Qty, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "cpunitcost"), "Unit Cost", orderLine.UnitCost, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "chargeCode"), "Resv Code", orderLine.ResvCode, true);
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "typeNum"), "Resv Ref No", orderLine.ResvRefNo, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "reqNo"), "ReqNo", orderLine.Requisition, false, "req_id");
                }
            }
            if (purchaseOrderObjects.GetOtherReqTab != null)
            {
                foreach (PartRequestTab orderLine in purchaseOrderObjects.PartRequestTab)
                {
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "Qty"), "Qty", orderLine.Qty, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "cpunitcost"), "Unit Cost", orderLine.UnitCost, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "chargeCode"), "Resv Code", orderLine.ResvCode, true);
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", orderLine.PartNumber,
                        "typeNum"), "Resv Ref No", orderLine.ResvRefNo, false, "value");
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
        }

        /// <summary>
        /// Verify Distributor tab Data
        /// </summary>
        /// <param name="distributorTab"></param>
        public void VerifyDistributorTabData(DistributorTab distributorTab)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("Shipping Addr"), "Shipping Address Distributor");
            CommonUtil.VerifyElementValue(_shippingName, "Shipping Name", distributorTab.ShippingName);
            CommonUtil.VerifyElementValue(_shippingAddress1, "Shipping Address1", distributorTab.ShippingAddress1);
            CommonUtil.VerifyElementValue(_shippingCity, "Shipping City", distributorTab.ShippingCity);
            CommonUtil.VerifyElementValue(_shippingCountry, "Shipping Country", distributorTab.ShippingCountry);
            CommonUtil.VerifyElementValue(_shippingContact, "Shipping Contact", distributorTab.ShippingContact);
            CommonUtil.VerifyElementValue(_shippingPhone, "Shipping Phone", distributorTab.ShippingPhone);
            CommonUtil.VerifyElementValue(_distName, "Distributor Name", distributorTab.DistributorNumber);
        }

        /// <summary>
        /// Verify PONote Tab Data
        /// </summary>
        /// <param name="poNoteTab"></param>
        public void VerifyPONoteTabData(PurchaseOrderObjects poNoteTab)
        {
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("PO Note"), "PO Note");
            CommonUtil.VerifyElementValue(_poNotes, "PO Note Tab data", poNoteTab.PONotes);
        }

        /// <summary>
        /// Verify PO Items tab data
        /// </summary>
        /// <param name="PoItems"></param>
        public void VerifyPOItemsTab(List<PoItemsTab> PoItems)
        {
            Settings.Logger.Info("Verify PO Items tab data");
            Driver.ScrollIntoViewAndClick(_extendpage.GetTabLinkByText("PO Items"), "PO Items");
            Driver.SwitchToFrame(_framePOItem, "PO Items");
            foreach (PoItemsTab PoItem in PoItems)
            {
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePOItem, "Item", PoItem.Item,
                    "field_type"), "Type", PoItem.Type, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePOItem, "Item", PoItem.Item, 
                    "value"), "Value", PoItem.Value, false, "value");
            }
        }

        /// <summary>
        /// Cancel Purchase Order
        /// </summary>
        /// <param name="PoNo"></param>
        /// <param name="PartNo"></param>
        public void CancelPurchaseOrder(string PoNo, string PartNo)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_poNO, PoNo, "Po Number");
            Driver.SwitchToFrame(_framePO, "Order Line Frame");
            _extendpage.GetTableActionElementByRelatedColumnValue(_tablePart, "Part No", PartNo, "POPartNo").Click();
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnDeleteButton();
            Driver.WaitForReady();
            _extendpage.ClickOnSaveButton();
            Driver.WaitForReady();
        }
    }
}