﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class EmployeeAssignmentPageActions : EmployeeAssignmentPage
    {
        public EmployeeAssignmentPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Retrieve Employee Assignment
        /// </summary>
        /// <param name="WorkOrderEmployeeAssignment"></param>
        public void RetrieveEmployeeAssignment(WorkOrderEmployeeAssignment WorkOrderEmployeeAssignment)
        {
            Settings.Logger.Info($"Add Selection Criteria WorkOrder Employee Assignment {WorkOrderEmployeeAssignment.UnitDepComp}");
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _unitDeptCompDd.SelectDropdownUsingValue("UnitDepCompName", WorkOrderEmployeeAssignment.UnitDepCompName);
            Driver.WaitForReady();
            _unitNoInput.SetText(WorkOrderEmployeeAssignment.UnitDepComp, "UnitDepComp");
            Driver.WaitForReady();
            _jobcode.SetText(WorkOrderEmployeeAssignment.JobCode, "JobCode");
            Driver.WaitForReady();
            _jobrsn.SetText(WorkOrderEmployeeAssignment.JobCReason, "JobCReason");
            Driver.WaitForReady();
            _retrieveBtn.ClickElement("retrieve", Driver);
            Settings.Logger.Info($"Retrieved Employee AssignmentQuery {WorkOrderEmployeeAssignment.UnitDepComp}");
        }

        /// <summary>
        /// Fill EmployeeAssignment Query Table
        /// </summary>
        /// <param name="WorkOrderEmployeeAssignment"></param>
        public void FillEmployeeAssignmentQueryTable(WorkOrderEmployeeAssignment WorkOrderEmployeeAssignment)
        {
            if (WorkOrderEmployeeAssignment.EmployeeAssignmentQueryTable != null)
            {
                Driver.SwitchToFrame(_empAssignFrame, "empAssignFrame ");
                Driver.ScrollInView(_empAssignTable);
                _extendpage.GetTableActionElementByRelatedColumnValue(_empAssignTable, "Unit", WorkOrderEmployeeAssignment.UnitDepComp, "assignment").SetText(WorkOrderEmployeeAssignment.EmployeeAssignmentQueryTable.EmpNo, "EmpNo");
                Driver.WaitForReady();
                _extendpage.GetElementForInput("resource_type0").SetText(WorkOrderEmployeeAssignment.EmployeeAssignmentQueryTable.Resource, "Resource");
                _extendpage.Save();
                Settings.Logger.Info($"Filed Employee AssignmentQuery for employee and resource ");
            }
        }

        /// <summary>
        /// Verify Employee Assignment Query
        /// </summary>
        /// <param name="WorkOrderEmployeeAssignment"></param>
        public void VerifyEmployeeAssignmentQuery(WorkOrderEmployeeAssignment WorkOrderEmployeeAssignment)
        {
            Driver.SwitchTo().DefaultContent();
            RetrieveEmployeeAssignment(WorkOrderEmployeeAssignment);
            Driver.SwitchToFrame(_empAssignFrame, "empAssignFrame ");
            Driver.ScrollInView(_empAssignTable);
            IWebElement UnitDepComp=_extendpage.GetTableActionElementByRelatedColumnValue(_empAssignTable, "Unit", WorkOrderEmployeeAssignment.UnitDepComp, "unit");
            CommonUtil.VerifyElementValue(UnitDepComp, "UnitDepComp", WorkOrderEmployeeAssignment.UnitDepComp,false, "value");
            IWebElement Location = _extendpage.GetTableActionElementByRelatedColumnValue(_empAssignTable, "Unit", WorkOrderEmployeeAssignment.UnitDepComp, "location");
            CommonUtil.VerifyElementValue(Location, "Location", WorkOrderEmployeeAssignment.EmployeeAssignmentQueryTable.Location, false, "value");
            IWebElement WorkOrderNo = _extendpage.GetElementForInput("abc$0","id","div");
            //Verifying work order link 
            CommonUtil.VerifyElementValue(WorkOrderNo, "WorkOrderNo","1",false, "click");
            Settings.Logger.Info($"Successfully verified  work order link exists for woe order  { WorkOrderEmployeeAssignment.WorkOrderNo}");
            CommonUtil.VerifyElementValue(WorkOrderNo, "WorkOrderNo", WorkOrderEmployeeAssignment.WorkOrderNo, false, "value");
            IWebElement EmpNo = _extendpage.GetTableActionElementByRelatedColumnValue(_empAssignTable, "Unit", WorkOrderEmployeeAssignment.UnitDepComp, "assignment");
            CommonUtil.VerifyElementValue(EmpNo, "EmpNo", WorkOrderEmployeeAssignment.EmployeeAssignmentQueryTable.EmpNo, false, "value");
            IWebElement Resource= _extendpage.GetElementForInput("resource_type0");
            CommonUtil.VerifyElementValue(Resource, "Resource", WorkOrderEmployeeAssignment.EmployeeAssignmentQueryTable.Resource, false, "value");
            Settings.Logger.Info($"Successfully verified Employee AssignmentQuery {WorkOrderEmployeeAssignment.UnitDepComp}");
        }

        /// <summary>
        /// Verify WO Page Opened Using Link
        /// </summary>
        /// <param name="WorkOrderEmployeeAssignment"></param>
        public void VerifyWOPageOpenedUsingLink(WorkOrderEmployeeAssignment WorkOrderEmployeeAssignment)
        {
           _extendpage.GetElementForInput("abc$0", "id", "div").Click();
            Driver.WaitForSomeTime();
            string parentWindow = Driver.SwitchToNewWindow();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForSomeTime(30);
            CommonUtil.VerifyElementValue(_workOrderNumber, "WorkOrderNo", WorkOrderEmployeeAssignment.WorkOrderNo);
            Driver.WaitForReady();
            Driver.SwitchTo().Window(parentWindow);
            Settings.Logger.Info($"Successfully verified open work order page using link for work order no  {WorkOrderEmployeeAssignment.WorkOrderNo}");
        }

        /// <summary>
        /// Verify Employee Assignment Query Claer
        /// </summary>
        /// <param name="WorkOrderEmployeeAssignment"></param>
        public void VerifyEmployeeAssignmentQueryClaer(WorkOrderEmployeeAssignment WorkOrderEmployeeAssignment)
        {
            Driver.SwitchTo().DefaultContent();
            RetrieveEmployeeAssignment(WorkOrderEmployeeAssignment);
            _clearBtn.ClickElement("retrieve", Driver);
            CommonUtil.VerifyElementValueNotBlank(_unitNoInput, "UnitCompdept field");
            Settings.Logger.Info($"Successfully verified Employee AssignmentQuery Clear button ");
        }
    }
}
