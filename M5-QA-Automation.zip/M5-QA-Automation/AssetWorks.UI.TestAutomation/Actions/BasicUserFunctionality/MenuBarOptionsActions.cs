﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.PagesObject.BasicUserFunctionality;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using Newtonsoft.Json.Linq;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.Actions.BasicUserFunctionality
{
    internal class MenuBarOptionsActions : MenuBarOptionsPage
    {
        public MenuBarOptionsActions(IWebDriver Driver) : base(Driver) { }
        
        /// <summary>
        /// Select Page from History Menu
        /// </summary>
        /// <param name="DataObject"></param>
        /// <returns></returns>
        public void SelectPageFromHistoryMenu(string pageName)
        {
            Settings.Logger.Info("Verifying Application User Maintenance after selecting Application User Maintenance from Menu");
            Driver.WaitForReady();
            _history.ClickElement("History",Driver);
            Driver.WaitForReady();
            Driver.FindElement(By.XPath($"//nav[@id='mainHistoryMenu']//li//li//a[contains(text(),'{pageName}')]")).Click();
            Driver.WaitForReady();         
        }
        /// <summary>
        /// Verify Page Title
        /// </summary>
        /// <param name="pageTitle"></param>
        public void VerifyPageTitle(string pageTitle)
        {
            Settings.Logger.Info("Verifying Page Titles");
            Driver.SwitchTo().DefaultContent();
            _extendPage.VerifyMenuBarHeaders(pageTitle);
        }
        /// <summary>
        /// Select Reports from Menu
        /// </summary>
        public void SelectReports()
        {
            Settings.Logger.Info("Select Reports from Menu");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _reports.ClickElement("Reports",Driver);         
        }
        /// <summary>
        /// Select Dashboard from the Menu Bar 
        /// </summary>
        public void SelectDashboard()
        {
            Settings.Logger.Info("Select Dashboard from Menu");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _dashboard.ClickElement("Dashboard",Driver);
            _extendPage.VerifyMenuBarHeaders("Operational Dashboard");
        }
        /// <summary>
        /// Select and Verify Help File from the Menu Bar
        /// </summary>
        public void SelectAndVerifyHelpFile()
        {
            Settings.Logger.Info("Verifying Help Window after selecting Help from Menu ");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _helpFile.ClickElement("HelpFile",Driver);
            Driver.SwitchToNewWindow();
            _helpFileNewWindow.VerifyElementDisplay("Operational Dashboard");         
        }
        /// <summary>
        /// Select and Verify Chat button from the Menu Bar
        /// </summary>
        public void SelectAndVerifyChatWindow()
        {
            Settings.Logger.Info("Verifying Chat Window after selecting Chat button from Menu");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _chatButton.ClickElement("Chat", Driver); ;                   
            _chatNewBtn.VerifyElementDisplay("New Massage");     
            _closeChatWindow.ClickElement("Close Chat Window Icon", Driver); ;
        }

        /// <summary>
        /// Select add icon button present on the favourites and verify the selected listitem
        /// </summary>
        public void SelectandVerifyAddFavourites(string DataKey)
        {
            Settings.Logger.Info("Select and verify add favorites icon present on the favourites");
            Driver.WaitForReady();
            string addfav = _addFav.GetAttribute("OnClick");
            if (addfav == "removeFavorite()")
            {
                Driver.ClickOnElement(_addFav, "");
            }
            Driver.SwitchTo().DefaultContent();
            Driver.ClickOnElement(_addFav, "");
            VerifyFavoritesList(CommonUtil.DataForKey(DataKey));            
           
        }

        /// Verify Favourite List
        /// </summary>
        /// <param name="expectedListItem"></param>
        public void VerifyFavoritesList(string expectedListItem)
        {
            Settings.Logger.Info("Verifying Favorites List Items in the list");
            IWebElement menuListItem = Driver.FindElement(By.XPath($"//nav[@id='mainFavoriteMenu']//li//li//a[contains(text(),'{expectedListItem}')]"));
            menuListItem.VerifyElementDisplay("expectedListItem");
        }

        /// <summary>
        /// Select Target Icon
        /// </summary>
        public void SelectTargettIcon()
        {
            Settings.Logger.Info("Logoff the application");
            Driver.WaitForClickable(_tagetWindowButton, "Target Window Button");
            _tagetWindowButton.Click();
            Driver.SwitchTo().DefaultContent();
            Driver.MouseHover(_chatButton, "");
            Driver.WaitForSomeTime();
        }
        /// <summary>
        /// Verify the frame opens in the new window after selectng target icon
        /// </summary>
        public void VerifyTargetIcon(string expectedNewWindowTitle)
        {
            Settings.Logger.Info("Logoff the application");
            _mainMain.SelectDropdownUsingValue("Equipment Types SKU", ScreensUrl.EquipmentTypesSKU);
            Driver.WaitForClickable(_loginPage._loggOff, "Log Off");
            Assert.AreEqual(2, Driver.WindowHandles.Count);
            var newWindowHandle = Driver.WindowHandles[1];
            Driver.WaitForSomeTime();
            Assert.AreEqual(Driver.SwitchTo().Window(newWindowHandle).Title, expectedNewWindowTitle);
            Driver.WaitForReady();
        }

      /// <summary>
        /// LogOff the application
        /// </summary>
        public void LoggOffApplicationAndSwitchToParentWindow()
        {
            _loginPage.LoggOffApplication();          
            var parentWindowHandle = Driver.WindowHandles[0];
            Driver.SwitchTo().Window(parentWindowHandle);
            Driver.WaitForSomeTime();
        }


        /// <summary>
        /// Edit the Home Page field in the Application User Maintainence Page
        /// </summary>
        /// <param name="DataObjectKey"></param>
        /// <param name="User"></param>
        public void EditHomePageDetails(string User, string homePageData)
        {
            Settings.Logger.Info("Edit User Home Page Details");
            _extendPage.RefreshAndSetText(_appUser, User, " Application User ");
            Driver.WaitForReady();
            _homePage.SetText(homePageData, "");
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClicKSave();
            Driver.WaitForSomeTime();
        }

        /// <summary>
        /// Verify the Home Page
        /// </summary>
        /// <param name="expectedHeader"></param>
        public void VerifyHomePageText(string PageText)
        {
            Settings.Logger.Info("Edit User Home Page Details");
            _extendPage.SwitchToContentFrame();
            _homePage.VerifyElementDisplay("Home Page");
            Assert.True(Driver.FindElement(By.XPath($"//span[contains(text(),'{PageText}')]")).VerifyElementDisplay(" Home Page Text "), "HomePage Not Dispalyed");
        }       

    }
}
