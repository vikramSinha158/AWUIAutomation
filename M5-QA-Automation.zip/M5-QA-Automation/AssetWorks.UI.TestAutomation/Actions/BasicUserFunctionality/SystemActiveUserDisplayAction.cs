﻿using AssetWorks.UI.Core.Extensions;
using OpenQA.Selenium;
using NUnit.Framework;
using System;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.BasicUserFunctionality;

namespace AssetWorks.UI.M5.TestAutomation.Actions.BasicUserFunctionality
{
    internal class SystemActiveUserDisplayAction : SystemActiveUserDisplayPage
    {       
        public SystemActiveUserDisplayAction(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Reload User
        /// </summary>
        public void ReloadUser()
        {
            Settings.Logger.Info("Clicking Reload Button");
            _extendpage.SwitchToContentFrame();
            _systemActiveReloadButton.Click();
            Driver.WaitForReady();
        }
        /// <summary>
        /// Verify Active User Details
        /// </summary>
        public void VerifyActiveUserDetails(string Datakey)
        {
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            ActiveUserDisplay activeUserObjectValues = CommonUtil.DataObjectForKey(Datakey).ToObject<ActiveUserDisplay>();
            Settings.Logger.Info("Verifying  Active User details");
            CommonUtil.VerifyElementValue(_licensedCount,"License Count", activeUserObjectValues.ExpectedLicCount);           
            Driver.SwitchToFrame(_userFrame, "Table frame");          
           _extendpage.AssetTrue(_user.GetAttribute("value"), activeUserObjectValues.Appuser);            
            string currentDate = DateTime.Now.ToString("MM/dd/yyyy");      
            Assert.IsTrue(_login.GetAttribute("value").Contains(currentDate));          
           _extendpage.AssetTrue(_lastFrame.GetAttribute("value"), activeUserObjectValues.ExpectedLastFrame);         
            Assert.IsTrue(_lastActivity.GetAttribute("value").Contains(currentDate));           
        }
       
    }
}
