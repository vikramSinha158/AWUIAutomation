﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Distributor;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Department
{
    internal class DistributorMainPageActions : DistributorMainPage
    {
        internal DistributorMainPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create New Distributor
        /// </summary>
        /// <param name="department"></param>
        /// <returns>DepartmentNo</returns>
        public DistributorMainObjects CreateDistributor(DistributorMainObjects distObject)
        {
            
            Settings.Logger.Info(" Creating a new Distributor ");
            string DistributorNo = string.Empty;           
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(distObject.DistributorNumber, ref DistributorNo, "DistributorQuery", 12))
            {
                distObject.DistributorNumber = DistributorNo;
                _distNumber.SetText(distObject.DistributorNumber.ToUpper(), "Distributor No", Driver, _extendedPage._contentFrame, "content frame");
                Driver.WaitForReady();
                _extendedPage.ClickOnDialogBoxButton("Create");
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
                _distName.SetText(distObject.DistributorName, "Distributor Name");
                Driver.WaitForReady();
                _disabled.SelectFilterValueHavingEqualValue(distObject.Disabled);
                Driver.WaitForReady();
                _address1.SetText(distObject.Address1, "Address1");
                Driver.WaitForReady();
                _address2.SetText(distObject.Address2, "Address2");
                Driver.WaitForReady();
                _city.SetText(distObject.City, "City");
                Driver.WaitForReady();
                _state.SetText(distObject.State, "State");
                Driver.WaitForReady();
                _zip.SetText(distObject.Zip, "Zip");
                Driver.WaitForReady();
                _country.SetText(distObject.Country, "Country");
                Driver.WaitForReady();
                _contact.SetText(distObject.Contact, "Contact");
                Driver.WaitForReady();
                _phone.SetText(distObject.Phone, "Phone");
                Driver.WaitForReady();
                _phoneExt.SetText(distObject.PhoneExt, "PhoneExt");
                Driver.WaitForReady();
                _email.SetText(distObject.Email, "Email");
                Driver.WaitForReady();
                _fax.SetText(distObject.Fax, "Fax");
                Driver.WaitForReady();                
                _extendedPage.VerifyRecordCreatedSuccess(_distNumber, _distName, distObject.DistributorNumber, "Distributor No");
                Settings.Logger.Info($" {distObject.DistributorNumber}: Distributor Created Successfully ");
            }
            return distObject;
        }

    }
}
