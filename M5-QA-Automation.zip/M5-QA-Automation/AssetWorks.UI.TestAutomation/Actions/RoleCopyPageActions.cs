﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class RoleCopyPageActions : RoleCopyPage
    {
        public RoleCopyPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Copy Existing Role Maintenance
        /// </summary>
        /// <param name="ExistingRoleName"></param>
        /// <returns></returns>
        public string CopyExistingRoleMaintenance(string ExistingRoleName)
        {
            Settings.Logger.Info(" Copy existing Role ");
            _extendpage.SwitchToContentFrame();
            _existingRoleInput.SetText(ExistingRoleName, "Old Role");
            string NewRoleName = CommonUtil.GetRandomStringWithSpecialChars(7);
            Driver.WaitForReady();
            _newRoleInput.SetText(NewRoleName, "Role Name");
            Driver.WaitForReady();
            _extendpage.EnterDescription(_newRoleDesc);
            _extendpage.Save();
            Driver.WaitForReady();
            Settings.Logger.Info($"Successfully created the Role Copy {NewRoleName}");
            return NewRoleName;
        }
    }
}
