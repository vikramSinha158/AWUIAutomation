﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;


namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class PayRollClassStepsPageActions : PartRollClassesStepsPage
    {
        public PayRollClassStepsPageActions(IWebDriver Driver) : base(Driver) { }       
        

      /// <summary>
      /// Create PayRoll Classes and Steps
      /// </summary>
      /// <param name="ObjectKey"></param>
      /// <returns></returns>
        public PayrollPayClassesAndSteps CreatePayRollClassesSteps(PayrollPayClassesAndSteps dataObject)
        {
            Settings.Logger.Info($"Creating PayrollClass: { dataObject.PayClass } and PayStep:{ dataObject.PayStep}");
            if (string.IsNullOrEmpty(dataObject.PayClass) || dataObject.PayClass.ToLower()=="random")
            {
                dataObject.PayClass = CommonUtil.GetRandomStringWithSpecialChars(6).ToUpper();
            }            
            string[] queryparam = { dataObject.PayClass, dataObject.PayStep };
            if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection, "PayRollClassesStepsQuery", queryparam, Settings.DBType))
            {               
                _extendpage.SwitchToContentFrame();
                Driver.SwitchToFrame(_frameEmpPayClass, "Table frame");
                _payClassNew.SetText(dataObject.PayClass, "PayClass");
                Driver.WaitForReady();
                _payStepNew.SetText(dataObject.PayStep, "PayStep");
                Driver.WaitForReady();
                _descNew.SetText(dataObject.Description, "Description");                
                 Driver.WaitForReady();
                _extendpage.Save();
                 Driver.WaitForReady();
                Assert.IsTrue(!CommonUtil.CheckDataExistWithMultipleParams(Settings.connection, "PayRollClassesStepsQuery", queryparam, Settings.DBType));
                Settings.Logger.Info($" PayrollClass: { dataObject.PayClass } and PayStep:{ dataObject.PayStep} Created Successfully");
            }
            return dataObject;
        }
    }
}
