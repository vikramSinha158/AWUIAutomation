﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Payroll;

namespace AssetWorks.UI.M5.TestAutomation.Actions.PayRoll
{
    internal class PayrollTimeTypeMatrixPageActions : PayrollTimeTypeMatrixPage
    {
        public PayrollTimeTypeMatrixPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Payroll Time Type
        /// </summary>
        /// <param name="types"></param>
        /// <returns></returns>
        public string CreatePayrollTimeTypeMatrix(TimeTypeMatrix matrix)
        {
            string Code = string.Empty;
            Settings.Logger.Info("Create Payroll Time Type");
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(matrix.BasePay, ref Code, "TimeTypeMatrixQuery", 3))
            {
                _extendedPage.SwitchToTableFrame(_frameMatrix);
                _newBasePay.SetText(Code, "Base Pay");
                Driver.WaitForReady();
                _newOvertime.SetText(matrix.Overtime, "Overtime");
                Driver.WaitForReady();
                _newDoubletime.SetText(matrix.Doubletime, "Doubletime");
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
                Driver.WaitForReady();
                _extendedPage.ClickOnRefreshButton();
                _extendedPage.SwitchToTableFrame(_frameMatrix);
                _extendedPage.VerifyTableColumnContainValue(_tableMatrix, "Base Pay", Code);
                Driver.SwitchTo().DefaultContent();
            }
            return Code;
        }
    }
}
