﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Payroll;

namespace AssetWorks.UI.M5.TestAutomation.Actions.PayRoll
{
    internal class PayrollTimeTypesPageActions : PayrollTimeTypesPage
    {
        public PayrollTimeTypesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Payroll Time Type
        /// </summary>
        /// <param name="types"></param>
        /// <returns></returns>
        public string CreatePayrollTimeType(TimeTypes types)
        {
            string Code = string.Empty;
            Settings.Logger.Info("Create Payroll Time Type");
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(types.Code, ref Code, "TimeTypesQuery", 3))
            {
                _extendedPage.SwitchToTableFrame(_frameTimeType);
                _newCode.SetText(Code, "Code");
                Driver.WaitForReady();
                _newDesc.SetText(types.Description, "Description");
                Driver.WaitForReady();
                _newMaxHours.SetText(types.MaxHours, "Max Hours");
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
                Driver.WaitForReady();
                _extendedPage.ClickOnRefreshButton();
                _extendedPage.SwitchToTableFrame(_frameTimeType);
                _extendedPage.VerifyTableColumnContainValue(_tableTimeType, "Code", Code);
                Driver.SwitchTo().DefaultContent();
            }
            return Code;
        }
    }
}
