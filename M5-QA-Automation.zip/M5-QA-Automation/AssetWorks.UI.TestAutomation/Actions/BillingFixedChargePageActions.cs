﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.Core.Utils;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class BillingFixedChargePageActions : BillingFixedChargePage
    {
        public BillingFixedChargePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Add Billing Fixed Charges
        /// </summary>
        public string AddBillingFixedCharges(BillingFixedCharge BillingFixedCharge)
        {
            string BillingIteCode = string.Empty;
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_billValidFixFrame, "_billValidFixFrame");
            if (!_extendpage.CheckDataExistenceAndGetActionCode(BillingFixedCharge.BillingItem, ref BillingIteCode, "BillingFixedChargeQuery"))
            {
                BillingFixedCharge.BillingItem = BillingIteCode;
                FillBillingFixedCharges(BillingFixedCharge);
            }
            Settings.Logger.Info(" Successfully Added Billing Fixed Charges");
            return BillingIteCode;
        }

        /// <summary>
        /// Verify Billing Fixed Charges
        /// </summary>
        public void VerifyBillingFixedCharges(BillingFixedCharge BillingFixedCharge, string BillitemCode)
        {
            RefreshAndMoveToBillingFixedFrame();
            string ActualbillitemValue = _extendpage.GetTableActionElementByRelatedColumnValue(_billValidFixTable, _headerBillItem, BillitemCode, _billitem).GetAttribute("value");
            CommonUtil.AssertTrue<string>(BillitemCode, ActualbillitemValue);
            string ActualbillDescValue = _extendpage.GetTableActionElementByRelatedColumnValue(_billValidFixTable, _headerBillItem, BillitemCode, _billDesc).GetAttribute("value");
            CommonUtil.AssertTrue<string>(BillingFixedCharge.Description, ActualbillDescValue);
            string ActualbilllimitValue = _extendpage.GetTableActionElementByRelatedColumnValue(_billValidFixTable, _headerBillItem, BillitemCode, _billlimit).GetAttribute("value"); ;
            CommonUtil.AssertTrue<string>(BillingFixedCharge.BillingLimit, ActualbilllimitValue);
            bool TaxStatus = _extendpage.GetTableActionElementByRelatedColumnValue(_billValidFixTable, _headerBillItem, BillitemCode, _billtax).Selected;
            CommonUtil.AssertTrue<bool>(BillingFixedCharge.Billtax, TaxStatus);
            Settings.Logger.Info(" Successfully Verified Billing Fixed Charges addiition ");
        }

        /// <summary>
        /// Delete New Added Billing Charges
        /// </summary>
        public void DeleteNewAddedBillingCharges(string BillitemValue)
        {
            RefreshAndMoveToBillingFixedFrame();
            _extendpage.GetTableActionElementByRelatedColumnValue(_billValidFixTable, _headerBillItem, BillitemValue, _billitem).Click();
            _extendpage.DeleteAndSave();
            Settings.Logger.Info($" Successfully Deleted New added Billing Item { BillitemValue } Billing Charges ");
        }

        /// <summary>
        /// Refresh And Move To Billing Fi9xed Frame
        /// </summary>
        private void RefreshAndMoveToBillingFixedFrame()
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_billValidFixFrame, "_billValidFixFrame");
            Settings.Logger.Info(" Refresh Fixed Charges addiition  ");
        }

        /// <summary>
        /// Add Multiple Billing Fixed Charges
        /// </summary>
        /// <param name="BillingFixedCharge"></param>
        /// <returns></returns>
        public List<string>? AddMultipleBillingFixedCharges(List<BillingFixedCharge> BillingFixedCharges)
        {
            List<string> BillingItemList = new List<string>();
            foreach (BillingFixedCharge BillingItemDetail in BillingFixedCharges)
            {
                string BillingItem = AddBillingFixedCharges(BillingItemDetail);
                BillingItemList.Add(BillingItem);
                Driver.SwitchTo().DefaultContent();
                _extendpage.ClickOnRefreshButton();
            }
            return BillingItemList;
        }

        /// <summary>
        /// Delete Multiple Bill Item
        /// </summary>
        /// <param name="BillingFixedCharges"></param>
        public void DeleteMultipleBillItem(List<string> BillingFixedCharges)
        {
            foreach (string BillingItemCode in BillingFixedCharges)
            {
                DeleteNewAddedBillingCharges(BillingItemCode);
            }
        }

        /// <summary>
        /// Fill Billing Fixed Charges
        /// </summary>
        /// <param name="BillingFixedCharge"></param>
        public void FillBillingFixedCharges(BillingFixedCharge BillingFixedCharge)
        {
            _extendpage.GetTableActionElementByRelatedColumnValue(_billValidFixTable, _headerBillItem, "", _billitem).SetText(BillingFixedCharge.BillingItem, "billitem");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_billValidFixTable, _headerBillItem, BillingFixedCharge.BillingItem, _billDesc).SetText(BillingFixedCharge.Description, "billDesc");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_billValidFixTable, _headerBillItem, BillingFixedCharge.BillingItem, _billlimit).SetText(BillingFixedCharge.BillingLimit, "BillingLimit");
            Driver.WaitForReady();
            IWebElement BilltaxFl = _extendpage.GetTableActionElementByRelatedColumnValue(_billValidFixTable, _headerBillItem, BillingFixedCharge.BillingItem, _billtax);
            _extendpage.SetCheckBox(BilltaxFl, "BilltaxFl", BillingFixedCharge.Billtax);
            _extendpage.Save();
            Settings.Logger.Info(" Added Billing Fixed Charges ");
        }

        /// <summary>
        /// Update Billing Fixed Charges
        /// </summary>
        /// <param name="BillingFixedCharge"></param>
        public void UpdateBillingFixedCharges(BillingFixedCharge BillingFixedCharge)
        {
            RefreshAndMoveToBillingFixedFrame();
            FillBillingFixedCharges(BillingFixedCharge);
            Settings.Logger.Info(" Successfully Verified Billing Fixed Charges addiition ");
        }

        /// <summary>
        /// Verify Billing FixedCharge Deletion
        /// </summary>
        /// <param name="BillingItemCode"></param>
        public void VerifyBillingFixedChargeDeletion(string BillingItemCode)
        {
            RefreshAndMoveToBillingFixedFrame();
            _extendpage.VerifyTableColumnDoesNotContainValue(_billValidFixTable, _headerBillItem, BillingItemCode);
            Settings.Logger.Info($" Successfully Verified Billing Fixed Charges Deletion {BillingItemCode}  ");
        }
    }
}
