﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class UnitDepartmentChangePageActions : UnitDepartmentChangePage
    {
        public UnitDepartmentChangePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Enter unit number and press tab key
        /// </summary>
        /// <param name="UnitNumber"></param>
        public void EnterUnitNumberAndPressTab(string UnitNumber)
        {
            Settings.Logger.Info("Enter Unit Number ");
            _inputUnitNo.SetText(UnitNumber, "Unit No", Driver, _extendedPage._contentFrame, "Content frame");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Search Unit No By Owner Department
        /// </summary>
        /// <param name="Keyword"></param>
        public void SearchUnitNoByOwnerDepartment(string Keyword)
        {
            Settings.Logger.Info("Search For Unit Number ");
            _extendedPage.SwitchToContentFrame();
            Driver.DoubleClick(_inputUnitNo, " input unit number ");
            Driver.SwitchTo().DefaultContent();
            _lov.EnterDesiredFilterKeywordAndSelectRecord(CommonUtil.DataForKey(Keyword), "Owner Department");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Search Unit No By Using Department
        /// </summary>
        /// <param name="Keyword"></param>
        public void SearchUnitNoByUsingDepartment(string Keyword)
        {
            Settings.Logger.Info("Search For Unit Number ");
            _extendedPage.SwitchToContentFrame();
            Driver.DoubleClick(_inputUnitNo, " input unit number ");
            Driver.SwitchTo().DefaultContent();
            _lov.EnterDesiredFilterKeywordAndSelectRecord(CommonUtil.DataForKey(Keyword), "Using Department");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Set unit department details
        /// </summary>
        public void SetUnitDepartmentNumberDetails()
        {
            Settings.Logger.Info("Set Unit Department Number Details ");
            _extendedPage.SwitchToContentFrame();
            _unitNumber = _inputUnitNo.GetElementValueByAttribute("ovalue");
            _deptOwning = _inputOwningDeptNo.GetElementValueByAttribute("ovalue");
            _deptUsing = _inputUsingDeptNo.GetElementValueByAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Department Details
        /// </summary>
        /// <param name="Owning"></param>
        /// <param name="Using"></param>
        /// <exception cref="Exception"></exception>
        public void VerifyDepartmentDetails(string Owning, string Using)
        {
            SetUnitDepartmentNumberDetails();
            if (Owning != null && Using != null)
            {
                Assert.AreEqual(_deptOwning, CommonUtil.DataForKey(Owning), "Department owning doesn't mached.");
                Assert.AreEqual(_deptUsing, CommonUtil.DataForKey(Using), "Department using doesn't mached.");
                Settings.Logger.Info($" Matched Actual dept owner : {_deptOwning} with expacted {_deptOwning}");
                Settings.Logger.Info($" Matched Actual dept using : {_deptUsing} with expacted {_deptUsing}");
            }
            else
                throw new Exception("Input required.!");
        }

        /// <summary>
        /// Search and select Owning Dept No
        /// </summary>
        /// <param name="DeptNumber"></param>
        public void SearchAndSelectOwningDeptNo(string DeptNumber)
        {
            Settings.Logger.Info("Search For Owning Department Number ");
            _extendedPage.SwitchToContentFrame();
            Driver.DoubleClick(_inputOwningDeptNo, " input Owning department no ");
            Driver.SwitchTo().DefaultContent();
            _lov.SearchAndSelectFirstRowData(DeptNumber);
            Driver.WaitForReady();
        }

        /// <summary>
        /// Search and select Using Dept No
        /// </summary>
        /// <param name="DeptNumber"></param>
        public void SearchAndSelectUsingDeptNo(string DeptNumber)
        {
            Settings.Logger.Info("Search For Using Department Number ");
            _extendedPage.SwitchToContentFrame();
            Driver.DoubleClick(_inputUsingDeptNo, " input Using department no ");
            Driver.SwitchTo().DefaultContent();
            _lov.SearchAndSelectFirstRowData(DeptNumber);
            Driver.WaitForReady();
        }

        /// <summary>
        /// Update Unit Departments
        /// </summary>
        /// <param name="Owning"></param>
        /// <param name="Using"></param>
        public void UpdateUnitDepartments(string Owning, string Using)
        {
            SearchAndSelectOwningDeptNo(CommonUtil.DataForKey(Owning));
            SearchAndSelectUsingDeptNo(CommonUtil.DataForKey(Using));
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Refresh And Verify Unit Department Details
        /// </summary>
        /// <param name="Owning"></param>
        /// <param name="Using"></param>
        public void RefreshAndVerifyUnitDepartmentDetails(string Owning, string Using)
        {
            _extendedPage.ClickOnRefreshButton();
            EnterUnitNumberAndPressTab(_unitNumber);
            VerifyDepartmentDetails(Owning, Using);
        }
    }
}
