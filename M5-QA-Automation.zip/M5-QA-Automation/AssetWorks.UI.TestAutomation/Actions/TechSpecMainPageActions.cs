﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SystemException = AssetWorks.UI.M5.TestAutomation.TestDataObjects.SystemException;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class TechSpecMainPageActions : TechSpecMainPage
    {
        public TechSpecMainPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Tech Spec
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <returns></returns>
        public string CreateTechSpec(TechSpecMain DataObject, string RequiredTechSpec = "random")
        {
            Settings.Logger.Info(" Creating Tech Spec ");
            string TechSpecNo = String.Empty;
            if (!_extendpage.CheckDataExistenceAndGetActionCode(RequiredTechSpec, ref TechSpecNo, "TechSpecQuery"))
            {
                _extendpage.SwitchToContentFrame();
                _techSpecNoInput.SetText(TechSpecNo, "TechSpec No");
                Settings.Logger.Info("Giving Tech SpecNo  as:" + TechSpecNo);
                Driver.SwitchTo().DefaultContent();
                _extendpage.ActionRequiredWindow("Create");
                _extendpage.SwitchToContentFrame();
                _extendpage.EnterDescription(_techSpecDesc);
                if (DataObject.DetailTab != null && DataObject.DetailTab.FillTechSpecDetail == "Yes")
                {
                    FillTechSpecDetail(DataObject);
                }
                if (DataObject.ProductsTab != null && DataObject.ProductsTab.FillProductsTab == "Yes")
                {
                    FillProductsTab(DataObject);
                }
                if (DataObject.ExceptionTab != null && DataObject.ExceptionTab.FillExceptionTab == "Yes")
                {
                    FillExceptionsTab(DataObject);
                }
                if (DataObject.AssocTechSpecTab != null && DataObject.AssocTechSpecTab.FillAssocTechSpecTab == "Yes")
                {
                    FillAssocTechSpecTab(DataObject);
                }
                if (DataObject.DocumentTypesTab != null && DataObject.DocumentTypesTab.FillDocumentTypesTab == "Yes")
                {
                    FillDocumentTypesTab(DataObject);
                }
                if (DataObject.ZonesTab != null && DataObject.ZonesTab.FillZonesTab == "Yes")
                {
                    FillZonesTab(DataObject);
                }
                Driver.SwitchTo().DefaultContent();
                _extendpage.VerifyCreatedActionNumber(_techSpecNoInput, TechSpecNo);
            }
            return TechSpecNo;
        }

        /// <summary>
        /// Fill Tech Spec Detail
        /// </summary>
        public void FillTechSpecDetail(TechSpecMain TechSpac)
        {
            Settings.Logger.Info(" Filling TechSpec Detail ");
            _yearInput.SetText(TechSpac.DetailTab.Year, "Tech Spec ");
            Driver.WaitForReady();
            _mfgInput.SetText(TechSpac.DetailTab.Manufacturer, " Manufacturer ");
            Driver.WaitForReady();
            _makeInput.SetText(TechSpac.DetailTab.Make, " Manufacturer ");
            Driver.WaitForReady();
            _modelInput.SetText(TechSpac.DetailTab.Model, " Model ");
            Driver.WaitForReady();
            _trimInput.SetText(TechSpac.DetailTab.Trim, "Trim  ");
            Driver.WaitForReady();
            _referenceInput.SetText(TechSpac.DetailTab.Reference, " ReferenceValue  ");
            Driver.WaitForReady();
            _licClassCodeInput.SetText(TechSpac.DetailTab.LicenseClassCode, "licClass Code");
            Driver.WaitForReady();
            _categoryInput.SetText(TechSpac.DetailTab.CategoryNumber, "CategoryNumbe");
            Driver.WaitForReady();
            Driver.WaitForReady();
            _replacementInput.SetText(TechSpac.DetailTab.Replacement, "replacement");
            Driver.WaitForReady();
            _gVWInput.SetText(TechSpac.DetailTab.GrossVehicleWeight, "Gross Vehicle Weight:");           
            Driver.WaitForReady();
            _offHwyPctInput.SetText(TechSpac.DetailTab.OffRoadUse, "Off-Road Use");
            Driver.WaitForReady();
            _testSuiteNameInput.SetText(TechSpac.DetailTab.TestSuite, "test Suite Name");
            Driver.WaitForReady();
            _techSpacNoteValue = _extendpage.EnterDescription(_techSpacNote);
            Driver.WaitForReady();
            _techSpecWONoteValue = _extendpage.EnterDescription(_techSpecWONote);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Fill Products Tab
        /// </summary>
        public void FillProductsTab(TechSpecMain TechSpac)
        {
            Settings.Logger.Info(" Filling Products Tab");
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _productTab.ClickElement("product Tab", Driver);
            _vehType.SelectFilterValueHavingEqualValue(TechSpac.ProductsTab.VehicleType);
            _fuelClass.SelectFilterValueHavingEqualValue(TechSpac.ProductsTab.FuelClass);
            Driver.WaitForReady();
            _uPQCity.SetText(TechSpac.ProductsTab.FuelEconomyCity, "Fuel Economy City");
            Driver.WaitForReady();
            _uPQHighway.SetText(TechSpac.ProductsTab.FuelEconomyHighway, "Fuel Economy Highway");
            Driver.WaitForReady();
            _uPQCombined.SetText(TechSpac.ProductsTab.FuelEconomyCombined, "_Fuel Economy Combined:");
            Driver.SwitchToFrame(_techSpecProdFrame, "techSpecProdFrame");
            if(TechSpac.ProductsTab.Products!=null)
            {
                List<Product> ProductList = TechSpac.ProductsTab.Products;
                int RowNum = 0;
                foreach (Product productItem in ProductList)
                {
                    AddProducts(RowNum, productItem);
                    RowNum++;
                }
            }     
        }

        /// <summary>
        /// AddP products in product tab
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void AddProducts(int RowNum, Product DataObject)
        {
            if (DataObject != null)
            {
                Settings.Logger.Info(" verifying added Fluid information ");
                _product_no = _extendpage.GetInputElementAndSetValue($"{_techSpecProduct}{RowNum}", DataObject.ProducCode, "name");
                Driver.WaitForReady();
                _capacity = _extendpage.GetInputElementAndSetValue($"{_techSpecCapacity}{RowNum}", DataObject.ProducCapacity, "name");
                Driver.WaitForReady();
                _maxDailyFuelings = _extendpage.GetInputElementAndSetValue($"{_techSpecMaxDailyFueling}{RowNum}", DataObject.Fuelings, "name");
                Driver.WaitForReady();
                _maxDailyQty = _extendpage.GetInputElementAndSetValue($"{_techSpecMaxDailyQty}{RowNum}", DataObject.MaxDailyQty, "name");
                Driver.WaitForReady();
                _priCheckbpx = _extendpage.GetElementForInput($"{_techSpecPri}{RowNum}","name");
                _priCheckbpx.SelectCheckBox("Pri Checkbox", DataObject.PriStatus);
                Driver.WaitForReady();
                _secCheckbox = _extendpage.GetElementForInput($"{_techSpecSec}{RowNum}","name");
                _secCheckbox.SelectCheckBox("Pri Checkbox", DataObject.SecStatus);
                Driver.SwitchTo().DefaultContent();
            }
            else { Assert.Fail("Data not vailable for prduct tab  "); }
        }

        /// <summary>
        /// Verify Tech Spec Information
        /// </summary>
        /// <param name="ObjectKey"></param>
        public void VerifyTechSpecInformation(string ObjectKey,string TechSpechNo)
        {
            TechSpecMain DataObject  = CommonUtil.DataObjectForKey(ObjectKey).ToObject<TechSpecMain>();
            _extendpage.RefreshAndSetText(_techSpecNoInput, TechSpechNo, "Tech Spec");
            if (DataObject.DetailTab!=null && DataObject.DetailTab.FillTechSpecDetail == "Yes")
            {
                VerifyDetailTab(DataObject);
            }
            if (DataObject.ProductsTab!=null && DataObject.ProductsTab.FillProductsTab == "Yes")
            {
                VerifyProductTab(DataObject);
            }
            if (DataObject.ExceptionTab != null && DataObject.ExceptionTab.FillExceptionTab == "Yes")
            {
                VerifyExceptionsTab(DataObject);
            }
            if (DataObject.AssocTechSpecTab != null && DataObject.AssocTechSpecTab.FillAssocTechSpecTab == "Yes")
            {
                VerifyAssocTechSpecTab(DataObject);
            }
            if (DataObject.DocumentTypesTab != null && DataObject.DocumentTypesTab.FillDocumentTypesTab == "Yes")
            {
                VerifyDocumentTypeTab(DataObject);
            }
            if (DataObject.ZonesTab != null &&  DataObject.ZonesTab.FillZonesTab == "Yes")
            {
                VerifyZonesTab(DataObject); ;
            }
            Settings.Logger.Info(" Successfully Verified Tech Spec Information");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Detail Tab
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyDetailTab(TechSpecMain DataObject)
        {
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_yearInput, "Year", DataObject.DetailTab.Year);
            CommonUtil.VerifyElementValue(_mfgInput, "Manufacturer", DataObject.DetailTab.Manufacturer);
            CommonUtil.VerifyElementValue(_makeInput, "Make", DataObject.DetailTab.Make);
            CommonUtil.VerifyElementValue(_modelInput, "Model", DataObject.DetailTab.Model);
            CommonUtil.VerifyElementValue(_trimInput, "trimValue", DataObject.DetailTab.Trim);
            CommonUtil.VerifyElementValue(_referenceInput, "referenceValue", DataObject.DetailTab.Reference);
            CommonUtil.VerifyElementValue(_licClassCodeInput, "License Class Code", DataObject.DetailTab.LicenseClassCode);
            CommonUtil.VerifyElementValue(_categoryInput, "Category Number", DataObject.DetailTab.CategoryNumber);
            CommonUtil.VerifyElementValue(_replacementInput, "replacementValue", DataObject.DetailTab.Replacement);
            CommonUtil.VerifyElementValue(_gVWInput, "gVWValue", DataObject.DetailTab.GrossVehicleWeight);
            CommonUtil.VerifyElementValue(_offHwyPctInput, "offHwyPctValue", DataObject.DetailTab.OffRoadUse);
            CommonUtil.VerifyElementValue(_testSuiteNameInput, "TestSuite", DataObject.DetailTab.TestSuite);
            CommonUtil.VerifyElementValue(_techSpacNote, "techSpacNoteValue", _techSpacNoteValue);
            CommonUtil.VerifyElementValue(_techSpecWONote, "techSpecWONoteValue", _techSpecWONoteValue);
            Settings.Logger.Info(" Successfully Verified Detail Tab in Tech Spec ");
        }

        /// <summary>
        /// Verify Product Tab
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyProductTab(TechSpecMain DataObject)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _productTab.ClickElement("product Tab", Driver);
            CommonUtil.VerifyElementValue(_vehType, "VehicleT ype", DataObject.ProductsTab.VehicleType, true);
            CommonUtil.VerifyElementValue(_fuelClass, "FuelClass", DataObject.ProductsTab.FuelClass, true);
            CommonUtil.VerifyElementValue(_uPQCity, "_uPQCityValue", DataObject.ProductsTab.FuelEconomyCity);
            CommonUtil.VerifyElementValue(_uPQHighway, "uPQHighwayValue", DataObject.ProductsTab.FuelEconomyHighway);
            CommonUtil.VerifyElementValue(_uPQCombined, "uPQCombinedValue", DataObject.ProductsTab.FuelEconomyCombined);
            Driver.SwitchToFrame(_techSpecProdFrame, "techSpecProdFrame");
            List<Product> ProductItems = DataObject.ProductsTab.Products;
            for (int RowNum = 0; RowNum < ProductItems.Count; RowNum++)
            {
                if (RowNum == 0)
                {
                    _product_no = _extendpage.GetElementForInput($"{"product_no$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_product_no, "Produc Code", ProductItems[RowNum].ProducCode, false, "value");
                    _capacity = _extendpage.GetElementForInput($"{"Capacity$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_capacity, "Produc Capacity", ProductItems[RowNum].ProducCapacity, false, "value");
                    _maxDailyFuelings = _extendpage.GetElementForInput($"{"max_daily_fuelings$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_maxDailyFuelings, "Fuelings", ProductItems[RowNum].Fuelings, false, "value");
                    _maxDailyQty = _extendpage.GetElementForInput($"{"max_daily_qty$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_maxDailyQty, "Max Daily Qty", ProductItems[RowNum].MaxDailyQty, false, "value");
                }              
                if (ProductItems.Count > 1) {
                    VerifyProductDetail(RowNum, ProductItems[RowNum++]);
                }          
            }
            Settings.Logger.Info(" Successfully Verified Produc tTab in Tech Spec ");
        }

        /// <summary>
        /// Verify Produc tDetail
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void VerifyProductDetail(int RowNum, Product DataObject)
        {
            _product_no = null;
            _capacity = null;
            _maxDailyFuelings = null;
            _maxDailyQty = null;
            _product_no = _extendpage.GetElementForInput($"{_techSpecProduct}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_product_no, "Produc Code", DataObject.ProducCode);
            _capacity = _extendpage.GetElementForInput($"{_techSpecCapacity}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_capacity, "Produc Capacity", DataObject.ProducCapacity);
            _maxDailyFuelings = _extendpage.GetElementForInput($"{_techSpecMaxDailyFueling}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_maxDailyFuelings, "Fuelings", DataObject.Fuelings);
            _maxDailyQty = _extendpage.GetElementForInput($"{_techSpecMaxDailyQty}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_maxDailyQty, "Max Daily Qty", DataObject.MaxDailyQty);
        }

        /// <summary>
        /// FillExceptions Tab
        /// </summary>
        public void FillExceptionsTab(TechSpecMain TechSpac)
         {
            Settings.Logger.Info(" Filling Exceptions Tab ");
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _exceptionsTab.ClickElement("product Tab", Driver);
             Driver.WaitForReady();
            _totalWOCostInput.SetText(TechSpac.ExceptionTab.TotalWOCost, "total WO Cost");
             Driver.WaitForReady();
            _maintCostsInput.SetText(TechSpac.ExceptionTab.MaintenanceCost, "Maintenance Cost");
            Driver.WaitForReady();
            _lTDTotMaintCostsInput.SetText(TechSpac.ExceptionTab.LTDMaintenanceCost, " LTD Maintenance Cost");
            Driver.SwitchToFrame(_techSpecReasonFrame, "techSpecReasonFrame");
            int RowNum = 0;
            foreach(ReasonException ReasonException in TechSpac.ExceptionTab.ReasonExceptions)
            {
                AddReasonException(RowNum, ReasonException);
                RowNum++;
            }
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_techSpecSysFrame, "techSpecSysFrame");
            RowNum = 0;
            foreach(SystemException SystemException in TechSpac.ExceptionTab.SystemExceptions)
            {
                AddSystemException(RowNum, SystemException);
                RowNum++;
            }          
        }

        /// <summary>
        /// AddReason Exception
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        private void AddReasonException(int RowNum, ReasonException DataObject)
        {
            _reasoncode = null;
            _estPrompt = null;
            _jobMaxCost = null;
            _sysJobMaxHrs = null;
            _lTDMaxCost = null;
            _reasoncode = _extendpage.GetInputElementAndSetValue($"{_reasoncodeName}{RowNum}", DataObject.ReasonCode, "name");
            Driver.WaitForReady();
            _estPrompt = _extendpage.GetInputElementAndSetValue($"{_estPromptName}{RowNum}", DataObject.EstimatePrompt, "name");
            Driver.WaitForReady();
            _jobMaxCost = _extendpage.GetInputElementAndSetValue($"{_jobMaxCostName}{RowNum}", DataObject.JobMaxCost, "name");
            Driver.WaitForReady();
            _sysJobMaxHrs = _extendpage.GetInputElementAndSetValue($"{_sysJobMaxHrsName}{RowNum}", DataObject.JobMaxHrs, "name");
            Driver.WaitForReady();
            _lTDMaxCost = _extendpage.GetInputElementAndSetValue($"{_lTDMaxCostName}{RowNum}", DataObject.LTDMaxCost, "name");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Add System Exception
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        private void AddSystemException(int RowNum, SystemException DataObject)
        {
            _systemcode = null;
            _sysEstPrompt = null;
            _sysJobMaxCost = null;
            _sysJobMaxHr = null;
            _sysLTDMaxCost = null;
            _systemcode = _extendpage.GetInputElementAndSetValue($"{_systemcodeName}{RowNum}", DataObject.SystemExceptionCode, "name");
            Driver.WaitForReady();
            _sysEstPrompt = _extendpage.GetInputElementAndSetValue($"{_sysEstPromptName}{RowNum}", DataObject.SysEstimatePrompt, "name");
            Driver.WaitForReady();
            _sysJobMaxCost = _extendpage.GetInputElementAndSetValue($"{_sysJobMaxCostName}{RowNum}", DataObject.SysJobMaxCost, "name");
            Driver.WaitForReady();
            _sysJobMaxHr = _extendpage.GetInputElementAndSetValue($"{_sysJobMaxHrName}{RowNum}", DataObject.SysJobMaxHrs, "name");
            Driver.WaitForReady();
            _sysLTDMaxCost = _extendpage.GetInputElementAndSetValue($"{_sysLTDMaxCostName}{RowNum}", DataObject.SysLTDMaxCost, "name");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Exceptions Tab
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyExceptionsTab(TechSpecMain DataObject)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _exceptionsTab.ClickElement("product Tab", Driver);
            CommonUtil.VerifyElementValue(_totalWOCostInput, "Total WOCost",DataObject.ExceptionTab.TotalWOCost);
            CommonUtil.VerifyElementValue(_maintCostsInput, "Maintenance Cost",DataObject.ExceptionTab.MaintenanceCost);
            CommonUtil.VerifyElementValue(_lTDTotMaintCostsInput, "LTD Maintenance Cost",DataObject.ExceptionTab.LTDMaintenanceCost);
            Driver.SwitchToFrame(_techSpecReasonFrame, "techSpecReasonFrame");
            List<ReasonException> ReasonExceptionsList = DataObject.ExceptionTab.ReasonExceptions;
            for (int RowNum = 0; RowNum < ReasonExceptionsList.Count; RowNum++)
            {
                if (RowNum == 0)
                {
                    _reasoncode = _extendpage.GetElementForInput($"{"reasoncode$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_reasoncode, "Reason Code", ReasonExceptionsList[RowNum].ReasonCode,false, "value");
                    _estPrompt = _extendpage.GetElementForInput($"{"EstPrompt$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_estPrompt, "Estimate Prompt", ReasonExceptionsList[RowNum].EstimatePrompt, false, "value");
                    _jobMaxCost = _extendpage.GetElementForInput($"{"JobMaxCost$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_jobMaxCost, "Job Max Cost", ReasonExceptionsList[RowNum].JobMaxCost, false, "value");
                    _sysJobMaxHrs = _extendpage.GetElementForInput($"{"JobMaxHrs$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_sysJobMaxHrs, " Job Max Hrs", ReasonExceptionsList[RowNum].JobMaxHrs, false, "value");
                    _lTDMaxCost = _extendpage.GetElementForInput($"{"LTDMaxCost$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_lTDMaxCost, "LTD Max Cost", ReasonExceptionsList[RowNum].LTDMaxCost, false, "value");
                }
                if (ReasonExceptionsList.Count > 1)
                {
                    VerifyReasonException(RowNum, ReasonExceptionsList[RowNum++]);
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_techSpecSysFrame, "techSpecSysFrame");
            List<SystemException> SystemExceptionList = DataObject.ExceptionTab.SystemExceptions;
            for (int RowNum = 0; RowNum < SystemExceptionList.Count; RowNum++)
            {
                if (RowNum == 0)
                {
                    _systemcode = _extendpage.GetElementForInput($"{"system_code$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_systemcode, "System Exception Code", SystemExceptionList[RowNum].SystemExceptionCode, false, "value");
                    _sysEstPrompt = _extendpage.GetElementForInput($"{"SysEstPrompt$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_sysEstPrompt, "Sys Estimate Prompt", SystemExceptionList[RowNum].SysEstimatePrompt, false, "value");
                    _sysJobMaxCost = _extendpage.GetElementForInput($"{"SysJobMaxCost$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_sysJobMaxCost, "SysJob Max Cost", SystemExceptionList[RowNum].SysJobMaxCost, false, "value");
                    _sysJobMaxHr = _extendpage.GetElementForInput($"{"SysJobMaxHrs$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_sysJobMaxHr, "Sys Job Max Hrs", SystemExceptionList[RowNum].SysJobMaxHrs, false, "value");
                    _sysLTDMaxCost = _extendpage.GetElementForInput($"{"SysLTDMaxCost$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_sysLTDMaxCost, "Sys LTD Max Cost", SystemExceptionList[RowNum].SysLTDMaxCost, false, "value");
                }
                if (SystemExceptionList.Count > 1)
                {
                    VerifySystemException(RowNum, SystemExceptionList[RowNum++]);
                }
            }
            Settings.Logger.Info(" Successfully Verified Exceptions Tab in Tech Spec ");
        }

        /// <summary>
        /// Verify Reason Exception
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        private void VerifyReasonException(int RowNum, ReasonException DataObject)
        {
            _reasoncode = null;
            _estPrompt = null;
            _jobMaxCost = null;
            _sysJobMaxHrs = null;
            _lTDMaxCost = null;
            _reasoncode = _extendpage.GetElementForInput($"{_reasoncodeName}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_reasoncode, "Reason Code", DataObject.ReasonCode);
            _estPrompt = _extendpage.GetElementForInput($"{_estPromptName}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_estPrompt, "Estimate Prompt", DataObject.EstimatePrompt);
            _jobMaxCost = _extendpage.GetElementForInput($"{_jobMaxCostName}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_jobMaxCost, "Job Max Cost", DataObject.JobMaxCost);
            _sysJobMaxHrs = _extendpage.GetElementForInput($"{_sysJobMaxHrsName}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_sysJobMaxHrs, " Job Max Hrs", DataObject.JobMaxHrs);
            _lTDMaxCost = _extendpage.GetElementForInput($"{_lTDMaxCostName}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_lTDMaxCost, "LTD Max Cost", DataObject.LTDMaxCost);
        }

        /// <summary>
        /// Verify System Exception
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        private void VerifySystemException(int RowNum, SystemException DataObject)
        {
            _systemcode = null;
            _sysEstPrompt = null;
            _sysJobMaxCost = null;
            _sysJobMaxHr = null;
            _sysLTDMaxCost = null;
            _systemcode = _extendpage.GetElementForInput($"{_systemcodeName}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_systemcode, "System Exception Code", DataObject.SystemExceptionCode);
            _sysEstPrompt = _extendpage.GetElementForInput($"{_sysEstPromptName}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_sysEstPrompt, "Sys Estimate Prompt", DataObject.SysEstimatePrompt);
            _sysJobMaxCost = _extendpage.GetElementForInput($"{_sysJobMaxCostName}{RowNum}","name");
            CommonUtil.VerifyElementValue(_sysJobMaxCost, "SysJob Max Cost", DataObject.SysJobMaxCost);
            _sysJobMaxHr = _extendpage.GetElementForInput($"{_sysJobMaxHrName}{RowNum}","name");
            CommonUtil.VerifyElementValue(_sysJobMaxHr, "Sys Job Max Hrs", DataObject.SysJobMaxHrs);
            _sysLTDMaxCost = _extendpage.GetElementForInput($"{_sysLTDMaxCostName}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_sysLTDMaxCost, "Sys LTD Max Cost", DataObject.SysLTDMaxCost);
        }

        /// <summary>
        /// Fill Assoc TechSpec Tab
        /// </summary>
        public void FillAssocTechSpecTab(TechSpecMain TechSpac)
        {
            Settings.Logger.Info(" Filling TechSpec Tab ");
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _assocTechSpecTab.ClickElement("Assoc Tech Spec Tab", Driver);
            Driver.SwitchToFrame(_assocTechSpecFrame, "_assocTechSpecFrame");
            List<AssocTechSpecRecord> AssocTechSpecList = TechSpac.AssocTechSpecTab.AssocTechSpecRecord;
            int RowNum = 0;
            foreach(AssocTechSpecRecord AssocTechSpec in AssocTechSpecList)
            {
                AddAssocTechSpec(RowNum, AssocTechSpec);
                RowNum++;
            }          
        }

        /// <summary>
        /// Add Assoc Tech Spec
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void AddAssocTechSpec(int RowNum, AssocTechSpecRecord DataObject)
        {
            if (DataObject != null)
            {
                _assocSpec = null;
                _maxNoAssoc = null;
                _maxNoAssocPosn = null;
                _minNoAssoc = null;
                _assocJob = null;
                _minNoAssocSale = null;
                _assocSpec = _extendpage.GetInputElementAndSetValue($"{_assocSpecNo}{RowNum}", DataObject.AssocSpecNo, "name");
                Driver.WaitForReady();
                _maxNoAssoc = _extendpage.GetInputElementAndSetValue($"{_maxNoAssocName}{RowNum}", DataObject.MaxNoAssoc, "name");
                Driver.WaitForReady();
                _maxNoAssocPosn = _extendpage.GetInputElementAndSetValue($"{_maxNoAssocPosnName}{RowNum}", DataObject.MaxNoAssocPosn, "name");
                Driver.WaitForReady();
                _minNoAssoc = _extendpage.GetInputElementAndSetValue($"{_minNoAssocName}{RowNum}", DataObject.MinNoAssoc, "name");
                Driver.WaitForReady();
                _assocJob = _extendpage.GetInputElementAndSetValue($"{_assocJobName}{RowNum}", DataObject.AssocJob, "name");
                Driver.WaitForReady();
                _minNoAssocSale = _extendpage.GetInputElementAndSetValue($"{_minNoAssocSaleName}{RowNum}", DataObject.MinNoAssocSale, "name");
            }
            else { Assert.Fail("Data not vailable for Assoc Tech Spec  "); }
        }

        /// <summary>
        /// Verify Assoc Tech Spec Tab
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyAssocTechSpecTab(TechSpecMain DataObject)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _assocTechSpecTab.ClickElement("Assoc Tech Spec Tab", Driver);
            Driver.SwitchToFrame(_assocTechSpecFrame, "assoc Tech Spec Frame");
             List<AssocTechSpecRecord> AssocTechList = DataObject.AssocTechSpecTab.AssocTechSpecRecord;
            for (int RowNum = 0; RowNum < AssocTechList.Count; RowNum++)
            {
                if (RowNum == 0)
                {
                    _assocSpec = _extendpage.GetElementForInput($"{"assocSpecNo$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_assocSpec, "Assoc Spec No", AssocTechList[RowNum].AssocSpecNo,false, "value");
                    _maxNoAssoc = _extendpage.GetElementForInput($"{"maxNoAssoc$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_maxNoAssoc, "Max No Assoc", AssocTechList[RowNum].MaxNoAssoc, false, "value");
                    _maxNoAssocPosn = _extendpage.GetElementForInput($"{"maxNoAssocPosn$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_maxNoAssocPosn, "Max No Assoc Posn", AssocTechList[RowNum].MaxNoAssocPosn, false, "value");
                    _minNoAssoc = _extendpage.GetElementForInput($"{"minNoAssoc$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_minNoAssoc, "Min No Assoc", AssocTechList[RowNum].MinNoAssoc, false, "value");
                    _assocJob = _extendpage.GetElementForInput($"{"assocJob$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_assocJob, "Assoc Job", AssocTechList[RowNum].AssocJob, false, "value");
                    _minNoAssocSale = _extendpage.GetElementForInput($"{"minNoAssocSale$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_minNoAssocSale, "Min No Assoc Sale", AssocTechList[RowNum].MinNoAssocSale, false, "value");
                }
                if (AssocTechList.Count > 1)
                {
                    VerifyAssocTechSpecRecords(RowNum, AssocTechList[RowNum++]);
                }
            }
            Settings.Logger.Info(" Successfully Verified AssocTechSpec Tab in Tech Spec ");
        }

        /// <summary>
        /// Verify Assoc Tech Spec Records
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void VerifyAssocTechSpecRecords(int RowNum, AssocTechSpecRecord DataObject)
        {
            _assocSpec = null;
            _maxNoAssoc = null;
            _maxNoAssocPosn = null;
            _minNoAssoc = null;
            _assocJob = null;
            _minNoAssocSale = null;
            _assocSpec = _extendpage.GetElementForInput($"{_assocSpecNo}{RowNum}","name");
            CommonUtil.VerifyElementValue(_assocSpec, "Assoc Spec No", DataObject.AssocSpecNo);
            _maxNoAssoc = _extendpage.GetElementForInput($"{_maxNoAssocName}{RowNum}","name");
            CommonUtil.VerifyElementValue(_maxNoAssoc, "Max No Assoc", DataObject.MaxNoAssoc);
            _maxNoAssocPosn = _extendpage.GetElementForInput($"{_maxNoAssocPosnName}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_maxNoAssocPosn, "Max No Assoc Posn", DataObject.MaxNoAssocPosn);
            _minNoAssoc = _extendpage.GetElementForInput($"{_minNoAssocName}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_minNoAssoc, "Min No Assoc", DataObject.MinNoAssoc);
            _assocJob = _extendpage.GetElementForInput($"{_assocJobName}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_assocJob, "Assoc Job", DataObject.AssocJob);
            _minNoAssocSale = _extendpage.GetElementForInput($"{_minNoAssocSaleName}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_minNoAssocSale, "Min No Assoc Sale", DataObject.MinNoAssocSale);
        }

        /// <summary>
        /// Fill Document Types Tab
        /// </summary>
        public void FillDocumentTypesTab(TechSpecMain _techSpac)
        {
            Settings.Logger.Info(" Filling DocumentTypes Tab ");
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _documentTypesTab.ClickElement("Assoc Tech Spec Tab", Driver);
            Driver.SwitchToFrame(_docTypesFrame, "docTypesFrame");
            List<DocumentTypesRecord> DocumentTypesList = _techSpac.DocumentTypesTab.DocumentTypesRecords;
            int RowNum = 0;
            foreach (DocumentTypesRecord DocumentTypes in DocumentTypesList)
            {
                DocumentTypeRecord(RowNum, DocumentTypes);
                RowNum++;
            }
        }

        /// <summary>
        /// Fill DocumentTyp eRecord
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void DocumentTypeRecord(int RowNum, DocumentTypesRecord DataObject)
        {
            if (DataObject != null)
            {
                _docType = _extendpage.GetInputElementAndSetValue($"{_docTypeName}{RowNum}", DataObject.DocType, "name");
                bool ExpDatStatus = DataObject.ExpDate;
                _expDateCheckbox = _extendpage.GetElementForInput($"{_expDateCheckboxName}{RowNum}", "name");
                Driver.WaitForReady();
                _expDateCheckbox.SelectCheckBox("ExpDate Checkbox", ExpDatStatus);
                bool AttachFileStatus = DataObject.AttachFile;
                _attachFileCheckbox = _extendpage.GetElementForInput($"{_attachFileCheckboxName}{RowNum}", "name");
                Driver.WaitForReady();            
              _attachFileCheckbox.SelectCheckBox("AttachFileStatus Checkbox", AttachFileStatus);
            } 
            else { Assert.Fail("Data not vailable for Document Type Record "); }         
        }

        /// <summary>
        /// Verify Document Type Tab
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyDocumentTypeTab(dynamic DataObject)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _documentTypesTab.ClickElement("product Tab", Driver);       
            Driver.SwitchToFrame(_docTypesFrame, "_docTypesFrame");
            List<DocumentTypesRecord> DocumentTypesList = DataObject.DocumentTypesTab.DocumentTypesRecords;
            for (int RowNum = 0; RowNum < DocumentTypesList.Count; RowNum++)
            {
                if (RowNum == 0)
                {
                    _docType = _extendpage.GetElementForInput($"{"DOC_TYPE$"}{RowNum}", "name");
                    CommonUtil.VerifyElementValue(_docType, "Doc Type", DocumentTypesList[RowNum].DocType, false, "value");
                    _expDateCheckbox = _extendpage.GetElementForInput($"{"EXPDATE_FL$"}{RowNum}", "name");
                    CommonUtil.VerifyCheckboxState(_expDateCheckbox, "ExpDate", DocumentTypesList[RowNum].ExpDate);
                    _attachFileCheckbox = _extendpage.GetElementForInput($"{"ATTACH_FL$new_"}{RowNum}", "name");
                    CommonUtil.VerifyCheckboxState(_attachFileCheckbox, "Attach File", DocumentTypesList[RowNum].AttachFile);
                }
                if (DocumentTypesList.Count > 1)
                {
                    VerifyDocumentTypeRecords(RowNum, DocumentTypesList[RowNum++]);
                }
            }
            Settings.Logger.Info(" Successfully Verified DocumentType Tab in Tech Spec ");
        }

        /// <summary>
        /// Verify DocumentType Records
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void VerifyDocumentTypeRecords(int RowNum, DocumentTypesRecord DataObject) 
        {
           _docType = null;
           _expDateCheckbox = null;
            _attachFileCheckbox = null;
            _docType = _extendpage.GetElementForInput($"{_docTypeName}{RowNum}", "name");
            CommonUtil.VerifyElementValue(_docType, "Doc Type", DataObject.DocType);
            _expDateCheckbox = _extendpage.GetElementForInput($"{_expDateCheckboxName}{RowNum}", "name");
            CommonUtil.VerifyCheckboxState(_expDateCheckbox, "ExpDate", DataObject.ExpDate);
            _attachFileCheckbox = _extendpage.GetElementForInput($"{_attachFileCheckboxName}{RowNum}", "name");
            CommonUtil.VerifyCheckboxState(_attachFileCheckbox, "Attach File", DataObject.AttachFile);

        }

        /// <summary>
        /// Fill Zones Tab
        /// </summary>
        public void FillZonesTab(TechSpecMain TechSpac)
        {
            Settings.Logger.Info(" Filling Zones Tab ");
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _zonesTab.ClickElement("product Tab", Driver);
            _emisRateInput.SetText(TechSpac.ZonesTab.EmissionsRating, "Emissions Rating ");
            Driver.WaitForReady();
            _maxRangeInput.SetText(TechSpac.ZonesTab.MaxRange, "Max Range");
            Driver.WaitForReady();
            _batRangeInput.SetText(TechSpac.ZonesTab.BatteryRange, "Battery Range");
            Driver.WaitForReady();
            _batDensityInput.SetText(TechSpac.ZonesTab.BatteryDensity, "Battery Density ");
            Driver.WaitForReady();
            _zoneslicClassInput.SetText(TechSpac.ZonesTab.ZonesLicenseClass, "Zones License Class");
            Driver.WaitForReady();
            _starRateInput.SetText(TechSpac.ZonesTab.VisionStarRating, "Vision Star Rating");
            Driver.WaitForReady();
            _dvPermitCheckbox.SelectCheckBox("dvPermitCheckbox", TechSpac.ZonesTab.DirectVisionPermit);
             Driver.WaitForReady();
            _cameraCheckbox.SelectCheckBox("_cameraCheckbox", TechSpac.ZonesTab.Camera);
            Driver.WaitForReady();
            _cammentDetailInput.SetText(TechSpac.ZonesTab.CameraDetails, "_camment Detail");
            Driver.WaitForReady();
            _compYearInput.SetText(TechSpac.ZonesTab.ComplianceYear, "comp Year");
            Driver.WaitForReady();
            _coInput.SetText(TechSpac.ZonesTab.COEmissions, "CO Emissions");
            Driver.WaitForReady();
            _co2Input.SetText(TechSpac.ZonesTab.CO2Emissions, "CO2 Emissions");
            Driver.WaitForReady();
            _coaInput.SetText(TechSpac.ZonesTab.CO2AEmissions, "CO2A Emissions");
            Driver.WaitForReady();
            _hcInput.SetText(TechSpac.ZonesTab.HCEmissions, "HC Emissions");
            Driver.WaitForReady();
            _noxInput.SetText(TechSpac.ZonesTab.NOxEmissions, "NOx Emissions");
            Driver.WaitForReady();
            _pmInput.SetText(TechSpac.ZonesTab.PMEmissions, "PM Emissions");
            Driver.WaitForReady();
            _pm10Input.SetText(TechSpac.ZonesTab.PM10Emissions, "PM10 Emissions");
        }

        /// <summary>
        /// Verify Zones Tab
        /// </summary>
        /// <param name="TechSpec"></param>
        public void VerifyZonesTab(TechSpecMain TechSpec)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _zonesTab.ClickElement("product Tab", Driver);
            CommonUtil.VerifyElementValue(_emisRateInput, "Driver No", TechSpec.ZonesTab.EmissionsRating);
            CommonUtil.VerifyElementValue(_maxRangeInput, "Max Range Input", TechSpec.ZonesTab.MaxRange);
            CommonUtil.VerifyElementValue(_batRangeInput, "Battery Range", TechSpec.ZonesTab.BatteryRange);
            CommonUtil.VerifyElementValue(_batDensityInput, "Battery Density", TechSpec.ZonesTab.BatteryDensity);
            CommonUtil.VerifyElementValue(_zoneslicClassInput, "Zones License Class", TechSpec.ZonesTab.ZonesLicenseClass);
            CommonUtil.VerifyElementValue(_starRateInput, "Vision Star Rating", TechSpec.ZonesTab.VisionStarRating);
            CommonUtil.VerifyCheckboxState(_dvPermitCheckbox, "Direct Vision Permit", TechSpec.ZonesTab.DirectVisionPermit);
            CommonUtil.VerifyCheckboxState(_cameraCheckbox, "Camera", TechSpec.ZonesTab.Camera);
            CommonUtil.VerifyElementValue(_cammentDetailInput, "Camera Details", TechSpec.ZonesTab.CameraDetails);
            CommonUtil.VerifyElementValue(_compYearInput, "comp Year", TechSpec.ZonesTab.ComplianceYear);
            CommonUtil.VerifyElementValue(_coInput, "CO Emissions", TechSpec.ZonesTab.COEmissions);
            CommonUtil.VerifyElementValue(_co2Input, "CO2 Emissions", TechSpec.ZonesTab.CO2Emissions);
            CommonUtil.VerifyElementValue(_coaInput, "CO2A Emissions", TechSpec.ZonesTab.CO2AEmissions);
            CommonUtil.VerifyElementValue(_hcInput, "HC Emissions", TechSpec.ZonesTab.HCEmissions);
            CommonUtil.VerifyElementValue(_noxInput, "NOx Emissions", TechSpec.ZonesTab.NOxEmissions);
            CommonUtil.VerifyElementValue(_pmInput, "PM Emissions", TechSpec.ZonesTab.PMEmissions);
            CommonUtil.VerifyElementValue(_pm10Input, "PM10 Emissions", TechSpec.ZonesTab.PM10Emissions);
            Settings.Logger.Info(" Successfully Verified Zones Tab in Tech Spec ");
        }

        /// <summary>
        /// Update Tech Spec
        /// </summary>
        /// <param name="ObjectKey"></param>
        public void UpdateTechSpec(string ObjectKey)
        {
            TechSpecMain DataObject = CommonUtil.DataObjectForKey(ObjectKey).ToObject<TechSpecMain>();
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_techSpecNoInput, TechSpecObjects.TechSpecNumber, "Tech Spec");
            Driver.WaitForReady();
            _categoryInput.SetText(DataObject.DetailTab.CategoryNumber, "CategoryNumbe");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClicKSave();
        }

        /// <summary>
        /// Verify TechSpec Numbere Deletion
        /// </summary>
        public void VerifyTechSpecNumbereDeletion(string TechSpecNo)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.VerifyCodeDeletion(_techSpecNoInput, TechSpecNo, "TechSpec No ");
        }

        /// <summary>
        /// Verify Associated Tech Spec Not Deleted
        /// </summary>
        /// <param name="TechSpecNo"></param>
        /// <param name="AssociatedDeletionMessage"></param>
        public void VerifyAssociatedTechSpecNotDeleted(string TechSpecNo,string AssociatedDeletionMessage)
        {
            _extendpage.VerifyAssociatedCodeNotDeleted(_techSpecNoInput, TechSpecNo, AssociatedDeletionMessage);
        }
    }
}
