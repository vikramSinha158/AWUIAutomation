﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using System;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    public class PartMergePageActions : PartMergePage
    {
        public PartMergePageActions(IWebDriver Driver) : base(Driver) { }


        /// <summary>
        /// Create Part Merge
        /// </summary>
        /// <param name="partTobeEliminate"></param>
        /// <param name="partTobeRemain"></param>
        public void CreatePartMerge(PartsMainCatalog partTobeEliminate, PartsMainCatalog partTobeRemain)
        {
            Settings.Logger.Info(" Create Part Merge.");
            _extendedPage.SwitchToContentFrame();
            _partNo.SetText(partTobeEliminate.PartNumber, "Part number");
            Driver.WaitForReady();
            _extendedPage.VerifyElement(_manufacturer, partTobeEliminate.Manufacturer);
            _remainPartNo.SetText(partTobeRemain.PartNumber, "Remain Part Number");
            Driver.WaitForReady();
            _extendedPage.VerifyElement(_newManufacturer, partTobeRemain.Manufacturer);
            partTobeRemain.Details.MergeInfoCount = GetPartMergeCount();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Verify Part Merge Info Details
        /// </summary>
        /// <param name="partTobeEliminate"></param>
        /// <param name="partTobeRemain"></param>
        public void VerifyPartMergeInfoDetails(PartsMainCatalog partTobeEliminate, PartsMainCatalog partTobeRemain)
        {
            Settings.Logger.Info(" Verifying Created Part Merge info details.");
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            CommonUtil.AssertTrue(true, GetPartMergeCount() > partTobeRemain.Details.MergeInfoCount);
            partTobeRemain.Details.MergeInfoCount = GetPartMergeCount();
            Driver.SwitchToFrame(_partMergeFrame, " Part Merge ");
            CommonUtil.AssertTrue(true, _verifyMergedInfo(partTobeEliminate.PartNumber, partTobeRemain.PartNumber).VerifyElementDisplay("Remain Part Number"));
            CommonUtil.AssertTrue(true, _verifyMergedInfo(partTobeEliminate.PartNumber, partTobeEliminate.Manufacturer).VerifyElementDisplay("Old Manufacturer"));
            CommonUtil.AssertTrue(true, _verifyMergedInfo(partTobeEliminate.PartNumber, partTobeRemain.Manufacturer).VerifyElementDisplay("New Manufacturer"));
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Verified Created Part Merge info details Successfully!!");
        }

        /// <summary>
        /// Delete Part Merge Info
        /// </summary>
        /// <param name="partTobeEliminate"></param>
        /// <param name="partTobeRemain"></param>
        public void DeletePartMergeInfo(PartsMainCatalog partTobeEliminate, PartsMainCatalog partTobeRemain)
        {
            Settings.Logger.Info("Delete Part Merge info details.");
            _extendedPage.SwitchToTableFrame(_partMergeFrame);
            _verifyMergedInfo(partTobeEliminate.PartNumber, partTobeRemain.PartNumber).ClickElement("Remain Part Number", Driver);
            _extendedPage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Delete Part Merge Info
        /// </summary>
        /// <param name="partTobeRemain"></param>
        public void VerifyDeletePartMergeInfoDetails(PartsMainCatalog partTobeRemain)
        {
            Settings.Logger.Info(" Verifying Delete Part Merge info details.");
            _extendedPage.SwitchToContentFrame();
            CommonUtil.AssertTrue(true, GetPartMergeCount() < partTobeRemain.Details.MergeInfoCount);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Verified Delete Part Merge info details Successfully!!");
        }

        public int GetPartMergeCount()
        {
            Driver.WaitForReady();
            string mergeCount = _partMergeCount.GetText("Merge Count");
            mergeCount = mergeCount.Replace("Scheduled Part Mergers (Loaded", "");
            mergeCount = mergeCount.Replace("records)", "").Trim();
            int count = Convert.ToInt32(mergeCount);
            return Convert.ToInt32(mergeCount);
        }
    }
}
