﻿using OpenQA.Selenium;
using NUnit.Framework;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartMainCatalogPageActions : PartMainCatalogPage
    {

        public PartMainCatalogPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create New Part
        /// </summary>
        /// <returns>Part No</returns>       
        public string CreateNewPart(PartsMainCatalog partsObject)
        {
            string PartNumber = string.Empty;
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(partsObject.PartNumber, ref PartNumber, "PartQuery", 12))
            {
                Settings.Logger.Info(" Create new part ");                
                _inputPartNo.SetText(PartNumber, "Part No", Driver, _extendedPage._contentFrame, "content frame");
                Driver.WaitForReady();
                if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                    _extendedPage.ClickOnDialogBoxButton("Create");
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
                _manufacturer.SetText(partsObject.Manufacturer, "Manufacturer");
                Driver.WaitForReady();
                partsObject.PartDesc = $"Random desc for {PartNumber}".ToUpper();
                _inputPDesc.SetText(partsObject.PartDesc, "Part Desc");
                if (partsObject.Details != null)
                    FillPartDetailsInformation(partsObject.Details);
                _extendedPage.VerifyRecordCreatedSuccess(_inputPartNo, _inputPDesc, PartNumber, "Part Number");
            }
            return PartNumber;
        }

        /// <summary>
        /// Update Part setting values
        /// </summary>
        /// <param name="partsObject"></param>
        public void UpdatePartSettingsValue(PartsMainCatalog partsObject)
        {
            Settings.Logger.Info("Update Part setting values");
            _extendedPage.RefreshAndSetText(_inputPartNo, partsObject.PartNumber, "Part No");
            Driver.WaitForReady();
            _manufacturer.SetText(partsObject.Manufacturer, "Manufacturer");
            Driver.WaitForReady();
            _inputPDesc.SetText(partsObject.PartDesc, "Part Desc");
            if (partsObject.Details != null)
                FillPartDetailsInformation(partsObject.Details);
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Fill Part Details Information
        /// </summary>
        /// <param name="partDetails"></param>
        public void FillPartDetailsInformation(PartsDetails partDetails)
        {
            Settings.Logger.Info(" Fill Part Settings Details");
            _extendedPartDescription.SetText(partDetails.ExtDescription, "Extended Part Description");
            Driver.WaitForReady();
            if (partDetails.StandardPrice != null)
                _extendedPage.SelectAllAndClearField(_extendedPartDescription);
            _inputSPrice.SetText(partDetails.StandardPrice, "Standard Price");
            Driver.WaitForReady();
            _inputAPrice.SetText(partDetails.AveragePrice, "Average Price");
            Driver.WaitForSomeTime();
            Driver.AcceptAlert();
            _inputRPrice.SetText(partDetails.RetailPrice, "Retail Price");
            Driver.WaitForReady();
            _inputPDiscountCode.SetText(partDetails.DiscountCode, "Discount Code");
            Driver.WaitForReady();
            _inputUnitOfInventory.SetText(partDetails.UnitOfInventory, "Unit Of Inventory");
            Driver.WaitForReady();
            _selectHazardous.SelectFilterValueHavingEqualValue(partDetails.Hazardous);
            if (partDetails.Hazardous != null && partDetails.Hazardous == "Yes")
            {
                Driver.WaitForSomeTime();
                HazardousMaterialPageActions hazardousPart = new(Driver);
                hazardousPart.PerformHazardousMaterialSetup(partDetails.HazardousInfo);
                _extendedPage.SwitchToContentFrame();
            }
            _inputCommodity.SetText(partDetails.Commodity, "Commodity");
            Driver.WaitForReady();
            _selectWarranty.SelectFilterValueHavingEqualValue(partDetails.Warranty);
            if (partDetails.Warranty != null && partDetails.Warranty == "Yes")
            {
                Driver.WaitForSomeTime();
                string parentWindow = Driver.SwitchToNewWindow();
                WarrantyPartSetupPageActions warrantyPart = new (Driver);
                warrantyPart.CreateWarrantyPart(partDetails.WarrantyPart);
                Driver.WaitForReady();
                Driver.Close();
                Driver.SwitchTo().Window(parentWindow);
                _extendedPage.SwitchToContentFrame();
            }
            _inputChargeCode.SetText(partDetails.ChargeCode, "Charge Code");
            Driver.WaitForReady();
            _inputCostCategory.SetText(partDetails.CostCategory, "Cost Category");
            Driver.WaitForReady();
            _inputPartClass.SetText(partDetails.PartClass, "Part Class");
            Driver.WaitForReady();
            Settings.Logger.Info(" Fill Part Classification and Location");
            _inputATAsys.SetText(partDetails.Sys, "Sys");
            Driver.WaitForReady();
            _inputATAcomp.SetText(partDetails.Assembly, "Assembly");
            Driver.WaitForReady();
            _inputATApart.SetText(partDetails.Part, "Part");
            Driver.WaitForReady();
            _selectStockType.SelectFilterValueHavingEqualValue(partDetails.StockType);
            Driver.WaitForReady();
            _inputPriVendor.SetText(partDetails.PrimaryVendor, "Primary Vendor");
            Driver.WaitForReady();
            Driver.WaitForReady();
            _inputSecVendor.SetText(partDetails.SecondaryVendor, "Secondary Vendor");
            Driver.WaitForReady();
            _inputSeasonCode.SetText(partDetails.SeasonCode, "Season Code");
            Driver.WaitForReady();
            _serialized.SelectFilterValueHavingEqualValue(partDetails.Serialized);
            Driver.WaitForReady();
            _autoGenSerial.SelectFilterValueHavingEqualValue(partDetails.AutoGenerateSerial);
            Driver.WaitForReady();
            _reUseSerial.SelectFilterValueHavingEqualValue(partDetails.ReusableSerial);
            Driver.WaitForReady();
            _lottedFlag.SelectFilterValueHavingEqualValue(partDetails.Lotted);
            Driver.WaitForReady();
            _coreCharge.SetText(partDetails.CoreCharge, "Code Charge");
            Driver.WaitForReady();
            _core_fl.SelectFilterValueHavingEqualValue(partDetails.CoreTracking);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Part Values
        /// </summary>
        /// <param name="partsObject"></param>
        public void VerifyPartValues(PartsMainCatalog partsObject)
        {
            Settings.Logger.Info($" Verifying Part Values for : {partsObject.PartNumber}");
            _extendedPage.RefreshAndSetText(_inputPartNo, partsObject.PartNumber, " Part Number ");
            Driver.WaitForReady();            
            CommonUtil.VerifyElementValue(_inputPDesc, "Part Desc", partsObject.PartDesc);
            CommonUtil.VerifyElementValue(_manufacturer,"Manufacturer", partsObject.Manufacturer);
            if (partsObject.Details != null)
                VerifyPartDetailsInformation(partsObject.Details);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Part Details Information
        /// </summary>
        /// <param name="partDetails"></param>
        public void VerifyPartDetailsInformation(PartsDetails partDetails)
        {
            Settings.Logger.Info(" Verifying Part Details Information ");
            CommonUtil.VerifyElementValue(_extendedPartDescription, "Extended Part Description ", partDetails.ExtDescription);
            CommonUtil.VerifyElementValue(_inputSPrice, "Standard Price", partDetails.StandardPrice);
            CommonUtil.VerifyElementValue(_inputAPrice, "Average Price ", partDetails.AveragePrice);
            CommonUtil.VerifyElementValue(_inputRPrice, "Retail Price", partDetails.RetailPrice);
            CommonUtil.VerifyElementValue(_inputPDiscountCode, "DiscountCode", partDetails.DiscountCode);
            CommonUtil.VerifyElementValue(_inputUnitOfInventory, "UnitOfInventory", partDetails.UnitOfInventory);
            CommonUtil.VerifyElementValue(_inputCommodity, "Commodity", partDetails.Commodity);
            CommonUtil.VerifyElementValue(_inputChargeCode, "Charge Code", partDetails.ChargeCode);
            CommonUtil.VerifyElementValue(_inputCostCategory, "Cost Category", partDetails.CostCategory);
            CommonUtil.VerifyElementValue(_inputPartClass, "PartClass", partDetails.PartClass);
            CommonUtil.VerifyElementValue(_inputATAsys, "Sys", partDetails.Sys);
            CommonUtil.VerifyElementValue(_inputATAcomp, "Assembly", partDetails.Assembly);
            CommonUtil.VerifyElementValue(_inputATApart, "Part", partDetails.Part);
            if (partDetails.StockType != null)
                CommonUtil.AssertTrue(partDetails.StockType, _selectStockType.GetVisibleText());
            if (partDetails.Serialized != null)
                CommonUtil.AssertTrue(partDetails.Serialized, _serialized.GetVisibleText());
            if (partDetails.ReusableSerial != null)
                CommonUtil.AssertTrue(partDetails.ReusableSerial, _reUseSerial.GetVisibleText());
            if (partDetails.AutoGenerateSerial != null)
                CommonUtil.AssertTrue(partDetails.AutoGenerateSerial, _autoGenSerial.GetVisibleText());
            if (partDetails.Lotted != null)
                CommonUtil.AssertTrue(partDetails.Lotted, _lottedFlag.GetVisibleText());
            if (partDetails.CoreTracking != null)
                CommonUtil.AssertTrue(partDetails.CoreTracking, _core_fl.GetVisibleText());
            CommonUtil.VerifyElementValue(_inputPriVendor, "PrimaryVendor", partDetails.PrimaryVendor);
            CommonUtil.VerifyElementValue(_inputSecVendor, "Secondary Vendor", partDetails.SecondaryVendor);
            CommonUtil.VerifyElementValue(_inputSeasonCode, "Season Code", partDetails.SeasonCode);
            CommonUtil.VerifyElementValue(_coreCharge, "Core Charge", partDetails.CoreCharge);
        }
      
        /// <summary>
        /// Verify Deleted Stock Part
        /// </summary>
        /// <returns>Part No</returns>
        public void VerifyDeletedStockPart(string PartNumber)
        {
            _extendedPage.VerifyCodeDeletion(_inputPartNo,PartNumber, "inputPartNo");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Navigate To Location Manager Page
        /// </summary>
        /// <param name="PartNumber"></param>
        /// <returns>PartInventoryLocationPageActions</returns>
        public PartInventoryLocationPageActions NavigateToLocationManagerPage(string PartNumber)
        {
            _extendedPage.SwitchToContentFrame();
            _inputPartNo.SetText(PartNumber, " Part Number ");
            Driver.WaitForReady();
            Settings.Logger.Info(" Click On Location Main Link ");
            _linkLocation.Click();
            Driver.SwitchToNewWindow();
            return new PartInventoryLocationPageActions(Driver);
        }

        /// Verify Part Number Deletion
        /// </summary>
        /// <param name="PartNumber"></param>
        /// <param name="ErrorMsg"></param>
        public void VerifyPartNumberDeletion(string PartNumber, string ErrorMsg = "N/A")
        {
            Settings.Logger.Info($" Deleting Part Number - {PartNumber}.");
            _extendedPage.RefreshAndSetText(_inputPartNo, PartNumber, "Part Number");
            _inputPartNo.ClickElement(PartNumber, Driver);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ActionRequiredWindow("Delete");
            Driver.WaitForReady();
            if (ErrorMsg != "N/A")
            {
                Settings.Logger.Info(" Verifying warning message ");
                CommonUtil.AssertTrue(ErrorMsg, _extendedPage.GetErrorMessage());
                _extendedPage.ClickOnRefreshButton();
                _extendedPage.ActionRequiredWindow("Leave");
            }
            else
            {
                _extendedPage.VerifyCodeDoesNotExist(_inputPartNo, PartNumber, "Part Number");
                Settings.Logger.Info($"Part Number - {PartNumber} Deleted successfully  ");
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Create New Warranty Part
        /// </summary>
        /// <param name="partsObject"></param>
        /// <returns></returns>
        public string CreateNewWarrantyPart(PartsMainCatalog partsObject)
        {
            if (string.IsNullOrEmpty(partsObject.PartNumber) || partsObject.PartNumber.ToLower().Equals("random"))
                partsObject.PartNumber = CommonUtil.GetRandomStringWithSpecialChars().ToUpper();
            string[] querryParam = { partsObject.PartNumber, "Y" };
            if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection, "WarrantyPartQuery", querryParam, Settings.DBType))
            {
                Settings.Logger.Info(" Create new part ");
                _inputPartNo.SetText(partsObject.PartNumber, "Part No", Driver, _extendedPage._contentFrame, "content frame");
                Driver.WaitForReady();
                if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                    _extendedPage.ClickOnDialogBoxButton("Create");
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
                _manufacturer.SetText(partsObject.Manufacturer, "Manufacturer");
                Driver.WaitForReady();
                partsObject.Details.WarrantyPart.PartNo = partsObject.PartNumber;
                partsObject.PartDesc = $"Random desc for {partsObject.PartNumber}".ToUpper();
                _inputPDesc.SetText(partsObject.PartDesc, "Part Desc");
                if (partsObject.Details != null)
                    FillPartDetailsInformation(partsObject.Details);
                _extendedPage.VerifyRecordCreatedSuccess(_inputPartNo, _inputPDesc, partsObject.PartNumber, "Part Number");
            }
            return partsObject.PartNumber;
        }

        /// <summary>
        /// Verify Part Serial Details
        /// </summary>
        /// <param name="partsObject"></param>
        public void VerifyPartSerialDetails(PartsMainCatalog partsObject)
        {
            Settings.Logger.Info($" Verifying Part Serial Details for : {partsObject.PartNumber}");
            _extendedPage.RefreshAndSetText(_inputPartNo, partsObject.PartNumber, " Part Number ");
            Driver.WaitForReady();
            _buttonserial.ClickElement("Serial Info", Driver);
            Driver.WaitForReady(); Driver.SwitchTo().DefaultContent();
            Driver.SwitchToFrame(_extendedPage._contentFrame2, "Content 2");
            Driver.SwitchToFrame(_framePartSerial, "Serial Entry");
            foreach(var serial in partsObject.serialNumbers)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePartSerial, _headerSerial,
                    serial.SerialNo, "PoNo"), "Purchase Order", serial.PurchaseOrder, false, "value");
                Assert.True(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePartSerial, _headerSerial, serial.SerialNo, 
                    "mfgDate").GetAttribute("value").Contains(serial.MfgDate));
                Assert.True(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePartSerial, _headerSerial, serial.SerialNo,
                    "expDate").GetAttribute("value").Contains(serial.ExpDate));
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
