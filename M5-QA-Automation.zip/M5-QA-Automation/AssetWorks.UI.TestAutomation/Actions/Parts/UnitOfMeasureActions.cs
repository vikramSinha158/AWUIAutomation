﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects.Equipment;
using OpenQA.Selenium;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class UnitOfMeasureActions : UnitOfMeasurePage
    {
        public UnitOfMeasureActions(IWebDriver? Driver) : base(Driver) { }      

        public List<UnitOfMeasure> CreateUnitOfMeasure(List<UnitOfMeasure> DataObject)
        {
           
            foreach (UnitOfMeasure data in DataObject)
            {               
                _extendpage.SwitchToTableFrame(_UnitFrame);
                if (string.IsNullOrEmpty(data.Code))
                data.Code = CommonUtil.GetRandomStringWithSpecialChars();
                Settings.Logger.Info($" Creating Unit Of Measure :{  data.Code } ");
                _codeNew.SetText(data.Code, "Code");
                Driver.WaitForReady();
                _descriptionNew.SetText(data.Description, "Description");
                Driver.WaitForReady();
                _disabledNew.SelectCheckBox("Disabled");
                Driver.WaitForReady();
                _extendpage.Save();
            }
            return DataObject;
        }

        /// <summary>
        /// Update Unit of Measure
        /// </summary>
        /// <param name="DataObject"></param>
        public void UpdateUnitOfMeasure(List<UnitOfMeasure> DataObject)
        {
            foreach (UnitOfMeasure data in DataObject)
            {
                Driver.SwitchTo().DefaultContent();
  
                _extendpage.SwitchToTableFrame(_UnitFrame);
                _extendpage.GetTableActionElementByRelatedColumnValue(_UnitTable, "Code", data.Code, "disabled").SelectCheckBox("Disabled");
                //_extendpage.GetTableActionElementByRelatedColumnValue(_UnitTable, "Code", data.Code, "desc").SetText(data.UpdatedDescription,"Updated Description");               
                _extendpage.GetTableActionElementByRelatedColumnValue(_UnitTable, "Code", data.Code, "conv_factor").SetText(data.USGConversionFactor,"USB Conversion Factor");
                Driver.WaitForReady();
                _extendpage.Save();
            }
        }
        /// <summary>
        /// Delete Unit Of Measure
        /// </summary>
        public void DeleteUnitOfMeasure(List<UnitOfMeasure> DataObject)
        {
            foreach (UnitOfMeasure data in DataObject)
            {
               Settings.Logger.Info("Deleting Unit Of Measure : ");
                _extendpage.GetTableActionElementByRelatedColumnValue(_UnitTable, "Code", data.Code, "desc").Click();
                Driver.WaitForReady();
                _extendpage.DeleteAndSave();
                Driver.SwitchTo().DefaultContent();
            }

        }

        /// <summary>
        /// Verify After Deletion
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyAfterDeletionUnitOfMeasure(List<UnitOfMeasure> DataObject)
        {
            foreach (UnitOfMeasure data in DataObject)
            {
                _extendpage.SwitchToContentFrame();   
                Driver.SwitchToFrame(_UnitFrame, "Unit Table frame");
                _extendpage.VerifyTableColumnDoesNotContainValue(_UnitTable, "Code", data.Code);
            }
        }
        /// <summary>
        /// Verify UnitOfMeasure
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyUnitOfMeasure(List<UnitOfMeasure> DataObject)
        {
            _extendpage.ClickRefresh();
            Driver.WaitForReady();
            foreach (UnitOfMeasure data in DataObject)
            {
               _extendpage.SwitchToTableFrame(_UnitFrame);
                IWebElement Code = _extendpage.GetTableActionElementByRelatedColumnValue(_UnitTable, "Code", data.Code, "code");
                CommonUtil.VerifyElementValue(Code, "Code", data.Code, false, "value");
                IWebElement Description = _extendpage.GetTableActionElementByRelatedColumnValue(_UnitTable, "Description", data.Description, "desc");
                CommonUtil.VerifyElementValue(Description, "Code", data.Description, false, "value");               
            }
            
        }        
    }
}
