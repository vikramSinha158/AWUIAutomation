﻿using System;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartRequestPageActions : PartRequestPage
    {
        public PartRequestPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Load Part Request Info
        /// </summary>
        /// <param name="partsRequest"></param>
        public void LoadPartRequest(PartRequestObjects partsRequest)
        {
            ExtendedPage.SwitchToContentFrame();
            _employeeNumber.SetText(partsRequest.EmployeeNumber, "EmployeeNumber");
            Driver.WaitForReady();
            _unitNo.SetText(partsRequest.UnitNumber, "Unit Number");
            Driver.WaitForReady();
            _woNo.SetText(partsRequest.WONo, "Work Order Number");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Add Parts To Part Request
        /// </summary>
        /// <param name="partsRequest"></param>
        public void AddPartsToPartRequest(PartRequestObjects partsRequest)
        {
            Settings.Logger.Info(" Add Parts To Part Request ");
            LoadPartRequest(partsRequest);
            if (partsRequest.Requests != null)
            {
                int rowNo = 0;
                Driver.SwitchToFrame(_partRequestFrame, "PartRequestFrame");
                foreach (Requests request in partsRequest.Requests)
                {
                    ExtendedPage.SelectAllAndClearField(_inputJobCode(rowNo.ToString()));
                    _inputJobCode(rowNo.ToString()).SetText(request.JobCode, "Job Code");
                    Driver.WaitForSomeTime();
                    _inputPartNo(rowNo.ToString()).SetText(request.PartNo, "Part No");
                    Driver.WaitForReady();
                    _inputRequestQuantity(rowNo.ToString()).SetText(request.RequestQty, "Request Quantity");
                    Driver.WaitForReady();
                    _inputNeededByDate(rowNo.ToString()).SendKeys(Keys.Tab);
                    Driver.WaitForReady();
                    rowNo++;
                }
            }
            ExtendedPage.Save();
        }

        /// <summary>
        /// Edit Part Request 
        /// </summary>
        /// <param name="partsRequest"></param>
        public void EditPartRequest(PartRequestObjects partsRequest)
        {
            Settings.Logger.Info("Edit already created part request");
            ExtendedPage.ClickOnRefreshButton();
            LoadPartRequest(partsRequest);
            if (partsRequest.Requests != null)
            {
                Driver.SwitchToFrame(_partRequestFrame, "PartRequestFrame");
                foreach (Requests request in partsRequest.Requests)
                {
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequest, "Part No",
                        request.PartNo, "pickedUp").SelectCheckBox("Picked Up");
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequest, "Part No",
                        request.PartNo, "noteBtn").Click();
                    Driver.WaitForReady();
                    Driver.SwitchTo().DefaultContent();
                    Driver.SwitchToFrame(_noteButtonContentFrame, "frameNote");
                    _testNote.SetText("TEST NOTE", "Test note");
                    Driver.WaitForReady();
                    _locked.SelectCheckBox("Locked");
                    Driver.WaitForReady();
                    ExtendedPage.Save();
                }
            }
        }

        /// <summary>
        /// Delete Part Request
        /// </summary>
        /// <param name="partsRequest"></param>
        public void DeletPartRequest(PartRequestObjects partsRequest)
        {
            Settings.Logger.Info("Delete Part Request");
            ExtendedPage.ClickOnRefreshButton();
            LoadPartRequest(partsRequest);
            if (partsRequest.Requests != null)
            {
                Driver.SwitchToFrame(_partRequestFrame, "PartRequestFrame");
                foreach (Requests request in partsRequest.Requests)
                {
                    string pickedUp = ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequest, "Part No",
                        request.PartNo, "pickedUp").GetAttribute("value");
                    if (pickedUp.ToUpper().Equals("Y"))
                    {
                        ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequest, "Part No",
                        request.PartNo, "pickedUp").DeSelectCheckBox("Picked Up");
                        ExtendedPage.Save();
                        ExtendedPage.SwitchToTableFrame(_partRequestFrame);
                    }
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequest, "Part No", request.PartNo, "job").Click();
                    ExtendedPage.DeleteAndSave();
                    Driver.SwitchToFrame(_partRequestFrame, "Table frame");
                    ExtendedPage.VerifyTableColumnDoesNotContainValue(_tablePartRequest, "Part No", request.PartNo);
                }
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Deleted Part Request");
        }

        /// <summary>
        /// Verify Part Request 
        /// </summary>
        /// <param name="partsRequest"></param>
        public void VerifyNewPartRequest(PartRequestObjects partsRequest)
        {
            Settings.Logger.Info("Verify new part request ");
            ExtendedPage.SwitchToContentFrame();
            CommonUtil.VerifyElementValue(_employeeNumber, "Employee Number", partsRequest.EmployeeNumber);
            CommonUtil.VerifyElementValue(_unitNo, "Unit No", partsRequest.UnitNumber);
            CommonUtil.VerifyElementValue(_woNo, "Work Order No", partsRequest.WONo);
            if (partsRequest.Requests != null)
            {
                Driver.SwitchToFrame(_partRequestFrame, "PartRequestFrame");
                foreach (Requests request in partsRequest.Requests)
                {
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequest, "Part No",
                        request.PartNo, "job"), "Job Code", request.JobCode, false, "Value");
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequest, "Part No",
                        request.PartNo, "pDesc"), "Description", request.Description, false, "Value");
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequest, "Part No",
                        request.PartNo, "availQty"), "AvailQty", request.AvailQty, false, "Value");
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequest, "Part No",
                        request.PartNo, "reqQty"), "RequestQty", request.RequestQty, false, "Value");
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequest, "Part No",
                        request.PartNo, "totalCost"), "TotalCost", request.TotalCost, false, "Value");
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequest, "Part No",
                        request.PartNo, "reqEmp"), "RequestedBy", request.RequestedBy, false, "Value");
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequest, "Part No",
                        request.PartNo, "hstatus"), "Status", request.Status, false, "Value");
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Part Request Data after click on Clear Button
        /// </summary>
        /// <param name="partsRequestObject"></param>
        public void VerifyPartRequestDataAfterClickOnClearButton(PartRequestObjects partsRequestObject)
        {
            Settings.Logger.Info("Verify Part Request Data after click on Clear Button");
            ExtendedPage.SwitchToContentFrame();
            _clearBtn.Click();
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_employeeNumber, "Employee Number", String.Empty);
            CommonUtil.VerifyElementValue(_unitNo, "Unit Number", String.Empty);
            CommonUtil.VerifyElementValue(_woNo, "Work Order Number", String.Empty);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Delete Button is Inactive
        /// </summary>
        /// <param name="partsRequest"></param>
        public void VerifyDeleteButtonInactive(PartRequestObjects partsRequest)
        {
            Settings.Logger.Info("Verify Delete Button is Inactive");
            ExtendedPage.ClickOnRefreshButton();
            LoadPartRequest(partsRequest);
            if (partsRequest.Requests != null)
            {
                Driver.SwitchToFrame(_partRequestFrame, "PartRequestFrame");
                foreach (Requests request in partsRequest.Requests)
                {
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequest, "Part No", request.PartNo, "job").Click();
                    Driver.SwitchTo().DefaultContent();
                    CommonUtil.AssertTrue(ExtendedPage._buttonDelete.GetAttribute("disabled").ToLower(), "true");
                    Settings.Logger.Info("Delete Button is Inactive");
                    ExtendedPage.SwitchToTableFrame(_partRequestFrame);
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Add Part To Part Request
        /// </summary>
        /// <param name="partsRequest"></param>
        public void AddPartToPartRequest(PartRequestObjects partsRequest)
        {
            Settings.Logger.Info(" Add Part To Part Request ");
            ExtendedPage.SwitchToTableFrame(_partRequestFrame);
            int rowNo = 0;
            foreach (Requests request in partsRequest.Requests)
            {
                _inputPartNo(rowNo.ToString()).SetText(request.PartNo, "Part No");
                Driver.WaitForReady();
                _inputRequestQuantity(rowNo.ToString()).SetText(request.RequestQty, "Request Quantity");
                Driver.WaitForReady();
                _inputNeededByDate(rowNo.ToString()).SendKeys(Keys.Tab);
                Driver.WaitForReady();
                rowNo++;
            }
            ExtendedPage.Save();
            Driver.WaitForSomeTime();
            ExtendedPage.SwitchToTableFrame(_partRequestFrame);
            _inputJobCode("0").Click();
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.ClickOnDeleteButton();
        }
    }
}



