﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartTransferPageActions : PartTransferPage
    {
        public PartTransferPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Retrieve Part Transfer
        /// </summary>
        /// <param name="transferObject"></param>
        public void RetrievePartTransfer(PartTransferObject transferObject)
        {
            Settings.Logger.Info(" Retrieve Part Transfer ");
            ExtendedPage.SwitchToContentFrame();
            CommonUtil.VerifyElementValue(_inputShippingLocation, "Shipping Location", transferObject.ShippingLocation);
            _inputEmployeeID.SetText(transferObject.EmployeeID, "Employee ID");
            Driver.WaitForReady();
            _inputRecvLocation.SetText(transferObject.RecvLocation, "Recv Location");
            Driver.WaitForReady();
            _inputTicketNo.SetText(transferObject.TicketNo, "Ticket No");
            Driver.WaitForReady();
            _inputPartNumber.SetText(transferObject.PartNo, "Part No");
            Driver.WaitForReady();
            _inputVendor.SetText(transferObject.Vendor, "Vendor");
            Driver.WaitForReady();
            if (transferObject.Added)
                _checkboxAdded.SelectCheckBox("Added", transferObject.Added);
            else
                _checkboxAdded.DeSelectCheckBox("Added");
            if (transferObject.Request)
                _checkboxRequest.SelectCheckBox("Request", transferObject.Request);
            else
                _checkboxRequest.DeSelectCheckBox("Request");
            if (transferObject.Pick)
                _checkboxPick.SelectCheckBox("Pick", transferObject.Pick);
            else
                _checkboxPick.DeSelectCheckBox("Pick");
            if (transferObject.Complete)
                _checkboxComplete.SelectCheckBox("Complete", transferObject.Complete);
            else
                _checkboxComplete.DeSelectCheckBox("Complete");
            Driver.WaitForReady();
            _buttonRetrieve.ClickElement("Retrieve", Driver);
            Driver.WaitForReady();
        }

        /// <summary>
        /// Create Part Transfer
        /// </summary>
        /// <param name="transferObject"></param>
        /// <returns>TicketNo</returns>
        public string CreatePartTransfer(PartTransferObject transferObject)
        {
            Settings.Logger.Info(" Create Part Transfer ");
            RetrievePartTransfer(transferObject);
            if (transferObject.PartTransferDetails != null)
            {
                int rowId = 0;
                Driver.SwitchToFrame(_framePartTransfer, "PartTransfer");
                foreach (PartTransferDetail transfer in transferObject.PartTransferDetails)
                {
                    _inputStatus(rowId.ToString()).SendKeys(Keys.Tab);
                    Driver.WaitForReady();
                    _inputRecvLoc(rowId.ToString()).SetText(transfer.RecvLoc, "RecvLoc");
                    Driver.WaitForReady();
                    _inputPartNo(rowId.ToString()).SetText(transfer.PartNo, "PartNo");
                    Driver.WaitForReady();
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartTransfer, "Part No", transfer.PartNo, 
                        "PickQty", "ovalue").SetText(transfer.PickQty, "PickQty");
                    Driver.WaitForReady();
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartTransfer, "Part No", transfer.PartNo,
                        "Ship", "ovalue").SetCheckBox("Ship", transfer.Ship);
                    Driver.WaitForReady();
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartTransfer, "Part No", transfer.PartNo,
                        "chargeCode", "ovalue").SelectFilterValueHavingEqualValue(transfer.ResvCode);
                    Driver.WaitForReady();
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartTransfer, "Part No", transfer.PartNo,
                        "typeNum", "ovalue").SetText(transfer.ResvRefNo, "ResvRefNo");
                    Driver.WaitForReady();
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartTransfer, "Part No",
                        transfer.PartNo, "ReqQty", "ovalue"), "ReqQty", transfer.ReqQty);
                    rowId++;
                }
                Driver.SwitchTo().DefaultContent();
                ExtendedPage.ClickOnSaveButton();
                Driver.WaitForSomeTime();
                if (_buttonPrintNothing.VerifyElementDisplay(" Print Request Dialog "))
                {
                    _buttonPrintNothing.Click();
                    Driver.WaitForReady();
                }
            }
            return transferObject.TicketNo;
        }

        /// <summary>
        /// Verify Part Transfer Status
        /// </summary>
        /// <param name="transferObject"></param>
        public void VerifyPartTransferStatus(PartTransferObject transferObject)
        {
            Settings.Logger.Info(" Verify Part Transfer Status ");
            RetrievePartTransfer(transferObject);
            if (transferObject.PartTransferDetails != null)
            {
                Driver.SwitchToFrame(_framePartTransfer, "PartTransfer");
                foreach (PartTransferDetail transfer in transferObject.PartTransferDetails)
                {
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartTransfer, "Part No",
                        transfer.PartNo, "status"), "Status", transfer.Status, false, "value");
                }
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
