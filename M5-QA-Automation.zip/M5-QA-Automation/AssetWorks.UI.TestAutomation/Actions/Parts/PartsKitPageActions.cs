﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class PartsKitPageActions : PartsKitPage
    {
        public PartsKitPageActions(IWebDriver Driver) : base(Driver) { }      
     
        /// <summary>
        /// Create Parts Kit
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <returns></returns>
        public string CreatePartsKit(PartsKit ObjectKey)
        {
            string KitCode = string.Empty;
            if (!_extendpage.CheckDataExistenceAndGetActionCode(ObjectKey.KitCode, ref KitCode, "PartsKitQuery", 6))
            {
                Settings.Logger.Info("Creating Part Kit Code:" + ObjectKey.KitCode);
                ObjectKey.KitCode = KitCode;
                _extendpage.SwitchToContentFrame();
                _kitNo.SetText(ObjectKey.KitCode, "KitCode");
                Driver.SwitchTo().DefaultContent();
                _extendpage.ClickOnDialogBoxButton("Create");
                Driver.WaitForReady();
                _extendpage.SwitchToContentFrame();
                _kDesc.SetText(ObjectKey.Description, "Description");
                Driver.SwitchToFrame(_framePartKit, "Table frame");
                int i=0;
                foreach (PartsKitTable TableData in ObjectKey.PartsKitTable)
                {                    
                    _PartNO(i).SetText(TableData.PartNumber, "PartNumber");
                    Driver.WaitForReady();
                    _PartQuantity(i).SetText(TableData.Quantity, "Quantity");
                    Driver.WaitForReady();
                    i++;                   
                }
                _extendpage.Save();               
                Settings.Logger.Info($"Part Kit Code:  { ObjectKey.KitCode  } created successfully");
            }            
            return KitCode;
        }

        /// <summary>
        /// Verify Parts Kit
        /// </summary>
        /// <param name="ObjectKey"></param>
        public void VerifyPartsKit(PartsKit ObjectKey)
        {
            Settings.Logger.Info($"Verifying Part Kit Code:  { ObjectKey.KitCode  }");
            _extendpage.RefreshAndSetText(_kitNo, ObjectKey.KitCode, "KitCode");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_kitNo, "KitCode", ObjectKey.KitCode, false, "value");
            CommonUtil.VerifyElementValue(_kDesc, "Description", ObjectKey.Description.ToUpper());
            Driver.WaitForSomeTime(2);
            foreach (PartsKitTable TableData in ObjectKey.PartsKitTable)
            {
                Driver.SwitchToFrame(_framePartKit, "Table frame");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tablePartKit, "Part Number", TableData.PartNumber, "pQty"), "Quantity", TableData.Quantity, false, "value");
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info($"Verified Part Kit Code:  { ObjectKey.KitCode  }");
        }

        /// <summary>
        /// Update Parts Kit
        /// </summary>
        /// <param name="ObjectKey"></param>
        public void UpdatePartsKit(PartsKit ObjectKey)
        {
            Settings.Logger.Info($"Updating Part Kit Code:  { ObjectKey.KitCode  }");
            _extendpage.RefreshAndSetText(_kitNo, ObjectKey.KitCode, "KitCode");
            Driver.WaitForReady(3);
            foreach (PartsKitTable TableData in ObjectKey.PartsKitTable)
            {
                Driver.SwitchToFrame(_framePartKit, "Table frame");
                _extendpage.GetTableActionElementByRelatedColumnValue(_tablePartKit, "Part Number", TableData.PartNumber, "pQty").SetText(TableData.Quantity, "Quantity");
            }
            _extendpage.Save();
        }
    
        /// <summary>
        /// Delete Parts Kit
        /// </summary>
        /// <param name="ObjectKey"></param>
        public void DeletePartsKit(PartsKit ObjectKey)
        {
            Settings.Logger.Info($"Deleting Part Kit Code:  { ObjectKey.KitCode  }");
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_kitNo, ObjectKey.KitCode, "KitCode");
            Driver.WaitForReady();
            foreach (PartsKitTable TableData in ObjectKey.PartsKitTable)
            {
                Driver.SwitchToFrame(_framePartKit, "Table frame");
                _extendpage.GetTableActionElementByRelatedColumnValue(_tablePartKit, "Part Number", TableData.PartNumber, "part").ClickElement( "Quantity",Driver);
                _extendpage.DeleteAndSave();
            }            
        }
       
        /// <summary>
        /// Verify Deleted Parts Kit
        /// </summary>
        /// <param name="ObjectKey"></param>
        public void VerifyDeletedPartsKit(PartsKit ObjectKey)
        {
            Settings.Logger.Info($" Verifing Deleted Part Kit Code:  { ObjectKey.KitCode  }");
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_kitNo, ObjectKey.KitCode, "KitCode");
            Driver.WaitForSomeTime();
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnDialogBoxButton("Cancel");
            Settings.Logger.Info($" Verified PartKit: {ObjectKey.KitCode} Deleted Successfully ");
            Driver.SwitchTo().DefaultContent();
        }
    }
}
