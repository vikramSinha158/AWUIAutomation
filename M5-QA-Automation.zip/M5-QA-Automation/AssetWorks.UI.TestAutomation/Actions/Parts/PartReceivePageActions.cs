﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartReceivePageActions : PartReceivePage
    {
        public PartReceivePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Update Part Receive Details
        /// </summary>
        /// <param name="receiveObject"></param>
        public string UpdatePartReceive(PartReceiveObject receiveObject)
        {
            Settings.Logger.Info(" Update Part Receive Details ");
            ExtendedPage.SwitchToContentFrame();
            receiveObject.InvoiceNo = CommonUtil.GetRandomStringWithSpecialChars(10);
            _selectType.SelectFilterValueHavingEqualValue(receiveObject.Type);
            Driver.WaitForSomeTime();
            if (receiveObject.Type == "System PO")
                VendorWithPO(receiveObject);
            else if (receiveObject.Type == "Manual PO")
                VendorWithoutPO(receiveObject);
            else if (receiveObject.Type == "Transfer")
                TransferTicket(receiveObject);
            else if (receiveObject.Type == "Neg Receive")
                ReturnToVendor(receiveObject);                  
            ExtendedPage.Save();
            Driver.WaitForReady();
            ExtendedPage.ActionRequiredWindow("Yes");
            Driver.WaitForReady();
            if (_buttonPrintNothing.VerifyElementDisplay(" Print Request Dialog "))
            {
                _buttonPrintNothing.Click();
                Driver.WaitForSomeTime();
            }
            return receiveObject.InvoiceNo;
        }

        /// <summary>
        /// Vendor With PO
        /// </summary>
        /// <param name="receiveObject"></param>
        public void VendorWithPO(PartReceiveObject receiveObject)
        {
            _inputPOno1.SetText(receiveObject.POno, "PO No");
            Driver.WaitForSomeTime();
            CommonUtil.VerifyElementValue(_inputVendorNo1, "Vendor No", receiveObject.VendorNo);
            Driver.WaitForReady();
            _inputEmployee1.SetText(receiveObject.Employee, "Employee");
            Driver.WaitForReady();
            _inputInvoiceNo1.SetText(receiveObject.InvoiceNo, "Invoice No");
            Driver.WaitForReady();
            if (receiveObject.EffectiveDate != null)
            {
                ExtendedPage.SelectAllAndClearField(_inputEffectiveDate1);
                _inputEffectiveDate1.SetText(receiveObject.EffectiveDate, "Effective Date");
                Driver.WaitForReady();
            }
            _inputTaxScheme1.SetText(receiveObject.TaxScheme, "Tax Scheme");
            Driver.WaitForReady();
            if (receiveObject.PartsDetail != null)
            {
                Driver.SwitchToFrame(_framePartsRecv, "Part Receive frame");
                Driver.WaitForReady();
                CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartsRecv, "Part No",
                    receiveObject.PartsDetail.PartNo, "requested", "val", "div"), "Requested", receiveObject.PartsDetail.Requested, false, "value");
                ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartsRecv, "Part No", receiveObject.PartsDetail.PartNo, "rcvdqty",
                    "val", "div").SetText(receiveObject.PartsDetail.ReceivedQty, "Received Qty");
                Driver.WaitForReady();
                ExtendedPage.SetCheckBox(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartsRecv, "Part No", receiveObject.PartsDetail.PartNo, "issue",
               "val", "div"), "Isue Check box", receiveObject.PartsDetail.Issue);
            }
            if (receiveObject.PartsDetailList != null)
            {
                FillPartsDetail(receiveObject);
            }
        }

        /// <summary>
        /// Vendor Without PO
        /// </summary>
        /// <param name="receiveObject"></param>
        public void VendorWithoutPO(PartReceiveObject receiveObject)
        {
            Driver.AcceptAlert();
            _inputVendorNo2.SetText(receiveObject.VendorNo, "Vendor No");
            Driver.WaitForReady();
            _inputEmployee2.SetText(receiveObject.Employee, "Employee");
            Driver.WaitForReady();
            _inputInvoiceNo2.SetText(receiveObject.InvoiceNo, "Invoice No");
            Driver.WaitForReady();
            _inputPOno2.SetText(receiveObject.POno, "PO No");
            Driver.WaitForReady();
            _inputEffectiveDate2.SetText(receiveObject.EffectiveDate, "Effective Date");
            Driver.WaitForReady();
            _inputTaxScheme2.SetText(receiveObject.TaxScheme, "Tax Scheme");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_framePartsRecv, "Part Receive frame");
            if (receiveObject.PartsDetailListManualPO != null)
            {
                int i = 0;
                foreach (PartsDetailListManualPO dataobject in receiveObject.PartsDetailListManualPO)
                {
                    _PartNO(i).SetText(dataobject.PartNo, "Part No");
                    Driver.WaitForReady();
                    if (dataobject.LotNumberRequired)
                    {
                        PartsAdjustment.AddLotNumber(dataobject.LotNumber, dataobject.MfgDate, dataobject.ExpDate);
                        Driver.SwitchToFrame(_framePartsRecv, "Part Receive frame");
                    }
                    Driver.WaitForReady();
                    _PartQuantity(i).SetText(dataobject.Quantity, "Quantity");
                    if (dataobject.SerialNoRequired)
                    {
                        dataobject.SerialNo = PartsAdjustment.AddPartSerialEntry(dataobject.SerialNo, dataobject.SerialNoMfgDate, dataobject.SerialNoExpDate);
                        Driver.SwitchToFrame(_framePartsRecv, "Part Receive frame");
                    }
                    Driver.WaitForReady();
                    i++;
                }
            }
            else
            {
                _inputPartNoNew.SetText(receiveObject.PartsDetail.PartNo, "Part No");
                Driver.WaitForReady();
                _inputQuantityNew.SetText(receiveObject.PartsDetail.ReceivedQty, "Received Qty");
                Driver.WaitForReady();
            }
        }

        /// <summary>
        /// Transfer Ticket
        /// </summary>
        /// <param name="receiveObject"></param>
        public void TransferTicket(PartReceiveObject receiveObject)
        {
            Lov.SelectFirstTableRecord(_inputTransferTicketNo, "Transfer Ticket No", true);
            Driver.WaitForReady();
            Driver.SwitchToFrame(_framePartsRecv, "Part Receive frame");
            Driver.WaitForReady();
            ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartsRecv, "Part No", receiveObject.PartsDetail.PartNo,
                "rcvdqty").SetText(receiveObject.PartsDetail.ReceivedQty, "Received Qty");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Return To Vendor
        /// </summary>
        /// <param name="receiveObject"></param>
        public void ReturnToVendor(PartReceiveObject receiveObject)
        {
            _inputVendorNo3.SetText(receiveObject.VendorNo, "Vendor No");
            Driver.WaitForReady();
            _inputEmployee3.SetText(receiveObject.Employee, "Employee");
            Driver.WaitForReady();
            _inputInvoiceNo3.SetText(receiveObject.InvoiceNo, "Invoice No");
            Driver.WaitForReady();
            _inputInvoiceDate.SetText(receiveObject.InvoiceDate, "Invoice Date");
            Driver.WaitForReady();
            _inputPOno3.SetText(receiveObject.POno, "PO No");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_framePartsRecv, "Part Receive frame");
            _inputPartNo3New.SetText(receiveObject.PartsDetail.PartNo, "Part No");
            Driver.WaitForReady();
            ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRcvNeg, "Part No", receiveObject.PartsDetail.PartNo,
                "quantity", "ovalue").SetText(receiveObject.PartsDetail.ReceivedQty, "Quantity");
            Driver.WaitForReady();
            ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRcvNeg, "Part No", receiveObject.PartsDetail.PartNo,
                "cpunitcost", "ovalue").SetText(receiveObject.PartsDetail.UnitCost, "Unit Cost");
            Driver.WaitForReady();
            ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRcvNeg, "Part No", receiveObject.PartsDetail.PartNo,
                "Rsn", "ovalue").SetText(receiveObject.PartsDetail.Reason, "Reason");
            Driver.WaitForReady();
            ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRcvNeg, "Part No", receiveObject.PartsDetail.PartNo,
                "RefNo", "ovalue").SetText(receiveObject.PartsDetail.RMARefNo, "RMA/Ref No");
            Driver.WaitForReady();
            ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRcvNeg, "Part No", receiveObject.PartsDetail.PartNo,
                "lot", "ovalue").SetText(receiveObject.PartsDetail.Lot, "Lot");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Fill Parts Detail
        /// </summary>
        /// <param name="receiveObject"></param>
        public void FillPartsDetail(PartReceiveObject receiveObject)
        {
            Settings.Logger.Info(" Fill Part Receive Details ");
            Driver.SwitchToFrame(_framePartsRecv, "Part Receive frame");
            foreach (PartsDetail PartsDetail in receiveObject.PartsDetailList)
            {
                Driver.WaitForReady();
                CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartsRecv, "Part No",
                    PartsDetail.PartNo, "requested", "val", "div"), "Requested", PartsDetail.Requested, false, "value");
                ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartsRecv, "Part No", PartsDetail.PartNo, "rcvdqty",
                    "val", "div").SetText(PartsDetail.ReceivedQty, "Received Qty");
                Driver.WaitForReady();
                if (PartsDetail.PartType != null)
                {
                    FillPartTypeDetails(PartsDetail);
                }
                ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartsRecv, "Part No", PartsDetail.PartNo, "issue",
                    "val", "div").SelectCheckBox("Issue?", PartsDetail.Issue);
                Driver.WaitForReady();
                if (PartsDetail.Position != null) ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartsRecv, "Part No", PartsDetail.PartNo, "Jobposition",
                    "val", "div").SetText(PartsDetail.Position, "Position");
                Driver.WaitForReady();
                ExtendedPage.SetCheckBox(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartsRecv, "Part No", PartsDetail.PartNo, "issue",
               "val", "div"), "Issue Check box", PartsDetail.Issue);
                Driver.WaitForReady();
            }
        }


        /// <summary>
        /// Fill Part Type Details
        /// </summary>
        /// <param name="PartsDetail"></param>
        public void FillPartTypeDetails(PartsDetail PartsDetail)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.SwitchToFrame(ExtendedPage._contentFrame2, "Content frame 2");
            if (PartsDetail.PartType.ToUpper().Equals("LOTTED"))
            {
                _inputLotNo.SetText(CommonUtil.GetRandomStringWithSpecialChars(6), "Lot No");
                Driver.WaitForReady();
                _inputLotMfgDate.SetText(PartsDetail.MfgDate, "Mfg date");
                _inputLotExpDate.SetText(PartsDetail.ExpDate, "Exp date");
            }
            else if (PartsDetail.PartType.ToUpper().Equals("SERIALIZED"))
            {
                Driver.SwitchToFrame(_frameSerialEntry, "Serial Entry");
                if (PartsDetail.SerialNumbers != null)
                {
                    foreach (var serial in PartsDetail.SerialNumbers)
                    {
                        serial.SerialNo = CommonUtil.GetRandomStringWithSpecialChars(6);
                        ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableSerialEntry, _headerSerial, "",
                            "SerialNo", "ovalue").SetText(serial.SerialNo, "Serial No");
                        Driver.WaitForReady();
                        ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableSerialEntry, _headerSerial, serial.SerialNo,
                            "mfgDate", "ovalue").SetText(serial.MfgDate, "Mfg Date");
                        ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableSerialEntry, _headerSerial, serial.SerialNo,
                            "expDate", "ovalue").SetText(serial.ExpDate, "Exp Date");
                    }
                }
                else
                {
                    _inputSerialNo.SetText(CommonUtil.GetRandomStringWithSpecialChars(6), "Serial No");
                    Driver.WaitForReady();
                    _inputSnMfgDate.SetText(PartsDetail.MfgDate, "Mfg date");
                    _inputSnExpDate.SetText(PartsDetail.ExpDate, "Exp date");
                }
            }
            else if (PartsDetail.PartType.ToUpper().Equals("SNGENERATION"))
            {
                if (PartsDetail.SnGeneration != null)
                {
                    _inputSerialNumberLength.SetText(PartsDetail.SnGeneration.SnLength, "Length");
                    Driver.WaitForReady();
                    _inputPrefix.SetText(PartsDetail.SnGeneration.Prefix, "Prefix");
                    _inputSuffix.SetText(PartsDetail.SnGeneration.Suffix, "Suffix");
                    _inputStartingNumber.SetText(PartsDetail.SnGeneration.StartingNumber, "Starting No");
                    Driver.WaitForReady();
                    _inputSMfgDate.SetText(PartsDetail.MfgDate, "Mfg Date");
                    Driver.WaitForReady();
                    _inputSExpDate.SetText(PartsDetail.ExpDate, "Exp Date");
                }
            }
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            ExtendedPage._closeShowAttachmentsBtn.Click();
            Driver.WaitForReady();
            ExtendedPage.SwitchToTableFrame(_framePartsRecv);
        }

    }
}
