﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartTransferRequestPageActions : PartTransferRequestPage
    {
        public PartTransferRequestPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Part Transfer Request
        /// </summary>
        /// <param name="request"></param>
        public void CreatePartTransferRequest(PTransferRequest request)
        {
            Settings.Logger.Info(" Create Part Transfer Request ");
            ExtendedPage.SwitchToContentFrame();
            _inputShippingFromLoc.SetText(request.ShippingFromLoc, "Shipping From Loc");
            Driver.WaitForReady();
            _selectReserveCode.SelectDropdownUsingValue("Reserve Code", request.ReserveCode);
            Driver.WaitForReady();
            _inputPartNo.SetText(request.PartNo, "Part No");
            Driver.WaitForReady();
            ExtendedPage.SelectAllAndClearField(_inputDaysBack);
            _inputDaysBack.SetText(request.DaysBack, "Days Back");
            Driver.WaitForReady();
            _selectStatus.SelectDropdownUsingValue("Status", request.Status);
            Driver.WaitForReady();
            _buttonRetrieve.ClickElement("Retrieve", Driver);
            Driver.WaitForReady();
            if (request.TransferRequest != null)
            {
                Driver.SwitchToFrame(_framePartRequests, "PartRequests");
                foreach (TransferRequests transfer in request.TransferRequest)
                {
                    _inputPartNoNew.SetText(transfer.PartNo, "Part No");
                    Driver.WaitForReady();
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequests, "Part No", transfer.PartNo,
                        "ShipTo", "ovalue").SetText(transfer.ShippingToLoc, "Shipping To Loc");
                    Driver.WaitForReady();
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequests, "Part No", transfer.PartNo,
                        "Qty", "ovalue").SetText(transfer.Quantity, "Quantity");
                    Driver.WaitForReady();
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequests, "Part No", transfer.PartNo,
                        "chargeCode", "ovalue").SelectFilterValueHavingEqualValue(transfer.ResvCode);
                    Driver.WaitForReady();
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartRequests, "Part No", transfer.PartNo,
                        "typeNum", "ovalue").SetText(transfer.ResvRefNo, "Resv Ref No");
                    Driver.WaitForReady();
                }
                Driver.SwitchTo().DefaultContent();
                ExtendedPage.ClicKSave();
            }
        }
    }
}
