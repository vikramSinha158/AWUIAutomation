﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartReturnPageActions : PartReturnPage
    {
        public PartReturnPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Retrieve PartReturn Detail
        /// </summary>
        /// <param name="PurcReturntObject"></param>
        public void RetrievePartReturnDetail(PartReturn PurcReturntObject)
        {
            Settings.Logger.Info(" Retrieve Part Return detail ");
            Driver.WaitForReady();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _returnTo.SelectDropdownUsingValue("",PurcReturntObject.ReturnTo);
            Driver.WaitForReady();
            if(PurcReturntObject.ReturnTo=="WO") _issueNum.SetText(PurcReturntObject.WorkOrderNo, "WorkOrderNo");
            else if (PurcReturntObject.ReturnTo == "ST") _issueNum.SetText(PurcReturntObject.PartNo, "PartNo");
            else if (PurcReturntObject.ReturnTo == "NS") _issueNum.SetText(PurcReturntObject.PartNo, "PartNo");
            Driver.WaitForReady();
            _proNumber.SetText(PurcReturntObject.PRONumber, "PRONumber");
            Driver.WaitForReady();
            _transDtTo.Click();
            _transDtTo.SelectFilterValueHavingEqualValue(PurcReturntObject.TransactionDate);
            Driver.WaitForReady();
            _custEmpNo.SetText(PurcReturntObject.EmpNo, "ReservRefNo");
            Driver.WaitForReady();
            _retrieve.Click();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Fill Part Return To WorkOrder
        /// </summary>
        /// <param name="PurcReturntObjec"></param>
        public void FillPartReturnToWorkOrder(PartReturn PurcReturntObjec)
        {
            Settings.Logger.Info($"  Fill Part Return To WorkOrder");
            RetrievePartReturnDetail(PurcReturntObjec);
            Settings.Logger.Info($" Filling Parts Return To Work Order");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_partReturnFrame, "PartRequestFrame");
            Driver.WaitForReady();
            foreach (PartReturnTable PartReturnDetail in PurcReturntObjec.PartReturnTable)
            {
                PartReturnDetail.RMARefNo=CommonUtil.GetRandomStringWithSpecialChars(5);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partReturnTable, "Part No", PartReturnDetail.PartNumber, "Rsn").SetText(PartReturnDetail.ReturnReason, "ReturnReason");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partReturnTable, "Part No", PartReturnDetail.PartNumber, "RtnQty").SetText(PartReturnDetail.ReturnQty, "ReturnQty");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partReturnTable, "Part No", PartReturnDetail.PartNumber, "RefNo").SetText(PartReturnDetail.RMARefNo, "RMARefNo");
                Driver.WaitForReady();
            }
            _extendpage.Save();
        }

        /// <summary>
        /// Verify No values Existing In The Parts Returned Frame
        /// </summary>
        /// <param name="PurcReturntObjec"></param>
        public void VerifyNovaluesExistingInThePartsReturnedFrame(PartReturn PurcReturntObjec,int ExpectedCount=0)
        {            
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            Driver.WaitForReady();
            RetrievePartReturnDetail(PurcReturntObjec);
            Driver.WaitForReady();
            Driver.SwitchToFrame(_partReturnFrame, "partReturnFrame");
            Driver.WaitForReady();
            int ActualCount = _partReturnTableRows.Count;
            CommonUtil.AssertTrue<int>(ExpectedCount, ActualCount);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info($"Successfully Verified No values Existing In The Parts Returned Frame");
        }

        /// <summary>
        /// Fill And Get PartReturn For Stock
        /// </summary>
        /// <param name="PurcReturntObjec"></param>
        /// <returns></returns>
        public string FillAndGetPartReturnForStock(PartReturn PurcReturntObjec)
        {
            Settings.Logger.Info($"  Fill Part Return To WorkOrder");
            RetrievePartReturnDetail(PurcReturntObjec);
            Settings.Logger.Info($" Filling Parts Return To Work Order");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_partReturnFrame, "PartRequestFrame");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_partReturnTable, "P.O.#", PurcReturntObjec.PO, "Rsn").SetText(PurcReturntObjec.StockReason, "StockReason");
            Driver.WaitForSomeTime(); 
            String PopMessage= Driver.GetAlertText();
            Driver.AcceptAlert();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            Driver.WaitForReady();
            _extendpage.ActionRequiredWindow("Leave");
            Driver.WaitForReady();
            return PopMessage;
        }

        /// <summary>
        /// Verify Stock Part Return Pop Message
        /// </summary>
        /// <param name="ActualMessage"></param>
        /// <param name="ExpectedMessage"></param>
        public void VerifyStockPartReturnPopMessage(string ActualMessage,string ExpectedMessage)
        {
            Assert.True(ActualMessage.Contains(ExpectedMessage,StringComparison.OrdinalIgnoreCase),$" Actual message --{ActualMessage } not contain expected message --{ExpectedMessage} ");
            Settings.Logger.Info($"Successfully Verified Stock Part return Po pMessage");
        }

        /// <summary>
        /// Fill Part Return For Stock
        /// </summary>
        /// <param name="PurcReturntObjec"></param>
        public void FillPartReturnForStock(PartReturn PurcReturntObjec)
        {
            Settings.Logger.Info($"  Fill Part Return To Stock Part");
            RetrievePartReturnDetail(PurcReturntObjec);
            Settings.Logger.Info($" Filling Parts Return To Stock Part");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_partReturnFrame, "PartRequestFrame");
            Driver.WaitForReady();
            foreach (PartReturnTable PartReturnDetail in PurcReturntObjec.PartReturnTable)
            {
                PartReturnDetail.RMARefNo = CommonUtil.GetRandomStringWithSpecialChars(5);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partReturnTable, "P.O.#", PartReturnDetail.PO, "Rsn").SetText(PartReturnDetail.ReturnReason, "StockReason");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partReturnTable, "P.O.#", PartReturnDetail.PO, "RtnQty").SetText(PartReturnDetail.ReturnQty, "ReturnQty");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partReturnTable, "P.O.#", PartReturnDetail.PO, "RefNo").SetText(PartReturnDetail.RMARefNo, "RMARefNo");
                Driver.WaitForReady();
            }
            _extendpage.Save();
        }

        /// <summary>
        /// Fill Part Return For Credit WorkOrder
        /// </summary>
        /// <param name="PurcReturntObjec"></param>
        public void FillPartReturnForCreditWorkOrder(PartReturn PurcReturntObjec)
        {
            Settings.Logger.Info($"  Fill Part Return To Credit WorkOrder");
            RetrievePartReturnDetail(PurcReturntObjec);
            Settings.Logger.Info($" Filling Parts Return To Stock Part");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_partReturnFrame, "PartRequestFrame");
            Driver.WaitForReady();
            foreach (PartReturnTable PartReturnDetail in PurcReturntObjec.PartReturnTable)
            {
                PartReturnDetail.RMARefNo = CommonUtil.GetRandomStringWithSpecialChars(5);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partReturnTable, "Work Order", "", "wono").SetText(PartReturnDetail.WorkOrderNo, "WorkOrderNo");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partReturnTable, "Work Order", PartReturnDetail.WorkOrderNo, "job").SetText(PartReturnDetail.JobCode, "JobCode");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partReturnTable, "Work Order", PartReturnDetail.WorkOrderNo, "partno").SetText(PartReturnDetail.PartNumber, "PartNumber");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partReturnTable, "Work Order", PartReturnDetail.WorkOrderNo, "creditqty").SetText(PartReturnDetail.ReturnQty, "CreditQty");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partReturnTable, "Work Order", PartReturnDetail.WorkOrderNo, "unitcost").SendKeys(Keys.Tab);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partReturnTable, "Work Order", PartReturnDetail.WorkOrderNo, "rsn").SetText(PartReturnDetail.ReturnReason, "Reason");

                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partReturnTable, "Work Order", PartReturnDetail.WorkOrderNo, "refno").SetText(PartReturnDetail.RMARefNo, "RMARefNo");
                Driver.WaitForReady();
            }
            _extendpage.Save();
        }
    }
}
