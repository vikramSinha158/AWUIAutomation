﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartsAdjustmentPageActions : PartAdjustmentPage
    {
        public PartsAdjustmentPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create New Part Inventory Adjustment
        /// </summary>
        public void CreateNewPartAdjustment(PartsAdjustmentObjects partAdjustment)
        {
            if (partAdjustment.Location == null)
                partAdjustment.Location = Settings.Location;
            string[] dataParams = { partAdjustment.Number, partAdjustment.AdjustQty, partAdjustment.Location };
            if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection, "PartAdjustmentQuery",
                dataParams, Settings.DBType))
            {
                Settings.Logger.Info(" Create new part adjustment");
                ExtendedPage.SwitchToContentFrame();
                _inputPartNumber.SetText(partAdjustment.Number, "Part Number");
                Driver.WaitForSomeTime();
                _ReasonCode.SetText(partAdjustment.ReasonCode, "Reason Codes");
                Driver.WaitForReady();
                _EmployeeNo.SetText(partAdjustment.EmployeeNumber, "Employee Number");
                Driver.WaitForReady();
                if (partAdjustment.LotNumberRequired)
                {
                    _lotInfoBtn.ClickElement("Lot Number Button", Driver);
                    partAdjustment.LotNumber = AddLotNumber(partAdjustment.LotNumber, partAdjustment.MfgDate, partAdjustment.ExpDate);
                }
                _AdjustmentQty.SetText(partAdjustment.AdjustQty, "Adjust Quantity");
                Driver.WaitForReady();
                _AdjustmentPrice.SetText(partAdjustment.AdjustPrice, "Adjust Price");
                Driver.WaitForReady();
                _Notes.SetText(partAdjustment.Notes, "Notes");
                Driver.WaitForReady();
         
                ExtendedPage.Save();
            }
        }


        /// <summary>
        /// Add Lot Number
        /// </summary>
        /// <param name="LotNumber"></param>
        /// <param name="MfgDate"></param>
        /// <param name="ExpDate"></param>
        public string AddLotNumber(string? LotNumber, string? MfgDate, string? ExpDate)
        {
            Settings.Logger.Info(" Adding Lot Number ");
            Driver.SwitchTo().DefaultContent();
            Driver.SwitchToFrame(ExtendedPage._contentFrame2, "Content frame 2");
            Driver.WaitForReady();
            if (LotNumber != null) _inputLotNo.SetText(LotNumber, "Lot No");
            else {
                LotNumber = (CommonUtil.GetRandomStringWithSpecialChars(6));
                _inputLotNo.SetText(LotNumber, "Lot No");
            }        
            Driver.WaitForReady();
            _inputLotMfgDate.SetText(MfgDate, "Mfg date");
            Driver.WaitForReady();
            _inputLotExpDate.SetText(ExpDate, "Exp date");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            ExtendedPage._closeShowAttachmentsBtn.Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.SwitchToContentFrame();
            return LotNumber;
        }

        /// <summary>
        /// Add Part Serial Entry
        /// </summary>
        /// <param name="SerialNo"></param>
        /// <param name="MfgDate"></param>
        /// <param name="ExpDate"></param>
        /// <returns></returns>
        public string AddPartSerialEntry(string? SerialNo, string? MfgDate, string? ExpDate)
        {
            Settings.Logger.Info(" SerialNo Lot Number ");
            Driver.SwitchTo().DefaultContent();
            Driver.SwitchToFrame(ExtendedPage._contentFrame2, "Content 2");
            Driver.SwitchToFrame(_frameSerialEntry, "Serial Entry");
            _inputSerialNo.SetText(CommonUtil.GetRandomStringWithSpecialChars(6), "Serial No");
            if (SerialNo != null) _inputSerialNo.SetText(SerialNo, "SerialNo");
            else
            {
                SerialNo = (CommonUtil.GetRandomStringWithSpecialChars(6));
                _inputSerialNo.SetText(SerialNo, "SerialNo");
            }
            Driver.WaitForReady();
            _inputSnMfgDate.SetText(MfgDate, "Mfg date");
            Driver.WaitForReady();
            _inputSnExpDate.SetText(ExpDate, "Exp date");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            ExtendedPage._closeShowAttachmentsBtn.Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.SwitchToContentFrame();
            return SerialNo;
        }

        /// <summary> 
        /// Move Part Serial No List
        /// </summary>
        /// <param name="SerialPartNo"></param>
        /// <param name="PartSerialNoList"></param>
        public void MovePartSerialNoList(string SerialNo)
        {
            Settings.Logger.Info(" Moving  Part Serial No List ");
            List<string> PartSerialNoList=new List<string>();
            PartSerialNoList.Add(SerialNo);
            Driver.SwitchTo().DefaultContent();
            Driver.SwitchToFrame(ExtendedPage._contentFrame2, "Content 2");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_serialFrame, "serialFrame Frame");
            Driver.WaitForReady();
            if (PartSerialNoList.Count > 0)
            {
                Driver.WaitForReady();             
                ExtendedPage.SelectMultipleItemFromList(_partSerialUnitRight, _partSerialUnitMoveLeft, PartSerialNoList);
            }
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            Driver.WaitForReady();
            ExtendedPage._closeShowAttachmentsBtn.Click();
            Driver.WaitForReady();
            ExtendedPage.SwitchToContentFrame();
        }
    }
}
