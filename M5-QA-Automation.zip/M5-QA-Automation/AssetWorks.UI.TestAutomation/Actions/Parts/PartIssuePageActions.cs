﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartIssuePageActions : PartIssuePage
    {
        public PartIssuePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Add Part Issue
        /// </summary>
        /// <param name="PartsIssue"></param>
        public PartsIssue CreatePartIssue(PartsIssue PartsIssue)
        {
            string InvoiceNo = String.Empty;
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _stocktype.SelectDropdownUsingValue("StockType", PartsIssue.StockType);
            Driver.WaitForReady();
            _issueTo.SelectDropdownUsingValue("IssueTo", PartsIssue.IssueTo);
            Driver.WaitForReady();
            _issuingEmpNo.SetText(PartsIssue.EmpNo, "EmpNo");
            Driver.WaitForReady();
            _vendorNo.SetText(PartsIssue.Vendor, "Vendor");
            Driver.WaitForReady();
            if (PartsIssue.StockType == "N")
            {
                InvoiceNo = Convert.ToString(CommonUtil.GenerateRandomIntValue(1000, 99999));
                PartsIssue.InvoiceNo = InvoiceNo;
                _invoiceNo.SetText(PartsIssue.InvoiceNo, "InvoiceNo");
                Driver.WaitForReady();
            }    
            _refNo.SetText(PartsIssue.RefReqNo, "RefReqNo");
            Driver.WaitForReady();
            if (PartsIssue.PRONumberRequired)
            {
                PartsIssue.PRONumber = Convert.ToString(CommonUtil.GenerateRandomIntValue(111111111, 999999999));
                Driver.WaitForReady();
                _proNumber.Click(); 
                _proNumber.SetText(PartsIssue.PRONumber, "PRONumber");
                Driver.WaitForReady();
            }
            Driver.WaitForReady();    
            if (PartsIssue.PartsIssueToUnits != null)
            {
                FillPartsIssueToUnits(PartsIssue);
            }
            if (PartsIssue.PartsIssueToDirectAccount != null)
            {
                FillPartsIssueToDirectaccount(PartsIssue);
            }
            if (PartsIssue.PartsIssueToIndirectAccount != null)
            {
                FillPartsIssueToIndirectAccount(PartsIssue);
            }
            if (PartsIssue.PartsIssueToDepartment != null)
            {
                FillPartsIssueToDepartment(PartsIssue);
            }
            if (PartsIssue.PartsIssueToWorkOrders != null)
            {
                FillPartsIssueToWorkOrders(PartsIssue);
            }            
            _extendpage.Save();
            _extendpage.ActionRequiredWindow("Print Request", "prtNothingBtn");
            Driver.WaitForReady();
            Settings.Logger.Info($" Created Part Issue ");
            return PartsIssue;
        }

        /// <summary>
        /// Fill Parts Issue To Units
        /// </summary>
        /// <param name="PartsIssue"></param>
        public void FillPartsIssueToUnits(PartsIssue PartsIssue)
        {
            Settings.Logger.Info($" Filling Parts Issue To Units");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_issueToAllFrame, "PartRequestFrame");
            Driver.WaitForReady();
            foreach (PartsIssueToUnit PartsIssueToUnit in PartsIssue.PartsIssueToUnits)
            {
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, "Unit/Comp No", "", "UnitNo").ClickElement("Unit/Comp No", Driver);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, "Unit/Comp No", "", "UnitNo").SetText(PartsIssueToUnit.UnitCompNo, "UnitCompNo");
                Driver.WaitForSomeTime();
                Driver.AcceptAlert();
                Driver.WaitForReady();
                if (PartsIssueToUnit.PartKitCode!=null)
                {
                    SelectPartKitUnitLOV(PartsIssueToUnit);
                }
                else
                {
                    _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, "Unit/Comp No", PartsIssueToUnit.UnitCompNo, "PartNo").SetText(PartsIssueToUnit.PartNumber, "PartNumber");
                }
                Driver.WaitForReady();
                _lov.VerifyLovAndSetValue(PartsIssue.PONumber);
                Driver.SwitchToFrame(_issueToAllFrame, "PartRequestFrame");
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                _extendpage.ActionRequiredWindow("Continue");
                Driver.WaitForReady();
                _extendpage.SwitchToContentFrame();
                Driver.SwitchToFrame(_issueToAllFrame, "PartRequestFrame");
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, "Unit/Comp No", PartsIssueToUnit.UnitCompNo, "cpqty").SetText(PartsIssueToUnit.Quantity, "Quantity");
                Driver.WaitForReady();
                if(PartsIssueToUnit.FailCode!=null) _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, "Unit/Comp No", PartsIssueToUnit.UnitCompNo, "cpfail").SetText(PartsIssueToUnit.FailCode, "FailCode");
                Driver.WaitForReady();
                if (PartsIssueToUnit.CheckAvlQuantity) PartsIssueToUnit.AvlQuantity = Convert.ToInt32(_extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, "Unit/Comp No", PartsIssueToUnit.UnitCompNo, "AvailQty").GetAttribute("ovalue"));
            }
        }


        /// <summary>
        /// Fill Parts Issue To Direct Account
        /// </summary>
        /// <param name="PartsIssue"></param>
        public void FillPartsIssueToDirectaccount(PartsIssue PartsIssue)
        {
            Settings.Logger.Info($" Filling Parts Issue To Direct Account");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_issueToAllFrame, "PartRequestFrame");
            Driver.WaitForReady();
            foreach (PartsIssueToDirectAccount PartsIssueToDA in PartsIssue.PartsIssueToDirectAccount)
            {
                string colHeader = "Direct\r\nAcct";
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, "", "DirAcctNo").ClickElement("Direct Account", Driver);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, "", "DirAcctNo").SetText(PartsIssueToDA.DirectAccountNo, "Direct Account");
                Driver.WaitForSomeTime();
                Driver.AcceptAlert();
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, PartsIssueToDA.DirectAccountNo, "PartNo").SetText(PartsIssueToDA.PartNumber, "PartNumber");
                Driver.WaitForReady();
                Driver.WaitForReady();
                _lov.VerifyLovAndSetValue(PartsIssueToDA.PartNumber);
                Driver.SwitchToFrame(_issueToAllFrame, "PartRequestFrame");
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                _extendpage.ActionRequiredWindow("Continue");
                Driver.WaitForReady();
                _extendpage.SwitchToContentFrame();
                Driver.SwitchToFrame(_issueToAllFrame, "PartRequestFrame");
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, PartsIssueToDA.DirectAccountNo, "cpqty").SetText(PartsIssueToDA.Quantity, "Quantity");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, PartsIssueToDA.DirectAccountNo, "cpfail").SetText(PartsIssueToDA.FailCode, "FailCode");
                Driver.WaitForReady();
            }
        }

        /// <summary>
        /// Fill Parts Issue To Indirect Account
        /// </summary>
        /// <param name="PartsIssue"></param>
        public void FillPartsIssueToIndirectAccount(PartsIssue PartsIssue)
        {
            Settings.Logger.Info($" Filling Parts Issue To Indirect Account");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_issueToAllFrame, "PartRequestFrame");
            Driver.WaitForReady();
            foreach (PartsIssueToIndirectAccount PartsIssueToIA in PartsIssue.PartsIssueToIndirectAccount)
            {
                string colHeader = "Indirect\r\nAcct";
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, "", "InAcctNo").ClickElement("Indirect Account", Driver);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, "", "InAcctNo").SetText(PartsIssueToIA.IndirectAccountNo, "Indirect Account");
                Driver.WaitForReady();
                _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, PartsIssueToIA.IndirectAccountNo, "fromResv"), "ReserverCheckBox", PartsIssueToIA.CheckReserveQuantity);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, PartsIssueToIA.IndirectAccountNo, "PartNo").SetText(PartsIssueToIA.PartNumber, "PartNumber");
                Driver.WaitForReady();
                _lov.VerifyLovAndSetValue(PartsIssueToIA.PartNumber);
                Driver.SwitchToFrame(_issueToAllFrame, "PartRequestFrame");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, PartsIssueToIA.IndirectAccountNo, "cpqty").SetText(PartsIssueToIA.Quantity, "Quantity");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, PartsIssueToIA.IndirectAccountNo, "cpfail").SetText(PartsIssueToIA.FailCode, "FailCode");
                Driver.WaitForReady();
                if (PartsIssueToIA.CheckAvlQuantity) PartsIssueToIA.AvlQuantity = Convert.ToInt32(_extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, PartsIssueToIA.IndirectAccountNo, "AvailQty").GetAttribute("ovalue"));
            }
        }
        /// <summary>
        /// Fill Parts Issue To Department
        /// </summary>
        /// <param name="PartsIssue"></param>
        public void FillPartsIssueToDepartment(PartsIssue PartsIssue)
        {
            Settings.Logger.Info($" Filling Parts Issue To Department");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_issueToAllFrame, "PartRequestFrame");
            Driver.WaitForReady();
            int i = 0;
            foreach (PartsIssueToDepartment PartsIssueToDE in PartsIssue.PartsIssueToDepartment)
            {              
               _DeptNO(i).SetText(PartsIssueToDE.DeptNo, "DeptNo");
                Driver.WaitForReady();                        
               _PartNO(i).SetText(PartsIssueToDE.PartNumber, "PartNumber");
                Driver.WaitForReady();
                _Qnty(i).SetText(PartsIssueToDE.Quantity, "Quantity");
                Driver.WaitForReady();
                _FailCode(i).SetText(PartsIssueToDE.FailCode, "FailCode");
                Driver.WaitForReady();
                i++;
            }
        }

        /// <summary>
        /// Fill Parts Issue To WorkOrders
        /// </summary>
        /// <param name="PartsIssue"></param>
        public void FillPartsIssueToWorkOrders(PartsIssue PartsIssue)
        {
            int RowNo = 1;
            string colHeader = "Part\r\nNumber";
            Settings.Logger.Info($" Filling Parts Issue To WorkOrder");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_issueToAllFrame, "PartRequestFrame");
            Driver.WaitForReady();
            foreach (PartsIssueToWorkOrder PartsIssueToWorkOrder in PartsIssue.PartsIssueToWorkOrders)
            {
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, "", "WOUnitNo").ClickElement("Unit/Comp No", Driver);
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, "", "WOUnitNo"));
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, "", "WOUnitNo").SetText(PartsIssueToWorkOrder.UnitCompNo, "UnitCompNo");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, "", "WorkNo").SendKeys(Keys.Tab);
                Driver.WaitForReady();
                if (RowNo == 1) _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, "", "JobNo").SetText(PartsIssueToWorkOrder.Job, "Job");
                else { _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, "", "JobNo").SendKeys(Keys.Tab); }
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, "", "PartNo").SetText(PartsIssueToWorkOrder.PartNumber, "PartNumber");
                Driver.WaitForReady();
                if (PartsIssueToWorkOrder.ActionRequired)
                {
                    Driver.SwitchTo().DefaultContent();
                    _extendpage.ActionRequiredWindow("Continue");
                    Driver.WaitForReady();
                    _extendpage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_issueToAllFrame, "PartRequestFrame");
                }
                _lov.VerifyLovAndSetValue(PartsIssueToWorkOrder.PartNumber);
                Driver.SwitchToFrame(_issueToAllFrame, "PartRequestFrame");
                _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, PartsIssueToWorkOrder.PartNumber, "cpqty").SetText(PartsIssueToWorkOrder.Quantity, "Quantity");
                Driver.WaitForReady();            
                if (PartsIssueToWorkOrder.Position != null) _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, PartsIssueToWorkOrder.PartNumber, "Position").SetText(PartsIssueToWorkOrder.Position, "Position");
                Driver.WaitForReady();
                if (PartsIssueToWorkOrder.FailCode != null) _extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, colHeader, PartsIssueToWorkOrder.PartNumber, "cpfail").SetText(PartsIssueToWorkOrder.FailCode, "FailCode");
                Driver.WaitForReady();
                RowNo++;
            }
        }

        /// <summary>
        /// Select Part Using PartKit
        /// </summary>
        /// <param name="PartKitobj"></param>
        public void SelectPartKitUnitLOV(PartsIssueToUnit PartKitobj)
        {
            Settings.Logger.Info("Slected Part KIt from LOV");
           Driver.DoubleClick(_extendpage.GetTableActionElementByRelatedColumnValue(_partsTable, "Unit/Comp No", PartKitobj.UnitCompNo, "PartNo"),"PartNo");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();           
            _partKitLink.Click();
            Driver.WaitForReady();            
            _lov.SearchAndClickElement(PartKitobj.PartKitCode);
            Driver.SwitchTo().DefaultContent();
            Driver.SwitchToFrame(_partListContentFrame, "");
            Driver.SwitchToFrame(_partListFrame, "PartRequestFrame");                  
             foreach (PartsListData obj in PartKitobj.PartsListData)
             {
                _extendpage.GetTableActionElementByRelatedColumnValue(_partListTable, "Part Number", obj.PartNo, "checkReq1")
               .SelectCheckBox("Select Checkbox");
                _extendpage.GetTableActionElementByRelatedColumnValue(_partListTable, "Part Number", obj.PartNo, "ShpQty")
                .SetText(obj.Quantity, "Quantity");               
             }
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnSaveButton();
            Driver.WaitForReady();
        }
    }
}
