﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using System;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    public class PartNumberChangePageActions : PartNumberChangePage
    {
        public PartNumberChangePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Perform Part number cahnge
        /// </summary>
        /// <param name="partObject"></param>
        /// <param name="newPartObject"></param>
        /// <returns> New part number</returns>
        public string PerformPartNumberChange(PartsMainCatalog partObject, PartsMainCatalog newPartObject)
        {
            Settings.Logger.Info("Perform part number change");
            _extendedPage.SwitchToContentFrame();
            FillAndVerifyExistingPartNumber(partObject);
            FillNewPartNumber(newPartObject);            
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            return newPartObject.PartNumber;
        }
          
        /// <summary>
        /// Fill existing part number and verify details
        /// </summary>
        /// <param name="partObject"></param>
        public void FillAndVerifyExistingPartNumber(PartsMainCatalog partObject)
        {
            _partNo.SetText(partObject.PartNumber, "Part Number");
            Driver.WaitForReady();
            _extendedPage.VerifyElement(_manufacturer, partObject.Manufacturer);
            _extendedPage.VerifyElement(_partDesc, partObject.PartDesc);
        }

        /// <summary>
        /// Fill new part number
        /// </summary>
        /// <param name="newPartObject"></param>
        public void FillNewPartNumber(PartsMainCatalog newPartObject)
        {
            string PartNumber = string.Empty;
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(newPartObject.PartNumber, ref PartNumber, "", 12))
            {
                newPartObject.PartNumber = PartNumber;
                _newPartNo.SetText(newPartObject.PartNumber, "New Part Number");
                Driver.WaitForReady();
                _newManufacturer.SetText(newPartObject.Manufacturer, "New Manufacturer");
                Driver.WaitForReady();
            }
        }

    }
}
