﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartReservesPageActions : PartReservesPage
    {
        public PartReservesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Retrieve PartReturn Detail
        /// </summary>
        /// <param name="PurcReturntObject"></param>
        public void CreatePartReserves(PartReserved PartReservedObject)
        {
            Settings.Logger.Info($"  Create Part Reserves");
            string colHeader = "PO/Tkt\r\nNo.";
            Settings.Logger.Info(" Retrieve Part Return detail ");
            Driver.WaitForReady();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _StatusDateFrom.SetText(PartReservedObject.StatusStartFrom, "StatusStartFrom");
            Driver.WaitForReady();
            _StatusDateTo.SetText(PartReservedObject.StatusStartTo, "StatusStartTo");
            Driver.WaitForReady();
            _partNo.SetText(PartReservedObject.PartNumber, "PartNumber");        
            Driver.WaitForReady();
            _retrieve.Click();
            Driver.WaitForReady();
            Driver.SwitchToFrame(_partReserveFram, "PartRequestFrame");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_partTable, colHeader, PartReservedObject.PO, "TypeCode").SelectDropdownUsingValue("Reserved", PartReservedObject.REserved);
            Driver.WaitForReady();
            _extendpage.Save();
        }

        /// <summary>
        /// Verify No values Existing In The Parts Reserves Frame
        /// </summary>
        /// <param name="PartReservedObject"></param>
        public void VerifyNovaluesExistingInThePartsReservesFrame(PartReserved PartReservedObject)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _StatusDateFrom.SetText(PartReservedObject.StatusStartFrom, "StatusStartFrom");
            Driver.WaitForReady();
            _StatusDateTo.SetText(PartReservedObject.StatusStartTo, "StatusStartTo");
            Driver.WaitForReady();
            _partNo.SetText(PartReservedObject.PartNumber, "PartNumber");
            Driver.WaitForReady();
            _retrieve.Click();
            Driver.WaitForReady();
            _extendpage.VerifyTableRowDeletion(_partReserveFram, _partTableRows, " Part Reserves table",0);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info($"Successfully Verified No values Existing In The Part Reserves tabl Frame");
        }
    }
}
