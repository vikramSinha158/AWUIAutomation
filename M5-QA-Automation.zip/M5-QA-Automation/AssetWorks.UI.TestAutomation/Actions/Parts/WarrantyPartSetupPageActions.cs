﻿
using OpenQA.Selenium;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.Core.Extensions;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class WarrantyPartSetupPageActions : WarrantyPartSetupPage
    {
        public WarrantyPartSetupPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Warranty Part
        /// </summary>
        /// <param name="warranty"></param>
        public void CreateWarrantyPart(WarrantyPart warranty)
        {
            Settings.Logger.Info(" Creating New Warranty Part ");
            _inputPartNo.SetText(warranty.PartNo, "Part Number", Driver, ExtendedPage._contentFrame, "content frame");
            Driver.WaitForReady();
            if (ExtendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                ExtendedPage.ClickOnDialogBoxButton("Create");
            ExtendedPage.SwitchToContentFrame();
            _inputVendorNo.SetText(warranty.VendorNo, "Vendor No");
            Driver.WaitForReady();
            _inputWarrantyCode.SetText(warranty.WarrantyCode, "Warranty Code");
            Driver.WaitForReady();
            _inputTermsUsage.SetText(warranty.TermsUsage, "Terms Usage");
            Driver.WaitForReady();
            _selectUsageUM.SelectFilterValueHavingEqualValue(warranty.UsageUM);
            Driver.WaitForReady();
            _inputTermsTime.SetText(warranty.TermsTime, "Terms Time");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Remove Warranty Part
        /// </summary>
        /// <param name="warranty"></param>
        public void RemoveWarrantyPart(WarrantyPart warranty)
        {
            Settings.Logger.Info(" Removing Warranty from Part ");
            ExtendedPage.RefreshAndSetText(_inputPartNo, warranty.PartNo, "Part Number");
            Driver.WaitForReady();
            _inputVendorNo.SetText(warranty.VendorNo, "Vendor No");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.ClickOnDeleteButton();
            ExtendedPage.ActionRequiredWindow("Delete");
            Driver.WaitForSomeTime();
            Driver.AcceptAlert();
        }
    }
}
