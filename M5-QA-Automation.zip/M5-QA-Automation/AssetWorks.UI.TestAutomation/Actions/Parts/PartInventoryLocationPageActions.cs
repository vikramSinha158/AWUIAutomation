﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartInventoryLocationPageActions : PartInventoryPage
    {
        public PartInventoryLocationPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create new part inventory location
        /// </summary>
        /// <param name="objPartInventory"></param>
        public string CreateNewPartInventoryLocation(PartsInventoryLocationObjects objPartInventory)
        {
            if (objPartInventory.Location == null)
                objPartInventory.Location = Settings.Location;
            string[] dataParams = { objPartInventory.Number, objPartInventory.Location};
            if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection, "PartInventoryQuery",
                dataParams, Settings.DBType))
            {
                Settings.Logger.Info(" Create new part inventory location");
                _inputPartNumber.SetText(objPartInventory.Number, "Part No", Driver, ExtendedPage._contentFrame, "Content Frame");
                Driver.WaitForSomeTime();
                if (ExtendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                    ExtendedPage.ClickOnDialogBoxButton("Create");
                Driver.WaitForReady();
                ExtendedPage.SwitchToContentFrame();
                if (objPartInventory.parametersTab != null)
                    FillParametersTabInfo(objPartInventory.parametersTab);
                if (objPartInventory.reorderTab != null)
                    FillReorderTabInfo(objPartInventory.reorderTab);
                ExtendedPage.VerifyRecordCreatedSuccess(_inputPartNumber, _inputDescription, objPartInventory.Number, "Part No");
            }
            return objPartInventory.Number;
        }

        /// <summary>
        /// Update Parts Inventory Location
        /// </summary>
        /// <param name="objPartInventory"></param>
        public void UpdatePartInventoryLocation(PartsInventoryLocationObjects objPartInventory)
        {
            Settings.Logger.Info("Update Parts Inventory Location Data for : " + objPartInventory.Number);
            ExtendedPage.RefreshAndSetText(_inputPartNumber, objPartInventory.Number, "Part No");
            Driver.WaitForReady();
            if (objPartInventory.parametersTab != null)
                FillParametersTabInfo(objPartInventory.parametersTab);
            if (objPartInventory.reorderTab != null)
                FillReorderTabInfo(objPartInventory.reorderTab);
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Fill Parameters Tab Info
        /// </summary>
        /// <param name="parametersTab"></param>
        public void FillParametersTabInfo(PILMParametersTab parametersTab)
        {
            Settings.Logger.Info(" Filling Parameters Tab Information ");
            _stockType.SelectFilterValueHavingEqualValue(parametersTab.StockType);
            Driver.WaitForReady();
            _reorderAllowed.SelectFilterValueHavingEqualValue(parametersTab.ReorderAllowed);
            Driver.WaitForReady();
            _issueToDepartment.SelectFilterValueHavingEqualValue(parametersTab.IssueToDepartment);
            Driver.WaitForReady();
            _issueToAccount.SelectFilterValueHavingEqualValue(parametersTab.IssueToAccount);
            Driver.WaitForReady();
            _coreTracking.SelectFilterValueHavingEqualValue(parametersTab.CoreTracking);
            Driver.WaitForReady();
            _coreCharge.SetText(parametersTab.CoreCharge, "Core Charge");
            Driver.WaitForReady();
            _chargeCode.SetText(parametersTab.ChargeCode, "Charge Code");
            Driver.WaitForReady();
            _costCategory.SetText(parametersTab.CostCategory, "Cost Category");
            Driver.WaitForReady();
            _markupScheme.SetText(parametersTab.MarkupScheme, "Markup Scheme");
            Driver.WaitForReady();
            _standard.SetText(parametersTab.Standard, "Standard");
            Driver.WaitForReady();
            _binPrimaryLoc.SetText(parametersTab.BinLocationPrimary, "Bin Location Primary");
            Driver.WaitForReady();
            _binAlternateLoc.SetText(parametersTab.BinLocationAlternate, "Bin Location Alternate");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Fill Reorder Tab Info
        /// </summary>
        /// <param name="reorderTab"></param>
        public void FillReorderTabInfo(PILMReorderTab reorderTab)
        {
            Settings.Logger.Info(" Filling Reorder Tab Information ");
            Driver.ScrollIntoViewAndClick(ExtendedPage.GetTabLinkByText("Reorder"), "Reorder Tab");
            Driver.WaitForReady();
            _vendorNo.SetText(reorderTab.VendorNo, "VendorNo");
            Driver.WaitForReady();
            _vendorAltNo.SetText(reorderTab.AltVendorNo, "AltVendorNo");
            Driver.WaitForReady();
            _stdOrderQty.SetText(reorderTab.StandardOrderQty, "Standard Order Qty");
            Driver.WaitForReady();
            _maxInvQty.SetText(reorderTab.MaximumInvQty, "Maximum Inv Qty");
            Driver.WaitForReady();
            _minInvQty.SetText(reorderTab.MinimumInvQty, "Minimum Inv Qty");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Parts Inventory Data
        /// </summary>
        public void VerifyPartsInventoryData(PartsInventoryLocationObjects objPartInventory)
        {
            Settings.Logger.Info("Verify Parts Inventory Location Data for : " + objPartInventory.Number);
            ExtendedPage.RefreshAndSetText(_inputPartNumber, objPartInventory.Number, "Part No");
            Driver.WaitForReady();
            if (objPartInventory.parametersTab != null)
            {
                CommonUtil.VerifyElementValue(_stockType, "Stock Type", objPartInventory.parametersTab.StockType, true);
                CommonUtil.VerifyElementValue(_reorderAllowed, "Reorder Allowed", objPartInventory.parametersTab.ReorderAllowed, true);
                CommonUtil.VerifyElementValue(_issueToDepartment, "Issue To Department", objPartInventory.parametersTab.IssueToDepartment, true);
                CommonUtil.VerifyElementValue(_issueToAccount, "Issue To Account", objPartInventory.parametersTab.IssueToAccount, true);
                CommonUtil.VerifyElementValue(_coreTracking, "Core Tracking", objPartInventory.parametersTab.CoreTracking, true);
                CommonUtil.VerifyElementValue(_coreCharge, "Core Charge", objPartInventory.parametersTab.CoreCharge);
                CommonUtil.VerifyElementValue(_chargeCode, "Charge Code", objPartInventory.parametersTab.ChargeCode);
                CommonUtil.VerifyElementValue(_standard, "Standard", objPartInventory.parametersTab.Standard);
                CommonUtil.VerifyElementValue(_binPrimaryLoc, "Bin Location Primary", objPartInventory.parametersTab.BinLocationPrimary);
                CommonUtil.VerifyElementValue(_binAlternateLoc, "Bin Location Alternate", objPartInventory.parametersTab.BinLocationAlternate,false,"value");
                CommonUtil.VerifyElementValue(_costCategory, "Cost Category", objPartInventory.parametersTab.CostCategory);
                CommonUtil.VerifyElementValue(_markupScheme, "Markup Scheme", objPartInventory.parametersTab.MarkupScheme);
            }
            if (objPartInventory.reorderTab != null)
            {
                Driver.ScrollIntoViewAndClick(ExtendedPage.GetTabLinkByText("Reorder"), "Reorder Tab");
                CommonUtil.VerifyElementValue(_vendorNo, "Vendor No", objPartInventory.reorderTab.VendorNo);
                CommonUtil.VerifyElementValue(_vendorAltNo, "Vendor Alt No", objPartInventory.reorderTab.AltVendorNo);
                CommonUtil.VerifyElementValue(_stdOrderQty, "Standard Order Qty", objPartInventory.reorderTab.StandardOrderQty);
                CommonUtil.VerifyElementValue(_maxInvQty, "Maximum Inventory Quantity", objPartInventory.reorderTab.MaximumInvQty);
                CommonUtil.VerifyElementValue(_minInvQty, "Minimum Inventory Quantity", objPartInventory.reorderTab.MinimumInvQty);
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Part Adjustment
        /// </summary>
        /// <param name="partAdjustmentObjects"></param>
        public void VerifyPartAjustment(PartsAdjustmentObjects partAdjustmentObjects)
        {
            Settings.Logger.Info("Verify Parts Inventory Locations for : " + partAdjustmentObjects.Number);
            ExtendedPage.RefreshAndSetText(_inputPartNumber, partAdjustmentObjects.Number, "Part Number");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_QtyOnHand, "Quantity On Hand", partAdjustmentObjects.QtyOnHand);
            Driver.ScrollIntoViewAndClick(ExtendedPage.GetTabLinkByText("Stock Status"), "Stock Status");
            CommonUtil.VerifyElementValue(_onHandQuantity, "On Hand Quantity", partAdjustmentObjects.QtyOnHand);
            CommonUtil.VerifyElementValue(_onHandAv, "On Hand Quantity Available", partAdjustmentObjects.AvlQtyOnHand);
            CommonUtil.VerifyElementValue(_onOrderRev, "On Order Reserved", partAdjustmentObjects.OnOrderReserved);
            CommonUtil.VerifyElementValue(_onHandRev, "On Hand Reserved", partAdjustmentObjects.OnHandRev);
            CommonUtil.VerifyElementValue(_onOrderQty, "On Order Quantity", partAdjustmentObjects.OnOrderQty);
            CommonUtil.VerifyElementValue(_onOrderAv, "On Order Available ", partAdjustmentObjects.OnOrderAv);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Part Inventory Location Deletion
        /// </summary>
        /// <param name="PartNo"></param>
        public void VerifyPartInventoryLocationDeletion(string PartNo)
        {
            Settings.Logger.Info("Verify Part Inventory Location Deletion : " + PartNo);
            ExtendedPage.SwitchToContentFrame();
            _inputPartNumber.SetText(PartNo, "Part No");
            Driver.WaitForReady();
            _inputPartNumber.Click();
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.ClickOnDeleteButton();
            ExtendedPage.ActionRequiredWindow("Delete");
            Driver.WaitForReady();
            ExtendedPage.VerifyCodeDoesNotExist(_inputPartNumber, PartNo, "Part No");
        }
    }
}