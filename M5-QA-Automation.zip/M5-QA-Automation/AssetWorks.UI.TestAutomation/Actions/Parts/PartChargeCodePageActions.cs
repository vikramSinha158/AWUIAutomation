﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;


namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartChargeCodePageActions : PartChargeCodePage
    {
        public PartChargeCodePageActions(IWebDriver? Driver) : base(Driver) { }

        /// <summary>
        /// Create new Part Charge Code
        /// </summary>
        /// <param name="partChargeCode"></param>
        /// <returns></returns>
        public string CreatePartChargeCode(PartChargeCodeObjects partChargeCode)
        {
            string Code = string.Empty;
            if (!ExtendedPage.CheckDataExistenceAndGetActionCode(partChargeCode.ChargeCode, ref Code, "PartChargeCodeQuery", 3))
            {
                Settings.Logger.Info(" Create new Part Charge Code ");
                ExtendedPage.SwitchToTableFrame(_framePartChargeCode);
                _inputChargeCode.SetText(Code, "Charge Code");
                _inputDescription.SetText(partChargeCode.Description, "Description");
                _selectChargeType.SelectFilterValueHavingEqualValue(partChargeCode.ChargeType);
                _checkboxDefault.SelectCheckBox("Default", partChargeCode.Default);
                Driver.SwitchTo().DefaultContent();
                ExtendedPage.ClickOnSaveButton();
                Driver.WaitForReady();
                VerifyPartChargeCode(Code);
            }
            return Code;
        }

        /// <summary>
        /// Verify Part Charge Code
        /// </summary>
        /// <param name="code"></param>
        public void VerifyPartChargeCode(string code)
        {
            Settings.Logger.Info(" Verify Part Charge Code ");
            ExtendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            ExtendedPage.SwitchToTableFrame(_framePartChargeCode);
            ExtendedPage.VerifyTableColumnContainValue(_tableChargeCode, "Charge Code", code);
            Driver.SwitchTo().DefaultContent();
        }
    }
}
