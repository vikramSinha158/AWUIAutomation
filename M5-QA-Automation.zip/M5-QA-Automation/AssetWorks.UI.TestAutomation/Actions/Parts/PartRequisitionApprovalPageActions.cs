﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartRequisitionApprovalPageActions : PartRequisitionApprovalPage
    {
        public PartRequisitionApprovalPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Approve Reject Part Requisition
        /// </summary>
        /// <param name="requisition"></param>
        public void ApproveRejectPartRequisition(RequisitionApproval requisition)
        {
            Settings.Logger.Info(" Approve Reject Part Requisition ");
            ExtendedPage.SwitchToContentFrame();
            _inputRequisitionNo.SetText(requisition.RequisitionNo, "Requisition No");
            Driver.WaitForReady();
            ExtendedPage.SelectAllAndClearField(_inputRequestor);
            _inputRequestor.SetText(requisition.Requestor, "Requestor");
            Driver.WaitForReady();
            _inputVendor.SetText(requisition.VendorNo, "Vendor");
            Driver.WaitForReady();
            ExtendedPage.SelectAllAndClearField(_inputNeededBy);
            _inputNeededBy.SetText(requisition.NeededBy, "Needed By");
            Driver.WaitForReady();
            _inputStartDate.SetText(requisition.StartDate, "Start Date");
            Driver.WaitForReady();
            _inputEndDate.SetText(requisition.EndDate, "End Date");
            Driver.WaitForReady();
            _inputPartNo.SetText(requisition.PartNumber, "Part No");
            Driver.WaitForReady();
            _selectReservedFor.SelectFilterValueHavingEqualValue(requisition.ReservedFor);
            Driver.WaitForReady();
            _btnRetrieve.ClickElement("Retrieve", Driver);
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameReqList, "ReqList");
            ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableReqList, "Requisition ID", requisition.RequisitionNo, "bStatus").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.SwitchToContentFrame();
            _checkboxProcess.SelectCheckBox("Process", requisition.Process);
            Driver.WaitForReady();
            _selectRejReason.SelectDropdownUsingValue("Reject Reason", requisition.RejReason);
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.ActionRequiredWindow("Continue");
            ExtendedPage.ClickOnSaveButton();
        }
    }
}
