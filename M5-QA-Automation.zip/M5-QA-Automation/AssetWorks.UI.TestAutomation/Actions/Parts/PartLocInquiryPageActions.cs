﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    public class PartLocInquiryPageActions : PartLocInquiryPage
    {
        public PartLocInquiryPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create part inventory inquiry
        /// </summary>
        /// <param name="partsInventoryInquiry"></param>
        public void CreatePartInventoryInquiry(PartInventoryInquiry partsInventoryInquiry)
        {
            _extendedPage.SwitchToContentFrame();
            _partNo.SetText(partsInventoryInquiry.Number, "Part Number");
            _location.SelectFilterValueHavingEqualValue(partsInventoryInquiry.Location);
            _showloc.SelectFilterValueHavingEqualValue(partsInventoryInquiry.Show);
            Driver.WaitForReady();
            _department.SetText(partsInventoryInquiry.Department, "Department");
            _retrive.ClickElement("Retrive", Driver);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Part Inventory Inquiry query result
        /// </summary>
        /// <param name="partsInventoryInquiry"></param>
        /// <param name="queryResult"></param>
        internal void VerifyPartInventoryInquiry(PartInventoryInquiry partsInventoryInquiry, PartQueryResult queryResult)
        {
            Settings.Logger.Info(" Verifying Part Query Result details.");
            _extendedPage.SwitchToTableFrame(_invLocInquiryTableFrame);
            CommonUtil.AssertTrue(true, _verifyDept(queryResult.Dept).VerifyElementDisplay("Dept."));
            CommonUtil.AssertTrue(true, _verifyLocation(queryResult.Dept, queryResult.Loc).VerifyElementDisplay("Loc"));
            CommonUtil.AssertTrue(true, _verifyQueryResult(queryResult.Dept, queryResult.Bin).VerifyElementDisplay("Bin"));
            CommonUtil.AssertTrue(true, _verifyQueryResult(queryResult.Dept, queryResult.QtyAvail).VerifyElementDisplay("QtyAvail"));
            CommonUtil.AssertTrue(true, _verifyQueryResult(queryResult.Dept, queryResult.QtyOnHand).VerifyElementDisplay("QtyOnHand"));
            CommonUtil.AssertTrue(true, _verifyQueryResult(queryResult.Dept, queryResult.QtyOnOrd).VerifyElementDisplay("QtyOnOrd"));
            CommonUtil.AssertTrue(true, _verifyQueryResult(queryResult.Dept, queryResult.QtyResv).VerifyElementDisplay("QtyResv"));
            CommonUtil.AssertTrue(true, _verifyQueryResult(queryResult.Dept, queryResult.MinQty).VerifyElementDisplay("MinQty"));
            CommonUtil.AssertTrue(true, _verifyQueryResult(queryResult.Dept, queryResult.MaxQty).VerifyElementDisplay("MaxQty"));
            CommonUtil.AssertTrue(true, _verifyQueryResult(queryResult.Dept, queryResult.AvgUnitCost).VerifyElementDisplay("AvgUnitCost"));
            CommonUtil.AssertTrue(true, _verifyQueryResult(queryResult.Dept, queryResult.TotalCost).VerifyElementDisplay("TotalCost"));
            Driver.SwitchTo().DefaultContent();
        }
    }
}
