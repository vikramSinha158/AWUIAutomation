﻿using System;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartJournalQueryPageActions : PartJournalQueryPage
    {
        public PartJournalQueryPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Retrieve Part Query Results
        /// </summary>
        /// <param name="queryObject"></param>
        public void RetrievePartQueryResults(PartQueryObject queryObject)
        {
            Settings.Logger.Info(" Retrieve Part Query Results ");
            Driver.WaitForReady();
            ExtendedPage.SwitchToContentFrame();
            if (queryObject.Location != null)
            {
                ExtendedPage.SelectAllAndClearField(_inputLocation);
                _inputLocation.SetText(queryObject.Location, "Location");
            }
            else
                _inputLocation.SendKeys(Keys.Tab);
            Driver.WaitForReady();            
            ExtendedPage.SelectAllAndClearField(_inputPartNo);
            _inputPartNo.SetText(queryObject.PartNo, "Part No");
            Driver.WaitForReady();
            _selectReservationType.SelectFilterValueHavingEqualValue(queryObject.ReservationType);
            Driver.WaitForReady();
            _inputReservRefNo.SetText(queryObject.ReservRefNo, "ReservRefNo");
            Driver.WaitForReady();
            _selectTransactionCode.SelectFilterValueHavingEqualValue(queryObject.TransactionCode);
            Driver.WaitForReady();
            _buttonRetrieve.Click();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Part Query Results
        /// </summary>
        /// <param name="queryObject"></param>
        public void VerifyPartQueryResults(PartQueryObject queryObject, string TransCode = "N/A")
        {
            Settings.Logger.Info(" Verify Part Query Results ");
            if (TransCode != "N/A")
                queryObject.TransactionCode = TransCode;
            RetrievePartQueryResults(queryObject);
            Driver.WaitForSomeTime();
            Driver.SwitchToFrame(_frameQueryResults, "PartRequestFrame");
            ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableQueryResults, "Part No.",
                queryObject.PartNo, "TransCode").Click();
            CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableQueryResults, "Part No.",
                queryObject.PartNo, "TransCode"), "Trans Code", queryObject.TransactionCode);
            CommonUtil.VerifyElementValueNotBlank(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableQueryResults, "Part No.",
            queryObject.PartNo, "JnlId"), "JournalNumber");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableQueryResults, "Part No.",
            queryObject.PartNo, "Qty"), "Quantity", queryObject.Quantity,false, "value");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableQueryResults, "Part No.",
            queryObject.PartNo, "User"), "EmployeeName", queryObject.EmployeeName, false, "value");
            Driver.WaitForReady();
            if (queryObject.CheckDate) ExtendedPage.VerifySystemDateContainAppdate(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tableQueryResults, "Part No.",
            queryObject.PartNo, "Date"), "Current Date ",0,"value");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Clear Part Query Results
        /// </summary>
        /// <param name="queryObject"></param>
        public void ClearPartQueryResults(PartQueryObject queryObject)
        {
            Settings.Logger.Info(" Clear Part Query Results ");
            RetrievePartQueryResults(queryObject);
            Driver.WaitForReady();
            _buttonClear.Click();
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputPartDesc, "Part Description", String.Empty);
            Driver.SwitchTo().DefaultContent();
        }
    }
}
