﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Parts;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Parts
{
    internal class PartRequestHandlingPageActions : PartRequestHandlingPage
    {
        public PartRequestHandlingPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Retrieve Part Requests
        /// </summary>
        /// <param name="partRequest"></param>
        public void RetrievePartRequests(PartRequestHandlingObject partRequest)
        {
            Settings.Logger.Info(" Retrieve Part Requests ");
            ExtendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            ExtendedPage.SwitchToContentFrame();
            _selectOption.SelectFilterValueHavingEqualValue(partRequest.Option);
            Driver.WaitForReady();
            _inputLocation.SetText(partRequest.Location, "Location");
            Driver.WaitForReady();
            _inputUnitNo.SetText(partRequest.UnitNo, "Unit No");
            Driver.WaitForReady();
            _inputWoNo.SetText(partRequest.WorkOrderNo, "Work Order No");
            Driver.WaitForReady();
            _selectStatus.SelectFilterValueHavingEqualValue(partRequest.Status);
            Driver.WaitForReady();
            _inputNeedBy.SetText(partRequest.NeedBy, "NeedBy");
            Driver.WaitForReady();
            _buttonRetrieve.Click();
            Driver.WaitForSomeTime();
        }

        /// <summary>
        /// Update Part Request
        /// </summary>
        /// <param name="partRequest"></param>
        public void UpdatePartRequest(PartRequestHandlingObject partRequest)
        {
            Settings.Logger.Info(" Update Part Request ");
            RetrievePartRequests(partRequest);
            if (partRequest.ExistingRequests != null)
            {
                Driver.SwitchToFrame(_framePartReqHandling, "Part Requests frame");
                foreach (ExistingRequests request in partRequest.ExistingRequests)
                {
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartReqDetail, "Part No",
                        request.PartNo, "hwono"), "Work Order No", partRequest.WorkOrderNo, false, "value");
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartReqDetail, "Part No", request.PartNo,
                        "reqApprove").SelectCheckBox("RequireApprove", request.RequireApprove);
                    Driver.WaitForReady();
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartReqDetail, "Part No", request.PartNo,
                        "approved").SelectCheckBox("Approved", request.Approved);
                    Driver.WaitForReady();
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartReqDetail, "Part No", request.PartNo,
                        "ready").SelectCheckBox("Ready", request.Ready);
                    Driver.WaitForReady();
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartReqDetail, "Part No", request.PartNo,
                        "shipTerm").SetText(request.Shipterms, "ShipTerm");
                    Driver.WaitForReady();
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartReqDetail, "Part No", request.PartNo,
                        "invEmp").SetText(request.InvEmp, "InvEmp");
                }
            }
            Driver.SwitchTo().DefaultContent();
            ExtendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Verify Part Request Status
        /// </summary>
        /// <param name="partRequest"></param>
        public void VerifyPartRequest(PartRequestHandlingObject partRequest)
        {
            Settings.Logger.Info(" Verify Part Request Status ");
            RetrievePartRequests(partRequest);
            if (partRequest.ExistingRequests != null)
            {
                Driver.SwitchToFrame(_framePartReqHandling, "Part Requests frame");
                foreach (ExistingRequests request in partRequest.ExistingRequests)
                {
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartReqDetail, "Part No",
                        request.PartNo, "hwono"), "Work Order No", partRequest.WorkOrderNo, false, "value");
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartReqDetail, "Part No",
                        request.PartNo, "hstatus"), "Status", request.Status, false, "value");
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartReqDetail, "Part No",
                       request.PartNo, "shipTerm"), "ShipTerms", request.Shipterms, false, "value");
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartReqDetail, "Part No",
                       request.PartNo, "invEmp"), "InvEmp", request.InvEmp, false, "value");
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Part Request
        /// </summary>
        /// <param name="partRequest"></param>
        public void DeletePartRequest(PartRequestHandlingObject partRequest)
        {
            Settings.Logger.Info(" Delete Part Request Status ");
            RetrievePartRequests(partRequest);
            if (partRequest.ExistingRequests != null)
            {                
                foreach (ExistingRequests request in partRequest.ExistingRequests)
                {
                    Driver.SwitchToFrame(_framePartReqHandling, "Part Requests frame");
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartReqDetail, "Part No", request.PartNo,
                        "hPartNo").ClickElement("PartNo", Driver);
                    Driver.SwitchTo().DefaultContent();
                    ExtendedPage.DeleteAndSave();
                }
            }
        }

        /// <summary>
        /// Verify there are Not any Existing Part Requests
        /// </summary>
        /// <param name="partRequest"></param>
        public void VerifyNoExistingRequests(PartRequestHandlingObject partRequest)
        {
            Settings.Logger.Info(" Verify No Existing Requests ");
            ExtendedPage.SwitchToContentFrame();
            if (partRequest.ExistingRequests != null)
            {
                Driver.SwitchToFrame(_framePartReqHandling, "Part Requests frame");
                foreach (ExistingRequests request in partRequest.ExistingRequests)
                {                    
                    ExtendedPage.VerifyTableColumnDoesNotContainValue(_tablePartReqDetail, "Part No", request.PartNo);                  
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        ///  //Verify Alert PopUp For Zero Qty
        /// </summary>
        /// <param name="partRequest"></param>
        public void UpdatePartRequestAndVerifyTheAlertPopUpForZeroQty(PartRequestHandlingObject partRequest)
        {
            Settings.Logger.Info(" Update Part Request ");
            RetrievePartRequests(partRequest);
            if (partRequest.ExistingRequests != null)
            {
                Driver.SwitchToFrame(_framePartReqHandling, "Part Requests frame");
                foreach (ExistingRequests request in partRequest.ExistingRequests)
                {
                    CommonUtil.VerifyElementValue(ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartReqDetail, "Part No",
                        request.PartNo, "hwono"), "Work Order No", partRequest.WorkOrderNo, false, "value");
                    Driver.WaitForReady();
                    ExtendedPage.GetTableActionElementByRelatedColumnValue(_tablePartReqDetail, "Part No", request.PartNo,
                       "ready").SelectCheckBox("ready", request.Ready);
                    Settings.Logger.Info(" Verify The Aleart PopUp ");
                    string text = Driver.GetAlertText();
                    Driver.AcceptAlert();
                    CommonUtil.AssertTrue<string>(text, request.AlertMessage);
                    Settings.Logger.Info($" Verified Aleart PopUp ::: {text} ");
                }
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
