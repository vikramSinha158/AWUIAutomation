﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class MCCCopyPageActions : MCCCopyPage
    {
        public MCCCopyPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Copy Existing MCC Copy
        /// </summary>
        /// <param name="OldMCCCopy"></param>
        /// <returns></returns>
        public string CopyExistingMCCCopy(string OldMCCCopy)
        {
            Settings.Logger.Info(" Copy MCC ");
            _extendpage.SwitchToContentFrame();
            _oldMCCKeyInput.SetText(OldMCCCopy, "Old MCC Copy no");
            string MCCCopyNo = CommonUtil.GetRandomStringWithSpecialChars(8);
            Driver.WaitForReady();
            _newNewMCCKeyInput.SetText(MCCCopyNo, "MCC Copy No");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClicKSave();
            Settings.Logger.Info($"Successfully creted the Copy MCC existing for MCC {OldMCCCopy}");
            return MCCCopyNo;
        }

    }
}
