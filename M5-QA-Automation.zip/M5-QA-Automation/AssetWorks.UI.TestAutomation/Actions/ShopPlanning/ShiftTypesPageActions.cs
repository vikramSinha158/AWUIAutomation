﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.ShopPlanning;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.ShopPlanning
{
    internal class ShiftTypesPageActions : ShiftTypesPage
    {
        public ShiftTypesPageActions(IWebDriver? Driver) : base(Driver) { }

        /// <summary>
        /// Create Schedule Shift
        /// </summary>
        /// <param name="ScheduleShiftDetail"></param>
        /// <returns></returns>
        public string CreateScheduleShift(ScheduleShift ScheduleShiftDetail)
        {          
            _extendpage.SwitchToContentFrame();
            string ScheduleShiftValue = string.Empty;
            Driver.SwitchToFrame(_schedShiftsFrame, "zoneClassCodesFrame");
            if (string.IsNullOrEmpty(ScheduleShiftDetail.ScheduleShiftCode))
            {
                ScheduleShiftValue = Convert.ToString(CommonUtil.GenerateRandomIntValue(1000, 99999));
                ScheduleShiftDetail.ScheduleShiftCode = ScheduleShiftValue;
                FillScheduleShift(ScheduleShiftDetail);
            }
            else
            {
                if (!CommonUtil.CheckDataExist(Settings.connection, "Query", ScheduleShiftDetail.ScheduleShiftCode, Settings.DBType))
                {
                    FillScheduleShift(ScheduleShiftDetail);
                }
            }        
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Created Schedule Shift");
            return ScheduleShiftDetail.ScheduleShiftCode;
        }

        /// <summary>
        /// FilScheduleShift
        /// </summary>
        /// <param name="ScheduleShiftDetail"></param>
        public void FillScheduleShift(ScheduleShift ScheduleShiftDetail)
        {
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_schedShiftTable, "Schedule Shift", "", "schedshift").SetText(ScheduleShiftDetail.ScheduleShiftCode, "ScheduleShiftCode");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_schedShiftTable, "Schedule Shift", ScheduleShiftDetail.ScheduleShiftCode, "desc").SetText(ScheduleShiftDetail.Description, "Description");
            Driver.WaitForReady();
            _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_schedShiftTable, "Schedule Shift", ScheduleShiftDetail.ScheduleShiftCode, "disabled"), "ScheduleShiftFlag", ScheduleShiftDetail.ScheduleShiftFlag);
            Driver.WaitForReady();
            _extendpage.Save();
        }

        /// <summary>
        /// Verify Schedule Shift
        /// </summary>
        /// <param name="ScheduleShiftDetail"></param>
        public void VerifyScheduleShift(ScheduleShift ScheduleShiftDetail)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_schedShiftsFrame, "Table frame");
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_schedShiftTable, "Schedule Shift", ScheduleShiftDetail.ScheduleShiftCode, "schedshift"), "ScheduleShiftCode", ScheduleShiftDetail.ScheduleShiftCode, false, "value");
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_schedShiftTable, "Schedule Shift", ScheduleShiftDetail.ScheduleShiftCode, "desc"), "Description", ScheduleShiftDetail.Description, false, "value");
            CommonUtil.VerifyCheckboxState(_extendpage.GetTableActionElementByRelatedColumnValue(_schedShiftTable, "Schedule Shift", ScheduleShiftDetail.ScheduleShiftCode, "disabled"), "ScheduleShiftFlag", ScheduleShiftDetail.ScheduleShiftFlag);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("verified Schedule Shift Details for : " + ScheduleShiftDetail.ScheduleShiftCode);
        }

        /// <summary>
        /// Update Schedule Shift
        /// </summary>
        /// <param name="ScheduleShiftDetail"></param>
        public void UpdateScheduleShift(ScheduleShift ScheduleShiftDetail)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_schedShiftsFrame, "Table frame");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_schedShiftTable, "Schedule Shift", ScheduleShiftDetail.ScheduleShiftCode, "desc").SetText(ScheduleShiftDetail.Description, "Description");
            Driver.WaitForReady();
            _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_schedShiftTable, "Schedule Shift", ScheduleShiftDetail.ScheduleShiftCode, "disabled"), "ScheduleShiftFlag", ScheduleShiftDetail.ScheduleShiftFlag);
            Driver.WaitForReady();
            _extendpage.Save();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Updated Schedule Shift");
        }

        /// <summary>
        /// Delete Schedshift Codes
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteSchedshiftCodes(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_schedShiftsFrame, "Table frame");
            _extendpage.GetTableActionElementByRelatedColumnValue(_schedShiftTable, "Schedule Shift", CodeVal, "schedshift").Click();
            Driver.WaitForReady();
            _extendpage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Deleted Schedshift Codes : " + CodeVal);
        }

        /// <summary>
        /// Verify Deleted Schedule Shift
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedSchedshiftCodes(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_schedShiftsFrame, "Table frame");
            _extendpage.VerifyTableColumnDoesNotContainValue(_schedShiftTable, "Schedule Shift", CodeVal);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verified Schedule ShiftDeletetion : " + CodeVal);
        }
    }
}
