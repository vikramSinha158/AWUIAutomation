﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.ShopPlanning;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.ShopPlanning
{
    internal class ShopPlanningSchedulePageActions : ShopPlanningSchedulePage
    {
        public ShopPlanningSchedulePageActions(IWebDriver? Driver) : base(Driver) { }

        /// <summary>
        /// Create Shop Planning Schedule
        /// </summary>
        /// <param name="ShopPlanningSchedule"></param>
        public void CreateShopPlanningSchedule(ShopPlanningSchedule ShopPlanningSchedule)
        {
            _extendpage.SwitchToContentFrame();
            _location.SetText(ShopPlanningSchedule.Location, "Location");
            Driver.SwitchToFrame(_planScheduleFrame, "schedShiftsFrame");
            foreach(PercentageTimeTable PercentageTimeTable in ShopPlanningSchedule.PercentageTimeTable)
            {
                string TableHaeader = "Schedule\r\nShift";
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, "", "schedule").SetText(PercentageTimeTable.ScheduleShift, "ScheduleShift");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "sm_order").SetText(PercentageTimeTable.SmoothingOrder, "SmoothingOrder");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "mon_pc").SetText(PercentageTimeTable.MonPercentage, "MonPercentage");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "tue_pc").SetText(PercentageTimeTable.TuePercentage, "TuePercentage");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "wed_pc").SetText(PercentageTimeTable.WedPercentage, "WedPercentage");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "thu_pc").SetText(PercentageTimeTable.ThrusPercentage, "ThrusPercentage");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "fri_pc").SetText(PercentageTimeTable.FriPercentage, "FriPercentage");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "sat_pc").SetText(PercentageTimeTable.SatPercentage, "SatPercentage");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "sun_pc").SetText(PercentageTimeTable.SunPercentage, "SunPercentage");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "otstarttimeM").SelectFilterValueHavingEqualValue(PercentageTimeTable.MonStartEnd);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "otstarttimetT").SelectFilterValueHavingEqualValue(PercentageTimeTable.TueStartEnd);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "otstarttimeW").SelectFilterValueHavingEqualValue(PercentageTimeTable.WedStartEnd);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "otstarttimeTH").SelectFilterValueHavingEqualValue(PercentageTimeTable.ThrusStartEnd);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "otstarttimeF").SelectFilterValueHavingEqualValue(PercentageTimeTable.FriStartEnd);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "otstarttimeS").SelectFilterValueHavingEqualValue(PercentageTimeTable.SatStartEnd);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "otstarttimeSU").SelectFilterValueHavingEqualValue(PercentageTimeTable.SunStartEnd);
                Driver.WaitForReady();
            }
            _extendpage.Save();
            Settings.Logger.Info("Created ShopPlanningSchedule ");
        }

        /// <summary>
        /// Verify Shop Planning Schedule
        /// </summary>
        /// <param name="ShopPlanningSchedule"></param>
        public void VerifyShopPlanningSchedule(ShopPlanningSchedule ShopPlanningSchedule)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_location, ShopPlanningSchedule.Location, "Location");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_planScheduleFrame, "schedShiftsFrame");
            foreach (PercentageTimeTable PercentageTimeTable in ShopPlanningSchedule.PercentageTimeTable)
            { 
                Driver.WaitForReady();
                string TableHaeader = "Schedule\r\nShift";
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "schedule"), "ScheduleShift",PercentageTimeTable.ScheduleShift, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "sm_order"), "SmoothingOrder",PercentageTimeTable.SmoothingOrder, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "mon_pc"), "MonPercentage",PercentageTimeTable.MonPercentage, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "tue_pc"), "TuePercentage",PercentageTimeTable.TuePercentage, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "wed_pc"), "WedPercentage",PercentageTimeTable.WedPercentage, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "thu_pc"), "ThrusPercentage",PercentageTimeTable.ThrusPercentage, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "fri_pc"), "FriPercentage",PercentageTimeTable.FriPercentage, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "sat_pc"), "SatPercentage",PercentageTimeTable.SatPercentage, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "sun_pc"), "SunPercentage",PercentageTimeTable.SunPercentage, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "otstarttimeM"), "MonStartEnd",PercentageTimeTable.MonStartEnd, true, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "otstarttimeT"), "TueStartEnd",PercentageTimeTable.TueStartEnd, true, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "otstarttimeW"), "WedStartEnd",PercentageTimeTable.WedStartEnd, true, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "otstarttimeTH"), "ThrusStartEnd",PercentageTimeTable.ThrusStartEnd, true, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "otstarttimeF"), "FriStartEnd",PercentageTimeTable.FriStartEnd, true, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "otstarttimeS"), "SatStartEnd",PercentageTimeTable.SatStartEnd, true, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, TableHaeader, PercentageTimeTable.ScheduleShift, "otstarttimeSU"), "SunStartEnd",PercentageTimeTable.SunStartEnd, true, "value");
            }
            Settings.Logger.Info("Verified ShopPlanningSchedule ");
        }

        /// <summary>
        /// Delete Shop Planning Schedule
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteShopPlanningSchedule(string CodeVal,string ScheduleShift)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_location, CodeVal, "Location");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_planScheduleFrame, "schedShiftsFrame");
            _extendpage.GetTableActionElementByRelatedColumnValue(_planScheduleTable, "Schedule\r\nShift", ScheduleShift, "schedule").Click();
            Driver.WaitForReady();
            _extendpage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Deleted Shop Planning Schedule : " + CodeVal);
        }

        /// <summary>
        /// Verify Deleted Shop Planning Schedule
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedShopPlanningSchedule(string CodeVal, string ScheduleShift)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_location, CodeVal, "Location");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_planScheduleFrame, "schedShiftsFrame");
            _extendpage.VerifyTableColumnDoesNotContainValue(_planScheduleTable, "Schedule\r\nShift", ScheduleShift);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verified Shop Planning Schedule  : " + CodeVal);
        }
    }
}
