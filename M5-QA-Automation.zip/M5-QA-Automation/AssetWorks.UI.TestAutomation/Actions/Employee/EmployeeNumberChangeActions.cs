﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Employee;
using AssetWorks.UI.Core.Utils;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Employee
{
    internal class EmployeeNumberChangeActions : EmployeeNumberChange
    {
        public EmployeeNumberChangeActions(IWebDriver Driver) : base(Driver) { }
        internal ExtendedPageActions _extendedPage => new ExtendedPageActions(Driver);
        internal ListOfValuesPageActions _lov => new ListOfValuesPageActions(Driver);

        /// <summary>
        /// Open Close help
        /// </summary>
        public void OpenAndCloseHelp()
        {
            Settings.Logger.Info(" Open and close help window ");
            _extendedPage._helpBtn.Click();
            Driver.SwitchToNewWBrowserTab(1);
            Driver.Close();
            Driver.SwitchToNewWBrowserTab(0);
        }

        /// <summary>
        /// Change employee id
        /// </summary>
        /// <param name="EmployeeId"></param>
        public (string, EmployeeMainPageActions) ChangeEmployeeId(string EmployeeId)
        {
            Settings.Logger.Info(" Change Employee ID ");
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _extendedPage.VerifyScreenUrl(_changeIdScreenName, ScreensUrl.EmployeeNumberChange);
            _inputEmpID.SetText(EmployeeId, "Edit employee ");
            Driver.WaitForReady();
            string newEmployeeId = string.Concat(EmployeeId, CommonUtil.GetRandomStringWithSpecialChars(2).ToUpper());
            _inputNewEmpID.SetText(newEmployeeId, " New Employee ID ");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            return (newEmployeeId, new EmployeeMainPageActions(Driver));
        }
    }
}
