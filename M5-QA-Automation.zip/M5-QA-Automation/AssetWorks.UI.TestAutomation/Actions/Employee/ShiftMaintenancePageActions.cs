﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Employee;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Employee
{
    internal class ShiftMaintenancePageActions : ShiftMaintenancePage
    {
        public ShiftMaintenancePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Shift Maintenance
        /// </summary>
        /// <param name="ShiftMaintenance"></param>
        /// <returns></returns>
        public string CreateShiftMaintenance(ShiftMaintenance ShiftMaintenance)
        {
            _extendpage.SwitchToContentFrame();
            if (ShiftMaintenance.ShiftDeletion)
            {
               if(CommonUtil.CheckDataExist(Settings.connection, "ShiftMaintenanceQuery", ShiftMaintenance.ShiftNumber, Settings.DBType)) { VerifyShiftDeletionDeletion(ShiftMaintenance.ShiftNumber); }
            }
            if (!CommonUtil.CheckDataExist(Settings.connection, "ShiftMaintenanceQuery", ShiftMaintenance.ShiftNumber, Settings.DBType))
            {
                _shiftno.SetText(ShiftMaintenance.ShiftNumber, "Shift Number");
                Driver.SwitchTo().DefaultContent();
                _extendpage.ActionRequiredWindow("Create");
                _extendpage.SwitchToContentFrame();
                Driver.WaitForReady();
                _shiftdesc.SetText(ShiftMaintenance.ShiftDescription, "ShiftDescription");
                _shifttype.ClickDropDownValuebyContainingText(ShiftMaintenance.Shifttype);
                _shiftstart.SetText(ShiftMaintenance.Shiftstart, "Shiftstart");
                if (ShiftMaintenance.ShiftMaintenanceList != null)
                {
                    FillShiftMaintenanceTable(ShiftMaintenance);
                }
            }         
            _extendpage.Save();
            Settings.Logger.Info($" Successfully Creatted ShiftMaintenance{ ShiftMaintenance.ShiftNumber} ");
            return ShiftMaintenance.ShiftNumber;
        }

        /// <summary>
        /// Fill Shift MaintenanceTable
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillShiftMaintenanceTable(ShiftMaintenance DataObject)
        {
            int RowNumm = 0;
            Driver.SwitchToFrame(_ShiftFrame, "ShiftFrame");
            List<ShiftMaintenanceList> ShiftMaintenanceRecords = DataObject.ShiftMaintenanceList;
            foreach (ShiftMaintenanceList ShiftMaintenanceRecord in ShiftMaintenanceRecords)
            {
                if (RowNumm == 0)
                {
                    Driver.WaitForReady();
                    IWebElement StartDayElement = _extendpage.GetElementForInput($"startday$new_{RowNumm}");
                    Driver.WaitForSomeTime();
                    StartDayElement.Clear();
                    Driver.WaitForSomeTime();
                    _extendpage.GetElementForInput($"startday$new_{RowNumm}").SetText(ShiftMaintenanceRecord.StartDay, "StartDay");
                    Driver.WaitForReady();
                    IWebElement StartTimeElement = _extendpage.GetElementForInput($"starttime$new_{RowNumm}");
                    StartTimeElement.Clear();
                    Driver.WaitForReady();
                    StartTimeElement.SetText(ShiftMaintenanceRecord.StartTime, "StartTime");
                    Driver.WaitForReady();
                    IWebElement EndDayElement = _extendpage.GetElementForInput($"endday$new_{RowNumm}");
                    EndDayElement.Clear();
                    Driver.WaitForReady();
                    EndDayElement.SetText(ShiftMaintenanceRecord.EndDay, "EndDay");
                    Driver.WaitForReady();
                    IWebElement EndTimeElement = _extendpage.GetElementForInput($"endtime$new_{RowNumm}");
                    EndTimeElement.Clear();
                    Driver.WaitForReady();
                    EndTimeElement.SetText(ShiftMaintenanceRecord.EndTime, "EndTime");
                    Driver.WaitForReady();
                    IWebElement PayShiftElement = _extendpage.GetElementForInput($"payshift$new_{RowNumm}");
                    PayShiftElement.Clear();
                    Driver.WaitForReady();
                    PayShiftElement.SetText(ShiftMaintenanceRecord.PayShift, "PayShift");
                    Driver.WaitForReady();
                }
                else {
                    Driver.WaitForReady();
                    _extendpage.GetElementForInput($"startday$new_{RowNumm}").SendKeys(Keys.Tab);
                    Driver.WaitForReady();
                    _extendpage.GetElementForInput($"starttime$new_{RowNumm}").SendKeys(Keys.Tab); ;
                    Driver.WaitForReady();
                    _extendpage.GetElementForInput($"endday$new_{RowNumm}").SendKeys(Keys.Tab); ;
                    Driver.WaitForReady();
                    _extendpage.GetElementForInput($"endtime$new_{RowNumm}").SendKeys(Keys.Tab); ;
                    Driver.WaitForReady();
                    if(RowNumm!= DataObject.WeekDays-1)
                    _extendpage.GetElementForInput($"payshift$new_{RowNumm}").SendKeys(Keys.Tab); ;
                }
                RowNumm++;
            }        
        }

        /// <summary>
        /// Verify Shift Maintenance
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyShiftMaintenance(ShiftMaintenance DataObject)
        {
            int RowNumm = 0;
            _extendpage.RefreshAndSetText(_shiftno, DataObject.ShiftNumber, "Shift Number");
            WaitFOrShitTable();
            CommonUtil.VerifyElementValue(_shiftno, "Shift Number ", DataObject.ShiftNumber);
            CommonUtil.VerifyElementValue(_shiftdesc, "Shift Description ", DataObject.ShiftDescription);
            CommonUtil.VerifyElementValue(_shifttype, "shift type", DataObject.Shifttype);
            CommonUtil.VerifyElementValue(_shiftstart, "shift start ", DataObject.Shiftstart);
            Driver.SwitchToFrame(_ShiftFrame, "ShiftFrame");
            List<ShiftMaintenanceList> ShiftMaintenanceRecords = DataObject.ShiftMaintenanceList;
            foreach (ShiftMaintenanceList ShiftMaintenanceRecord in ShiftMaintenanceRecords)
            {
                CommonUtil.VerifyElementValue(_extendpage.GetElementForInput($"startday${RowNumm}"), " StartDay", ShiftMaintenanceRecord.StartDayId);
                CommonUtil.VerifyElementValue(_extendpage.GetElementForInput($"starttime${RowNumm}"), " StartTime ", ShiftMaintenanceRecord.StartTimeValue);
                CommonUtil.VerifyElementValue(_extendpage.GetElementForInput($"endday${RowNumm}"), " EndDay", ShiftMaintenanceRecord.EndDayId);
                CommonUtil.VerifyElementValue(_extendpage.GetElementForInput($"endtime${RowNumm}"), " EndTime", ShiftMaintenanceRecord.EndTimeValue);
                CommonUtil.VerifyElementValue(_extendpage.GetElementForInput($"payshift${RowNumm}"), " PayShift ", ShiftMaintenanceRecord.PayShift,false, "value");
                RowNumm++;
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info($" Successfully Verified ShiftMaintenance{ DataObject.ShiftNumber} ");
        }

        /// <summary>
        /// WaitFOrShitTable
        /// </summary>
        public void WaitFOrShitTable()
        {
            Driver.WaitForReady();
            Driver.SwitchToFrame(_ShiftFrame, "ShiftFrame");
            Driver.WaitForVisibility(By.XPath("//table[@id='ShiftTable']"), "ShiftTable");
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
        }

        /// <summary>
        /// Verify Test Suite Deletion
        /// </summary>
        /// <param name="ShiftNumber"></param>
        public void VerifyShiftDeletionDeletion(string ShiftNumber)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_shiftno, ShiftNumber, "Shift Number");
            WaitFOrShitTable();
            _shiftno.ClickElement("shiftno", Driver);
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnDeleteButton();
            _extendpage.ActionRequiredWindow("Delete");
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            Driver.WaitForInvisibility(By.XPath(Settings.ActionDialog), "Deletion dialog ");
            string ValueAfterDeletion = _shiftno.GetAttribute("ovalue");
            Assert.True(String.IsNullOrEmpty(ValueAfterDeletion), $"{ShiftNumber} not deleted, found value { ValueAfterDeletion}");
            Settings.Logger.Info($"Shiftno - {ShiftNumber} Deleted successfully  ");
        }
    }
}
