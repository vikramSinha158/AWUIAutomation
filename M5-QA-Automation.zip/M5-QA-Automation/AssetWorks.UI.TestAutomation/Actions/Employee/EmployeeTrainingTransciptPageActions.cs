using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class EmployeeTrainingTransciptPageActions : EmployeeTrainingTransciptPage
    {
        public EmployeeTrainingTransciptPageActions(IWebDriver Driver) : base(Driver) { }

        public static string locator = "new_";
        public static int ValidDays;

        /// <summary>
        /// Add Training Course for an Employee
        /// </summary>
        /// <param name="DataObjectKey"></param>
        /// <returns></returns>
        public EmpTrainingTranscipt AddTrainingCourse(EmpTrainingTranscipt EmpTTObject)
        {
            Settings.Logger.Info($" Add Training Course for an Employee :{EmpTTObject.EmployeeData.EmpNo}");
            _extendpage.SwitchToContentFrame();
            _employeeNo.SetText(EmpTTObject.EmployeeData.EmpNo, "Emloyee No.");
            Driver.WaitForReady();
            if (EmpTTObject.TrainingCourseData != null)
            {
                EmpTTObject.TrainingCourseData = AddCourseData(EmpTTObject.TrainingCourseData);
            }
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickRefresh();
            _extendpage.SwitchToContentFrame();
            _employeeNo.SetText(EmpTTObject.EmployeeData.EmpNo, "Emloyee No.");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info($"Added Traning Course for Employee: {EmpTTObject.EmployeeData.EmpNo}");
            return EmpTTObject;
        }

        /// <summary>
        /// Add Course Data
        /// </summary>
        /// <param name="CourseDataObject"></param>
        public List<TrainingCourseDatum> AddCourseData(List<TrainingCourseDatum> CourseDataObject)
        {            
            for (int i = 0; i < CourseDataObject.Count; i++)
            {
                Driver.SwitchToFrame(_empTrainingFrame, "Employee Training Frame");
                _extendpage.GetElementForInput($"{Course}{locator}0").SetText(CourseDataObject[i].Course, "Course");
                Driver.WaitForReady();
                if (!string.IsNullOrEmpty(CourseDataObject[i].Planned.ToString()))
                {
                     ValidDays = Convert.ToInt32(CourseDataObject[i].Planned) + Convert.ToInt32(CourseDataObject[i].ValidUntil);                  
                    CourseDataObject[i].Planned = CommonUtil.GenerateRandomDateString(Convert.ToInt32(CourseDataObject[i].Planned));
                    _extendpage.GetElementForInput($"{PlannedDate}{locator}0").SetText(CourseDataObject[i].Planned, "Planned");
                }
                Driver.WaitForReady();
                if (!string.IsNullOrEmpty(CourseDataObject[i].Attended))
                {
                     ValidDays = Convert.ToInt32(CourseDataObject[i].Attended) + Convert.ToInt32(CourseDataObject[i].ValidUntil);                  
                    CourseDataObject[i].Attended = CommonUtil.GenerateRandomDateString(Convert.ToInt32(CourseDataObject[i].Attended));
                    _extendpage.GetElementForInput($"{AttendedDate}{locator}0").SetText(CourseDataObject[i].Attended, "Attended");
                }
                CourseDataObject[i].ValidUntil = DateTime.Today.AddDays(ValidDays).ToString("MM/dd/yyyy");
                Driver.WaitForReady();
                _extendpage.GetElementForInput($"{Result}{locator}0", "id", "select").SelectFilterValueHavingEqualValue(CourseDataObject[i].Result);
                Driver.WaitForReady();
                _extendpage.GetElementForInput($"{Grade}{locator}0").SetText(CourseDataObject[i].Grade, "Grade");
                Driver.WaitForReady();
                _extendpage.GetElementForInput($"{CertificateNo}{locator}0").SetText(CourseDataObject[i].CertificateNO, "CertificateNO");
                if (!string.IsNullOrEmpty(CourseDataObject[i].Notes))
                {
                    _extendpage.AddNotes(_extendpage.GetElementForInput($"{Notes}{locator}0", "id", "button"), CourseDataObject[i].Notes);
                    _extendpage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_empTrainingFrame, "Employee Training Frame");
                }
                _extendpage.Save();
                Driver.WaitForReady();
                _extendpage.SwitchToContentFrame();
                if (CourseDataObject[i].AttachmentData!=null)
                {                   
                    Driver.SwitchToFrame(_empTrainingFrame, "Training Course Frame");
                    Driver.WaitForReady();
                    _extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "attaBtn").ClickElement("Attach Link", Driver);
                    Driver.WaitForReady();
                    Driver.SwitchTo().DefaultContent();
                    Driver.SwitchToFrame(_contentFrame2, "Content Frame2");                   
                    if (CourseDataObject[i].AttachmentData.NewFile!=null)
                    {                       
                        AddNewFile(CourseDataObject[i].AttachmentData.NewFile);                       
                    }
                    if (CourseDataObject[i].AttachmentData.WebAddress != null)
                    {
                        AddNewWebAddress(CourseDataObject[i].AttachmentData.WebAddress);
                    }
                    if (CourseDataObject[i].AttachmentData.PreviouslyAttachedDoc != null)
                    {
                        AddExistingAttachment(CourseDataObject[i].AttachmentData.PreviouslyAttachedDoc);
                    }
                    Driver.WaitForReady();
                    _OkBtn.ClickElement("OK Button", Driver);
                    Driver.WaitForReady();
                    Driver.SwitchTo().DefaultContent();
                    _extendpage.SwitchToContentFrame();                  
                    Driver.SwitchToFrame(_empTrainingFrame, "Employee Training Frame");
                }
            }
            return CourseDataObject;
        }

        /// <summary>
        /// Add New File Attachment
        /// </summary>
        /// <param name="NewFileData"></param>
        public void AddNewFile(List<NewFile> NewFileData)
        {
           for (int j = 0; j< NewFileData.Count; j++)
           {              
                _attachNewFile.ClickElement("Attach New File Link", Driver);
                Driver.WaitForReady();               
                _chooseFile.SendKeys(AppDomain.CurrentDomain.BaseDirectory + "\\TestData\\"+ NewFileData[j].InputFile);
                _FileDesc.SetText(NewFileData[j].FileDesc, "File Description");
                _attachNewFileBtn.ClickElement("Save File Button", Driver);              
            }
        }

        /// <summary>
        /// Attach New Web Address
        /// </summary>
        /// <param name="WebAddress"></param>
        public void AddNewWebAddress(List<WebAddress> WebAddress)
        {
            for (int j = 0; j < WebAddress.Count; j++)
            {                
                _attachWebAddress.ClickElement("Attach Web Address Link", Driver);
                Driver.WaitForReady();
                _webAddress.SetText(WebAddress[j].Address,"Web Address");
                Driver.WaitForReady();
                _webAddressDesc.SetText(WebAddress[j].Desc, "File Description");
                Driver.WaitForReady();
                _attachAddressBtn.ClickElement("Attach Address Button", Driver);
            }
        }

        /// <summary>
        /// Attach Previously Uploaded File
        /// </summary>
        /// <param name="PreviouslyAttachedDoc"></param>
        public void AddExistingAttachment(List<PreviouslyAttachedDoc> PreviouslyAttachedDoc)
        {
            for (int j = 0; j < PreviouslyAttachedDoc.Count; j++)
            {
                _attachExistingFile.ClickElement("Attach previously Uploaded File Link", Driver);
                Driver.WaitForReady();
                if (string.IsNullOrEmpty(PreviouslyAttachedDoc[j].FileAddress))
                {
                    Driver.DoubleClickWithJS(_previousUploadedFile, "File or Address");
                    _lov.SearchAndSelectFirstRowData();
                    Driver.SwitchTo().DefaultContent();
                    Driver.SwitchToFrame(_contentFrame2, "");                  
                }
                else
                {
                  _previousUploadedFile.SetText(PreviouslyAttachedDoc[j].FileAddress, "Web Address"); 
                }
                Driver.WaitForReady();             
                _associateBtn.ClickElement("Associate Button", Driver);
            }
        }

        /// <summary>
        /// Edit Course Data
        /// </summary>
        /// <param name="DataObject"></param>
        public EmpTrainingTranscipt EditCourseData(EmpTrainingTranscipt DataObject)
        {
            List<TrainingCourseDatum> CourseDataObject = DataObject.TrainingCourseData;
            Settings.Logger.Info("Editing Training Couse data");
            _extendpage.RefreshAndSetText(_employeeNo, DataObject.EmployeeData.EmpNo, "Employee Number ");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_empTrainingFrame, "Employee Training Frame");
            for (int i = 0; i < CourseDataObject.Count; i++)
            {
                if (!string.IsNullOrEmpty(CourseDataObject[i].Planned.ToString()))
                {
                    CourseDataObject[i].ValidUntil = DateTime.Today.AddDays(Convert.ToInt32(CourseDataObject[i].Planned)).AddYears(1).Date.ToString("MM/dd/yyyy");
                    CourseDataObject[i].Planned = CommonUtil.GenerateRandomDateString(Convert.ToInt32(CourseDataObject[i].Planned));
                }
                _extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "plan_dt").SetText(CourseDataObject[i].Planned, "Planned");
                Driver.WaitForReady();
                if (!string.IsNullOrEmpty(CourseDataObject[i].Attended.ToString()))
                {
                    CourseDataObject[i].Attended = CommonUtil.GenerateRandomDateString(Convert.ToInt32(CourseDataObject[i].Attended));
                }
                _extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "attend_dt").SetText(CourseDataObject[i].Attended, "Attended");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "result").SelectFilterValueHavingEqualValue(CourseDataObject[i].Result);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "grade").SetText(CourseDataObject[i].Grade, "Grade");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "certificate").SetText(CourseDataObject[i].CertificateNO, "CertificateNO");
              if (!string.IsNullOrEmpty(CourseDataObject[i].Notes))
                {
                    _extendpage.AddNotes(_extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "noteBtn"), CourseDataObject[i].Notes);
                    _extendpage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_empTrainingFrame, "Employee Training Frame");
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnSaveButton();
            return DataObject;
        }

        /// <summary>
        /// Verify Employee Training Transcipt
        /// </summary>
        /// <param name="EmpTTObject"></param>
        public void VerifyEmployeeTrainingTranscript(EmpTrainingTranscipt EmpTTObject)
        {
            Settings.Logger.Info("Verify Employee Training Transcipt");
            _extendpage.RefreshAndSetText(_employeeNo, EmpTTObject.EmployeeData.EmpNo, "Employee Number ");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_employeeNo, "Employee Number ", EmpTTObject.EmployeeData.EmpNo);
            CommonUtil.VerifyElementValue(_employeeName, "Employee Name ", EmpTTObject.EmployeeData.EmpName);
            CommonUtil.VerifyElementValue(_empStatus, "Employee Status ", EmpTTObject.EmployeeData.EmpStatus);
            if (EmpTTObject.TrainingCourseData != null)
            {
                VerifyTrainingCourseData(EmpTTObject.TrainingCourseData);
            }
            Settings.Logger.Info("Employee Training Transcipt Verified Successfully");
        }

        /// <summary>
        /// Verify Training Course Data
        /// </summary>
        /// <param name="CourseDataObject"></param>
        public void VerifyTrainingCourseData(List<TrainingCourseDatum> CourseDataObject)
        {
            Driver.SwitchToFrame(_empTrainingFrame, "Training Course Frame");
            for (int i = 0; i < CourseDataObject.Count; i++)
            {
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "course"), "Course", CourseDataObject[i].Course, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "desc"), "Course Description", CourseDataObject[i].CourseDesp, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "vendorNo"), "Vendor No", CourseDataObject[i].VendorNo, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "plan_dt"), "Planned Date", CourseDataObject[i].Planned, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "attend_dt"), "Attended Date", CourseDataObject[i].Attended, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "result"), "Result", CourseDataObject[i].Result, true, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "grade"), "Grade", CourseDataObject[i].Grade, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "valid"), "Valid Until", CourseDataObject[i].ValidUntil, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "certificate"), "CertificateNO", CourseDataObject[i].CertificateNO, false, "value");
                if (!string.IsNullOrEmpty(CourseDataObject[i].Notes))
                {
                    _extendpage.VerifyAddedNotes(_extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", CourseDataObject[i].Course, "noteBtn"), CourseDataObject[i].Notes);
                    _extendpage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_empTrainingFrame, "Training Course Frame");
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Training Course Deletion
        /// </summary>
        /// <param name="EmpTTObject"></param>
        public void VerifyTrainingCourseDeletion(EmpTrainingTranscipt EmpTTObject)
        {
            Settings.Logger.Info("Verifying Training Course Deletion");
            _extendpage.RefreshAndSetText(_employeeNo, EmpTTObject.EmployeeData.EmpNo, "Employee Number ");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_empTrainingFrame, "Training Course Frame");
            for (int i = 0; i < EmpTTObject.TrainingCourseData.Count; i++)
            {
                _extendpage.VerifyTableColumnDoesNotContainValue(_empTrainingTable, "Course", EmpTTObject.TrainingCourseData[i].Course);
                Settings.Logger.Info($"Verified Training Course Deletion for :{EmpTTObject.TrainingCourseData[i].Course}");
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete All Training Course
        /// </summary>
        /// <param name="EmpNO"></param>
        public void DeleteAllTrainingCourse(string EmpNO)
        {
            _extendpage.SwitchToContentFrame();
            _employeeNo.SetText(EmpNO, "Emloyee No.");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_empTrainingFrame, "Training Course Frame");
            int ExistingCourseCount = _empTrainingTableRows.Count - 1;
            for (int i = 0; i < ExistingCourseCount; i++)
            {
                _extendpage.GetElementForInput($"{PlannedDate}0").ClickElement("PlannedDate", Driver);
                _extendpage.DeleteAndSave();              
                Driver.SwitchToFrame(_empTrainingFrame, "Training Course Frame");
            }
            Settings.Logger.Info($"Deleted All Training Course for Employee:{EmpNO}");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Total Attachments
        /// </summary>
        /// <param name="Course"></param>
        /// <param name="AttachmentCount"></param>
        public void VerifyTotalAttachedDocs(List<TrainingCourseDatum> TrainingCourseData)
        {
            for (int i = 0; i < TrainingCourseData.Count; i++)
            {
                if (TrainingCourseData[i].AttachmentData != null)
                {
                    _extendpage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_empTrainingFrame, "Training Course Frame");
                    //Verify Attachment Link Icon shows Attachment Exists
                    string ActalIconState = _extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", TrainingCourseData[i].Course, "attaBtn").GetAttribute("hasatt");
                    CommonUtil.AssertTrue<string>("Y", ActalIconState);
                    _extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", TrainingCourseData[i].Course, "attaBtn").ClickElement("Attach Link", Driver);
                    Driver.SwitchTo().DefaultContent();
                    Driver.SwitchToFrame(_contentFrame2, "");
                    Driver.SwitchToFrame(_showAttachmentsFrame, "");
                    CommonUtil.AssertTrue<int>(TrainingCourseData[i].TotalAttachments, _extendpage.GetTotalTableRecords(_attachTable));
                    Driver.SwitchTo().DefaultContent();                 
                    _closeShowAttachmentsBtn.ClickElement("Close Button", Driver);
                    Driver.WaitForReady();                   
                }                
            }
        }

        /// <summary>
        /// Delete All Attachments
        /// </summary>
        /// <param name="Course"></param>
        public void DetachAllAttachments(string EmpNO)
        {
            _extendpage.SwitchToContentFrame();
            _employeeNo.SetText(EmpNO, "Emloyee No.");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_empTrainingFrame, "Training Course Frame");
            int ExistingCourseCount = _empTrainingTableRows.Count - 1;
            for (int i = 0; i < ExistingCourseCount; i++)
            {
                IWebElement AttachDocLoc = _extendpage.GetElementForInput($"{AttachDoc}{i}","id","button");
                string ActalIconState = AttachDocLoc.GetAttribute("hasatt");
                if (ActalIconState == "Y")
                {
                    AttachDocLoc.ClickElement("Attachment", Driver);
                    Driver.WaitForReady();
                    Driver.SwitchTo().DefaultContent();
                    Driver.SwitchToFrame(_contentFrame2, "");
                    Driver.SwitchToFrame(_showAttachmentsFrame, "");
                    int TotalDoc = _extendpage.GetTotalTableRecords(_attachTable);
                    for (int j = 0; j < TotalDoc; j++)
                    {
                        _extendpage.GetElementForInput($"{AttachDesc}{j}", "id", "textarea").ClickElement("Atatchment Description", Driver);
                        _extendpage.DeleteAndSave();
                        Driver.SwitchTo().DefaultContent();
                        Driver.SwitchToFrame(_contentFrame2, "");
                        Driver.SwitchToFrame(_showAttachmentsFrame, "");
                    }
                    Driver.SwitchTo().DefaultContent();
                    _closeShowAttachmentsBtn.ClickElement("Close Button", Driver);
                    Driver.WaitForReady();
                    _extendpage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_empTrainingFrame, "Training Course Frame");
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Detach Documents
        /// </summary>
        /// <param name="Course"></param>
        /// <param name="AttachmentCount"></param>
        public void VerifyDetachDocs(List<TrainingCourseDatum> TrainingCourseData)
        {
            //Driver.SwitchToFrame(_contentFrame2, "");
           // _closeShowAttachmentsBtn.ClickElement("Close Button",Driver);
            Driver.WaitForReady();
            for (int i = 0; i < TrainingCourseData.Count; i++)
            {
                if (TrainingCourseData[i].AttachmentData != null)
                {
                    _extendpage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_empTrainingFrame, "Training Course Frame");
                    //Verify Attachment Link Icon shows No Added Attachment
                    string ActalIconState = _extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", TrainingCourseData[i].Course, "attaBtn").GetAttribute("hasatt");
                    CommonUtil.AssertTrue<string>("N", ActalIconState);
                    _extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", TrainingCourseData[i].Course, "attaBtn").ClickElement("Attach Link", Driver);
                    Driver.SwitchTo().DefaultContent();
                    Driver.SwitchToFrame(_contentFrame2, "");
                    Driver.SwitchToFrame(_showAttachmentsFrame, "");
                    CommonUtil.AssertTrue<int>(0, _extendpage.GetTotalTableRecords(_attachTable));
                    Driver.SwitchTo().DefaultContent();
                }
            }
        }

        /// <summary>
        /// Click Attachment Link for Course
        /// </summary>
        /// <param name="Course"></param>
        public void ClickAttachmentLinkRelatedToCourse(string Course)
        {
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_empTrainingFrame, "Training Course Frame");
            _extendpage.GetTableActionElementByRelatedColumnValue(_empTrainingTable, "Course", Course, "attaBtn").ClickElement("Attach Link", Driver);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Driver.SwitchToFrame(_contentFrame2, "");
            Driver.SwitchToFrame(_showAttachmentsFrame, "");
        }

        /// <summary>
        /// Get Updated Training Transcript Object
        /// </summary>
        /// <param name="queryObject"></param>
        /// <returns></returns>
        public EmpTrainingTranscipt GetUpdatedTrainingTranscriptObject(EmployeeCourseQuery queryObject)
        {
            EmpTrainingTranscipt empTrainScint = new EmpTrainingTranscipt();
            empTrainScint.EmployeeData = queryObject.EmployeeData;
            empTrainScint.TrainingCourseData = queryObject.TrainingCourseData;
            return empTrainScint;
        }
    }
}


