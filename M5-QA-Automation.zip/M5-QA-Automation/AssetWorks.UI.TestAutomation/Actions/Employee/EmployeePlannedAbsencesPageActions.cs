﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Labor;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Labor
{
    internal class EmployeePlannedAbsencesPageActions : EmployeePlannedAbsencesPage
    {
        internal EmployeePlannedAbsencesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Add Employee Planned Absences
        /// </summary>
        /// <param name="absences"></param>
        public EmpPlannedAbsences AddEmployeePlannedAbsences(EmpPlannedAbsences absences)
        {
            Settings.Logger.Info($" Add Employee Planned Absences for Employee:{absences.EmployeeNo} ");
            _extendedPage.SwitchToContentFrame();
            _inputEmployeeNo.SetText(absences.EmployeeNo, "Employee No");
            Driver.WaitForReady();            
            _inputStartingPeriod.SetText(absences.StartingPeriod, "Starting Period");
            absences.StartingPeriod = _inputStartingPeriod.GetAttribute("value");
            if (absences.AbsencesDetails != null)
            {                
                WaitForTableToLoad();
                int row = 0;           
               foreach (var absence in absences.AbsencesDetails)
                {
                    _inputNewIndirectAccount(row.ToString()).ClickElement("Indirect Account", Driver);
                    _inputNewIndirectAccount(row.ToString()).SetText(absence.IndirectAccount, "Indirect Account");
                    Driver.WaitForReady();
                    _inputNewStartDate(row.ToString()).SetText(absence.StartDate, "Start Date");
                    Driver.WaitForReady();
                    absence.StartDate = _inputNewStartDate(row.ToString()).GetAttribute("ovalue");
                    _inputNewStartTime(row.ToString()).SetText(absence.StartTime, "Start Time");
                    Driver.WaitForReady();
                    _inputNewEndDate(row.ToString()).SetText(absence.EndDate, "End Date");
                    Driver.WaitForReady();
                    absence.EndDate = _inputNewEndDate(row.ToString()).GetAttribute("ovalue");
                    _inputNewEndTime(row.ToString()).SetText(absence.EndTime, "End Time");
                    Driver.WaitForReady();
                    _inputNewDescription(row.ToString()).SetText(absence.Description, "Description");
                    Driver.WaitForReady();
                    _extendedPage.SelectAllAndClearField(_inputNewTimeType(row.ToString()));
                    _inputNewTimeType(row.ToString()).SetText(absence.TimeType, "Time Type");
                    Driver.WaitForReady();
                    _extendedPage.SelectAllAndClearField(_inputNewUnion(row.ToString()));
                    _inputNewUnion(row.ToString()).SetText(absence.Union, "Union");
                    Driver.WaitForReady();
                    _extendedPage.SelectAllAndClearField(_inputNewPayClass(row.ToString()));
                    _inputNewPayClass(row.ToString()).SetText(absence.PayClass, "Pay Class");
                    Driver.WaitForReady();
                    _extendedPage.SelectAllAndClearField(_inputNewPayStep(row.ToString()));
                    _inputNewPayStep(row.ToString()).SetText(absence.PayStep, "Pay Step");
                    Driver.WaitForReady();
                    if (absence.IgnorePlannedAbsences)
                        _checkboxNewIgnoreSubtraction(row.ToString()).SelectCheckBox("Ignore Subtraction");
                    row++;
                }
            }
            _extendedPage.Save();
            return absences;
        }

        /// <summary>
        /// Verify Employee Planned Absences
        /// </summary>
        /// <param name="absences"></param>
        public void VerifyEmployeePlannedAbsences(EmpPlannedAbsences absences)
        {
            Settings.Logger.Info(" Verify Employee Planned Absences ");
            _extendedPage.RefreshAndSetText(_inputEmployeeNo, absences.EmployeeNo, "Employee No");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputEmployeeName, "Employee Name", absences.EmployeeName);
            CommonUtil.VerifyElementValue(_inputEmployeeStatus, "Employee Status", absences.EmployeeStatus);
            CommonUtil.VerifyElementValue(_inputShiftCode, "Shift Code", absences.ShiftCode);
            CommonUtil.VerifyElementValue(_inputShiftCodeDesc, "Shift Code Description", absences.ShiftCodeDesc);
            CommonUtil.VerifyElementValue(_inputStartingPeriod, "Starting Period", absences.StartingPeriod);
            if (absences.AbsencesDetails != null)
            {
                WaitForTableToLoad();              
                foreach (var absence in absences.AbsencesDetails)
                {                 
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount",
                        absence.IndirectAccount, "IndAcct"), "Indirect Account", absence.IndirectAccount, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount",
                        absence.IndirectAccount, "IndDesc"), "Account Description", absence.AccountDescription, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount",
                       absence.IndirectAccount, "Start_Date"), "Start Date", absence.StartDate, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount",
                        absence.IndirectAccount, "Start_Time"), "Start Time", absence.StartTime, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount",
                      absence.IndirectAccount, "End_Date"), "End Date", absence.EndDate, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount",
                        absence.IndirectAccount, "End_Time"), "End Time", absence.EndTime, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount",
                        absence.IndirectAccount, "HolidayDesc"), "Planned Absence Description", absence.Description, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount",
                        absence.IndirectAccount, "TimeType"), "Time Type", absence.TimeType, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount",
                        absence.IndirectAccount, "Union"), "Union", absence.Union, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount",
                        absence.IndirectAccount, "PayClass"), "Pay Class", absence.PayClass, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount",
                        absence.IndirectAccount, "PayStep"), "Pay Step", absence.PayStep, false, "value");
                    CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount",
                        absence.IndirectAccount, "IgnoreSubtraction"), "Ignore Subtraction$0", absence.IgnorePlannedAbsences);
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Employee Planned Absences
        /// </summary>
        /// <param name="absences"></param>
        public void DeleteEmployeePlannedAbsences(EmpPlannedAbsences absences)
        {
            Settings.Logger.Info(" Delete Employee Planned Absences ");
            _extendedPage.RefreshAndSetText(_inputEmployeeNo, absences.EmployeeNo, "Employee No");
            Driver.WaitForReady();                            
           if (absences.AbsencesDetails != null)
           {
                WaitForTableToLoad();
                foreach (var absence in absences.AbsencesDetails)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence,
                        "Indirect\r\nAccount", absence.IndirectAccount, "IndAcct").Click();
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.ClickOnDeleteButton();
                    Driver.WaitForReady();
                    _extendedPage.SwitchToTableFrame(_frameAbsence);
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Delete All Employee Planned Absences Table Rows
        /// </summary>
        /// <param name="EmpNO"></param>
        public void DeleteAllPlannedAbsences(string EmpNO)
        {
            Settings.Logger.Info(" Delete All Existing Employee Planned Absences ");
            _extendedPage.RefreshAndSetText(_inputEmployeeNo, EmpNO, "Employee No");
            Driver.WaitForReady();
            WaitForTableToLoad();
            int TotalRows = _tablePlanAbsenceTotalRows.Count - 1;
            while (TotalRows > 0)
            {
                _inputIndirectAccount((TotalRows - 1).ToString()).ClickElement("Indirect Account", Driver);
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnDeleteButton();
                Driver.WaitForReady();
                _extendedPage.SwitchToTableFrame(_frameAbsence);
                TotalRows--;
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Update Employee Planned Absences
        /// </summary>
        /// <param name="absences"></param>
        public EmpPlannedAbsences UpdateEmployeePlannedAbsences(EmpPlannedAbsences absences)
        {
            Settings.Logger.Info(" Update Employee Planned Absences ");
            _extendedPage.RefreshAndSetText(_inputEmployeeNo, absences.EmployeeNo, "Employee No");
            Driver.WaitForReady();
            _inputStartingPeriod.SetText(absences.StartingPeriod, "Starting Period");
            if (absences.AbsencesDetails != null)
            {
                WaitForTableToLoad();               
                int row = 0;          
                foreach (var absence in absences.AbsencesDetails)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "IndAcct").ClickElement("IndAcct", Driver);
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "Start_Date").ClickElement("Start Date", Driver);
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "Start_Date").SetText(absence.StartDate, "Start Date");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "Start_Time").SetText(absence.StartTime, "Start Time");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "End_Date").SetText(absence.EndDate, "End Date");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "End_Time").ClickElement("End Time", Driver);
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "End_Time").SetText(absence.EndTime, "End Time");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "HolidayDesc").SetText(absence.Description, "Planned Absence Description");
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "TimeType").ClickElement("Time Type", Driver);
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "TimeType").SetText(absence.TimeType, "Time Type");
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "Union").ClickElement("Union", Driver);
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "Union").SetText(absence.Union, "Union");
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "PayClass").SetText(absence.PayClass, "Pay Class");
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "PayStep").SetText(absence.PayStep, "Pay Step");
                    if (absence.IgnorePlannedAbsences)
                        _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "IgnoreSubtraction")
                        .SelectCheckBox("Ignore Subtraction");
                    else
                        _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "IgnoreSubtraction")
                        .DeSelectCheckBox("Ignore Subtraction");
                    absence.StartDate = _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "Start_Date").GetAttribute("ovalue");
                    absence.EndDate = _extendedPage.GetTableActionElementByRelatedColumnValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount, "End_Date").GetAttribute("ovalue");
                    row++;
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            return absences;
        }

        /// <summary>
        /// Verify EmployeePlanned Absences Deletion
        /// </summary>
        /// <param name="absences"></param>
        public void VerifyDeleteEmployeePlannedAbsences(EmpPlannedAbsences absences)
        {
            Settings.Logger.Info(" Verify Employee Planned Absences Deletion ");
            _extendedPage.RefreshAndSetText(_inputEmployeeNo, absences.EmployeeNo, "Employee No");
            Driver.WaitForReady();
            if (absences.AbsencesDetails != null)
            {
                WaitForTableToLoad();
                foreach (AbsencesDetails absence in absences.AbsencesDetails)
                {
                    _extendedPage.VerifyTableColumnDoesNotContainValue(_tablePlanAbsence, "Indirect\r\nAccount", absence.IndirectAccount);

                }
            }
            else
            {
                Assert.Fail("Delete Verification Data Not Available");
            }
        }

        /// <summary>
        /// Wait for Employee Planned Absence Table To Load
        /// </summary>
        public void WaitForTableToLoad()
        {
            _inputStartingPeriod.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            Driver.WaitForVisibility(LocatorTableHeader, "Table Header");
            Driver.SwitchToFrame(_frameAbsence, "Absence frame");         
            Driver.WaitForClickable(_inputNewIndirectAccount(0.ToString()), "Indirect Account");
        }
    }
}
