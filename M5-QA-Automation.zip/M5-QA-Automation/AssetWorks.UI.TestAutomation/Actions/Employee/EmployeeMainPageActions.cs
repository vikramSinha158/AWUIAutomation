﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class EmployeeMainPageActions : EmployeeMainPage
    {
        public EmployeeMainPageActions(IWebDriver Driver) : base(Driver) { }

        string Tripcardpin = string.Empty;
        string driverNO = string.Empty;
        /// <summary>
        /// Method to create an employee
        /// </summary>
        /// <returns>Employee Id for newly created employee</returns>
        public CreateEmployeeObject CreateNewEmployee(CreateEmployeeObject createEmpObjectValues)
        {
            string EmpID = string.Empty;
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(createEmpObjectValues.EmployeeData.EmployeeID, ref EmpID, "EmployeeQuery"))
            {
                if (string.IsNullOrEmpty(createEmpObjectValues.EmployeeData.EmpName))
                {
                    createEmpObjectValues.EmployeeData.EmpName= $"AUT Employee {EmpID}";
                }               
                Settings.Logger.Info($" Creating Employee :{EmpID}, Name: {createEmpObjectValues.EmployeeData.EmpName}   ");
                Driver.WaitForSomeTime();
                //Enter Employee ID                
                _inputEmpID.SetText(EmpID, "Employee ID", Driver, _extendedPage._contentFrame, "content frame");
                Driver.WaitForReady();           
               _extendedPage.ClickOnDialogBoxButton("Create");
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
                // Enter Employee Name
                Driver.WaitForReady();
                _inputName.SetText(createEmpObjectValues.EmployeeData.EmpName, "Employee Name");
                Driver.WaitForReady();
                //Select status          
                _selectStatus.SelectFilterValueHavingEqualValue(createEmpObjectValues.EmployeeData.Status);
                FillGeneralData(createEmpObjectValues);
                FillAssignmentTab(createEmpObjectValues);
                if (createEmpObjectValues.Flags.FillPayrollTab == "Yes")
                {
                    FillPayrollTab(createEmpObjectValues);
                }
                if (createEmpObjectValues.Flags.FillResourceTypeTab == "Yes")
                {
                    FillResourceTypeTab(createEmpObjectValues);
                }
                if (createEmpObjectValues.Flags.FillDriverInformationTab == "Yes")
                {
                    FillDriverInfoTab(createEmpObjectValues);
                }
                if (createEmpObjectValues.Flags.FillMotorPoolTab == "Yes")
                {
                    FillMotorPoolTab(createEmpObjectValues);
                }
                Driver.WaitForReady();         
                _extendedPage.SaveAndChackWarning();              
                createEmpObjectValues.EmployeeData.EmployeeID = EmpID;
                EmployeeMainPage.EmpID = EmpID;
                EmployeeMainPage.EmpName = createEmpObjectValues.EmployeeData.EmpName;
                EmployeeMainPage.TripCardPin = Tripcardpin;
                EmployeeMainPage.DriverNO = DriverNO;
            }
            return createEmpObjectValues;
       }

        /// <summary>
        /// Method to fill data in employee main general tab
        /// </summary>
        public void FillGeneralData(CreateEmployeeObject createEmpObjectValues)
        {
            _jobTitle.SetText(createEmpObjectValues.EmployeeData.Title, "Title");
            Driver.WaitForReady();
            _skillLevel.SetText(createEmpObjectValues.EmployeeData.SkillLevel, "Skill Level");
            Driver.WaitForReady();
            _inputShiftCode.SetText(createEmpObjectValues.EmployeeData.ShiftCode, "Shift Code");
            Driver.WaitForReady();
            _AuthChargeTime.SelectFilterValueHavingEqualValue(createEmpObjectValues.EmployeeData.AuthChargeTime);
            Driver.WaitForReady();
            _usePayrollRates.SelectCheckBox("Use Payroll Rates", createEmpObjectValues.EmployeeData.UsePayrollRates);
            Driver.WaitForReady();
            _lov.SelectCode(_markupScheme, "MarkUp Scheme", createEmpObjectValues.EmployeeData.MarkUpScheme);
            Driver.WaitForReady();
            _Unit.SelectCheckBox("Unit", createEmpObjectValues.EmployeeData.Unit);
            _WorkOrder.SelectCheckBox("Work Order", createEmpObjectValues.EmployeeData.WorkOrder);
            Driver.WaitForReady();
            _IndirectAcct.SelectCheckBox("Indirect Account", createEmpObjectValues.EmployeeData.IndAcct);
            if (createEmpObjectValues.EmployeeData.DiAcct)
            {
                _DirectAccount.SelectCheckBox("Direct Account", createEmpObjectValues.EmployeeData.DiAcct);
            }
            else {_DirectAccount.DeSelectCheckBox("DirectAccount"); }           
            _Department.SelectCheckBox("Dpartment", createEmpObjectValues.EmployeeData.Department);
            if (createEmpObjectValues.EmployeeData.TripCardPin!=null && createEmpObjectValues.EmployeeData.TripCardPin.ToLower() == "random")
            { Tripcardpin = CommonUtil.GetRandomStringWithSpecialChars(4); }
            else
            {
                Tripcardpin = createEmpObjectValues.EmployeeData.TripCardPin;
            }
            _tripCard.SetText(Tripcardpin, "Tripcard Pin");
            if (createEmpObjectValues.EmployeeData.StartDate)
            {
                _startDate.SetText(DateTime.Now.AddDays(-60).ToString("MM/dd/yyyy"), "Start Date");
                Driver.WaitForReady();
            }
            if (createEmpObjectValues.EmployeeData.TermDate)
            {
                _terminationDate.Click();
                _terminationDate.SendKeys("Now");
            }
            _telephone.SetText(createEmpObjectValues.EmployeeData.Phone, "Telephone");
            _phoneExt.SetText(createEmpObjectValues.EmployeeData.PhonExt, "Phone Extension");
            _phoneExt.SetText(createEmpObjectValues.EmployeeData.PhonExt, "Phone Extension");
            _email.SetText(createEmpObjectValues.EmployeeData.Email, "Email");
            _pin.SetText(createEmpObjectValues.EmployeeData.Pin, "Pin");
            _supervisor.SelectFilterValueHavingEqualValue(createEmpObjectValues.EmployeeData.Suprvisor);
            _contractor.SelectFilterValueHavingEqualValue(createEmpObjectValues.EmployeeData.Contractor);
            _dptContact.SelectFilterValueHavingEqualValue(createEmpObjectValues.EmployeeData.DeptContact);
            _exempt.SelectFilterValueHavingEqualValue(createEmpObjectValues.EmployeeData.Exempt);
            _driver.SelectFilterValueHavingEqualValue(createEmpObjectValues.EmployeeData.Driver);
            _technician.SelectFilterValueHavingEqualValue(createEmpObjectValues.EmployeeData.Technician);
            _addJobOnLabor.SelectFilterValueHavingEqualValue(createEmpObjectValues.EmployeeData.AddJobsLabor);
            _timeKeeper.SelectFilterValueHavingEqualValue(createEmpObjectValues.EmployeeData.TimeKeper);
            _mpAppr.SelectFilterValueHavingEqualValue(createEmpObjectValues.EmployeeData.MPAppReq);
            _invEmp.SelectFilterValueHavingEqualValue(createEmpObjectValues.EmployeeData.InvEmp);
            _tempEmp.SelectFilterValueHavingEqualValue(createEmpObjectValues.EmployeeData.Temporary);
            _empNotes.SetText(createEmpObjectValues.EmployeeData.EmpNotes, "Employee Notes");

        }

        /// <summary>
        /// Fill Asignment Tab Fields
        /// </summary>
        /// <param name="createEmpObjectValues"></param>
        public void FillAssignmentTab(CreateEmployeeObject createEmpObjectValues)
        {        
                Driver.ClickOnElement(_assignmentTab, "Assignment Tab");
                Driver.WaitForReady();
                _supervisorID.SetText(createEmpObjectValues.EmployeeData.SupervisorID, "supervisorID");
                Driver.WaitForReady();
                _inputHomeLOcation.SetText(createEmpObjectValues.EmployeeData.HomeLocation, "Home Location ");
                Driver.WaitForReady();
               _deptNo.SetText(createEmpObjectValues.EmployeeData.DeptNO, "Department No ");
                Driver.WaitForReady();
                _vendorNo.SetText(createEmpObjectValues.EmployeeData.VendorNO, "Vendor No ");         
                Driver.WaitForReady();
               _unionNo.SetText(createEmpObjectValues.EmployeeData.GroupNO, "Group No ");
        }            

        /// <summary>
        /// Fill Payroll Tab Fields
        /// </summary>
        /// <param name="createEmpObjectValues"></param>
        public void FillPayrollTab(CreateEmployeeObject createEmpObjectValues)
        {
             Driver.ClickOnElement(_payrollTab, "Payroll Tab");          
            Driver.WaitForReady();
            _primaryPayClass.SetText(createEmpObjectValues.EmployeeData.PrimaryPayClass ,"Primary Pay Class");
            Driver.WaitForReady();
            _primaryPayStep.SetText(createEmpObjectValues.EmployeeData.PrimaryPaystep, "Primary Pay Step");
            Driver.WaitForReady();
            _secondaryPayClass.SetText(createEmpObjectValues.EmployeeData.SecPayClass, "Secondary Pay Class");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_secondaryPayStep);
            Driver.WaitForReady();
            _secondaryPayStep.SetText(createEmpObjectValues.EmployeeData.SecPaystep, "Secondary Pay Step");
            Driver.WaitForReady();
            _tertiaryPayClass.SetText(createEmpObjectValues.EmployeeData.TerPayClass, "Tertiary Pay Class");
            Driver.WaitForReady();
            _tertiaryPayStep.SetText(createEmpObjectValues.EmployeeData.TerPaystep, "Tertiary Pay Step");
            Driver.WaitForReady();
            _timeType.SetText(createEmpObjectValues.EmployeeData.TimeType, "Time Type");

        }
        /// <summary>
        /// Fill Resource Type Fields
        /// </summary>
        /// <param name="createEmpObjectValues"></param>
        public void FillResourceTypeTab(CreateEmployeeObject createEmpObjectValues)
        {
            Driver.ClickOnElement(_resourceTypeTab, "ResourceType Tab");
            Driver.SwitchToFrame(_frameResouceType, "Table frame");
            Settings.Logger.Info("Entering Resource Type Table Values");
            _lov.SelectFirstTableRecord(_inputResourceType, "Resource Type", createEmpObjectValues.EmployeeData.ResourceType);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameResouceType, "Table frame");
            Driver.WaitForReady();
             _inputExpiryDate.SetText(createEmpObjectValues.EmployeeData.ExpireDate, "Expiry Date");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
        }

        /// <summary>
        /// Fill Driver Information Tab fields
        /// </summary>
        /// <param name="createEmpObjectValues"></param>
        public void FillDriverInfoTab(CreateEmployeeObject createEmpObjectValues)
        {
            Driver.WaitForReady();
            Driver.ClickOnElement(_driverInfoTab, "Driver Info Tab");
            if (createEmpObjectValues.EmployeeData.DriverNo != null && createEmpObjectValues.EmployeeData.DriverNo.ToLower() == "random")
            {
                driverNO = CommonUtil.GetRandomStringWithSpecialChars(5);
            }
            else
            {
                driverNO = createEmpObjectValues.EmployeeData.DriverNo;
            }
            _inputDriverNO.SetText(driverNO, "Driver No");
            _taxformOnFile.SelectFilterValueHavingEqualValue(createEmpObjectValues.EmployeeData.TaxformOnFile);
            Driver.WaitForReady();
            _inputLicenceNO.SetText(createEmpObjectValues.EmployeeData.LicenseNo, "License No");
            Driver.WaitForReady();
            if (createEmpObjectValues.EmployeeData.LicenseExpiry)
            {
            _icenceExpiry.SetText("Now", "License Expiry"); 
            }
            Driver.WaitForReady();
            _txtDriverStatus.SetText(createEmpObjectValues.EmployeeData.DriverStatus, "Driver Status");
            Driver.WaitForReady();
            _txtDriverType.SetText(createEmpObjectValues.EmployeeData.DriverType, "Driver Type");
            Driver.WaitForReady();
            _txtDriverClass.SetText(createEmpObjectValues.EmployeeData.DriverClass,"Driver Class");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_address1);
            Driver.WaitForReady();
            _address1.SetText(createEmpObjectValues.EmployeeData.Address1, "Address1");
            Driver.WaitForReady();
            _address2.SetText(createEmpObjectValues.EmployeeData.Address2, "Address2");
            Driver.WaitForReady();
            _city.SetText(createEmpObjectValues.EmployeeData.City, "City");
            Driver.WaitForReady();
            _state.SetText(createEmpObjectValues.EmployeeData.State, "State");
            Driver.WaitForReady();
            _zipCode.SetText(createEmpObjectValues.EmployeeData.Zip, "Zip");
            Driver.WaitForReady();
            _region.SetText(createEmpObjectValues.EmployeeData.Region, "Region");
            Driver.WaitForReady();
            _municipality.SetText(createEmpObjectValues.EmployeeData.Municipality, "Municipality");
            Driver.WaitForReady();
            _country.SetText(createEmpObjectValues.EmployeeData.Country, "Country");
            Driver.WaitForReady();
            _mobile.SetText(createEmpObjectValues.EmployeeData.Mobile, "Mobile");
            Driver.WaitForReady();
            _monthlyUsage.SetText(createEmpObjectValues.EmployeeData.Usage, "Usage");
            Driver.WaitForReady();
            _monthlyBisUsage.SetText(createEmpObjectValues.EmployeeData.BusinessUsage, "Business Usage");
        }
        /// <summary>
        /// Fill Motor Pool Tab Fields
        /// </summary>
        /// <param name="createEmpObjectValues"></param>
        public void FillMotorPoolTab(CreateEmployeeObject createEmpObjectValues)
        {
            Driver.WaitForReady();
            Driver.ClickOnElement(_motorPoolTab, "Motor Pool Tab");
            Driver.WaitForReady();
            Driver.WaitForSomeTime();
           // Driver.ScrollInView(_restMPReservation);         
            if (createEmpObjectValues.EmployeeData.RestMPReservation)
            {               
                _restMPReservation.SelectCheckBox("Restrict MP Reservation", createEmpObjectValues.EmployeeData.RestMPReservation);
            }
            else{_restMPReservation.DeSelectCheckBox("restMPReservation"); }
            Driver.SwitchToFrame(_frameMotorPoolTable, "Table frame");
            Settings.Logger.Info("Entering Motor Pool Table Values");
            Driver.WaitForReady();
            _lov.SelectCode(_motorpoolClass, "Motor Pool Class", createEmpObjectValues.EmployeeData.CreateMotolPoolClass);                     
        }

        /// <summary>
        /// Method to verify the employee Details
        /// </summary>
        /// <param name="EmployeeID">Employee ID whose details needs to be verified.</param>
        public void VerifyEmployeeMainInfo(CreateEmployeeObject empObjectValues, bool EmployeeCopy=false)
            {
              Settings.Logger.Info(" Verifying  Employee Main");
            if (!EmployeeCopy)
            {
                Settings.Logger.Info(" Refresh and set Text Employee ID ");
                _extendedPage.ClickOnRefreshButton();
                _extendedPage.SwitchToContentFrame();
                Driver.WaitForReady();
                Driver.WaitForSomeTime();
                _inputEmpID.SetText(empObjectValues.EmployeeData.EmployeeID, "Employee ID ");                            
                Driver.WaitForReady();
                Driver.ClickOnElement(_generalTab, "General Tab");
                CommonUtil.AssertTrue<string>(empObjectValues.EmployeeData.EmployeeID, _inputEmpID.GetElementValueByAttribute("ovalue"));              
                CommonUtil.AssertTrue<string>(EmployeeMainPage.EmpName, _inputName.GetElementValueByAttribute("ovalue"));
            }
            else
            {
               _extendedPage.SwitchToContentFrame();
                Driver.WaitForReady();
                Driver.WaitForSomeTime();
                CommonUtil.AssertTrue<string>(empObjectValues.EmployeeData.EmployeeID, _inputEmpID.GetElementValueByAttribute("ovalue"));
             }           
            //Verify Status
            CommonUtil.AssertTrue<string>(empObjectValues.EmployeeData.Status, _selectStatus.GetVisibleText());            
            VerifyGeneralTabInfo(empObjectValues);           
            VerifyAssignmentTabInfo(empObjectValues);
            if (empObjectValues.Flags.FillPayrollTab == "Yes")
            {
                VerifyPayrollTabInfo(empObjectValues);
                Driver.WaitForReady();
            }            
            if (empObjectValues.Flags.VerifySubordinatesTab == "Yes")
            {
                Driver.ClickOnElement(_subordinatesTab, "Subordinates Tab");
                CommonUtil.AssertTrue<bool>(true, _frameText.GetText("Table Text").Contains("Loaded 0 records"));
                Driver.WaitForReady();
            }
            if (empObjectValues.Flags.FillResourceTypeTab == "Yes")
            {
                Driver.ClickOnElement(_resourceTypeTab, "Resource Type Tab");
                CommonUtil.AssertTrue<bool>(true, _frameTextResourcePool.GetText("Table Text").Contains("Loaded 1 records"));
            }
            if (empObjectValues.Flags.FillDriverInformationTab == "Yes")
            {
                VerifyDriverInfoTabData(empObjectValues);
            }
            if (empObjectValues.Flags.FillMotorPoolTab == "Yes")
            {
                VerifyMotorPoolData(empObjectValues);
            }
            Driver.SwitchTo().DefaultContent();
        }
        /// <summary>
        /// Verify General Tab Data
        /// </summary>
        /// <param name="empObjectValues"></param>
        public void VerifyGeneralTabInfo(CreateEmployeeObject empObjectValues)
        {
            CommonUtil.VerifyElementValue(_inputShiftCode, "Shift Code",empObjectValues.EmployeeData.ShiftCode);            
            CommonUtil.VerifyElementValue(_ShiftCodeDesc, "Shift Code Description", empObjectValues.EmployeeData.ShiftCodeDesc);
            CommonUtil.VerifyElementValue(_effectiveDate, "Effective Date", empObjectValues.EmployeeData.EffectiveDate);
            CommonUtil.VerifyElementValue(_AuthChargeTime,"Autorized To Charge Time", empObjectValues.EmployeeData.AuthChargeTime,true);
            CommonUtil.VerifyCheckboxState(_usePayrollRates,"Payroll Rates" ,empObjectValues.EmployeeData.UsePayrollRates);
            CommonUtil.VerifyElementValueNotBlank(_markupScheme,"MarkUp Scheme", empObjectValues.EmployeeData.MarkUpScheme);
            CommonUtil.VerifyCheckboxState(_Unit, "Unit",empObjectValues.EmployeeData.Unit);
            CommonUtil.VerifyCheckboxState(_WorkOrder,"Wrk Order", empObjectValues.EmployeeData.WorkOrder);
            CommonUtil.VerifyCheckboxState(_IndirectAcct,"Indirect Acct.", empObjectValues.EmployeeData.IndAcct);
            CommonUtil.VerifyCheckboxState(_DirectAccount,"Direct Acct", empObjectValues.EmployeeData.DiAcct);
            CommonUtil.VerifyCheckboxState(_Department,"Department", empObjectValues.EmployeeData.Department);           
            CommonUtil.VerifyElementValue(_tripCard,"TripCardPin" ,EmployeeMainPage.TripCardPin);
            CommonUtil.VerifyElementValueNotBlank(_startDate, "Start Date", empObjectValues.EmployeeData.StartDate);
            string ActVal = _terminationDate.GetElementValueByAttribute("ovalue");
            Assert.IsEmpty(ActVal, "Termination Date is not empty");          
            CommonUtil.VerifyElementValueNotBlank(_telephone, "Telephone", empObjectValues.EmployeeData.PhoneToVerify);
            CommonUtil.VerifyElementValue(_phoneExt, "Phone Extension",empObjectValues.EmployeeData.PhonExt);
            CommonUtil.VerifyElementValue(_email, "Email",empObjectValues.EmployeeData.Email);
            CommonUtil.VerifyElementValue(_pin,"Pin", empObjectValues.EmployeeData.Pin);
            CommonUtil.VerifyElementValue(_supervisor,"Supervisor", empObjectValues.EmployeeData.Suprvisor,true);
            CommonUtil.VerifyElementValue(_contractor,"Contractor", empObjectValues.EmployeeData.Contractor,true);
            CommonUtil.VerifyElementValue(_dptContact,"Department Contact", empObjectValues.EmployeeData.DeptContact,true);
            CommonUtil.VerifyElementValue(_exempt,"Exempt", empObjectValues.EmployeeData.Exempt,true);
            CommonUtil.VerifyElementValue(_driver, "Driver",empObjectValues.EmployeeData.Driver, true);
            CommonUtil.VerifyElementValue(_technician, "Technician",empObjectValues.EmployeeData.Technician, true);
            CommonUtil.VerifyElementValue(_addJobOnLabor,"Add Job On Labor", empObjectValues.EmployeeData.AddJobsLabor, true);
            CommonUtil.VerifyElementValue(_timeKeeper,"Timekeeper", empObjectValues.EmployeeData.TimeKeper, true);
            CommonUtil.VerifyElementValue(_mpAppr, "MP Approval Required", empObjectValues.EmployeeData.MPAppReq, true);
            CommonUtil.VerifyElementValue(_invEmp, "Inv. Emp", empObjectValues.EmployeeData.InvEmp, true);
            CommonUtil.VerifyElementValue(_tempEmp, "Temporary", empObjectValues.EmployeeData.Temporary, true);
             CommonUtil.VerifyElementValue(_empNotes, "Employee Notes", empObjectValues.EmployeeData.EmpNotes);                   
         }
        /// <summary>
        /// Verify Assignment Tab Data
        /// </summary>
        /// <param name="empObjectValues"></param>
        public void VerifyAssignmentTabInfo(CreateEmployeeObject empObjectValues)
        {
            Driver.ClickOnElement(_assignmentTab, "Assignment Tab");          
            CommonUtil.VerifyElementValue(_inputHomeLOcation, "Home Location", empObjectValues.EmployeeData.HomeLocation);
            CommonUtil.VerifyElementValue(_HomeLocationDesc, "Home Location Description", empObjectValues.EmployeeData.HomeLocationDescription);
            CommonUtil.VerifyElementValue(_supervisorID, "Supervisor ID", empObjectValues.EmployeeData.SupervisorID);
            CommonUtil.VerifyElementValue(_deptNo, "Dept NO", empObjectValues.EmployeeData.DeptNO);
            CommonUtil.VerifyElementValue(_deptNoDesc, "Dept NO Description", empObjectValues.EmployeeData.DepartmentDesc);
            CommonUtil.VerifyElementValue(_vendorNo, "Vendor NO", empObjectValues.EmployeeData.VendorNO);
            CommonUtil.VerifyElementValue(_vendorNoDesc, "Vendor NO Description", empObjectValues.EmployeeData.VendorDesc);
            CommonUtil.VerifyElementValue(_unionNo, "Group NO", empObjectValues.EmployeeData.GroupNO);
            CommonUtil.VerifyElementValue(_unionNoDesc, "Group NO Description", empObjectValues.EmployeeData.GroupDescription);
        }
        /// <summary>
        /// Verify Payroll Tab Data
        /// </summary
        public void VerifyPayrollTabInfo(CreateEmployeeObject empObjectValues)
        {
            Driver.ClickOnElement(_payrollTab, "Payroll Tab");
            CommonUtil.VerifyElementValue(_primaryPayClass, "Primary Pay Class", empObjectValues.EmployeeData.PrimaryPayClass);
            CommonUtil.VerifyElementValue(_primaryPayStep, "Primary Pay Step", empObjectValues.EmployeeData.PrimaryPaystep);
            CommonUtil.VerifyElementValue(_primaryPayDescription, "Primary Pay Description", empObjectValues.EmployeeData.PrimaryDescription);
            CommonUtil.VerifyElementValue(_secondaryPayClass, "Secondary Pay Class", empObjectValues.EmployeeData.SecPayClass);
            CommonUtil.VerifyElementValue(_secondaryPayStep, "Secondary Pay Step", empObjectValues.EmployeeData.SecPaystep);
            CommonUtil.VerifyElementValue(_secondaryPayDescription, "Secondary Pay Description", empObjectValues.EmployeeData.SecondaryDescription);
            CommonUtil.VerifyElementValue(_tertiaryPayClass, "Tertiary Pay Class", empObjectValues.EmployeeData.TerPayClass);
            CommonUtil.VerifyElementValue(_tertiaryPayStep, "Tertiary Pay Step", empObjectValues.EmployeeData.TerPaystep);
            CommonUtil.VerifyElementValue(_tertiaryPayDescription, "Tertiary Pay Description", empObjectValues.EmployeeData.TertiaryDescription);
        }

        /// <summary>
        /// Verify General Tab Data
        /// </summary>
        /// <param name="empObjectValues"></param>
        public void VerifyMotorPoolData(CreateEmployeeObject empObjectValues)
        {
            Driver.ClickOnElement(_motorPoolTab, "Motor Pool Tab");
            CommonUtil.VerifyCheckboxState(_restMPReservation, "Restrict MP reservations", empObjectValues.EmployeeData.RestMPReservation);           
            Driver.WaitForReady();            
            CommonUtil.AssertTrue<bool>(true, _frameTextMotorPool.GetText("Table Text").Contains("Loaded 1 records"));
        }

        /// <summary>
        /// Verify Driver Information Tab Data
        /// </summary>
        /// <param name="createEmpObjectValues"></param>
        public void VerifyDriverInfoTabData(CreateEmployeeObject createEmpObjectValues)
        {
            Driver.ClickOnElement(_driverInfoTab, "Diver Information Tab");
            CommonUtil.VerifyElementValue(_inputDriverNO, "Driver No", EmployeeMainPage.DriverNO);
            CommonUtil.VerifyElementValue(_taxformOnFile, "Tax Form On File", createEmpObjectValues.EmployeeData.TaxformOnFile, true);
            CommonUtil.VerifyElementValue(_inputLicenceNO, "License No", createEmpObjectValues.EmployeeData.LicenseNo);
            CommonUtil.VerifyElementValueNotBlank(_icenceExpiry, "License Expiry", createEmpObjectValues.EmployeeData.LicenseExpiry);
            CommonUtil.VerifyElementValue(_txtDriverStatus, "Driver Status", createEmpObjectValues.EmployeeData.DriverStatus);
            CommonUtil.VerifyElementValue(_driverStatusDesc, "Driver Status Description", createEmpObjectValues.EmployeeData.DriverStatusDesc);
            CommonUtil.VerifyElementValue(_txtDriverType, "Driver Type ", createEmpObjectValues.EmployeeData.DriverType);
            CommonUtil.VerifyElementValue(_driverTypeDesc, "Driver Type Description", createEmpObjectValues.EmployeeData.DriverTypeDesc);
            CommonUtil.VerifyElementValue(_txtDriverClass, "Driver Class", createEmpObjectValues.EmployeeData.DriverClass);
            CommonUtil.VerifyElementValue(_driverClassDesc, "Driver Class Description", createEmpObjectValues.EmployeeData.DriverClassDesc);
            CommonUtil.VerifyElementValue(_address1, "Address1", createEmpObjectValues.EmployeeData.Address1);
            CommonUtil.VerifyElementValue(_address2, "Address2", createEmpObjectValues.EmployeeData.Address2);
            if(!string.IsNullOrEmpty(createEmpObjectValues.EmployeeData.City))
            CommonUtil.VerifyElementValue(_city, "City", createEmpObjectValues.EmployeeData.City.ToUpper().Trim());          
            CommonUtil.VerifyElementValue(_state, "State", createEmpObjectValues.EmployeeData.State);
            CommonUtil.VerifyElementValue(_zipCode, "Zip", createEmpObjectValues.EmployeeData.Zip);
            if (!string.IsNullOrEmpty(createEmpObjectValues.EmployeeData.Region))
            CommonUtil.VerifyElementValue(_region, "Region", createEmpObjectValues.EmployeeData.Region.ToUpper().Trim());
            if (!string.IsNullOrEmpty(createEmpObjectValues.EmployeeData.Municipality))
            CommonUtil.VerifyElementValue(_municipality, "Municipality", createEmpObjectValues.EmployeeData.Municipality.ToUpper().Trim());
            CommonUtil.VerifyElementValue(_country, "Country", createEmpObjectValues.EmployeeData.Country);
            CommonUtil.VerifyElementValueNotBlank(_mobile, "Mobile", createEmpObjectValues.EmployeeData.MobileVerify);
            CommonUtil.VerifyElementValue(_monthlyUsage, "Usage", createEmpObjectValues.EmployeeData.Usage);
            CommonUtil.VerifyElementValue(_monthlyBisUsage, "Business Usage", createEmpObjectValues.EmployeeData.BusinessUsage);
        }

        /// <summary>
        /// Verify Employee Info
        /// </summary>
        /// <param name="EmpId"></param>
        /// <param name="EmpName"></param>
        public void VerifyEmployeeInfo(string EmpId, string EmpName)
        {
            Settings.Logger.Info(" Verifying  Employee Info");
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            CommonUtil.AssertTrue<string>(EmpId, _inputEmpID.GetElementValueByAttribute("ovalue"));
            CommonUtil.AssertTrue<string>(EmpName, _inputName.GetElementValueByAttribute("ovalue"));
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete employee and Verify deletion       
        /// </summary>
        /// <param name="EmployeeID"></param>
        public void DeleteAndVerifyEmployeeDeletion(string EmployeeID)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.VerifyCodeDeletion(_inputEmpID, EmployeeID, "Employee ID");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Create Employee For Transfer
        /// </summary>
        public void CreateEmployeeForTransfer()
        {
            CreateEmployeeObject DataObjectSup1 = CommonUtil.DataObjectForKey("EmployeeSupervisor1").ToObject<CreateEmployeeObject>();
            CreateEmployeeObject DataObjectSup2 = CommonUtil.DataObjectForKey("EmployeeSupervisor2").ToObject<CreateEmployeeObject>();

            CreateMultipleEmployee(DataObjectSup1);
            CreateMultipleEmployee(DataObjectSup2);
        }

        /// <summary>
        /// Create Multiple Employee
        /// </summary>
        /// <param name="ObjectKey"></param>
        public void CreateMultipleEmployee(CreateEmployeeObject DataObject)
        {
            List<string> EmployeeIDList = DataObject.EmployeeData.EmployeeIDList;
            if (EmployeeIDList != null)
            {
                foreach (string EmployeeID in EmployeeIDList)
                {
                    DataObject.EmployeeData.EmployeeID = EmployeeID;
                   CreateNewEmployee(DataObject);
                }
            }
        }

        /// <summary>
        /// Verify Search Result for Title LOV
        /// </summary>
        /// <param name="EmpID"></param>
        /// <param name="searchText"></param>
        public void VerifyDataNotExistsInTitleLOV(string EmpID, string searchText)
        {            
            _extendedPage.RefreshAndSetText(_inputEmpID, EmpID, "Employee ID ");
            Driver.WaitForSomeTime(15);
            Driver.DoubleClick(_jobTitle, "Job Title");
            Driver.WaitForReady();
            string Text = _lov.SearchAndGetSearchCount(searchText);
            Assert.IsTrue(Text.Contains("Showing 0 to 0 of 0 entries"));
            Driver.SwitchTo().DefaultContent();

        }
        
        /// Verify Supervisor Name intransfered Employee
        /// </summary>
        /// <param name="DataObjectKey"></param>
        /// <param name="EmployeList"></param>
        public void VerifySupervisorNameintransferedEmployee(string DataObjectKey,List<string>  EmployeList)
        {
            foreach (string Employee in EmployeList)
            {
                VerifySupervisorName(DataObjectKey, Employee);
            }          
        }

        /// <summary>
        /// Verify Supervisor Name
        /// </summary>
        /// <param name="DataObjectKey"></param>
        /// <param name="EmployeeID"></param>
        public void VerifySupervisorName(string DataObjectKey, string EmployeeID)
        {
            CreateEmployeeObject empObjectValues = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<CreateEmployeeObject>();
            Settings.Logger.Info(" Verifying  Employee Main");
            Settings.Logger.Info(" Refresh and set Text Employee ID ");
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            Driver.WaitForSomeTime();
            _inputEmpID.SetText(EmployeeID, "Employee ID ");
            Driver.ClickOnElement(_assignmentTab, "Assignment Tab"); 
            CommonUtil.VerifyElementValue(_supervisorID, "Supervisor ID", empObjectValues.EmployeeData.SupervisorIDAfterTransfer);
            Settings.Logger.Info(" Successfully Verified SupervisorID After Transfer");
            Driver.SwitchTo().DefaultContent();
        }


        public void VerifyShiftCode(string EmployeeID,string ShiftCode)
        {          
            Settings.Logger.Info("Verifying  Shift Code");        
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            Driver.WaitForSomeTime();
            _inputEmpID.SetText(EmployeeID, "Employee ID ");           
            CommonUtil.VerifyElementValue(_inputShiftCode, "Shift Code", ShiftCode);
            Settings.Logger.Info(" Successfully Verified ShiftCode");
            Driver.SwitchTo().DefaultContent();
        }
        
        public string CopyEmployee(EmployeeCopy empCopyObjectValues)
        {
            string NewEmployeeID=string.Empty;
                  _extendedPage.SwitchToContentFrame();
            if (string.IsNullOrEmpty(empCopyObjectValues.NewEmployeeID) || empCopyObjectValues.NewEmployeeID.ToLower() == "random")
                NewEmployeeID = CommonUtil.GetRandomStringWithSpecialChars(8).ToUpper();
            Settings.Logger.Info($" Copy Employee :{empCopyObjectValues.EmployeeIDToCopy} To {NewEmployeeID}");
            _inputEmpID.SetText(empCopyObjectValues.EmployeeIDToCopy, "Employee No To Copy");
            Driver.WaitForReady();
            _inputNewEmpID.SetText(NewEmployeeID, "New Employee ID");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();            
            return NewEmployeeID;
        }

        /// <summary>
        /// Verify employee id change
        /// </summary>
        /// <param name="EmployeeId"></param>
        public void VerifyEmployeeIdChange(string EmployeeId)
        {
            Settings.Logger.Info(" Verify employee id change ");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            CommonUtil.AssertTrue<string>(EmployeeId, _inputEmpID.GetElementValueByAttribute("ovalue"));
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
        }
        /// <summary>
        /// Edit employee status
        /// </summary>
        /// <param name="DataObjectKey"></param>
        /// <param name="EmployeeId"></param>
        public void EditAndVerifyEmployeeStatus(EmployeeData employeeStatus, string EmployeeId)
        {
            Settings.Logger.Info(" Verifying  Employee Main");
            Settings.Logger.Info(" Refresh and set Text Employee ID ");
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            Driver.WaitForSomeTime();
           // EmployeeData employeeStatus = CommonUtil.DataObjectForKey(DataObjectKey).ToObject<EmployeeData>();
            _inputEmpID.SetText(EmployeeId, "Edit employee ");
            Driver.WaitForReady();
            _selectStatus.SelectFilterValueHavingEqualValue(employeeStatus.Status);
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            VerifyEmployeeStatus(employeeStatus.Status, EmployeeId);
        }

        /// <summary>
        /// Verify employee status
        /// </summary>
        /// <param name="status"></param>
        /// <param name="employeeID"></param>
        public void VerifyEmployeeStatus(string status, string employeeID)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputEmpID.SetText(employeeID, "Edit employee ");
            Driver.WaitForReady();
            CommonUtil.AssertTrue<string>(status, _selectStatus.GetVisibleText());
        }

        /// <summary>
        /// Update Employee Information
        /// </summary>
        /// <param name="DataObjectKey"></param>
        /// <param name="EmployeeName"></param>
        public void UpdateEmployeeInformation(CreateEmployeeObject empObjectValues)
        {
            Settings.Logger.Info("Update Employee Information");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForSomeTime(15);           
            _extendedPage.RefreshAndSetText(_inputEmpID, empObjectValues.EmployeeData.EmployeeID, "Employee ID ");
            FillGeneralData(empObjectValues);
            FillAssignmentTab(empObjectValues);
            FillPayrollTab(empObjectValues);
            FillResourceTypeTab(empObjectValues);
            FillDriverInfoTab(empObjectValues);
            FillMotorPoolTab(empObjectValues);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

    }
}

