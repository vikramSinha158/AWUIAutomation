﻿using System;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class EmployeeShiftAssignPageActions : EmployeeShiftAssignmentPage
    {
        public EmployeeShiftAssignPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Add Employee Shift Assignment
        /// </summary>
        /// <param name="shiftAssign"></param>
        /// <returns></returns>
        public string AssignShifts(EmployeeShiftAssign shiftAssign)
        {
            string CurrentAssignedShift = string.Empty;
            Settings.Logger.Info("Add Employee Shift Assignment");
            _inputEmpID.SetText(shiftAssign.EmployeeNo, "Employee No", Driver, _extendedPage._contentFrame, "Content Frame");
            Driver.WaitForReady();
            string[] queryparam = { shiftAssign.EmployeeNo, "ShiftCode" };
            foreach (ShiftDatum shift in shiftAssign.ShiftData)
            {
                queryparam[1] = shift.ShiftCode;
                if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection,
                    "EmpShiftAssignmentQuery", queryparam, Settings.DBType))
                {
                    _extendedPage.SwitchToTableFrame(_shiftAssignFrame);
                    _shiftCode.SetText(shift.ShiftCode, "Shift Code");
                    Driver.WaitForReady();
                    if (shift.EffectiveDate.Equals("0"))
                        CurrentAssignedShift = shift.ShiftCode;

                    if (!shift.EffectiveDate.Contains('/'))
                        shift.EffectiveDate = CommonUtil.GenerateRandomDateString(Convert.ToInt32(shift.EffectiveDate));
                    _effDt.SetText(shift.EffectiveDate, "EffectiveDate");
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.ClickOnSaveButton();
                }
            }
            return CurrentAssignedShift;
        }

        /// <summary>
        /// Verify Employee Shift Assignment
        /// </summary>
        /// <param name="shiftAssign"></param>
        public void VerifyAssignShifts(EmployeeShiftAssign shiftAssign)
        {
            Settings.Logger.Info("Verify Employee Shift Assignment");
            _extendedPage.RefreshAndSetText(_inputEmpID, shiftAssign.EmployeeNo, "EmployeeNo");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_shiftAssignFrame, "Shift Assignment Frame");
            foreach (ShiftDatum shift in shiftAssign.ShiftData)
            {
                string cellEffDAte = _extendedPage.GetTableActionElementByRelatedColumnValue(_shiftAssignTable, "Shift", 
                    shift.ShiftCode, "effDt").GetAttribute("value");
                CommonUtil.AssertTrue(shift.EffectiveDate, cellEffDAte);
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Shift Assignment
        /// </summary>
        /// <param name="shiftAssign"></param>
        public void DeleteAssignShifts(EmployeeShiftAssign shiftAssign)
        {
            Settings.Logger.Info("Delete Shift Assignment");
            _extendedPage.RefreshAndSetText(_inputEmpID, shiftAssign.EmployeeNo, "EmployeeNo");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_shiftAssignFrame, "Shift Assignment Frame");
            foreach (ShiftDatum shift in shiftAssign.ShiftData)
            {         
                _extendedPage.GetTableActionElementByRelatedColumnValue(_shiftAssignTable, "Shift", 
                    shift.ShiftCode, "effDt").ClickElement("Effective Date", Driver);
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnDeleteButton();
                _extendedPage.ClickOnSaveButton();
                _extendedPage.SwitchToTableFrame(_shiftAssignFrame);
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Deleted Shift Assignment
        /// </summary>
        /// <param name="shiftAssign"></param>
        public void VerifyDeletedAssignShifts(EmployeeShiftAssign shiftAssign)
        {
            Settings.Logger.Info("Verify Deleted Shift Assignment");
            _extendedPage.RefreshAndSetText(_inputEmpID, shiftAssign.EmployeeNo, "EmployeeNo");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_shiftAssignFrame, "Shift Assignment Frame");
            foreach (ShiftDatum shift in shiftAssign.ShiftData)
            {
                _extendedPage.VerifyTableColumnDoesNotContainValue(_shiftAssignTable, "Shift", shift.ShiftCode); 
            }
            Driver.SwitchTo().DefaultContent();
        }
    }    
}

