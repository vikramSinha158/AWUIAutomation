﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;

namespace AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct
{
    internal class FuelProductPageActions : FuelProductPage
    {
        public FuelProductPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Fuel Product Page
        /// </summary>
        /// <param name=""></param>
        public string CreateFuelProduct(FuelProducts fuelProducts)
        {
            string ProductNumber = String.Empty;           
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(fuelProducts.ProductNumber, ref ProductNumber, "ProductNumberQuery", 2))
            {
                _extendedPage.SwitchToContentFrame();
                Driver.WaitForReady();
                _fuelProductNumber.SetText(ProductNumber, "Product Number");
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ActionRequiredWindow("Create");
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
                _fuelProductDescription.SetText(fuelProducts.Description, "Test Description");
                Driver.WaitForReady();
                _fuelProductType.SelectFilterValueHavingEqualValue(fuelProducts.Type);
                Driver.WaitForReady();
                _fuelProductUnitIssue.SetText(fuelProducts.UnitIssue, "Unit Issue");
                Driver.WaitForReady();
                _fuelProductMarkUp.SelectFilterValueHavingEqualValue(fuelProducts.Markup);
                Driver.WaitForReady();
                _fuelProductAssociatedPart.SetText(fuelProducts.AssociatedPart, "Associated Part");
                Driver.WaitForReady();
                _fuelProductFuelType.SetText(fuelProducts.FuelType, "Fuel Type");
                Driver.WaitForReady();
                _carWebProduct.SelectCheckBox("CarWebProduct");
                Driver.WaitForReady();
                _fuelInsideBillItem.SetText(fuelProducts.FuelInsideBillItem, "Fuel InsideBillItem");
                Driver.WaitForReady();
                _fuelOutsideBillItem.SetText(fuelProducts.FuelOutsideBillItem, "Fuel OutsideBillItem");
                Driver.WaitForReady();
                _fuelMarkupBillItem.SetText(fuelProducts.FuelMarkupBillItem, "Fuel MarkupBillItem");
                Driver.WaitForReady();
                _fuelUnitPrice.SetText(fuelProducts.FuelUnitPrice, "Fuel UnitPrice");
                Driver.WaitForReady();
                _fuelFlatMarkupPrice.SetText(fuelProducts.FuelFlatMarkup, "Fuel FlatMarkup Price");
                Driver.WaitForReady();
                _fuelMarkupPrice.SetText(fuelProducts.FuelMarkup, "Fuel Markup Price");
                Driver.WaitForReady();
                _jobReason.SetText(fuelProducts.JobReason, "Job Reason");
                Driver.WaitForReady();
                _jobCode.SetText(fuelProducts.JobCode, "Job Code");
                Driver.WaitForReady();
                _applyTax.SelectFilterValueHavingEqualValue(fuelProducts.ApplyTax);
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.Save();
                _extendedPage.SwitchToContentFrame();
                Settings.Logger.Info("Created Fuel Product");
                ProductNumber = _fuelProductNumber.GetAttribute("ovalue");
            }
            return ProductNumber;
        }

        /// <summary>
        /// Verify Fuel Product
        /// </summary>
        /// <param name="fuelProducts"></param>
        public void VerifyFuelProduct(FuelProducts fuelProducts)
        {
            Settings.Logger.Info("Verify Fuel Product for : " + fuelProducts.ProductNumber);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_fuelProductNumber, fuelProducts.ProductNumber,"Fuel Product Number");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_fuelProductDescription, "Fuel Product Description", fuelProducts.Description);
            CommonUtil.VerifyElementValue(_fuelProductType, "Product Type", fuelProducts.Type,true);
            CommonUtil.VerifyElementValue(_fuelProductUnitIssue, "Unit Issue", fuelProducts.UnitIssue);
            CommonUtil.VerifyElementValue(_fuelProductUnitIssueDesc, "Unit Issue Desc", fuelProducts.UnitIssueDesc);

            CommonUtil.VerifyElementValue(_fuelProductAssociatedPart, "Associated Part", fuelProducts.AssociatedPart);
            CommonUtil.VerifyElementValue(_fuelProductAssociatedPartDesc, "Associated Part Desc", fuelProducts.AssociatedPartDesc);

            CommonUtil.VerifyElementValue(_fuelProductFuelType, "Fuel Type", fuelProducts.FuelType);
            CommonUtil.VerifyElementValue(_fuelProductFuelTypeDesc, "Fuel Type Desc", fuelProducts.FuelTypeDesc);

            CommonUtil.VerifyElementValue(_fuelInsideBillItem, "Fuel InsideBillItem", fuelProducts.FuelInsideBillItem);
            CommonUtil.VerifyElementValue(_fuelInsideBillItemDesc, "Fuel InsideBillItem Desc", fuelProducts.FuelInsideBillItemDesc);

            CommonUtil.VerifyElementValue(_fuelOutsideBillItem, "Fuel OutsideBillItem", fuelProducts.FuelOutsideBillItem);
            CommonUtil.VerifyElementValue(_fuelOutsideBillItemDesc, "Fuel OutsideBillItem Desc", fuelProducts.FuelOutsideBillItemDesc);

            CommonUtil.VerifyElementValue(_fuelUnitPrice, "Fuel UnitPrice", fuelProducts.FuelUnitPrice);
            CommonUtil.VerifyElementValue(_fuelMarkupPrice, "Fuel MarkupPrice", fuelProducts.FuelMarkup);
            CommonUtil.VerifyElementValue(_fuelFlatMarkupPrice, "Fuel Flat MarkupPrice", fuelProducts.FuelFlatMarkup);
            CommonUtil.VerifyCheckboxState(_carWebProduct, "Car Web Product", fuelProducts.CarWebProduct);
            CommonUtil.VerifyElementValue(_jobReason, "Job Reason", fuelProducts.JobReason);
            CommonUtil.VerifyElementValue(_jobReasonDesc, "Job Reason Desc", fuelProducts.JobReasonDesc);

            CommonUtil.VerifyElementValue(_jobCode, "Job Code", fuelProducts.JobCode);
            CommonUtil.VerifyElementValue(_jobCodeDesc, "Job Code desc", fuelProducts.JobCodeDesc);

            CommonUtil.VerifyElementValue(_applyTax, "Apply Tax", fuelProducts.ApplyTax,true);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verified Fuel Product Successfully for : " + fuelProducts.ProductNumber);
        }

        /// <summary>
        /// Fuel Product Deletion
        /// </summary>
        /// <param name="ProductNumber"></param>
        public void DeleteFuelProduct(string ProductNumber)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.VerifyCodeDeletion(_fuelProductNumber, ProductNumber, "Product Number");
        }
    }
}
