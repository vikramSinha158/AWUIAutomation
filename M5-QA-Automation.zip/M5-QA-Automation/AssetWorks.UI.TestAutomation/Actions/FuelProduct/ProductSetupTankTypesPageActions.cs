﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct
{
    internal class ProductSetupTankTypesPageActions : ProductSetupTankTypesPage
    {
        public ProductSetupTankTypesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Product Setup Tank Types
        /// </summary>
        /// <param name="ProductSetupTankTypes"></param>
        /// <returns></returns>
        public string CreateProductSetupTankTypes(ProductSetupTankTypes ProductSetupTankTypes)
        {           
            string TankType=string.Empty;
            if (!_extendpage.CheckDataExistenceAndGetActionCode(ProductSetupTankTypes.TankType, ref TankType, "ProductSetupTankTypesQuery", 3))
            {
                _extendpage.SwitchToContentFrame();
                _tankTypeKey.SetText(TankType, " TankType ");
                Driver.SwitchTo().DefaultContent();
                _extendpage.ActionRequiredWindow("Create");
                _extendpage.SwitchToContentFrame();
                _capacity.SetText(ProductSetupTankTypes.TankCapacity, " TankCapacity ");
                Driver.WaitForReady();
                _extendpage.SetCheckBox(_convFl, "Needs Conversion check box", ProductSetupTankTypes.NeedsConversion);
                Driver.WaitForReady();
                if (ProductSetupTankTypes.ManufacturersInformation != null)
                {
                    FillManufacturersInformation(ProductSetupTankTypes);
                }
                if (ProductSetupTankTypes.StickConversion != null)
                {
                    FillStickConversion(ProductSetupTankTypes);
                }
                Driver.WaitForReady();
                ProductSetupTankTypes.TankType=TankType;
                _note.SetText(ProductSetupTankTypes.Note, "Note");
                _extendpage.Save();
                Settings.Logger.Info(" Created New Product Setup Tank Types   ");
            }
            return ProductSetupTankTypes.TankType;
        }

        /// <summary>
        /// Fill Manufacturers Information
        /// </summary>
        /// <param name="ProductSetupTankTypes"></param>
        public void FillManufacturersInformation(ProductSetupTankTypes ProductSetupTankTypes)
        { 
            Settings.Logger.Info(" Fill Manufacturer sInformation  ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_mfrInfoFrame, "mfrInfoFrame");
            Driver.WaitForReady();
            foreach (ManufacturersInformation ManufacturersInformation in ProductSetupTankTypes.ManufacturersInformation)
            {
                _extendpage.GetTableActionElementByRelatedColumnValue(_tankManufacturersinfoTable, "Manufacturer", "", "make").SetText(ManufacturersInformation.Manufacturer, "Manufacturer");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_tankManufacturersinfoTable, "Manufacturer", ManufacturersInformation.Manufacturer, "model").SetText(ManufacturersInformation.Model, "Model");
                Driver.WaitForReady();
            }
        }

        /// <summary>
        /// Fill Stick Conversion
        /// </summary>
        /// <param name="ProductSetupTankTypes"></param>
        public void FillStickConversion(ProductSetupTankTypes ProductSetupTankTypes)
        {
            Settings.Logger.Info(" Fill Stick Conversion  ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_stickConvrsnFrame, "stickConvrsnFrame");
            Driver.WaitForReady();
            foreach (StickConversion StickConversion in ProductSetupTankTypes.StickConversion)
            {
                _extendpage.GetTableActionElementByRelatedColumnValue(_stickConversionTableTable, "Increment", "", "stickread").SetText(StickConversion.Increment, "Increment");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_stickConversionTableTable, "Increment", StickConversion.Increment, "stickqty").SetText(StickConversion.Quantity, "Quantity");
                Driver.WaitForReady();
            }
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
        }

        /// <summary>
        /// Verify Product Setup Tank Types
        /// </summary>
        /// <param name="ProductSetupTankTypes"></param>
        public void VerifyProductSetupTankTypes(ProductSetupTankTypes ProductSetupTankTypes)
        {
            Settings.Logger.Info($"Verifying ProductSetupTankTypes  {ProductSetupTankTypes.TankType}");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendpage.RefreshAndSetText(_tankTypeKey, ProductSetupTankTypes.TankType, "TankType");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_tankTypeKey, "TankType", ProductSetupTankTypes.TankType);
            CommonUtil.VerifyElementValue(_capacity, "TankCapacity", ProductSetupTankTypes.TankCapacity);
            CommonUtil.VerifyCheckboxState(_convFl, "NeedsConversion", ProductSetupTankTypes.NeedsConversion);
            Driver.WaitForReady();
            if (ProductSetupTankTypes.ManufacturersInformation != null)
            {
                Driver.SwitchToFrame(_mfrInfoFrame, "mfrInfoFrame");
                foreach (ManufacturersInformation ManufacturersInformation in ProductSetupTankTypes.ManufacturersInformation)
                {
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tankManufacturersinfoTable, "Manufacturer", ManufacturersInformation.Manufacturer, "make"), "Manufacturer", ManufacturersInformation.Manufacturer,false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_tankManufacturersinfoTable, "Manufacturer", ManufacturersInformation.Manufacturer, "model"), "Model", ManufacturersInformation.Model, false, "value");
                }
                Driver.SwitchTo().DefaultContent();
                _extendpage.SwitchToContentFrame();
            }
            if (ProductSetupTankTypes.StickConversion != null)
            {
                Driver.SwitchToFrame(_stickConvrsnFrame, "stickConvrsnFrame");
                foreach (StickConversion StickConversion in ProductSetupTankTypes.StickConversion)
                {
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_stickConversionTableTable, "Increment", StickConversion.Increment, "stickread"), "Increment", StickConversion.Increment, false, "value");
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_stickConversionTableTable, "Increment", StickConversion.Increment, "stickqty"), "Increment", StickConversion.Quantity, false, "value");
                }
                Driver.SwitchTo().DefaultContent();
                _extendpage.SwitchToContentFrame();
            }
            CommonUtil.VerifyElementValue(_note, "NeedsConversion", ProductSetupTankTypes.Note);
            Settings.Logger.Info($"Successfully verified Product Setup Tank Types  {ProductSetupTankTypes.TankType}");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Product Setup Tank Types
        /// </summary>
        /// <param name="ProductSetupTankTypes"></param>
        public void VerifyProductSetupTankTypeDeletion(string ProductSetupTankTypes)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.VerifyCodeDeletion(_tankTypeKey, ProductSetupTankTypes, "Product Setup Tank Types");
        }

        /// <summary>
        /// Update Product Setup Tank Types
        /// </summary>
        /// <param name="ProductSetupTankTypes"></param>
        public void UpdateProductSetupTankTypes(ProductSetupTankTypes ProductSetupTankTypes)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_tankTypeKey, ProductSetupTankTypes.TankType, "TankType");
            Driver.WaitForReady();
            if (ProductSetupTankTypes.ManufacturersInformation != null)
            {
                FillManufacturersInformation(ProductSetupTankTypes);
            }
            if (ProductSetupTankTypes.StickConversion != null)
            {
                FillStickConversion(ProductSetupTankTypes);
            }
            Driver.WaitForReady();
            _note.SetText(ProductSetupTankTypes.Note, "Note");
            _extendpage.Save();
            Settings.Logger.Info(" Edited Product Setup Tank Types   ");
        }
    }
}
