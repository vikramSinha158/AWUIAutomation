﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System.Collections.Generic;


namespace AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct
{
    internal class ProductSetupTanksPageActions : ProductSetupTanksPage
    {
        public ProductSetupTanksPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Product Tank
        /// </summary>
        /// <param name="DataObject"></param>
        /// <param name="PreSetUpData"></param>
        public void CreateProductTank(ProductTank DataObject, bool PreSetUpData=false)
        {          
            List<UpdateProductTank> ProductTankList = DataObject.UpdateProductTank;
            _extendedPage.SwitchToContentFrame();
            _fuelLocation.SetText(DataObject.FuelLocation, "_fuelLocation");         
            foreach (UpdateProductTank updateProductTank in ProductTankList)
            {
                string[] queryparam = { updateProductTank.ProductNo, updateProductTank.TankNo, DataObject.FuelLocation };
                bool DataNotExist = CommonUtil.CheckDataExistWithMultipleParams(Settings.connection,
                "ProductTankQuery", queryparam, Settings.DBType);
                if (PreSetUpData)
                {
                    if (DataNotExist)
                    {
                        FillTankData(updateProductTank);                      
                    }
                }
                else
                {
                    DeleteProductTank(DataObject);
                    FillTankData(updateProductTank);
                }             
            }
           
        }

        /// <summary>
        /// Fill Tank Data
        /// </summary>
        /// <param name="updateProductTank"></param>
        public void FillTankData(UpdateProductTank updateProductTank)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();           
            Driver.SwitchTo().Frame(_LocFuelTankFrame);
            Driver.WaitForReady();
            _tankNo.SetText(updateProductTank.TankNo, "TankNo");
            Driver.WaitForReady();
            _productNo.SetText(updateProductTank.ProductNo, "ProductNo");
            Driver.WaitForReady();
            _productType.SetText(updateProductTank.Type, "Type");
            Driver.WaitForReady();
            _adjAccount.SetText(updateProductTank.Adj_Account, "Adj_Account");
            Driver.WaitForReady();
            _checkBoxEVR.SelectCheckBox("EVREnforced", updateProductTank.EVREnforced);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }   

        /// <summary>
        /// Verify Created Product Tank
        /// </summary>
        /// <param name=""></param>
        public void VerifyCreatedProductTank(ProductTank DataObject)
        {            
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchTo().Frame("LocFuelTankFrame");
            List<UpdateProductTank> ProductTankList = DataObject.UpdateProductTank;
            foreach (UpdateProductTank updateProductTank in ProductTankList)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo, "tTank_no"), "", updateProductTank.TankNo, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo, "tProd_no"),"", updateProductTank.ProductNo,false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo, "tProdDesc"),"", updateProductTank.ProductDescription,false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo, "tTank_Type"),"", updateProductTank.Type,false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo, "tAdj_Acct"),"", updateProductTank.Adj_Account,false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo, "tIndAcctDesc"),"", updateProductTank.AccountDescription,false, "value");
                CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo, "EVRII_reqd"), "", updateProductTank.EVREnforced);
             }
        }

        /// <summary>
        /// Update and Delete Product Tank
        /// </summary>
        /// <param name=""></param>
        public void UpdateProductTank(ProductTank DataObject)
        {
            _extendedPage.ClickRefresh();
            _extendedPage.SwitchToContentFrame();
            _fuelLocation.SetText(DataObject.FuelLocation, "_fuelLocation");
            Driver.SwitchTo().Frame("LocFuelTankFrame");
            Driver.WaitForReady();
            List<UpdateProductTank> ProductTankList = DataObject.UpdateProductTank;
            foreach (UpdateProductTank updateProductTank in ProductTankList)
            {
                _extendedPage.SetCheckBox(_extendedPage.GetTableActionElementByRelatedColumnValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo, "EVRII_reqd"),"", updateProductTank.EVREnforced);
            }            
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Delete Product Tank
        /// </summary>
        /// <param name="DataObject"></param>
        public void DeleteProductTank(ProductTank DataObject)
        {
            List<UpdateProductTank> ProductTankList = DataObject.UpdateProductTank;
            foreach (UpdateProductTank updateProductTank in ProductTankList)
            {                
                foreach (IWebElement tank in _verifyTankNo(updateProductTank.TankNo))
                {
                    tank.ClickElement("tank", Driver);
                    Driver.WaitForReady();
                    _extendedPage.DeleteAndSave();
                }
                Driver.SwitchTo().Frame("LocFuelTankFrame");               
            }
        }

        /// <summary>
        /// Verify Deleted Product Tank
        /// </summary>
        /// <param name=""></param>
        public void VerifyDeletedProductTank(ProductTank DataObject)
        {
            _extendedPage.ClickRefresh();
            _extendedPage.SwitchToContentFrame();
            _fuelLocation.SetText(DataObject.FuelLocation, "_fuelLocation");
            Driver.SwitchTo().Frame("LocFuelTankFrame");
            Driver.WaitForReady();
            List<UpdateProductTank> ProductTankList = DataObject.UpdateProductTank;
            foreach (UpdateProductTank updateProductTank in ProductTankList)
            {
                if (_verifyTankNo(updateProductTank.TankNo).Count > 0)
                {
                    _extendedPage.VerifyTableColumnDoesNotContainValue(_LocFuelTankTable, _headerTankNo, updateProductTank.TankNo);
                }
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}