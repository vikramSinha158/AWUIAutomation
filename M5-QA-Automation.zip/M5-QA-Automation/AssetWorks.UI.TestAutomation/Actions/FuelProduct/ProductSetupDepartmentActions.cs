﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct
{
    internal class ProductSetupDepartmentActions : ProductSetupDepartmentPage
    {
        public ProductSetupDepartmentActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Product Department
        /// </summary>
        /// <param name=""></param>
        public void CreateProductSetUpDepartment(ProductSetUpDepartment DataObject)
        {
            _extendedPage.SwitchToContentFrame();
            _department.SetText(DataObject.Department, "Department");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _employeeRequired.SelectCheckBox("Employee Required",DataObject.EmployeeRequired);
            Driver.WaitForReady();
            _validateEmployee.SelectCheckBox("Validate Employee",DataObject.ValidateEmployee);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            DeleteProductInformation(DataObject.SetUpDepartmentDetails.DepartmentProduct);
            DeleteCardInformation(DataObject.SetUpDepartmentDetails.DeparmtmentCardsInformation);
            EnterProductInformation(DataObject.SetUpDepartmentDetails.DepartmentProduct);
            EnterCardInformation(DataObject.SetUpDepartmentDetails.DeparmtmentCardsInformation);
        }


        /// <summary>
        /// Verify Product Department
        /// </summary>
        /// <param name=""></param>
        public void VerifyProductDepartment(ProductSetUpDepartment DataObject)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            CommonUtil.VerifyCheckboxState(_employeeRequired, "Element Required", true);
            CommonUtil.VerifyCheckboxState(_validateEmployee, "Validate Employee", true);
            Driver.SwitchTo().DefaultContent();
            VerifyProductInformation(DataObject.SetUpDepartmentDetails.DepartmentProduct);
            VerifyCardInformation(DataObject.SetUpDepartmentDetails.DeparmtmentCardsInformation);
        }


        /// <summary>
        /// Verify Card Information
        /// </summary>
        /// <param name=""></param>
        public void VerifyCardInformation(List<DeparmtmentCardsInformation> cardInformation)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            _cardsTab.ClickElement("Card Information", Driver);
            Driver.SwitchToFrame(_cardFrame, "_cardFrame");
            foreach (DeparmtmentCardsInformation information in cardInformation)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _cardTable, "Card No", information.CardNo, "VendorNo"), "Card No", information.VendorNo, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _cardTable, "Card No", information.CardNo, "PromptID"), "Card No", information.PromptId, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _cardTable, "Card No", information.CardNo, "Pin"), "Card No", information.Pin, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _cardTable, "Card No", information.CardNo, "MsgText"), "Card No", information.MessageText, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _cardTable, "Card No", information.CardNo, "DeviceSrNo"), "Card No", information.DeviceSerialNumber, false, "value");
                Driver.ScrollIntoViewAndClick(_extendedPage.GetTableActionElementByRelatedColumnValue(_cardTable, "Card No", information.CardNo, "Notes"), "Notes table");
                Driver.SwitchTo().DefaultContent();
                CommonUtil.AssertTrue(information.CardNotes, _cardMaintenanceNotes.GetText("_cardNotes"));
                _cardMaintenanceOkButton.ClickElement("_cardMaintenanceOkButton", Driver);
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_cardFrame, "_cardFrame");
                Driver.WaitForReady();
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
              _cardTable, "Card No", information.CardNo, "Card_Disabled"), "Card No", information.DisableCard);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _cardTable, "Card No", information.CardNo, "userData1"), "Card No", information.UserData1, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _cardTable, "Card No", information.CardNo, "userData2"), "Card No", information.UserData2, false, "value");
            }
        }

        /// <summary>
        /// Verify product Information
        /// </summary>
        /// <param name=""></param>
        public void VerifyProductInformation(List<DepartmentProduct> DepartmentProducts)
        {
            foreach (DepartmentProduct information in DepartmentProducts)
            {
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
                CommonUtil.VerifyCheckboxState(_productEditMode(DepartmentProducts[0].ProductMEditMode), "Edit Mode", true);
                Driver.SwitchToFrame(_prodInfoFrame, "_prodInfoFrame");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _productTable, "Product", information.ProductId, "description"), "Product Id", information.Description, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _productTable, "Product", information.ProductId, "tank_capacity"), "Tank Capacity", information.TankCapacity, false, "value");
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Enter Product Information
        /// </summary>
        /// <param name=""></param>
        public void EnterProductInformation(List<DepartmentProduct> ProductInformation)
        {
            _extendedPage.SwitchToContentFrame();
            _productsTab.ClickElement("_productsTab", Driver);
            foreach (DepartmentProduct information in ProductInformation)
            {
                _productEditMode(information.ProductMEditMode).ClickElement("Product EditMode",Driver);
                Driver.SwitchToFrame(_prodInfoFrame, "Product Info Frame");
                _productNo.SetText(information.ProductId,"ProductId");
                Driver.WaitForReady();
                _tankCapacity.SetText(information.TankCapacity,"Tank Capacity");
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClicKSave();
                _extendedPage.SwitchToContentFrame();
            }
            Driver.SwitchTo().DefaultContent();
        }
        /// <summary>
        /// Enter Card Information
        /// </summary>
        /// <param name=""></param>
        public void EnterCardInformation(List<DeparmtmentCardsInformation> cardInformation)
        {
                _extendedPage.SwitchToContentFrame();
                _cardsTab.ClickElement("Card Information", Driver);
                foreach (DeparmtmentCardsInformation information in cardInformation)
                {
                    Driver.SwitchToFrame(_cardFrame, "_cardFrame");
                    _cardNo.SetText(information.CardNo, "Card Number");
                    Driver.WaitForReady();
                    _effectiveDate.SetText(CommonUtil.GenerateRandomDateString(Convert.ToInt16(information.EffectiveDate)), "Effective Date");
                    Driver.WaitForReady();
                    _expirationDate.SetText(CommonUtil.GenerateRandomDateString(Convert.ToInt16(information.ExpirationDate)), "Expiration Date");
                    Driver.WaitForReady();
                    _vendorNo.SetText(information.VendorNo, "_vendorNo");
                    Driver.WaitForReady();
                    _promptId.SetText(information.PromptId, "_promptId");
                    Driver.WaitForReady();
                    _pinId.SetText(information.Pin, "Pin");
                    Driver.WaitForReady();
                    _messageText.SetText(information.MessageText, "_messageText");
                    Driver.WaitForReady();
                    _deviceSerial.SetText(information.DeviceSerialNumber, "_deviceSerial");
                    Driver.WaitForReady();
                    _cardDisable.SelectDropdownUsingValue("_cardDisable", information.DisableCard);
                    _cardNotes.ClickElement("_cardNotes", Driver);
                    Driver.SwitchTo().DefaultContent();
                    _cardMaintenanceNotes.SetText(information.CardNotes, "Card Notes");
                    _cardMaintenanceOkButton.ClickElement("_cardMaintenanceOkButton", Driver);
                    _extendedPage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_cardFrame, "_cardFrame");
                    _userData1.SetText(information.UserData1, "_userData1");
                    _userData2.SetText(information.UserData2, "_userData2");
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.ClicKSave();
                    _extendedPage.SwitchToContentFrame();
                }
        }

        /// <summary>
        /// Delete Product Information
        /// </summary>
        /// <param name=""></param>
        public void DeleteProductInformation(List<DepartmentProduct> DepartmentProduct)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            _productsTab.ClickElement("ProductInformation", Driver);
            Driver.SwitchToFrame(_prodInfoFrame, "_prodInfoFrame");
            foreach (DepartmentProduct information in DepartmentProduct)
            {
                List<string> productNumbers = new List<string>(_productNos.Select(x => x.GetAttribute("value").ToString()));
                if (productNumbers.Contains(information.ProductId))
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_productTable, "Product", information.ProductId, "tank_capacity").ClickElement("Tank Capacity", Driver);
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.DeleteAndSave();
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_prodInfoFrame, "_prodInfoFrame");
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Card information
        /// </summary>
        /// <param name=""></param>
        public void DeleteCardInformation(List<DeparmtmentCardsInformation> cardInformation)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            _cardsTab.ClickElement("_cardInformation", Driver);
            Driver.SwitchToFrame(_cardFrame, "Card Frame");
            foreach (DeparmtmentCardsInformation information in cardInformation)
            {
                List<string> cardNumbers = new List<string>(_cardNos.Select(x => x.GetAttribute("value").ToString())); ;
                if (cardNumbers.Contains(information.CardNo))
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_cardTable, "Card No", information.CardNo, "VendorNo").ClickElement("CardNo", Driver);
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.DeleteAndSave();
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.SwitchToContentFrame();
                    _cardFrame.ClickElement("_cardFrame", Driver);
                }
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}