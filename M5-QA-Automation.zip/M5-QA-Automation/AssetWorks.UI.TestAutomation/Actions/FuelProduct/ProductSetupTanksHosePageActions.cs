﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System.Collections.Generic;


namespace AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct
{
    internal class ProductSetupTanksHosePageActions : ProductSetupTanksHosePage
    {
        public ProductSetupTanksHosePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Product Tank Hose
        /// </summary>
        /// <param name=""></param>
        public void CreateProductTankHose(ProductSetUpTankHoseObjects DataObject,bool PreSetUpData=false)
        {
            _extendedPage.SwitchToContentFrame();                    
            if (DataObject.ProductSetUpTankHose.SetUpTankHose != null)
            {
                _fuelLocation.SetText(DataObject.ProductSetUpTankHose.FuelLocation, "_fuelLocation");
                int i = 0;
                foreach (SetUpTankHose input in DataObject.ProductSetUpTankHose.SetUpTankHose)
                {
                    string[] queryparam = { DataObject.ProductSetUpTankHose.SetUpTankHose[i].HoseNo, DataObject.ProductSetUpTankHose.FuelLocation };
                  bool DataNotExist= CommonUtil.CheckDataExistWithMultipleParams(Settings.connection, "LocTankHoseQuery", queryparam, Settings.DBType);
                    
                    if (PreSetUpData)
                    {
                        if (DataNotExist)
                        {
                            FillHoseInformation(input);
                        }
                    }
                    else
                    {
                        if (!(DataNotExist))
                        {
                            DeleteHoseInformation(input);
                        }
                        FillHoseInformation(input);
                    }
                    i++;
                }               
             }
            }
        

        /// <summary>
        /// Update Product Tank Hose
        /// </summary>
        /// <param name=""></param>
        public void UpdateProductTankHose(ProductSetUpTankHoseObjects DataObject)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_fuelLocation, DataObject.ProductSetUpTankHose.FuelLocation,"Fuel Location");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            if (DataObject.ProductSetUpTankHose.SetUpTankHose != null)
                UpdateHoseInformation(DataObject.ProductSetUpTankHose.SetUpTankHose);
        }


        /// <summary>
        /// Delete and verify the Tank Hose
        /// </summary>
        /// <param name=""></param>
        public void DeleteAndVerifyTheTankHose(ProductSetUpTankHoseObjects DataObject)
        {
            foreach (SetUpTankHose hose in DataObject.ProductSetUpTankHose.SetUpTankHose)
            {
                DeleteHoseInformation(hose);
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_fuelHoseFrame, "_fuelHoseFrame");
                _extendedPage.VerifyTableColumnDoesNotContainValue(_hoseTable, "Hose No", hose.HoseNo);
            }         
        }

        /// <summary>
        /// Delete Hose Information
        /// </summary>
        /// <param name=""></param>
        public void DeleteHoseInformation(SetUpTankHose data)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_fuelHoseFrame, "_fuelHoseFrame");
            foreach (IWebElement element in _hoseNumbers)
            {
                if (element.GetAttribute("value") == data.HoseNo)
                {
                    element.ClickElement("Hose Number", Driver);
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.ClickOnDeleteButton();
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Fill Hose information
        /// </summary>
        /// <param name=""></param>
        public void FillHoseInformation(SetUpTankHose input)
        {
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_fuelHoseFrame, "_fuelHoseFrame");
                _hoseNo.SetText(input.HoseNo, "Hose Number");
                Driver.WaitForReady();
                _tankNo.SetText(input.TankNo,"Tank Number");
                Driver.WaitForReady();
                _dedicatedCardNumber.SetText(input.DedicatedCardNo,"Dedicated Number");
                Driver.WaitForReady();
                _extendedPage.SetCheckBox(_evrComplaint, "_evrComplaint",input.EVRIIComplaint);
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
                Driver.WaitForReady();
        }

        /// <summary>
        /// Update Hose Information
        /// </summary>
        /// <param name=""></param>
        public void UpdateHoseInformation(List<SetUpTankHose> details)
        {
            foreach (SetUpTankHose input in details)
            {
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
                Driver.WaitForReady();
                Driver.SwitchToFrame(_fuelHoseFrame, "_fuelHoseFrame");
                Driver.WaitForReady();
                _extendedPage.SetCheckBox(_extendedPage.GetTableActionElementByRelatedColumnValue(
                 _hoseTable, "Hose No", input.HoseNo, "EVRII_comp"), "EVRIIComplaint", input.EVRIIComplaint);
                _extendedPage.SetCheckBox(_extendedPage.GetTableActionElementByRelatedColumnValue(
              _hoseTable, "Hose No", input.HoseNo, "defuel_fl"), "Defueling Hose", input.DefuelingHose);
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
            }
        }

        /// <summary>
        /// Verify Entered Hose information
        /// </summary>
        /// <param name=""></param>
        public void VerifyHoseInformation(ProductSetUpTankHoseObjects DataObject)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_fuelLocation,DataObject.ProductSetUpTankHose.FuelLocation,"Fuel Location");
            Driver.WaitForReady();
            foreach (SetUpTankHose input in DataObject.ProductSetUpTankHose.SetUpTankHose)
            {
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
                Driver.WaitForReady();
                Driver.SwitchToFrame(_fuelHoseFrame, "_fuelHoseFrame");
                Driver.WaitForReady();
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
               _hoseTable, "Hose No", input.HoseNo, "hTank_no"), "Hose No", input.TankNo,false,"value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _hoseTable, "Hose No", input.HoseNo, "hProd_no"), "Product No", input.ProductNo, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _hoseTable, "Hose No", input.HoseNo, "hProd_desc"), "Description", input.Description, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _hoseTable, "Hose No", input.HoseNo, "hCard_no"), "Card Number", input.DedicatedCardNo, false, "value");
                CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _hoseTable, "Hose No", input.HoseNo, "EVRII_comp"),"EVRII CheckBox",input.EVRIIComplaint);
                CommonUtil.AssertTrue(_extendedPage.GetTableActionElementByRelatedColumnValue(
              _hoseTable, "Hose No", input.HoseNo, "defuel_fl").Selected, input.DefuelingHose);
            }
        }
    }   
}