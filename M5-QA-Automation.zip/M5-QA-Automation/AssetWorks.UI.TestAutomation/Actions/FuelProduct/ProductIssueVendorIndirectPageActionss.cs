﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct
{
    internal class ProductIssueVendorIndirectPageActionss : ProductIssueVendorIndirectPage
    {
        public ProductIssueVendorIndirectPageActionss(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Creat eProduct Issue Vendor Indirect
        /// </summary>
        /// <param name="ProductIssueVendorIndirect"></param>
        public void CreateProductIssueVendorIndirect(ProductIssueVendorIndirect ProductIssueVendorIndirect)
        {
            Settings.Logger.Info(" Create New Product Issue Vendor Indirect ");
            _extendpage.SwitchToContentFrame();
            _location.SetText(ProductIssueVendorIndirect.Location, "Location");
            Driver.WaitForReady();
            _indAcct.SetText(ProductIssueVendorIndirect.IndAcctNo, "IndAcctNo");
            Driver.WaitForReady();
            _vendorNo.SetText(ProductIssueVendorIndirect.VendorNo, "VendorNo");
            Driver.WaitForReady();
            _poNo.SetText(ProductIssueVendorIndirect.PONo, "PONo");
            Driver.WaitForReady();
            _refNo.SetText(ProductIssueVendorIndirect.RefNo, "RefNo");
            Driver.WaitForReady();
            _invoiceNo.SetText(ProductIssueVendorIndirect.InvoiceNo, "InvoiceNo");
            Driver.WaitForReady();
            _tax.SetText(ProductIssueVendorIndirect.Tax, "Tax");
            if (ProductIssueVendorIndirect.ProductIssueVendorIndirectTable != null)
            {
                FillOtherInformation(ProductIssueVendorIndirect);
            }
            _extendpage.Save();
        }

        /// <summary>
        /// Fill Other Information
        /// </summary>
        /// <param name="ProductIssueVendorIndirect"></param>
        public void FillOtherInformation(ProductIssueVendorIndirect ProductIssueVendorIndirect)
        {
            Settings.Logger.Info(" Fill Other Information ");
            Driver.SwitchToFrame(_prodIssueFrame, "prodIssueFrame");
            foreach (ProductIssueVendorIndirectTable ProductIssueVendorIndirectTable in ProductIssueVendorIndirect.ProductIssueVendorIndirectTable)
            {
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_prodIssue4Table, "Product", "", "IssueDateTime").SendKeys(Keys.Tab);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_prodIssue4Table, "Product", "", "Product").SetText(ProductIssueVendorIndirectTable.Product, "Product");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_prodIssue4Table, "Product", ProductIssueVendorIndirectTable.Product, "Quantity").SetText(ProductIssueVendorIndirectTable.Quantity, "Quantity");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_prodIssue4Table, "Product", ProductIssueVendorIndirectTable.Product, "Unit_Cost").SetText(ProductIssueVendorIndirectTable.UnitCost, "UnitCost");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_prodIssue4Table, "Product", ProductIssueVendorIndirectTable.Product, "Employee").SetText(ProductIssueVendorIndirectTable.Employee, "Employee");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_prodIssue4Table, "Product", ProductIssueVendorIndirectTable.Product, "State").SetText(ProductIssueVendorIndirectTable.State, "State");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_prodIssue4Table, "Product", ProductIssueVendorIndirectTable.Product, "Credit_Card").SetText(ProductIssueVendorIndirectTable.CreditCard, "CreditCard");
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Product Issue Vendor Indirect
        /// </summary>
        /// <param name="ProductIssueVendorIndirect"></param>
        public void VerifyProductIssueVendorIndirect(ProductIssueVendorIndirect ProductIssueVendorIndirect)
        {
            Settings.Logger.Info(" Verify Product Issue Vendor Indirectt ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            //Verify record should disappear from the Other Information ifram
            if (ProductIssueVendorIndirect.ProductIssueVendorIndirectTable != null)
            {
                _extendpage.VerifyTableRowDeletion(_prodIssueFrame, _prodIssue4TableRows, "prodIssueFrame");
                Driver.SwitchTo().DefaultContent();
                _extendpage.SwitchToContentFrame();
            }    
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_location, "Location", ProductIssueVendorIndirect.Location);
            CommonUtil.VerifyElementValue(_indAcct, "IndAcctNo", ProductIssueVendorIndirect.IndAcctNo);
            CommonUtil.VerifyElementValue(_vendorNo, "VendorNo", ProductIssueVendorIndirect.VendorNo);
            CommonUtil.VerifyElementValue(_poNo, "PONo", ProductIssueVendorIndirect.PONo);
            CommonUtil.VerifyElementValue(_refNo, "RefNo", ProductIssueVendorIndirect.RefNo);
            CommonUtil.VerifyElementValue(_invoiceNo, "InvoiceNo", ProductIssueVendorIndirect.InvoiceNo);
            CommonUtil.VerifyElementValue(_tax, "Tax", ProductIssueVendorIndirect.Tax);
        }
    }
}
