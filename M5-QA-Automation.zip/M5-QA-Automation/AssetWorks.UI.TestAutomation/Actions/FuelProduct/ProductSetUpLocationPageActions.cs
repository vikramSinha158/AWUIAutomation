﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;

namespace AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct
{
    internal class ProductSetUpLocationPageActions : ProductSetUpLocationPage
    {
        public ProductSetUpLocationPageActions(IWebDriver Driver) : base(Driver) { }


        /// <summary>
        /// Create Product Location
        /// </summary>
        /// <param name=""></param>
        public void CreateProductLocation(ProductSetUpLocation DataObject)
        {
            _extendedPage.SwitchToContentFrame();
            _location.SetText(DataObject.Location,"Location");
            Driver.WaitForReady();
            _productNo.SetText(DataObject.ProductNo, "Product Number");
            Driver.WaitForReady();
            _tankNo.SetText(DataObject.TankNo, "Tank No");
            Driver.WaitForReady();
            Driver.ScrollIntoViewAndClick(methodTrackingStock(DataObject.MethodOfTrackingStock),"Method Tracking Stock");
            Driver.WaitForReady();
            Driver.ScrollIntoViewAndClick(issueQuantityCalculation(DataObject.IssueQuantityCalculation), "Method Tracking Stock");
            Driver.WaitForReady();
            _maxQuantity.SetText(DataObject.MaximumQuantity,"Maximum Quantity");
            Driver.WaitForReady();
            _minimumQuantity.SetText(DataObject.MinimumQuantity, "Minium Quantity Quantity");
            _stockStatusTab.ClickElement("_stockStatusTab",Driver);
            Driver.WaitForReady();
            _perTransactionCharge.SetText(DataObject.PerTransactionCharge,"Per Transaction Charge");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClicKSave();
        }

        /// <summary>
        /// Create Product Location
        /// </summary>
        /// <param name=""></param>
        public void UpdateProductLocation(ProductSetUpLocation DataObject)
        {
            _extendedPage.SwitchToContentFrame();
            _detailedInformationTab.ClickElement("_detailedInformationTab",Driver);
            Driver.WaitForReady();
            Driver.ScrollIntoViewAndClick(methodTrackingStock(DataObject.MethodOfTrackingStock), "Method Tracking Stock");
            Driver.WaitForReady();
            Driver.ScrollIntoViewAndClick(issueQuantityCalculation(DataObject.IssueQuantityCalculation), "Method Tracking Stock");
            Driver.WaitForReady();
            _maxQuantity.SetText(DataObject.MaximumQuantity, "Maximum Quantity");
            Driver.WaitForReady();
            _minimumQuantity.SetText(DataObject.MinimumQuantity, "Minium Quantity Quantity");
            _stockStatusTab.ClickElement("_stockStatusTab", Driver);
            Driver.WaitForReady();
            _unitPR.SetText(DataObject.UnitCost,"_unitPR");
            Driver.WaitForReady();
            _perTransactionCharge.SetText(DataObject.PerTransactionCharge, "Per Transaction Charge");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClicKSave();
        }

        public void VerifyProductLocation(ProductSetUpLocation DataObject)
        {
            _extendedPage.SwitchToContentFrame();
            CommonUtil.AssertTrue(DataObject.Location, _location.GetAttribute("ovalue"));
            CommonUtil.AssertTrue(DataObject.ProductNo, _productNo.GetAttribute("ovalue"));
            CommonUtil.AssertTrue(DataObject.TankNo, _tankNo.GetAttribute("ovalue"));
            _detailedInformationTab.ClickElement("_detailedInformationTab",Driver);
            CommonUtil.VerifyCheckboxState(methodTrackingStock(DataObject.MethodOfTrackingStock),"Method Tracking",true);
            CommonUtil.VerifyCheckboxState(issueQuantityCalculation(DataObject.IssueQuantityCalculation), "Issue Quantity Calculation", true);
            CommonUtil.AssertTrue(DataObject.MaximumQuantity, _maxQuantity.GetAttribute("ovalue"));
            CommonUtil.AssertTrue(DataObject.MinimumQuantity, _minimumQuantity.GetAttribute("ovalue"));
            _stockStatusTab.ClickElement("_stockStatusTab",Driver);
            CommonUtil.AssertTrue(DataObject.PerTransactionCharge,_perTransactionCharge.GetAttribute("ovalue"));
            Driver.SwitchTo().DefaultContent();
        }
    }
}
