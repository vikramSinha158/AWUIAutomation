﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct
{
    internal class ProductSetupUnitPageAction : ProductSetupUnitPage
    {
        public ProductSetupUnitPageAction(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create ProductSetup nit
        /// </summary>
        /// <param name="ProductSetupUnit"></param>
        public void CreateOrUpdateProductSetupUnit(ProductSetupUnit ProductSetupUnit)
        {
            Settings.Logger.Info(" Create ProductSetup Unit ");
            _extendpage.ClickOnRefreshButton();
            Driver.WaitForReady();
            _extendpage.SwitchToContentFrame();
            _assignUnitID.SetText(ProductSetupUnit.Unit, "Unit");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow("No");
            _extendpage.SwitchToContentFrame();
            _extendpage.SetCheckBox(_enforceValidMeter, "EnforceValidMeter", ProductSetupUnit.EnforceValidMeter);
            Driver.WaitForReady();
            _meterCount.SetText(ProductSetupUnit.MeterCount, "MeterCount");
            Driver.WaitForReady();
            _extendpage.SetCheckBox(_resShift, "EnforceValidMeter", ProductSetupUnit.ResShift);
            Driver.WaitForReady();
            _meter2Count.SetText(ProductSetupUnit.Meter2Count, "MeterCount");
            Driver.WaitForReady();
            _extendpage.SetCheckBox(_employeeRequired, "EmployeeRequired", ProductSetupUnit.EmployeeRequired);
            Driver.WaitForReady();
            _extendpage.SetCheckBox(_validateEmployee, "ValidateEmployee", ProductSetupUnit.ValidateEmployee);
            if (ProductSetupUnit.Products != null)
            {
                if (ProductSetupUnit.Products.Manual)
                {
                    FillProductInformationforUnit(ProductSetupUnit.Products);
                }
            }
            if (ProductSetupUnit.Cards != null)
            {
                FillCards(ProductSetupUnit.Cards);
            }
            _extendpage.Save();
        }

        /// <summary>
        /// Fill Product formation for Unit
        /// </summary>
        /// <param name="Products"></param>
        public void FillProductInformationforUnit(Products Products)
        {
            Settings.Logger.Info(" Fill Product formation for Unit ");
            string colHeader = "Prod\r\nNo";
            _extendpage.GetTabLinkByText("Products").ClickElement("ProductsTab",Driver);
            Driver.SwitchToFrame(_prodInfoFrame, "prodInfoFrame");
            foreach (ProductsTable ProductsTable in Products.ProductsTable)
            {
                if(!ProductsTable.EditProductsTable) _extendpage.GetTableActionElementByRelatedColumnValue(_productTable, colHeader, "", "product_no").SetText(ProductsTable.productNo, "productNo");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_productTable, colHeader, ProductsTable.productNo, "tank_capacity").SetText(ProductsTable.TankCapacity, "TankCapacity");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_productTable, colHeader, ProductsTable.productNo, "max_daily_fuelings").SetText(ProductsTable.MaxDailyFuelings, "MaxDailyFuelings");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_productTable, colHeader, ProductsTable.productNo, "max_daily_qty").SetText(ProductsTable.MaxDailyQuantity, "MaxDailyQuantity");
                Driver.WaitForReady();
            }

        }

        /// <summary>
        /// Fill Cards
        /// </summary>
        /// <param name="Cards"></param>
        public void FillCards(Cards Cards)
        {
            Settings.Logger.Info(" Fill Cards ");
            string colHeader = "Card No";
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _extendpage.GetTabLinkByText("Cards").ClickElement("CardsTab", Driver);
            Driver.SwitchToFrame(_cardFrame, "cardFrame");
            foreach (CardsTable CardsTable in Cards.CardsTable)
            {
                if (!CardsTable.EditCardsTable) _extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, "", "CardNo").SetText(CardsTable.CardNo, "CardNo");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "EffDate").SetText(CardsTable.EffDate, "EffDate");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "EndDate").SetText(CardsTable.EndDate, "EndDate");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "VendorNo").SetText(CardsTable.VendorNo, "VendorNo");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "PromptID").SetText(CardsTable.PromptID, "PromptID");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "Pin").SetText(CardsTable.Pin, "Pin");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "MsgText").SetText(CardsTable.MsgText, "MsgText");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "DeviceSrNo").SetText(CardsTable.DeviceSrNo, "DeviceSrNo");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "Card_Disabled").SelectFilterValueHavingEqualValue(CardsTable.Card_Disabled);
                Driver.WaitForReady();
                _extendpage.AddNotes(_extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "Notes"), CardsTable.Notes);

            }
        }

        /// <summary>
        /// Chaeck And Delete Product SetUp table
        /// </summary>
        /// <param name="UnitNo"></param>
        public void ChaeckAndDeleteProductSetUptable(ProductSetupUnit ProductSetupUnit)
        {
            Settings.Logger.Info(" Chaeck And Delete Product SetUp table ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _assignUnitID.SetText(ProductSetupUnit.Unit, "Unit");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow("No");
            _extendpage.SwitchToContentFrame();
            if (ProductSetupUnit.Products != null)
            {
                _extendpage.GetTabLinkByText("Products").ClickElement("ProductsTab", Driver);
                Driver.SwitchToFrame(_prodInfoFrame, "prodInfoFrame");
                _extendpage.DeleteTableRowsUsingColumnName(_productTable, "Prod\r\nNo", "product_no");
                Driver.SwitchTo().DefaultContent();
                _extendpage.SwitchToContentFrame();
            }
            if (ProductSetupUnit.Cards != null)
            {
                _extendpage.GetTabLinkByText("Cards").ClickElement("CardsTab", Driver);
                Driver.SwitchToFrame(_cardFrame, "cardFrame");
                _extendpage.DeleteTableRowsUsingColumnName(_cardTable, "Card No", "CardNo");            
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Product Setup Unit
        /// </summary>
        /// <param name="ProductSetupUnit"></param>
        public void VerifyProductSetupUnit(ProductSetupUnit ProductSetupUnit)
        {
            Settings.Logger.Info(" Verify Product Setup Unit ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            _assignUnitID.SetText(ProductSetupUnit.Unit, "Unit");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_assignUnitID, "Unit", ProductSetupUnit.Unit);
            CommonUtil.VerifyCheckboxState(_enforceValidMeter, "EnforceValidMeter", ProductSetupUnit.EnforceValidMeter);
            CommonUtil.VerifyElementValue(_meterCount, "MeterCount", ProductSetupUnit.MeterCount);
            CommonUtil.VerifyCheckboxState(_resShift, "EnforceValidMeter", ProductSetupUnit.ResShift);
            CommonUtil.VerifyElementValue(_meter2Count, "Meter2Count", ProductSetupUnit.Meter2Count);
            CommonUtil.VerifyCheckboxState(_employeeRequired, "EmployeeRequired", ProductSetupUnit.EmployeeRequired);
            CommonUtil.VerifyCheckboxState(_validateEmployee, "ValidateEmployee", ProductSetupUnit.ValidateEmployee);
            if (ProductSetupUnit.Products != null)
            {
                if (ProductSetupUnit.Products.Manual)
                {
                    VerifyProductInformationforUnit(ProductSetupUnit.Products);
                }
            }
            if (ProductSetupUnit.Cards != null)
            {
                VerifyCards(ProductSetupUnit.Cards);
            }
        }

        /// <summary>
        /// Verify Product Information for Unit
        /// </summary>
        /// <param name="Products"></param>
        public void VerifyProductInformationforUnit(Products Products)
        {
            Settings.Logger.Info(" Verify Product Information for Unit ");
            string colHeader = "Prod\r\nNo";
            _extendpage.GetTabLinkByText("Products").ClickElement("ProductsTab", Driver);
            Driver.SwitchToFrame(_prodInfoFrame, "prodInfoFrame");
            foreach (ProductsTable ProductsTable in Products.ProductsTable)
            {
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_productTable, colHeader, ProductsTable.productNo, "product_no"), "productNo", ProductsTable.productNo,false,"value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_productTable, colHeader, ProductsTable.productNo, "tank_capacity"), "TankCapacity",ProductsTable.TankCapacity, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_productTable, colHeader, ProductsTable.productNo, "max_daily_fuelings"), "MaxDailyFuelings",ProductsTable.MaxDailyFuelings, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_productTable, colHeader, ProductsTable.productNo, "max_daily_qty"), "MaxDailyQuantity",ProductsTable.MaxDailyQuantity, false, "value");
            }
        }

        /// <summary>
        /// Verify Cards
        /// </summary>
        /// <param name="Cards"></param>
        public void VerifyCards(Cards Cards)
        {
            Settings.Logger.Info("  Verify Cards ");
            string colHeader = "Card No";
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _extendpage.GetTabLinkByText("Cards").ClickElement("CardsTab", Driver);
            Driver.SwitchToFrame(_cardFrame, "cardFrame");
            foreach (CardsTable CardsTable in Cards.CardsTable)
            {
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "CardNo"), "CardNo",CardsTable.CardNo, false, "value");
                _extendpage.VerifySystemDateContainAppdate(_extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "EffDate"), "EffDate", 0,"value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "VendorNo"), "VendorNo", CardsTable.VendorNo, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "PromptID"), "PromptID", CardsTable.PromptID, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "Pin"), "Pin",CardsTable.Pin, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "MsgText"), "MsgText",CardsTable.MsgText, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "DeviceSrNo"), "DeviceSrNo",CardsTable.DeviceSrNo, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "Card_Disabled"), "Card_Disabled", CardsTable.Card_Disabled,true, "value");
                _extendpage.VerifyAddedNotes(_extendpage.GetTableActionElementByRelatedColumnValue(_cardTable, colHeader, CardsTable.CardNo, "Notes"), CardsTable.Notes);

            }
        }

        /// <summary>
        /// Verify Delete Product SetUp table
        /// </summary>
        /// <param name="ProductSetupUnit"></param>
        public void VerifyDeleteProductSetUptable(ProductSetupUnit ProductSetupUnit)
        {
            Settings.Logger.Info(" Verify Product SetUp table deletion ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _assignUnitID.SetText(ProductSetupUnit.Unit, "Unit");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow("No");
            _extendpage.SwitchToContentFrame();
            if (ProductSetupUnit.Products != null)
            {
                _extendpage.GetTabLinkByText("Products").ClickElement("ProductsTab", Driver);
                _extendpage.VerifyTableRowDeletion(_prodInfoFrame, _productTableRows, "prodInfoFrame");
                Driver.SwitchTo().DefaultContent();
                _extendpage.SwitchToContentFrame();
            }
            if (ProductSetupUnit.Cards != null)
            {
                _extendpage.GetTabLinkByText("Cards").ClickElement("CardsTab", Driver);
                Driver.SwitchToFrame(_cardFrame, "cardFrame");
                _extendpage.VerifyTableRowDeletion(_cardFrame, _cardTableTableRows, "cardFrame");
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
