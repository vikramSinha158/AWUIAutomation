﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.PagesObject.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct
{
    internal class ProductSetupEmployee : ProductSetupEmployeePage
    {
        public ProductSetupEmployee(IWebDriver Driver) : base(Driver) { }
        /// <summary>
        /// Create Product Employee SetUp
        /// </summary>
        /// <param name=""></param>
        public void CreateProductEmployee(SetUpEmployeeDetails productSetUpEmployees)
        {
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForSomeTime();
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForSomeTime(20);
            if (productSetUpEmployees.PINManagement!=null)
                FillPINManagement(productSetUpEmployees.PINManagement);
            if (productSetUpEmployees.PINManagement != null)
                EnterProductInformation(productSetUpEmployees.ProductInformation);
            if (productSetUpEmployees.CardsInformation != null)
                EnterCardInformation(productSetUpEmployees.CardsInformation);
            Driver.SwitchTo().DefaultContent();
        }
        public void CleanUpData(ProductSetUpEmployees productSetUpEmployees)
        {
            _extendedPage.SwitchToContentFrame();
            _employeeIdInput.SetText(productSetUpEmployees.EmployeeId, "_employeeIdInput");
            ResetPinManagement();
            DeleteProductInformation();
            DeleteCardInformation();
        }
        /// <summary>
        /// Update Product Employee SetUp
        /// </summary>
        /// <param name=""></param>
        public void UpdateProductEmployee(ProductSetUpEmployees productSetUpEmployees)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_employeeIdInput, productSetUpEmployees.EmployeeId, "_employeeIdInput");
            Driver.WaitForSomeTime();
            if (productSetUpEmployees.SetUpEmployeeDetails.PINManagement!=null)
             FillPINManagement(productSetUpEmployees.SetUpEmployeeDetails.PINManagement);
            DeleteProductInformation();
            _extendedPage.SwitchToContentFrame();
            if (productSetUpEmployees.SetUpEmployeeDetails.ProductInformation != null)
                EnterProductInformation(productSetUpEmployees.SetUpEmployeeDetails.ProductInformation);
            DeleteCardInformation();
            if (productSetUpEmployees.SetUpEmployeeDetails.CardsInformation != null)
                EnterCardInformation(productSetUpEmployees.SetUpEmployeeDetails.CardsInformation);
            Driver.SwitchTo().DefaultContent();
        }
        /// <summary>
        /// Verify Employee Setup
        /// </summary>
        /// <param name=""></param>
        public void VerifyEmployeeSetUp(ProductSetUpEmployees productSetUpEmployees)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_employeeIdInput, productSetUpEmployees.EmployeeId, "_employeeIdInput");
            VerifyPINManagement(productSetUpEmployees.SetUpEmployeeDetails.PINManagement);
            VerifyProductInformation(productSetUpEmployees.SetUpEmployeeDetails.ProductInformation);
            VerifyCardInformation(productSetUpEmployees.SetUpEmployeeDetails.CardsInformation);
        }

        /// <summary>
        /// Fill PIN Management
        /// </summary>
        /// <param name="pinManagement"></param>
        public void FillPINManagement(PINManagement pinManagement)
        {
             Driver.ScrollIntoViewAndClick(PinManagementTab, "PinManagementTab");
            _extendedPage.SetCheckBox(_pinRequiredInput, "_pinRequiredInput", pinManagement.PINRequired);
            _extendedPage.SetCheckBox(_icuRequiredInput, "_icuRequiredInput", pinManagement.ICUSupervisor);
            _extendedPage.SetCheckBox(_unitNumberRequired, "_unitNumberRequired", pinManagement.UnitNumberRequired);
            _extendedPage.SetCheckBox(_restrictedToShiftRequired, "_restrictedToShiftRequired", pinManagement.RestrictedToShift);
        }

        /// <summary>
        /// Verify PIN Management
        /// </summary>
        /// <param name="pinManagement"></param>
        public void VerifyPINManagement(PINManagement pinManagement)
        {
            Driver.WaitForReady();
            CommonUtil.VerifyCheckboxState(_pinRequiredInput, "_pinRequiredInput", pinManagement.PINRequired);
            CommonUtil.VerifyCheckboxState(_icuRequiredInput, "_icuRequiredInput", pinManagement.ICUSupervisor);
            CommonUtil.VerifyCheckboxState(_unitNumberRequired, "_unitNumberRequired", pinManagement.UnitNumberRequired);
            CommonUtil.VerifyCheckboxState(_restrictedToShiftRequired, "_restrictedToShiftRequired", pinManagement.RestrictedToShift);

        }

        /// <summary>
        /// Enter Product Information
        /// </summary>
        /// <param name="productInformation"></param>
        public void EnterProductInformation(List<ProductInformation> productInformation)
        {
            Driver.ScrollIntoViewAndClick(_productInformation, "_productionInformation");
            foreach (ProductInformation information in productInformation)
            {
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_productInformationFrame, "_productionInformationFrame");
                _productNumber.SetText(information.Product, "ProductInformation");
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClicKSave();
            }
        }
        public void VerifyProductInformation(List<ProductInformation> productInformation)
        {
            Driver.WaitForReady();
            Driver.ScrollIntoViewAndClick(_productInformation, "_productionInformation");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_productInformationFrame, "_productionInformationFrame");
            foreach (ProductInformation information in productInformation)
            {
               CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
               _productTable, "Product", information.Product, "description"), "Product", information.Description,false,"value");
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Enter Card Information
        /// </summary>
        /// <param name="cardInformation"></param>
        public void EnterCardInformation(List<CardsInformation> cardInformation)
        {
            _extendedPage.SwitchToContentFrame();
            _cardInformation.ClickElement("Card Information",Driver);
            foreach (CardsInformation information in cardInformation)
            {
                Driver.SwitchToFrame(_cardFrame, "_cardFrame");
                _cardNo.SetText(information.CardNo, "Card Number");
                Driver.WaitForReady();
                _effectiveDate.SetText(CommonUtil.GenerateRandomDateString(Convert.ToInt16(information.EffectiveDate)), "Effective Date");
                Driver.WaitForReady();
                _expirationDate.SetText(CommonUtil.GenerateRandomDateString(Convert.ToInt16(information.ExpirationDate)), "Expiration Date");
                Driver.WaitForReady();
                _vendorNo.SetText(information.VendorNo, "_vendorNo");
                Driver.WaitForReady();
                _promptId.SetText(information.PromptId, "_promptId");
                Driver.WaitForReady();
                _pinId.SetText(information.Pin,"Pin");
                Driver.WaitForReady();
                _messageText.SetText(information.MessageText, "_messageText");
                Driver.WaitForReady();
                _deviceSerial.SetText(information.DeviceSerialNumber, "_deviceSerial");
                Driver.WaitForReady();
                _cardDisable.ClickDropDownValuebyContainingText(information.DisableCard);
                _cardNotes.ClickElement("_cardNotes",Driver);
                Driver.SwitchTo().DefaultContent();
                _cardMaintenanceNotes.SetText(information.CardNotes,"Card Notes");
                _cardMaintenanceOkButton.ClickElement("_cardMaintenanceOkButton", Driver);
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_cardFrame, "_cardFrame");
                _userData1.SetText(information.UserData1, "_userData1");
                _userData2.SetText(information.UserData2, "_userData2");
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClicKSave();
                _extendedPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Verify Card Information
        /// </summary>
        /// <param name="cardInformation"></param>
        public void VerifyCardInformation(List<CardsInformation> cardInformation)
        {
            _extendedPage.SwitchToContentFrame();
            _cardInformation.ClickElement("Card Information", Driver);
            Driver.SwitchToFrame(_cardFrame, "_cardFrame");
            foreach (CardsInformation information in cardInformation)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _cardTable, "Card No", information.CardNo, "VendorNo"), "Card No", information.VendorNo,false,"value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _cardTable, "Card No", information.CardNo, "PromptID"), "Card No", information.PromptId, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _cardTable, "Card No", information.CardNo, "Pin"), "Card No", information.Pin, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _cardTable, "Card No", information.CardNo, "MsgText"), "Card No", information.MessageText, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _cardTable, "Card No", information.CardNo, "DeviceSrNo"), "Card No", information.DeviceSerialNumber, false, "value");
                _cardNote.ClickElement("_cardNotes", Driver);
                Driver.SwitchTo().DefaultContent();
                CommonUtil.AssertTrue(information.CardNotes, _cardMaintenanceNotes.GetText("_cardNotes"));
                _cardMaintenanceOkButton.ClickElement("_cardMaintenanceOkButton", Driver);
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_cardFrame, "_cardFrame");
                Driver.WaitForReady();
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
              _cardTable, "Card No", information.CardNo, "Card_Disabled"), "Card No", information.DisableCard,true);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _cardTable, "Card No", information.CardNo, "userData1"), "Card No", information.UserData1, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _cardTable, "Card No", information.CardNo, "userData2"), "Card No", information.UserData2, false, "value");
            }
        }

        /// <summary>
        /// Reset PinManagement
        /// </summary>
        public void ResetPinManagement()
        {
             if (_pinRequiredInput.Selected == true)
                    _pinRequiredInput.ClickElement("_pinRequiredInput", Driver);
             if (_icuRequiredInput.Selected == true)
                    _icuRequiredInput.ClickElement("_icuRequiredInput", Driver);
             if (_unitNumberRequired.Selected == true)
                   _unitNumberRequired.ClickElement("_unitNumberRequired", Driver);
             if (_restrictedToShiftRequired.Selected == true)
                    _restrictedToShiftRequired.ClickElement("_unitNumberRequired", Driver);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.Save();
        }

        /// <summary>
        /// Delete Product Information
        /// </summary>
        public void DeleteProductInformation()
        {
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            Driver.ScrollIntoViewAndClick(_productInformation, "_productInformation");
            Driver.SwitchToFrame(_productInformationFrame, "_productInformationFrame");
            foreach (IWebElement element in _products)
            {
                Driver.ScrollIntoViewAndClick(_product, "_productNumber");
                element.ClickElement("product Number", Driver);
                Driver.SwitchTo().DefaultContent();
                _extendedPage.DeleteAndSave();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_productInformationFrame, "_productInformationFrame");
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Card Information
        /// </summary>
        public void DeleteCardInformation()
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            _cardInformation.ClickElement("_cardInformation", Driver);
            Driver.SwitchToFrame(_cardFrame,"Card Frame");
            foreach (IWebElement element in _cardNumbers)
            {
                Driver.ScrollIntoViewAndClick(_cardNumber, "_cardNumber");
                Driver.ScrollIntoViewAndClick(element,"CardNo");
                element.ClickElement("CardNumber",Driver);
                Driver.SwitchTo().DefaultContent();
                _extendedPage.DeleteAndSave();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
                _cardFrame.ClickElement("_cardFrame", Driver);
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Check Product Set Up In Employee
        /// </summary>
        /// <param name="productSetUpEmployees"></param>
        public void CheckAndAddProductSetUpInEmployee(SetUpEmployeeDetails productSetUpEmployees)
        {
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            _employeeIdInput.SetText(productSetUpEmployees.EmployeeId, "_employeeIdInput");
            Driver.WaitForSomeTime();
            Driver.ScrollIntoViewAndClick(_productInformation, "_productionInformation");
            if (productSetUpEmployees.ProductInformation != null)
                foreach (ProductInformation information in productSetUpEmployees.ProductInformation)
                {
                    Driver.SwitchToFrame(_productInformationFrame, "_productionInformationFrame");
                    if (!_extendedPage.CheckTableColumnContainValue(_productTable, "Product", information.Product))
                    {
                        _productNumber.SetText(information.Product, "ProductInformation");
                        _extendedPage.Save();
                    }                   
                }
            Driver.SwitchTo().DefaultContent();
        }
    }
}