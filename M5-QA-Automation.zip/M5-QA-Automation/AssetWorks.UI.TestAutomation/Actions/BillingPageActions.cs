﻿using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class BillingPageActions : BillingPage
    {
        public BillingPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Billing Code
        /// </summary>
        /// <param name="BillingType"></param>
        /// <returns> BillingCode </returns>
        public string CreateBillingCode(AddBillingInformation DataObject)
        {
            string BillingCode = string.Empty;
            if (!_extendpage.CheckDataExistenceAndGetActionCode(DataObject.BillingCode, ref BillingCode, "BillingQuery"))
            {
                _extendpage.SwitchToContentFrame();
                _billingCodeInput.SetText(BillingCode, " Billing Code ");
                Driver.SwitchTo().DefaultContent();
                _extendpage.ActionRequiredWindow("Create");
                _extendpage.SwitchToContentFrame();
                _billingDescInput.SetText(DataObject.Description, " billingDescInput ");
                Driver.WaitForReady();
                _effectiveDate.SetText(DataObject.BillingEffectiveDate, " Effective Date ");
                BillingObjects.EffectiveDate = _effectiveDate.GetElementValueByAttribute("ovalue");
                Driver.WaitForReady();
                _billingType.SelectFilterValueHavingEqualValue(DataObject.BillingType);      
                if (DataObject.DetailsInformationTab != null)
                {
                    FillDetailsInformationTab(DataObject.DetailsInformationTab);
                }
                if (DataObject.BillingMotorPoolTab != null)
                {
                    FillMotorPoolTab(DataObject.BillingMotorPoolTab);
                }
                if (DataObject.FixedTab != null)
                {
                    FillFixedTab(DataObject.FixedTab);
                }
                _extendpage.SaveWithRequiredAction("Continue");
                Settings.Logger.Info(" Creating Billing Code   ");
            } 
            return BillingCode;
        }

        /// <summary>
        /// Verify Billig Code Info
        /// </summary>
        public void VerifyBillingCodeInfo(AddBillingInformation DataObject,string BillingCode)
        {
            _extendpage.RefreshAndSetText(_billingCodeInput, BillingCode, " Billing Code");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_billingCodeInput, "BillingCode", BillingCode);
            CommonUtil.VerifyElementValue(_billingDescInput, "Description", DataObject.Description);
            CommonUtil.VerifyElementValue(_effectiveDate, "EffectiveDate", BillingObjects.EffectiveDate);
            CommonUtil.VerifyElementValue(_billingType, "BillingType", DataObject.BillingType,true);
            if (DataObject.DetailsInformationTab != null)
            {
                VerifyDetailsInformationTab(DataObject.DetailsInformationTab);
            }
            if (DataObject.BillingMotorPoolTab != null)
            {
                VerifyMotorPoolTab(DataObject.BillingMotorPoolTab);
            }
            if (DataObject.FixedTab != null)
            {
                VerifyFixedTab(DataObject.FixedTab);
            }
            Settings.Logger.Info(" Successfully Verified Billing ");
        }

        /// <summary>
        /// Verify Billing Code Deletion
        /// </summary>
        public void VerifyBillingCodeDeletion(string BillingCode)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.VerifyCodeDeletion(_billingCodeInput, BillingCode, "Billing Code");
        }

        /// <summary>
        /// Fill Details InformationTab
        /// </summary>
        /// <param name="DetailsInformationTab"></param>
        public void FillDetailsInformationTab(DetailsInformationTab DetailsInformationTab)
        {
            _billingDetailTab.ClickElement("BillingDetailTab", Driver);
            Driver.WaitForReady();
            _extendpage.SelectAllAndClearField(_leaseRateInput);
            _leaseRateInput.SetText(DetailsInformationTab.LeaseRate, "LeaseRate");
            Driver.WaitForReady();
             if(DetailsInformationTab.LeaseRatePer!=null) _leaseRatePer.SelectDropdownUsingValue("SelectDropdownUsingValue",DetailsInformationTab.LeaseRatePer.ToUpper());
            Driver.WaitForReady();         
            _extendpage.SetCheckBox(_taxableFl, "taxableFl",DetailsInformationTab.TaxableFl);
            Driver.WaitForReady();
            _extendpage.SetTextWithLovOption(_taxScheme, DetailsInformationTab.TaxScheme, DetailsInformationTab.TaxSchemeLOV);
            Driver.WaitForReady();
            _extendpage.SetTextWithLovOption(_shift, DetailsInformationTab.Shift, DetailsInformationTab.ShiftLOv);
            Driver.WaitForReady();
            _extendpage.SetTextWithLovOption(_season, DetailsInformationTab.Season, DetailsInformationTab.SeasonLOV);
            Driver.WaitForReady();
            _fixedBids.ClickDropDownValuebyContainingText(DetailsInformationTab.FixedBids);
            Driver.WaitForReady();
            _extendpage.SetTextWithLovOption(_billItem, DetailsInformationTab.BillItem, DetailsInformationTab.BillItemLOV);
            Driver.WaitForReady();
            _laborBilling.ClickDropDownValuebyContainingText(DetailsInformationTab.LaborBilling);
            Driver.WaitForReady();
            _partBilling.ClickDropDownValuebyContainingText(DetailsInformationTab.PartBilling);
            Driver.WaitForReady();
            _commBilling.ClickDropDownValuebyContainingText(DetailsInformationTab.CommBilling);
            Driver.WaitForReady();
            _flatPerPeriod.SetText(DetailsInformationTab.FlatPerPeriod, "FlatPerPeriod");
            Driver.WaitForReady();
            _chargePerUsage.SetText(DetailsInformationTab.ChargePerUsage, "ChargePerUsage");
            Driver.WaitForReady();
            _howToCharge.ClickDropDownValuebyContainingText(DetailsInformationTab.HowToCharge);
            Driver.WaitForReady();
            _recordingMethod.ClickDropDownValuebyContainingText(DetailsInformationTab.RecordingMethod);
            Driver.WaitForReady();
            _iFuelProducts.ClickDropDownValuebyContainingText(DetailsInformationTab.IFuelProducts);
            Driver.WaitForReady();
            _oFuelProducts.ClickDropDownValuebyContainingText(DetailsInformationTab.OFuelProducts);
            Driver.WaitForReady();
            _chargePerGal.SetText(DetailsInformationTab.ChargePerGal, "chargePerGal");
            Settings.Logger.Info(" Added Billing Code Details Information Tab  ");
        }

        /// <summary>
        /// Verify Details Information Tab
        /// </summary>
        /// <param name="DetailsInformationTab"></param>
        public void VerifyDetailsInformationTab(DetailsInformationTab DetailsInformationTab)
        {
            _billingDetailTab.ClickElement("BillingDetailTab", Driver);
            CommonUtil.VerifyElementValue(_leaseRateInput, "LeaseRate", DetailsInformationTab.LeaseRate);
            CommonUtil.VerifyElementValue(_leaseRatePer, "leaseRatePer", DetailsInformationTab.LeaseRatePer,true);
            CommonUtil.VerifyCheckboxState(_taxableFl, "taxableFl", DetailsInformationTab.TaxableFl);
            CommonUtil.VerifyElementValue(_taxScheme, "TaxScheme", DetailsInformationTab.TaxScheme);
            CommonUtil.VerifyElementValue(_shift, "shift", DetailsInformationTab.Shift);
            CommonUtil.VerifyElementValue(_season, "season", DetailsInformationTab.Season);
            CommonUtil.VerifyElementValue(_fixedBids, "fixedBids",DetailsInformationTab.FixedBids, true);
            CommonUtil.VerifyElementValue(_billItem, "_billItem", DetailsInformationTab.BillItem);
            CommonUtil.VerifyElementValue(_laborBilling, "LaborBilling", DetailsInformationTab.LaborBilling, true);
            CommonUtil.VerifyElementValue(_partBilling, "PartBilling", DetailsInformationTab.PartBilling, true);
            CommonUtil.VerifyElementValue(_commBilling, "CommBilling", DetailsInformationTab.CommBilling, true); 
            CommonUtil.VerifyElementValue(_flatPerPeriod, "FlatPerPeriod", DetailsInformationTab.FlatPerPeriod);
            CommonUtil.VerifyElementValue(_chargePerUsage, "ChargePerUsage", DetailsInformationTab.ChargePerUsage);
            CommonUtil.VerifyElementValue(_howToCharge, "PartBilling", DetailsInformationTab.HowToCharge, true);
            CommonUtil.VerifyElementValue(_recordingMethod, "RecordingMethod", DetailsInformationTab.RecordingMethod, true);
            CommonUtil.VerifyElementValue(_iFuelProducts, "IFuelProducts", DetailsInformationTab.IFuelProducts, true);
            CommonUtil.VerifyElementValue(_oFuelProducts, "OFuelProducts", DetailsInformationTab.OFuelProducts, true);
            CommonUtil.VerifyElementValue(_chargePerGal, "ChargePerGal", DetailsInformationTab.ChargePerGal);
            Settings.Logger.Info(" Successfully Verified DetailsInformationTab ");
        }

        /// <summary>
        /// Fill MotorPool Tab
        /// </summary>
        /// <param name="MotorPoolTab"></param>
        public void FillMotorPoolTab(BillingMotorPoolTab MotorPoolTab)
        {
            _motorPoolTab.ClickElement("BillingDetailTab", Driver);
            Driver.WaitForReady();
            _fuelCharge.SetText(MotorPoolTab.FuelCharge, "FuelCharge");
            Driver.WaitForReady();
            _extendpage.SetTextWithLovOption(_timeType, MotorPoolTab.TimeType, MotorPoolTab.TimeTypeLOV);
            Driver.WaitForReady();
            _empTime.SetText(MotorPoolTab.EmpTime, "EmpTime");
            Driver.WaitForReady();
            _overtime.SetText(MotorPoolTab.Overtime, "Overtime");
            Driver.WaitForReady();
            _doubletime.SetText(MotorPoolTab.Doubletime, "Doubletime");
            Driver.WaitForReady();  
            if (MotorPoolTab.BillingMethod != null) _billingMethod.ClickDropDownValuebyContainingText(MotorPoolTab.BillingMethod.ToUpper());
            Driver.WaitForReady();
            _extendpage.SetCheckBox(_billWeekends, "BillWeekends", MotorPoolTab.BillWeekends);
            Driver.WaitForReady();
            _extendpage.SetCheckBox(_billHolidays, "BillHolidays", MotorPoolTab.BillHolidays);
            Driver.WaitForReady();
            _hourlyRate.SetText(MotorPoolTab.HourlyRate, "HourlyRate");
            Driver.WaitForReady();
            _hourlyUsage.SetText(MotorPoolTab.HourlyUsage, "HourlyUsage");
            Driver.WaitForReady();
            _dailyRate.SetText(MotorPoolTab.DailyRate, "DailyRate");
            Driver.WaitForReady();
            _dailyUsage.SetText(MotorPoolTab.DailyUsage, "DailyUsage");
            Driver.WaitForReady();
            _weeklyRate.SetText(MotorPoolTab.WeeklyRate, "WeeklyRate");
            Driver.WaitForReady();
            _weeklyUsage.SetText(MotorPoolTab.WeeklyUsage, "WeeklyUsage");
            Driver.WaitForReady();
            _monthlyRate.SetText(MotorPoolTab.MonthlyRate, "MonthlyRate");
            Driver.WaitForReady();
            _monthlyUsage.SetText(MotorPoolTab.MonthlyUsage, "MonthlyUsage");
            Settings.Logger.Info(" Added Billing Code Motor Pool Tab ");
        }

        /// <summary>
        /// Verify MotorPool Tab
        /// </summary>
        /// <param name="MotorPoolTab"></param>
        public void VerifyMotorPoolTab(BillingMotorPoolTab MotorPoolTab)
        {
            _motorPoolTab.ClickElement("BillingDetailTab", Driver);
            CommonUtil.VerifyElementValue(_fuelCharge, "FuelCharge", MotorPoolTab.FuelCharge);
            CommonUtil.VerifyElementValue(_timeType, "TimeType", MotorPoolTab.TimeType);
            CommonUtil.VerifyElementValue(_empTime, "EmpTime", MotorPoolTab.EmpTime);
            CommonUtil.VerifyElementValue(_overtime, "Overtime", MotorPoolTab.Overtime);
            CommonUtil.VerifyElementValue(_doubletime, "Doubletime", MotorPoolTab.Doubletime);
            CommonUtil.VerifyElementValue(_billingMethod, "BillingMethod", MotorPoolTab.BillingMethod,true);
            CommonUtil.VerifyCheckboxState(_billWeekends, "BillWeekends", MotorPoolTab.BillWeekends);
            CommonUtil.VerifyCheckboxState(_billHolidays, "BillHolidays", MotorPoolTab.BillHolidays);
            CommonUtil.VerifyElementValue(_hourlyRate, "HourlyRate", MotorPoolTab.HourlyRate);
            CommonUtil.VerifyElementValue(_hourlyUsage, "HourlyUsage", MotorPoolTab.HourlyUsage);
            CommonUtil.VerifyElementValue(_dailyRate, "DailyRate", MotorPoolTab.DailyRate);
            CommonUtil.VerifyElementValue(_dailyUsage, "DailyUsage", MotorPoolTab.DailyUsage);
            CommonUtil.VerifyElementValue(_weeklyRate, "WeeklyRate", MotorPoolTab.WeeklyRate);
            CommonUtil.VerifyElementValue(_weeklyUsage, "WeeklyUsage", MotorPoolTab.WeeklyUsage);
            CommonUtil.VerifyElementValue(_monthlyRate, "MonthlyRate", MotorPoolTab.MonthlyRate);
            CommonUtil.VerifyElementValue(_monthlyUsage, "MonthlyUsage", MotorPoolTab.MonthlyUsage);
            Settings.Logger.Info(" Successfully Verified MotorPoolTab ");
        }

        /// <summary>
        /// Fill Fixed Tab
        /// </summary>
        /// <param name="FixedTab"></param>
        public void FillFixedTab(FixedTab FixedTab)
        {
            _extendpage.SaveWithRequiredAction("Continue");
            _extendpage.SwitchToContentFrameAndTabClick(_fixedlTab);
            if (FixedTab.FillFixedTableTab)
            {
                _extendpage.AddRecordsInTable(_fixedTable, _fixedFrame, FixedTab.BillingCodeFixedTableTableKey);
 
            }
        }

        /// <summary>
        /// Verify Fixed Tab
        /// </summary>
        /// <param name="FixedTab"></param>
        public void VerifyFixedTab(FixedTab FixedTab)
        {
            _extendpage.SwitchToContentFrameAndTabClick(_fixedlTab);
            _extendpage.VerifyRecordsInTable(_fixedTable, _fixedFrame, FixedTab.BillingCodeFixedTableTableKey);         
            Settings.Logger.Info(" Successfully Verified Fixed Tab");
        }

        /// <summary>
        /// Update Billing Code
        /// </summary>
        /// <param name="DataObject"></param>
        /// <param name="BillingCode"></param>
        public void UpdateBillingCode(AddBillingInformation DataObject,string BillingCode)
        {
                Driver.SwitchTo().DefaultContent();
                _extendpage.RefreshAndSetText(_billingCodeInput, BillingCode, " BillingCode ");
                Driver.WaitForReady();
                _billingDescInput.SetText(DataObject.Description, " billingDescInput ");
                Driver.WaitForReady();
                _newEffDate.SetText(DataObject.NewBillingEffectiveDate, " NewBillingEffectiveDate ");
                BillingObjects.EffectiveDate = _newEffDate.GetElementValueByAttribute("ovalue");
                Driver.WaitForReady();
                _billingType.SelectFilterValueHavingEqualValue(DataObject.BillingType);
                if (DataObject.DetailsInformationTab != null)
                {
                    FillDetailsInformationTab(DataObject.DetailsInformationTab);
                }
                if (DataObject.BillingMotorPoolTab != null)
                {
                    FillMotorPoolTab(DataObject.BillingMotorPoolTab);
                }
                if (DataObject.FixedTab != null)
                {
                    FillFixedTab(DataObject.FixedTab);
                }
                _extendpage.SaveWithRequiredAction("Continue");
                Settings.Logger.Info(" Updated Billing Code   ");
        }

        /// <summary>
        /// Verify Associated Billing CodeNot Deleted
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyAssociatedBillingCodeNotDeleted(AddBillingInformation DataObject)
        {
            _extendpage.VerifyAssociatedCodeNotDeleted(_billingCodeInput, DataObject.BillingCode, DataObject.NotBillingDeletionMessage);
            Settings.Logger.Info(" Successfully Verified Associated Billing Code Not Deleted  ");
        }

        /// <summary>
        /// Delete Fixed Tab
        /// </summary>
        /// <param name="BillingCode"></param>
        public void DeleteFixedTable(string BillingCode)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_billingCodeInput, BillingCode, " UnitDeptNo ");
            _extendpage.SwitchToContentFrameAndTabClick(_fixedlTab);
            Driver.WaitForReady();
            Driver.SwitchToFrame(_fixedFrame, "fixedFrame");
            _extendpage.DeleteTableRowsUsingColumnName(_fixedTable, "Bill Item", "billitem", _fixedFrame,true);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Deleted FixedTable  ");
        }

        /// <summary>
        /// Verify Delete Fixed Tab
        /// </summary>
        /// <param name="BillingCode"></param>
        public void VerifyDeletionFixedTable(string BillingCode)
        {
            _extendpage.RefreshAndSetText(_billingCodeInput, BillingCode, " BillingCode ");
            Driver.WaitForReady();
            _extendpage.SwitchToContentFrameAndTabClick(_fixedlTab);          
            _extendpage.VerifyTableRowDeletion(_fixedFrame, _fixedTableRows, "nFixedTable");
        }

        /// <summary>
        /// Change Billing Code State
        /// </summary>
        /// <param name="BillingCode"></param>
        /// <param name="State"></param>
        public void ChangeBillingCodeState(string BillingCode, string State)
        {
            _extendpage.SwitchToContentFrame();
            _billingCodeInput.SetText(BillingCode, " Billing Code ");
            Driver.WaitForReady();
            _billingState.ClickDropDownValuebyContainingText(State);
            _extendpage.SaveWithRequiredAction("Continue");
            Settings.Logger.Info($"Change BillingCode state to {State}");
        }

        /// <summary>
        /// Verify Billing Code State
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyBillingCodeState(AddBillingInformation DataObject)
        {
            _extendpage.RefreshAndSetText(_billingCodeInput, DataObject.BillingCode, " UnitDeptNo ");
            Driver.WaitForReady();
            _extendpage.VerifyReadOnlyField(_billingDescInput, DataObject.IsReadOnly, "billingDescInput");
            _extendpage.VerifyReadOnlyField(_effectiveDate, DataObject.IsReadOnly, "effectiveDate");
            _extendpage.VerifyFieldState(_billingType, DataObject.IsEnabled, "billingType");
            _extendpage.VerifyReadOnlyField(_leaseRateInput, DataObject.IsReadOnly,"");
            _extendpage.VerifyFieldState(_leaseRatePer, DataObject.IsEnabled, "leaseRatePer");
            _extendpage.VerifyReadOnlyField(_shift, DataObject.IsReadOnly, "shift");
            _extendpage.VerifyReadOnlyField(_season, DataObject.IsReadOnly, "season");
            _extendpage.VerifyFieldState(_fixedBids, DataObject.IsEnabled, "fixedBids");
            _extendpage.VerifyReadOnlyField(_billItem, DataObject.IsReadOnly, "billItem");
            _extendpage.VerifyFieldState(_laborBilling, DataObject.IsEnabled, "laborBilling"); ;
            _extendpage.VerifyFieldState(_partBilling, DataObject.IsEnabled, "partBilling");
            _extendpage.VerifyFieldState(_commBilling, DataObject.IsEnabled, "commBilling");
            _extendpage.VerifyReadOnlyField(_flatPerPeriod, DataObject.IsReadOnly, "flatPerPeriod");
            _extendpage.VerifyReadOnlyField(_chargePerUsage, DataObject.IsReadOnly, "chargePerUsage");
            _extendpage.VerifyFieldState(_howToCharge, DataObject.IsEnabled, "_howToCharge");
            _extendpage.VerifyFieldState(_recordingMethod, DataObject.IsEnabled, "recordingMethod");
            _extendpage.VerifyFieldState(_iFuelProducts, DataObject.IsEnabled, "iFuelProducts");
            _extendpage.VerifyFieldState(_oFuelProducts, DataObject.IsEnabled, "oFuelProducts");
            _extendpage.VerifyReadOnlyField(_chargePerGal, DataObject.IsReadOnly, "chargePerGal");
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info($"Successfully verified BillingCode state.");
        }
    }
}
