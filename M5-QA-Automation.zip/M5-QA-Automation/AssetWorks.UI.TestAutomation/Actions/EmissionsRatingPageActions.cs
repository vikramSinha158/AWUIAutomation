﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class EmissionsRatingPageActions : EmissionsRatingPage
    {
        public EmissionsRatingPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Emissions Rating
        /// </summary>
        /// <param name="EmissionsRating"></param>
        /// <returns></returns>
        public string CreateEmissionsRating(EmissionsRating EmissionsRating)
        {
            string EmissionsRatingBame = string.Empty;
            _extendpage.SwitchToContentFrame();
            if (!_extendpage.CheckDataExistenceAndGetActionCode(EmissionsRating.EmissionsRatingValue, ref EmissionsRatingBame, "EmissionsRatingQuery"))
            {
                EmissionsRating.EmissionsRatingValue = EmissionsRatingBame;
                FillEmissionsRatingTable(EmissionsRating);
                Settings.Logger.Info($" Successfully Creatted Emissions Rating { EmissionsRating.EmissionsRatingValue} ");
            }
            return EmissionsRating.EmissionsRatingValue;
        }

        /// <summary>
        /// Fill Emissions Rating Table
        /// </summary>
        /// <param name="EmissionsRating"></param>
        public void FillEmissionsRatingTable(EmissionsRating EmissionsRating)
        {
            Driver.SwitchToFrame(_emisRateFrameFrame, "emisRateFrameFrame");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_emisRateTableTable, "Emis Rating", "", "emisRate").SetText(EmissionsRating.EmissionsRatingValue, "EmissionsRating");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_emisRateTableTable, "Emis Rating", EmissionsRating.EmissionsRatingValue, "desc").SetText(EmissionsRating.Description, "EmissionsRating Description");
            Driver.WaitForReady();
            _extendpage.Save();
            Driver.WaitForReady();
            Settings.Logger.Info(" Added Emissions Rating ");
        }
    }
}
