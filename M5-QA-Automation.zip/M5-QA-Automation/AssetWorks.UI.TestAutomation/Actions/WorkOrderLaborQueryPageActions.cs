﻿using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class WorkOrderLaborQueryPageActions : WorkOrderLaborChargeQueryPage
    {
        public WorkOrderLaborQueryPageActions(IWebDriver? Driver) : base(Driver) { }

        /// <summary>
        /// Add Selection Criteria
        /// </summary>
        /// <param name="WorkOrderLaborChargeQuery"></param>
        public void AddSelectionCriteria(WorkOrderLaborChargeQuery WorkOrderLaborChargeQuery)
        {
            Settings.Logger.Info($"Add Selection Criteria Labor Charge Query for unit {WorkOrderLaborChargeQuery.UnitDepComp}");
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _unitDeptCompDd.SelectDropdownUsingValue("UnitDepCompName", WorkOrderLaborChargeQuery.UnitDepCompName);
            Driver.WaitForReady();
            _unitDeptCompInput.SetText(WorkOrderLaborChargeQuery.UnitDepComp, "UnitDepComp");
            Driver.WaitForReady();
            _location.SetText(WorkOrderLaborChargeQuery.Location, "Location");
            Driver.WaitForReady();
            _position.SetText(WorkOrderLaborChargeQuery.PositionCode, "PositionCode");
            Driver.WaitForReady();
            _jobcode.SetText(WorkOrderLaborChargeQuery.JobCode, "JobCode");
            Driver.WaitForReady();
            _wrsyscode.SetText(WorkOrderLaborChargeQuery.SystemCode, "SystemCode");
            Driver.WaitForReady();
            _retrieveBtn.ClickElement("retrieve", Driver);
        }

        /// <summary>
        /// verify Labor Charge Query
        /// </summary>
        /// <param name="WorkOrderLaborChargeQuery"></param>
        public void VerifyLaborChargeQuery(WorkOrderLaborChargeQuery WorkOrderLaborChargeQuery)
        {
            Settings.Logger.Info("Verify Selection Criteria Labor Charge Query");
            Driver.SwitchToFrame(_laborInqByUnitFrame, "laborInqByUnitFrame  ");
            Driver.ScrollInView(_laborInqByUnitTable);
            IWebElement UnitDepComp = _extendpage.GetTableActionElementByRelatedColumnValue(_laborInqByUnitTable, "Unit", WorkOrderLaborChargeQuery.UnitDepComp, "unit");
            CommonUtil.VerifyElementValue(UnitDepComp, "UnitDepComp", WorkOrderLaborChargeQuery.UnitDepComp,false, "value");
            IWebElement WONO = _extendpage.GetTableActionElementByRelatedColumnValue(_laborInqByUnitTable, "Unit", WorkOrderLaborChargeQuery.UnitDepComp, "WONO");
            CommonUtil.VerifyElementValue(WONO, "WorkOrderNo", WorkOrderLaborChargeQuery.WorkOrderNo, false, "value");
            IWebElement Location = _extendpage.GetTableActionElementByRelatedColumnValue(_laborInqByUnitTable, "Unit", WorkOrderLaborChargeQuery.UnitDepComp, "Loc");
            CommonUtil.VerifyElementValue(Location, "Location", WorkOrderLaborChargeQuery.Location, false, "value");
            IWebElement JobCode = _extendpage.GetTableActionElementByRelatedColumnValue(_laborInqByUnitTable, "Unit", WorkOrderLaborChargeQuery.UnitDepComp, "jobCode");
            CommonUtil.VerifyElementValue(JobCode, "JobCode", WorkOrderLaborChargeQuery.JobCode, false, "value");
            IWebElement EmpNo = _extendpage.GetTableActionElementByRelatedColumnValue(_laborInqByUnitTable, "Unit", WorkOrderLaborChargeQuery.UnitDepComp, "emp_no");
            CommonUtil.VerifyElementValue(EmpNo, "EmpNo", WorkOrderLaborChargeQuery.EmpNo, false, "value");
            IWebElement EmpName = _extendpage.GetTableActionElementByRelatedColumnValue(_laborInqByUnitTable, "Unit", WorkOrderLaborChargeQuery.UnitDepComp, "emp_name");
            CommonUtil.VerifyElementValue(EmpName, "EmpName", WorkOrderLaborChargeQuery.EmpName, false, "value");
            Settings.Logger.Info("Successfully verified Selection Criteria Labor Charge Query for unit {WorkOrderLaborChargeQuery.UnitDepComp}");
        }
    }
}
