﻿using AssetWorks.UI.M5.TestAutomation.PagesObject;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class ComponentAssignmentHistoryPageActions : ComponentAssignmentHistoryPage
    {
        public ComponentAssignmentHistoryPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Add Component Assignment History
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <param name="ComponentNo"></param>
        public void AddComponentAssignmentHistory(string ObjectKey,string ComponentNo)
        {
            Settings.Logger.Info(" Adding Component Assignment history");
            UpdateDeportment Dept = CommonUtil.DataObjectForKey(ObjectKey).ToObject<UpdateDeportment>();
            _extendpage.SwitchToContentFrame();
            _componenNotInput.SetText(ComponentNo, "ComponentNo");
            Driver.SwitchToFrame(_DeptFrame, "_DeptFrame");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_deptTable, _DepartmentHeaderName, "", "OwnDept").SetText(Dept.OwningDepartment, "Owning Dept");
            FillDeptInformation(Dept);
        }

        /// <summary>
        /// Fill Item Information
        /// </summary>
        /// <param name="ComponentDepartment"></param>
        public void FillDeptInformation(UpdateDeportment Dept)
        {           
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_deptTable, _DepartmentHeaderName, Dept.OwningDepartment, "EffectiveDate").SetText(Dept.PastDate, "Effective Date");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClicKSave();
        }

        /// <summary>
        /// Verify Component Department
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <param name="ComponentNo"></param>
        public void VerifyComponentDepartment(string ObjectKey, string ComponentNo)
        {
            UpdateDeportment Dept = CommonUtil.DataObjectForKey(ObjectKey).ToObject<UpdateDeportment>();
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_componenNotInput, ComponentNo, "ComponentNo");  
            Driver.SwitchToFrame(_DeptFrame, "compItemFrame");
            Driver.WaitForReady();
            IWebElement Department = _extendpage.GetTableActionElementByRelatedColumnValue(_deptTable, _DepartmentHeaderName, Dept.OwningDepartment, "OwnDept");
            CommonUtil.VerifyElementValue(Department, "ComponentItems", Dept.OwningDepartment, false, "value");
            Driver.WaitForReady();
            IWebElement EffectDate = _extendpage.GetTableActionElementByRelatedColumnValue(_deptTable, _DepartmentHeaderName, Dept.OwningDepartment, "EffectiveDate");
            CommonUtil.VerifyElementValue(EffectDate, "ComponentItemsVlaue", Dept.PastDate, false, "value");
        }

        /// <summary>
        /// Verify Component Department Deletion
        /// </summary>
        /// <param name="ComponentNo"></param>
        /// <param name="ObjectKey"></param>
        public void VerifyComponentDepartmentDeletion(string ObjectKey,string ComponentNo)
        {
            UpdateDeportment Dept = CommonUtil.DataObjectForKey(ObjectKey).ToObject<UpdateDeportment>();
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_deptTable, _DepartmentHeaderName, Dept.OwningDepartment, "OwnDept").Click();
            _extendpage.DeleteAndVerifySingleTableRowDeletion(_componenNotInput, ComponentNo, _DeptFrame, _DeptTableRows);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Successfully Verified Department Deletion ");
        }
    }
}
