﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.WorkRequest;
using OpenQA.Selenium;


namespace AssetWorks.UI.M5.TestAutomation.Actions.WorkRequest
{
    internal class WorkRequestPlanPageActions : WorkRequestPlanPage
    {
        public WorkRequestPlanPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create  Work Request plan
        /// </summary>
        /// <param name="WRObject"></param>
        /// <returns></returns>
        public string CreateWorkPlan(WorkRequestPlan WRObject)
        {
            _extendpage.SwitchToContentFrame();
            Settings.Logger.Info("Creating New or Loading Work Request Plan");
            if (WRObject.NewWorkPlan)
            {
                _newWorkPlan.ClickElement("", Driver);
            }
            else
            {
                _workPlanNo.SetText(WRObject.WorkPlanNo, "WorkPlanNo");
            }
            Driver.WaitForReady();
            _unitNo.SetText(WRObject.UnitNo, "UnitNo");
            Driver.WaitForReady();
            _dueWITHIN.SetText(WRObject.DueWithin, "DueWithin");
            Driver.WaitForReady();
            _extendpage.Save();
            _extendpage.SwitchToContentFrame();
            WRObject.WorkPlanNo = _workPlanNo.GetAttribute("value");
            return WRObject.WorkPlanNo;
        }

        /// <summary>
        /// Assign Work Request And Verify
        /// </summary>
        /// <param name="WRObject"></param>
        public void AssignWorkRequestAndVerify(WorkRequestPlan WRObject)
        {
            Settings.Logger.Info($" Assign Work Request and Verify");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_workPlanUnassignedFrame, "WorkPlanUnassignedFrame");
            Driver.WaitForReady();
            foreach (WorkRequestDetails WRlist in WRObject.WorkRequestDetails)
            {
                _extendpage.GetTableActionElementByRelatedColumnValue(_workPlanUnassignedTable, "Work Req", WRlist.WorkReqNo, "wpuAdd").SelectCheckBox("Add");
                WRlist.DueDate = _extendpage.GetTableActionElementByRelatedColumnValue(_workPlanUnassignedTable, "Work Req", WRlist.WorkReqNo, "wpuDueDate").GetAttribute("value");
                WRlist.EarliestDate = _extendpage.GetTableActionElementByRelatedColumnValue(_workPlanUnassignedTable, "Work Req", WRlist.WorkReqNo, "wpuFirstDate").GetAttribute("value");
            }
            _extendpage.Save();
            _extendpage.SwitchToContentFrame();
            foreach (WorkRequestDetails WRlist in WRObject.WorkRequestDetails)
            {
                VerifyAssignedWorkRequest(WRObject);
            }
        }

        /// <summary>
        /// Verify Assigned Work Request
        /// </summary>
        /// <param name="WRObject"></param>
        public void VerifyAssignedWorkRequest(WorkRequestPlan WRObject)
        {
            Settings.Logger.Info($" Verify Assigned Work Request");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_workPlanAssignedFrame, "WorkPlanAssignedFrame");
            Driver.WaitForReady();
            foreach (WorkRequestDetails WRlist in WRObject.WorkRequestDetails)
            {
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_workPlanAssignedTable, "Work Req", WRlist.WorkReqNo, "wpaJob"), "wpaJob", WRlist.Job,false,"value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_workPlanAssignedTable, "Work Req", WRlist.WorkReqNo, "wpaJobDesc"), "wpaJobDesc", WRlist.JobDesc, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_workPlanAssignedTable, "Work Req", WRlist.WorkReqNo, "wpaLocation"), "wpaLocation", WRlist.Location, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_workPlanAssignedTable, "Work Req", WRlist.WorkReqNo, "wpaDueDate"), "wpaDueDate", WRlist.DueDate, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_workPlanAssignedTable, "Work Req", WRlist.WorkReqNo, "wpaFirstDate"), "wpaFirstDate", WRlist.EarliestDate, false, "value");
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// UnAssign Work Request And Verify
        /// </summary>
        /// <param name="WRObject"></param>
        public void UnAssignWorkRequestAndVerify(WorkRequestPlan WRObject)
        {
            _extendpage.SwitchToContentFrame();
            Settings.Logger.Info($" UnAssign Work Request And Verify");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_workPlanAssignedFrame, "WorkPlanAssignedFrame");
            Driver.WaitForReady();
            foreach (WorkRequestDetails WRlist in WRObject.WorkRequestDetails)
            {
                _extendpage.GetTableActionElementByRelatedColumnValue(_workPlanAssignedTable, "Work Req", WRlist.WorkReqNo, "wpaRemove").SelectCheckBox("Remove");
            }
            _extendpage.Save();
            _extendpage.SwitchToContentFrame();
            VerifyUnAssignedWorkRequest(WRObject);
        }

        /// <summary>
        /// Verify UnAssigned Work Request
        /// </summary>
        /// <param name="WRObject"></param>
        public void VerifyUnAssignedWorkRequest(WorkRequestPlan WRObject)
        {
            Settings.Logger.Info($" Verify UnAssigned Work Request");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_workPlanUnassignedFrame, "WorkPlanAssignedFrame");
            Driver.WaitForReady();
            foreach (WorkRequestDetails WRlist in WRObject.WorkRequestDetails)
            {
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_workPlanUnassignedTable, "Work Req", WRlist.WorkReqNo, "wpuJob"), "wpuJob", WRlist.Job,false,"value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_workPlanUnassignedTable, "Work Req", WRlist.WorkReqNo, "wpuJobDesc"), "wpuJobDesc", WRlist.JobDesc, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_workPlanUnassignedTable, "Work Req", WRlist.WorkReqNo, "wpuLocation"), "wpuLocation", WRlist.Location, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_workPlanUnassignedTable, "Work Req", WRlist.WorkReqNo, "wpuDueDate"), "wpuDueDate", WRlist.DueDate, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_workPlanUnassignedTable, "Work Req", WRlist.WorkReqNo, "wpuFirstDate"), "wpuFirstDate", WRlist.EarliestDate, false, "value");
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Work Request Plan
        /// </summary>
        /// <param name="PlanNo"></param>
        public void DeleteWorkPlan(string PlanNo)
        {
            Settings.Logger.Info($" Delete Work Request Plan {PlanNo}");
            _extendpage.RefreshAndSetText(_workPlanNo, PlanNo, "PlanNo");
            _workPlanNo.ClickElement("", Driver);
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnDeleteButton();
            Driver.WaitForReady();
            _extendpage.ClickOnDialogBoxButton("Delete");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Work Request Deletion
        /// </summary>
        /// <param name="PlanNo"></param>
        public void VerifyDeleteWorkPlan(string PlanNo)
        {
            Settings.Logger.Info($" Verify Work Request Plan {PlanNo} Deletion");
            _extendpage.ClickRefresh();
            _extendpage.SwitchToContentFrame();
            _workPlanNo.SetText(PlanNo,"PlanNo");
            Driver.WaitForSomeTime();
            IAlert Alert = Driver.SwitchTo().Alert();
            CommonUtil.AssertTrue(true,Alert.Text.Contains($"Value {PlanNo} not found on file"));
            Alert.Accept();            
        }
    }
}
