﻿using OpenQA.Selenium;
using NUnit.Framework;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.WorkRequest;
using System;
using System.Linq;

namespace AssetWorks.UI.M5.TestAutomation.Actions.WorkRequest
{
    public class WorkRequestIncidentPageActions : WorkRequestIncidentPage
    {

        public WorkRequestIncidentPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create and Update Work Request Incident
        /// </summary>
        /// <param name="request"></param>
        public string CreateAndUpdateWorkRequestIncident(WorkRequestIncident request)
        {
            Settings.Logger.Info("Creating and Updating work request");
            _extendedPage.SwitchToContentFrame();
            _selectWRType.SelectFilterValueHavingEqualValue(request.WRType);          
            _inputWRUnitNo.SetText(request.WRUnitNo, "Unit No");
            Driver.WaitForReady();
            if (request.IsNewTicket)
            {
                _newIncidentBtn.ClickElement("new Ticket", Driver);
                Driver.WaitForReady();
            }
            Driver.SwitchTo().DefaultContent();
            FillIncidentDetails(request);           
            if(request.AdditionalInfo != null)
                FillAdditionalInfo(request.AdditionalInfo); 
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            GetValuesAfterSave(request);
            Settings.Logger.Info($"Created work Request {request.WorkRequestNo}");
            Assert.IsFalse(string.IsNullOrEmpty(request.WorkRequestNo), "work Request number is empty");
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Created/Updated work request Successfully");
            return request.WorkRequestNo;
        }

        /// <summary>
        /// Get incident status and unit value
        /// </summary>
        /// <param name="request"></param>
        internal void GetValuesAfterSave(WorkRequestIncident request)
        {
            request.OpenDateTime = _openDateTime.GetElementValueByAttribute("ovalue");
            request.LastIncidentStatusChange = _lastIncidentStatusChange.GetElementValueByAttribute("ovalue");
            request.LastStatusChange = _lastStatusChange.GetElementValueByAttribute("ovalue");
            request.ParkingLoc = _parkingLoction.GetElementValueByAttribute("ovalue");
            request.ServiceDate = _serviceDate.GetElementValueByAttribute("ovalue");
            request.MaintLoc = _mainLocation.GetElementValueByAttribute("ovalue");
            request.WorkRequestNo = _incidentNo.GetElementValueByAttribute("ovalue");
        }

        /// <summary>
        ///  Fill incident details
        /// </summary>
        /// <param name="request"></param>
        public void FillIncidentDetails(WorkRequestIncident request)
        {
            _extendedPage.SwitchToContentFrame();
            _extendedPage.SelectAllAndClearField(_status);
            _status.SetText(request.Status, "Status");
            _note.SetText(request.Notes, "Notes");
            Driver.WaitForReady();
            if (!request.WRType.ToLower().Contains("dept"))
            {
                _failState.SendKeys(Keys.Tab);
                Driver.WaitForReady();
                _failState.SetText(request.FaildAtState, "Faild at State");
                Driver.WaitForReady();
            }
            else
            {
                _deptMaintLoc.SetText(request.MaintLoc, "Maint Loc");               
                Driver.WaitForReady();
            }           
            _reportedBy.SetText(request.ReportedBy, "Reported By");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_phone);
            _phone.SetText(request.ContactNo, "Phone Number");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Fill additional information
        /// </summary>
        /// <param name="additionalInfo"></param>
        public void FillAdditionalInfo(AdditionalInfo additionalInfo)
        {
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _source.SetText(additionalInfo.Source, " Source");
            Driver.WaitForReady();
            _symptom.SetText(additionalInfo.Symptom, " Symptom");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_priority);
            _priority.SetText(additionalInfo.Priority, "Priority");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_zone);
            _zone.SetText(additionalInfo.Zone, "Zone");
            Driver.WaitForReady();            
            _compoment.SetText(additionalInfo.Component, "Component");
            Driver.WaitForReady();
            _condition.SetText(additionalInfo.Condition, "Condition");
            Driver.WaitForReady();
            _run.SetText(additionalInfo.Run, "Run");
            Driver.WaitForReady();
            _block.SetText(additionalInfo.Block, "Block");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify created Work Request Incident
        /// </summary>
        /// <param name="request"></param>
        public void VerifyCreatedWorkRequestIncident(WorkRequestIncident request)
       {
            Settings.Logger.Info("Verifying created work request details");
            _extendedPage.SwitchToContentFrame();
            CommonUtil.VerifyElementValue(_inputWRUnitNo, "Unit Number", request.WRUnitNo);
            CommonUtil.VerifyElementValue(_incidentNo, "Incident Number", request.WorkRequestNo);
            CommonUtil.VerifyElementValue(_status, "Status", request.Status);
            CommonUtil.VerifyElementValue(_note, "Notes", request.Notes);
            CommonUtil.VerifyElementValue(_openDateTime, "Open Date Time", request.OpenDateTime);
            CommonUtil.VerifyElementValue(_lastIncidentStatusChange, "Last Incident Status Change", request.LastIncidentStatusChange);
            CommonUtil.VerifyElementValue(_lastStatusChange, "Last Status Change", request.LastStatusChange);
            CommonUtil.VerifyElementValue(_reportedBy, "Reported By", request.ReportedBy);
            CommonUtil.AssertTrue(request.ContactNo,_phone.GetAttribute("ovalue").Trim());
            CommonUtil.VerifyElementValue(_serviceDate, "Date In Service", request.ServiceDate);
            CommonUtil.VerifyElementValue(_parkingLoction, "Parking Location", request.ParkingLoc);
            CommonUtil.VerifyElementValue(_mainLocation, "Maintainence", request.MaintLoc);
            CommonUtil.VerifyElementValue(_failState, "Reported By", request.FaildAtState);
            if(request.AdditionalInfo != null)
            {
                VerfiyAdditionalInfo(request.AdditionalInfo);
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verified created work request details Successfully!!");           
        }

        /// <summary>
        /// Verify Additional Inforamtion
        /// </summary>
        /// <param name="additionalInfo"></param>
        public void VerfiyAdditionalInfo(AdditionalInfo additionalInfo)
        {
            Settings.Logger.Info("Verifying Additional information");
            CommonUtil.VerifyElementValue(_source, "Source", additionalInfo.Source);
            CommonUtil.VerifyElementValue(_symptom, "Symptom", additionalInfo.Symptom);
            CommonUtil.VerifyElementValue(_compoment, "Component", additionalInfo.Component);
            CommonUtil.VerifyElementValue(_priority, "Priority", additionalInfo.Priority);
            CommonUtil.VerifyElementValue(_zone, "Zone", additionalInfo.Zone);
            CommonUtil.VerifyElementValue(_condition, "Condition", additionalInfo.Condition);
            CommonUtil.VerifyElementValue(_block, "Block", additionalInfo.Block);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verified Additional information Successfully!!");
        }

        /// <summary>
        /// Delete work request incident
        /// </summary>
        /// <param name="wrNumber"></param>
        public void DeleteWorkRequestIncidentDepartment(WorkRequestIncident request)
        {
            Settings.Logger.Info($"Deleting Work request incident:{request.WRType}");
            _extendedPage.ClickRefresh();
            _extendedPage.SwitchToContentFrame();
            _selectWRType.SelectFilterValueHavingEqualValue(request.WRType);
            Driver.WaitForReady();
            _inputWRUnitNo.SetText(request.WRUnitNo, "Unit No");
            Driver.WaitForReady();
            _incidentNo.SetText(request.WorkRequestNo, "IncidentNo");
            Driver.WaitForReady();
            _incidentNo.ClickElement("IncidentNo", Driver);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            Driver.WaitForReady();
            _extendedPage.ActionRequiredWindow("Delete");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Delete work request incident
        /// </summary>
        /// <param name="wrNumber"></param>
        public void DeleteWorkRequestIncident(string wrNumber)
        {
            Settings.Logger.Info("Delete Work request incident");
            _extendedPage.SwitchToContentFrame();
            _wrTextNo.ClickElement("WR text no", Driver);
            Driver.SwitchToNewWindow();
            _extendedPage.VerifyMenuBarHeaders("Work Request Main");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ActionRequiredWindow("Delete");
            Driver.WaitForReady();
            Driver.Close();
            Driver.SwitchTo().Window(Driver.WindowHandles.Last());
            Driver.SwitchTo().DefaultContent();
            _extendedPage.VerifyCodeDeletion(_incidentNo, wrNumber, "Incident Number");
            Driver.SwitchTo().DefaultContent();
        }        

        /// <summary>
        /// Verify Delete created Work Request Incident
        /// </summary>
        /// <param name="request"></param>
        public void VerifyDeleteCreatedWorkRequestIncident(WorkRequestIncident request)
        {
            if (!request.WRType.ToLower().Contains("dept"))
            {
                _extendedPage.RefreshAndSetText(_incidentNo, request.WorkRequestNo, "Incident Number");
            }
            else
            {
                _extendedPage.ClickRefresh();
                _extendedPage.SwitchToContentFrame();
                _selectWRType.SelectFilterValueHavingEqualValue(request.WRType);
                Driver.WaitForReady();
                _inputWRUnitNo.SetText(request.WRUnitNo, "Unit No");
                Driver.WaitForReady();
                _incidentNo.SetText(request.WorkRequestNo, "IncidentNo");
            }
            Driver.WaitForSomeTime();
            IAlert alert = Driver.SwitchTo().Alert();
            CommonUtil.AssertTrue(true, alert.Text.Contains($"Value {request.WorkRequestNo} not found on file"));
            alert.Accept();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Successfully Deleted Work request incident");
        }

        /// <summary>
        /// Make Incident Into A Work Request
        /// </summary>
        /// <param name="request"></param>
        public void MakeIncidentIntoWorkRequest(WorkRequestIncident request)
        {
            Settings.Logger.Info("Make This Incident Into A Work Request");
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            _selectWRType.SelectFilterValueHavingEqualValue(request.WRType);
            Driver.WaitForReady();
            _inputWRUnitNo.SetText(request.WRUnitNo, "Unit No");
            Driver.WaitForReady();
            _incidentNo.SetText(request.WorkRequestNo, "IncidentNo");
            Driver.WaitForReady();
            _wrLink.ClickElement("Make This Incident Into A Work Request", Driver);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Driver.SwitchToFrame(_extendedPage._contentFrame2, "Work Request");
            _wrJob.SetText(request.WorkRequestObj.Job, "Job");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ActionRequiredWindow("Yes");
            Driver.SwitchToFrame(_extendedPage._contentFrame2, "Work Request");
            _wrLocation.SetText(request.WorkRequestObj.Location, "Location");
            Driver.WaitForReady();
            _wrJobReason.SetText(request.WorkRequestObj.JobReason, "Job Reason");
            Driver.WaitForReady();
            _wrEstCost.SetText(request.WorkRequestObj.EstCost, "Est Cost");
            Driver.WaitForReady();
            _wrEstLabor.SetText(request.WorkRequestObj.EstLaborHours, "Est Labor Hours");
            Driver.WaitForReady();
            _wrEmployee.SetText(request.WorkRequestObj.EmployeeGroup, "Employee/Group");
            Driver.WaitForReady();
            _btnProcessWR.ClickElement("Process Work Request", Driver);
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForSomeTime();
        }

        /// <summary>
        /// Create A Work Order For This Incident
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public string CreateWorkOrderForIncident(WorkRequestIncident request)
        {
            Settings.Logger.Info("Create A Work Order For This Incident");
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            _selectWRType.SelectFilterValueHavingEqualValue(request.WRType);
            Driver.WaitForReady();
            _inputWRUnitNo.SetText(request.WRUnitNo, "Unit No");
            Driver.WaitForReady();
            _incidentNo.SetText(request.WorkRequestNo, "IncidentNo");
            Driver.WaitForReady();
            Driver.ScrollIntoViewAndClick(_woLink, "Create A Work Order For This Incident");
            Driver.SwitchToNewWindow();
            _extendedPage.VerifyMenuBarHeaders("Work Order Main");
            WorkOrderMainPageActions workOrder = new (Driver);
            workOrder.FillWorkOrderDetail(request.WorkOrderMainObj, request.WRUnitNo);
            _extendedPage.Save();
            _extendedPage.MoveUpAndSwitchContentFrame();
            string WorkOrderNo = workOrder._workOrderNumber.GetElementValueByAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            Driver.Close();
            Driver.SwitchTo().Window(Driver.WindowHandles.Last());
            return WorkOrderNo;
        }

        /// <summary>
        /// Verify and Delete Work Order For Incident
        /// </summary>
        /// <param name="request"></param>
        /// <param name="WorkOrderNo"></param>
        public void VerifyAndDeleteWorkOrderForIncident(WorkRequestIncident request, string WorkOrderNo)
        {
            Settings.Logger.Info("Verify and Delete Work Order For Incident");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            _selectWRType.SelectFilterValueHavingEqualValue(request.WRType);
            Driver.WaitForReady();
            _inputWRUnitNo.SetText(request.WRUnitNo, "Unit No");
            Driver.WaitForReady();
            _incidentNo.SetText(request.WorkRequestNo, "IncidentNo");
            Driver.WaitForReady();
            CommonUtil.VerifyElementText(_woTextNo, "Work Order No", WorkOrderNo);
            _woTextNo.ClickElement("Work Order", Driver);
            Driver.SwitchToNewWindow();
            _extendedPage.VerifyMenuBarHeaders("Work Order Main");
            Driver.WaitForSomeTime(10);
            WorkOrderMainPageActions workOrder = new(Driver);
            CommonUtil.VerifyElementValue(workOrder._workOrderNumber, "Work Order No", WorkOrderNo);
            workOrder._workOrderNumber.ClickElement(WorkOrderNo, Driver);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ActionRequiredWindow("Proceed");
            Driver.WaitForReady();
            Driver.Close();
            Driver.SwitchTo().Window(Driver.WindowHandles.Last());
            Driver.SwitchTo().DefaultContent();
        }
    }
}
