﻿using AssetWorks.UI.M5.TestAutomation.PagesObject.WorkRequest;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using System;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.Actions.WorkRequest
{
    internal class WorkRequestCampaignPageActions : WorkRequestCampaignPage
    {
        public WorkRequestCampaignPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create work request campaign
        /// </summary>
        /// <param name="parameter"></param>
        /// <param name="isNewWorkRequest"></param>
        /// <returns></returns>
        public string CreateWorkRequestCampaign(WorkRequestParameter parameter, bool isNewWorkRequest = true)
        {
            Driver.WaitForSomeTime(10);
            if (isNewWorkRequest)
            {
                _extendedPage.SwitchToContentFrame();
                _newCampaign.ClickElement("_newCampaign", Driver);
                Driver.WaitForReady();
                CommonUtil.VerifyElementValue(_campaignState, "Status", CommonUtil.GetEnumDescription(WorkRequestStatus.Build));
                Driver.SwitchTo().DefaultContent();
            }
            FillCampaignDetails(parameter);
            if (parameter.GeneralInfo != null)
            {
                FillGeneralInfo(parameter.GeneralInfo);
            }
            if (parameter.InclusionsInfo != null)
            {
                FillInclusionsInfo(parameter.InclusionsInfo);
            }
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            Settings.Logger.Info($"Created work Request {_inputCampaignNo.GetElementValueByAttribute("ovalue")}");
            parameter.CampaignNo = _inputCampaignNo.GetElementValueByAttribute("ovalue");
            parameter.Status = _campaignState.GetElementValueByAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            return parameter.CampaignNo;
        }

        /// <summary>
        ///  Enter details to create new campaign
        /// </summary>
        /// <param name="parameter"></param>
        public void FillCampaignDetails(WorkRequestParameter parameter)
        {
            _extendedPage.SwitchToContentFrame();
            _campaignDesc.SetText(parameter.CampaignDesc, "Description");
            _jobCode.SetText(parameter.WRJobCode, "Job Code");
            Driver.WaitForReady();
            _jobReason.SetText(parameter.WRJobReason, "Job Reason");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("General"), "General Tab");
            _earlDate.SetText(DateTime.Today.AddDays(Convert.ToInt32(parameter.EarliestDate)).ToString("MM\\/dd\\/yyyy"), "Earliest Date");
            _preferDate.SetText(DateTime.Today.AddDays(Convert.ToInt32(parameter.PreferredDate)).ToString("MM\\/dd\\/yyyy"), "Preferred Date");
            _latestDate.SetText(DateTime.Today.AddDays(Convert.ToInt32(parameter.LatestDate)).ToString("MM\\/dd\\/yyyy"), "Latest Date");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify created work request campaign
        /// </summary>
        /// <param name="parameter"></param>
        public void VerifyCreatedWorkRequestCampaign(WorkRequestParameter parameter)
        {
            Settings.Logger.Info("Verify work request details");
            LoadWorkRequest(parameter.CampaignNo);
            _extendedPage.SwitchToContentFrame();
            CommonUtil.VerifyElementValue(_campaignState, "Status", parameter.Status);
            CommonUtil.VerifyElementValue(_campaignDesc, "Description", parameter.CampaignDesc);
            CommonUtil.VerifyElementValue(_jobCode, "Job Code", parameter.WRJobCode);
            CommonUtil.VerifyElementValue(_jobReason, "Job Code Reason", parameter.WRJobReason);
            if (parameter.EarliestDate != null)
                CommonUtil.VerifyElementValue(_earlDate, "Earliest Date", DateTime.Today.AddDays(Convert.ToInt32(parameter.EarliestDate)).ToString("MM\\/dd\\/yyyy"));
            if (parameter.PreferredDate != null)
                CommonUtil.VerifyElementValue(_preferDate, "Preferred Date", DateTime.Today.AddDays(Convert.ToInt32(parameter.PreferredDate)).ToString("MM\\/dd\\/yyyy"));
            if (parameter.LatestDate != null)
                CommonUtil.VerifyElementValue(_latestDate, "Latest Date", DateTime.Today.AddDays(Convert.ToInt32(parameter.LatestDate)).ToString("MM\\/dd\\/yyyy"));
            Driver.SwitchTo().DefaultContent();
            if (parameter.GeneralInfo!=null)
            {
                VerifyAddedGeneralInfo(parameter.GeneralInfo);
            }  
            if(parameter.InclusionsInfo!=null)
            {
                VerifyAddedInclusionsInfo(parameter.InclusionsInfo);
            }
            Settings.Logger.Info("Successfully verified Work request campaign.");
        }

        /// <summary>
        /// Verify Delete Work Request campaign
        /// </summary>
        /// <param name="campaignNo"></param>
        public void VerifyDeleteWorkRequestCampaign(string campaignNo)
        {
            Settings.Logger.Info("Deleting work request campaign");
            //_extendedPage.VerifyCodeDeletion(_inputCampaignNo, campaignNo, "Campaign Number");
            _extendedPage.SwitchToContentFrame();
            _inputCampaignNo.ClickElement(campaignNo, Driver);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            Driver.WaitForReady();
            _extendedPage.ActionRequiredWindow("Delete");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_campaignState, "Status", String.Empty);           
            Driver.WaitForReady();
            _inputCampaignNo.SetText(campaignNo, "Number");
            Driver.SwitchTo().DefaultContent();
            CommonUtil.AssertTrue(true, _dailogText(campaignNo).VerifyElementDisplay("Action Required Dailog"));
            _extendedPage.ActionRequiredWindow("Cancel");
            Settings.Logger.Info("Successfully Deleted Work request campaign");
        }
                
        /// <summary>
        /// Load work request after refresh
        /// </summary>
        /// <param name="campaignNo"></param>
        public void LoadWorkRequest(string campaignNo)
        {
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForSomeTime(10);
            _extendedPage.SwitchToContentFrame();
            if (campaignNo == null)
                Assert.Fail("Campaign Number is null or not created");
            _inputCampaignNo.SetText(campaignNo, "Number");
            Driver.SwitchTo().DefaultContent();
        }
        /// <summary>
        /// Fill General tab information
        /// </summary>
        /// <param name="generalInfo"></param>
        public void FillGeneralInfo(GeneralInfo generalInfo)
        {
            Settings.Logger.Info("Adding General info for work request campaign");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("General"), "General Tab");
            _reportedBy.SetText(generalInfo.ReportedBy, "Reported By");
            Driver.WaitForReady();
            _contactPhone.SetText(generalInfo.ContactPhone, "Contact Phone");
            Driver.WaitForReady();
            _reqRef.SetText(generalInfo.ReqRef, "Requisition Reference");
            Driver.WaitForReady();
            _dirAcct.SetText(generalInfo.DirectAcc, "Direct Account");
            Driver.WaitForReady();
            _maintLoc.SetText(generalInfo.MaintLoc, "Maintenance Location");
            Driver.WaitForReady();
            _crewSize.SetText(generalInfo.CrewSize, "Crew Size");
            if (generalInfo.SpanShift)
                _spanShiftsflChk.SelectCheckBox("Span Shift");
            else
                _spanShiftsflChk.DeSelectCheckBox("Span Shift");
            if (generalInfo.SpreadDueDt)
                _spreadDueDt.SelectCheckBox("Spread Due Dates");
            else
                _spreadDueDt.DeSelectCheckBox("Spread Due Dates");
            if (generalInfo.SendToVendor)
                _sendToVendorChk.SelectCheckBox("Send To Vendor");
            else
                _sendToVendorChk.DeSelectCheckBox("Send To Vendor");
            _notes.SetText(generalInfo.Notes, "Notes");
            _complaintNote.SetText(generalInfo.ComplaintNote, "Complaint Note");
            _causeNote.SetText(generalInfo.CauseNote, "Cause Note");
            _correctNote.SetText(generalInfo.CorrectNote, "Correct Note");
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("General info Added for work request campaign");
        }

        /// <summary>
        /// Fill Inclusions tab information
        /// </summary>
        /// <param name="inclusionsinfo"></param>
        private void FillInclusionsInfo(InclusionsInfo inclusionsInfo)
        {
            Settings.Logger.Info("Adding Inclusions info for work request campaign");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Inclusions"), "Inclusions Tab");
            Driver.SwitchToFrame(_reportFilterFrame, " Report Filter Frame");
            _enabledCheckbox(inclusionsInfo.FieldName).SelectCheckBox("Checkbox");
            Driver.WaitForReady();
            _operator(inclusionsInfo.FieldName).SelectFilterValueHavingEqualValue(inclusionsInfo.Operator);
            _fieldValue(inclusionsInfo.FieldName).SetText(inclusionsInfo.UnitNumberValue, "Value");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Added genral information
        /// </summary>
        /// <param name="generalInfo"></param>
        public void VerifyAddedGeneralInfo(GeneralInfo generalInfo)
        {
            Settings.Logger.Info("Verify work request campaign General tab info");
            _extendedPage.SwitchToContentFrame();
            CommonUtil.VerifyElementValue(_reportedBy, "Reported By", generalInfo.ReportedBy);
            CommonUtil.VerifyElementValue(_reqRef, "Requisition Reference", generalInfo.ReqRef);
            CommonUtil.VerifyElementValue(_dirAcct, "Direct Account", generalInfo.DirectAcc);
            CommonUtil.VerifyElementValue(_maintLoc, "Maintenance Location", generalInfo.MaintLoc);
            CommonUtil.VerifyElementValue(_crewSize, "Crew Size", generalInfo.CrewSize);
            CommonUtil.VerifyCheckboxState(_spanShiftsflChk, "Span Shift", generalInfo.SpanShift);
            CommonUtil.VerifyCheckboxState(_spreadDueDt, "Spread Due Dates", generalInfo.SpreadDueDt);
            CommonUtil.VerifyCheckboxState(_sendToVendorChk, "Send To Vendor", generalInfo.SendToVendor);
            CommonUtil.VerifyElementValue(_complaintNote, "Complaint Note", generalInfo.ComplaintNote);
            CommonUtil.VerifyElementValue(_causeNote, "Cause Note", generalInfo.CauseNote);
            CommonUtil.VerifyElementValue(_correctNote, "Correct Note", generalInfo.CorrectNote);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Successfully verified Work request campaign General tab info.");
        }

        /// <summary>
        /// Verify Added inclusions information
        /// </summary>
        /// <param name="inclusionsInfo"></param>
        public void VerifyAddedInclusionsInfo(InclusionsInfo inclusionsInfo)
        {
            Settings.Logger.Info("Verify work request campaign Inclusions tab info");
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Inclusions"), "Inclusions Tab");           
            Driver.WaitForReady();
            Driver.SwitchToFrame(_reportFilterFrame, " Report Filter Frame");
            CommonUtil.VerifyCheckboxState(_enabledCheckbox(inclusionsInfo.FieldName), "Enabled", inclusionsInfo.Enabled);
            CommonUtil.VerifyElementValue(_operator(inclusionsInfo.FieldName), "Operator", inclusionsInfo.Operator, true);
            CommonUtil.VerifyElementValue(_fieldValue(inclusionsInfo.FieldName), "Value", inclusionsInfo.UnitNumberValue, false, "value");
            Driver.SwitchTo().DefaultContent();
        }
        /// <summary>
        /// Verify button Enabled state
        /// </summary>
        /// <param name="_uiElement"></param>
        /// <param name="webElementName"></param>
        /// <param name="isEnabled"></param>
        public void VerifyButtonState(IWebElement uiElement, string webElementName, bool isEnabled)
        {
            CommonUtil.AssertTrue(isEnabled,uiElement.Enabled);
            Settings.Logger.Info($"Successfully verified {webElementName} state.");
        }

        /// <summary>
        /// Check Work Request Status
        /// </summary>
        /// <param name="status"></param>
        public void VerifyWRStatus(string status)
        {
            _extendedPage.SwitchToContentFrame();
            CommonUtil.VerifyElementValue(_campaignState, "Status", status);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Successfully verified Work request campaign Status.");
        }

        /// <summary>
        /// Click on Icon Menu button and verify button state and WR status
        /// </summary>
        /// <param name="WRSateStatus"></param>
        public void ClickOnButtonAndVerifyStateAndStatus(WorkRequestStateAndStatus wRSateStatus)
        {
            Settings.Logger.Info($"Click on {wRSateStatus.ElementName} button and Verify button state and Work request status.");
            switch (wRSateStatus.WRStatus)
            {
                case nameof(WorkRequestStatus.Preview):
                    ClickAndVerifyStateStatus(_previewBtn, wRSateStatus);
                    break;
                case nameof(WorkRequestStatus.Customize):
                    ClickAndVerifyStateStatus(_customizeBtn, wRSateStatus);
                    break;
                case nameof(WorkRequestStatus.Finalized):
                    ClickAndVerifyStateStatus(_finalizeBtn, wRSateStatus); 
                    break;
                case nameof(WorkRequestStatus.Update):
                    ClickAndVerifyStateStatus(_updateBtn, wRSateStatus);
                    break;
                case nameof(WorkRequestStatus.Unlock):
                    ClickAndVerifyStateStatus(_unlockBtn, wRSateStatus);
                    break;
            }
        }

        /// <summary>
        /// Click And Verify State and Status
        /// </summary>
        /// <param name="actionBtn"></param>
        /// <param name="wRSateStatus"></param>
        public void ClickAndVerifyStateStatus(IWebElement actionBtn, WorkRequestStateAndStatus wRSateStatus)
        {
            actionBtn.ClickElement(wRSateStatus.ElementName + "Button", Driver);
            _extendedPage.ActionRequiredWindow(wRSateStatus.ElementName);
            Driver.WaitForReady();
            if(wRSateStatus.WRStatus == nameof(WorkRequestStatus.Unlock))
                VerifyStateAndStatus(WorkRequestStatus.Customize.ToString(), wRSateStatus.IsPreviewEnabled, wRSateStatus.IsCustomizeEnabled, wRSateStatus.IsFinalizedEnabled, wRSateStatus.IsUpdateEnabled, wRSateStatus.IsUnlockEnabled);
            else
                VerifyStateAndStatus(wRSateStatus.WRStatus, wRSateStatus.IsPreviewEnabled, wRSateStatus.IsCustomizeEnabled, wRSateStatus.IsFinalizedEnabled, wRSateStatus.IsUpdateEnabled, wRSateStatus.IsUnlockEnabled);
        }

        /// <summary>
        /// Verify Menu button enabled state and WR status
        /// </summary>
        /// <param name="status"></param>
        /// <param name="isPreviewEnabled"></param>
        /// <param name="isCustomizeEnabled"></param>
        /// <param name="isFinalizeEnabled"></param>
        /// <param name="isUnlockEnabled"></param>
        /// <param name="isUpdateEnabled"></param>
        public void VerifyStateAndStatus(string status, bool isPreviewEnabled = false, bool isCustomizeEnabled = false, bool isFinalizeEnabled = false, bool isUnlockEnabled = false, bool isUpdateEnabled = false)
        {            
            VerifyButtonState(_previewBtn, "Preview Button", isPreviewEnabled);
            VerifyButtonState(_customizeBtn, "Customize Button", isCustomizeEnabled);
            VerifyButtonState(_finalizeBtn, "Finalize Button", isFinalizeEnabled);
            VerifyButtonState(_unlockBtn, "Unlock Button", isUnlockEnabled);
            VerifyButtonState(_updateBtn, "Update Button", isUpdateEnabled);
            VerifyWRStatus(status);
        }
    }
}
