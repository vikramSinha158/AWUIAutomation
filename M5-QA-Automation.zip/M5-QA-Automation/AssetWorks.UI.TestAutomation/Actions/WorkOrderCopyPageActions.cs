﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class WorkOrderCopyPageActions : WorkOrderCopyPage
    {
        public WorkOrderCopyPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Copy Existing Work Ordere
        /// </summary>
        /// <param name="ExistingWorkOrderNo"></param>
        /// <param name="UnitNo"></param>
        /// <returns></returns>
        public string CopyExistingWorkOrder(string ExistingWorkOrderNo,string UnitNo)
        {
            Settings.Logger.Info($" Created Copying Existing Work Order ");
            string NewWONumber = String.Empty;
            _extendpage.SwitchToContentFrame();
            _wonumber.SetText(ExistingWorkOrderNo, "ExistingBillingCode");
            Driver.WaitForReady();
            _unitno.SetText(UnitNo, "UnitNo");
            Driver.WaitForReady();
            _extendpage.Save();
            Driver.WaitForSomeTime();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            NewWONumber = _newWo.GetElementValueByAttribute("ovalue");          
            Settings.Logger.Info($" Created new work order { NewWONumber } by Copying Existing Work Order { ExistingWorkOrderNo }");
            Driver.WaitForReady();
            return NewWONumber;
        }

        /// <summary>
        /// Create Multiple WorkOrder Copies
        /// </summary>
        /// <param name="WorkOrderMain"></param>
        /// <returns></returns>
        public List<string>? CreateMultipleWorkOrderCopies(WorkOrderMain WorkOrderMain)
        {
            Settings.Logger.Info($" Created Copying Existing Work Order ");
            List<string>? workOrderCopies = new List<string>();
            string NewWONumber = String.Empty;
            _extendpage.SwitchToContentFrame();
            _wonumber.SetText(WorkOrderMain.ExistingWorkOrderNo, "ExistingBillingCode");
            Driver.WaitForReady();
            if (WorkOrderMain.UnitList != null)
            {
                int i = 0;
                foreach (string UnitNo in WorkOrderMain.UnitList)
                {
                    _unit(i).SetText(UnitNo, "Unit No");
                    i++;
                }
            }
            _extendpage.Save();
            Driver.WaitForSomeTime();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            //if(WorkOrderMain.WorkOrderList!=null) WorkOrderMain.WorkOrderList.Clear();
            int WorkOrderCount = WorkOrderMain.UnitList.Count;
            for (int i = 0; i < WorkOrderCount; i++)
            {
                NewWONumber = _workorder(i).GetElementValueByAttribute("ovalue");
                workOrderCopies.Add(NewWONumber);
                Settings.Logger.Info($" Created new work order { NewWONumber } by Copying Existing Work Order ");
            }          
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            return workOrderCopies;
        }
    }
}
