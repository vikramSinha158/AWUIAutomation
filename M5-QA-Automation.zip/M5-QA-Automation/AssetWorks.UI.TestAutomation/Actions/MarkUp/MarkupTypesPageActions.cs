﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.MarkUp;

namespace AssetWorks.UI.M5.TestAutomation.Actions.MarkUp
{
    internal class MarkupTypesPageActions : MarkupTypesPage
    {
        public MarkupTypesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Update Markup Lookups
        /// </summary>
        /// <param name="markup"></param>
        public void UpdateMarkupLookups(MarkupLookups markup)
        {
            Settings.Logger.Info(" Update Markup Type Lookups ");
            if (markup.markups != null)
            {
                _extendedPage.SwitchToTableFrame(_frameMarkupTypes);
                foreach (var markupType in markup.markups)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType, markupType.MarkupType,
                        _selectLookup1).SelectFilterValueHavingEqualValue(markupType.Lookup1);
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType, markupType.MarkupType,
                        _selectLookup2).SelectFilterValueHavingEqualValue(markupType.Lookup2);
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType, markupType.MarkupType,
                        _selectLookup3).SelectFilterValueHavingEqualValue(markupType.Lookup3);
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType, markupType.MarkupType,
                        _selectLookup4).SelectFilterValueHavingEqualValue(markupType.Lookup4);
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
                Driver.WaitForSomeTime();
            }
        }

        /// <summary>
        /// Verify Markup Lookups
        /// </summary>
        /// <param name="markup"></param>
        public void VerifyMarkupLookups(MarkupLookups markup)
        {
            IWebElement webElement = null;
            Settings.Logger.Info(" Verify MarkUp Type Lookups ");
            if (markup.markups != null)
            {
                _extendedPage.ClickOnRefreshButton();
                Driver.WaitForReady();
                _extendedPage.SwitchToTableFrame(_frameMarkupTypes);
                foreach (var markupType in markup.markups)
                {
                    webElement = _extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType, markupType.MarkupType,
                        _selectLookup1);
                    if (markupType.Lookup1 != null && markupType.Lookup1 == "")
                        CommonUtil.AssertTrue(webElement.GetVisibleText(), markupType.Lookup1);
                    else
                        CommonUtil.VerifyElementValue(webElement, "1st Lookup", markupType.Lookup1, true);
                    webElement = _extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType, markupType.MarkupType,
                        _selectLookup2);
                    if (markupType.Lookup2 != null && markupType.Lookup2 == "")
                        CommonUtil.AssertTrue(webElement.GetVisibleText(), markupType.Lookup2);
                    else
                        CommonUtil.VerifyElementValue(webElement, "2nd Lookup", markupType.Lookup2, true);
                    webElement = _extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType, markupType.MarkupType,
                        _selectLookup3);
                    if (markupType.Lookup3 != null && markupType.Lookup3 == "")
                        CommonUtil.AssertTrue(webElement.GetVisibleText(), markupType.Lookup3);
                    else
                        CommonUtil.VerifyElementValue(webElement, "3rd Lookup", markupType.Lookup3, true);
                    webElement = _extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType, markupType.MarkupType,
                        _selectLookup4);
                    if (markupType.Lookup4 != null && markupType.Lookup4 == "")
                        CommonUtil.AssertTrue(webElement.GetVisibleText(), markupType.Lookup4);
                    else
                        CommonUtil.VerifyElementValue(webElement, "4th Lookup", markupType.Lookup4, true);
                }
                Driver.SwitchTo().DefaultContent();
            }
        }

        /// <summary>
        /// Clear Markup Lookups
        /// </summary>
        /// <param name="markup"></param>
        public void ClearMarkupLookups(MarkupLookups markup)
        {
            Settings.Logger.Info(" Clear Markup Type Lookups ");
            if (markup.markups != null)
            {
                _extendedPage.SwitchToTableFrame(_frameMarkupTypes);
                foreach (var markupType in markup.markups)
                {
                    _extendedPage.SelectBlankValueFromDropdown(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType,
                        markupType.MarkupType, _selectLookup4), "4th Lookup", markupType.Lookup4);
                    _extendedPage.SelectBlankValueFromDropdown(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType,
                        markupType.MarkupType, _selectLookup3), "3rd Lookup", markupType.Lookup3);
                    _extendedPage.SelectBlankValueFromDropdown(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType,
                        markupType.MarkupType, _selectLookup2), "2nd Lookup", markupType.Lookup2);
                    _extendedPage.SelectBlankValueFromDropdown(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType,
                        markupType.MarkupType, _selectLookup1), "1st Lookup", markupType.Lookup1);
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
                Driver.WaitForSomeTime();
            }
        }

        /// <summary>
        /// Verify Alerts On Markup Lookups
        /// </summary>
        /// <param name="markup"></param>
        public void VerifyAlertsOnMarkupLookups(MarkupLookups markup)
        {
            Settings.Logger.Info(" Verify Alerts on Markup Type Lookups ");
            if (markup.markups != null)
            {
                _extendedPage.SwitchToTableFrame(_frameMarkupTypes);
                foreach (var markupType in markup.markups)
                {
                    if (markupType.Lookup1 != null)
                    {
                        _extendedPage.SelectDropdownValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType,
                            markupType.MarkupType, _selectLookup1), markupType.Lookup1);
                    }
                    if (markupType.Lookup2 != null)
                    {
                        _extendedPage.SelectDropdownValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType,
                            markupType.MarkupType, _selectLookup2), markupType.Lookup2);
                    }
                    if (markupType.Lookup3 != null)
                    {
                        _extendedPage.SelectDropdownValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType,
                            markupType.MarkupType, _selectLookup3), markupType.Lookup3);
                    }
                    if (markupType.Lookup4 != null)
                    {
                        _extendedPage.SelectDropdownValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableMarkupTypes, _headerMarkupType,
                            markupType.MarkupType, _selectLookup4), markupType.Lookup4);
                    }
                    Driver.WaitForSomeTime();
                    _extendedPage.VerifyTextAndAcceptAlert(Driver, markupType.AlertMsg);
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
                Driver.WaitForSomeTime();
            }
        }        
    }
}
