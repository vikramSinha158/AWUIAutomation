﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Collections.Generic;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.MarkUp;

namespace AssetWorks.UI.M5.TestAutomation.Actions.MarkUp
{
    internal class MarkUpSchemePageActions : MarkUpSchemeMainPage    
    {
        public MarkUpSchemePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Markup Scheme
        /// </summary>
        /// <param name="markupScheme"></param>
        /// <returns></returns>
        public string CreateMarkupScheme(CreateMarkUpScheme markupScheme)
        {
            Settings.Logger.Info(" Create new Markup Scheme");
            string SchemeName = String.Empty;
            if (!_extendPage.CheckDataExistenceAndGetActionCode(markupScheme.Scheme, ref SchemeName, "MarkupSchemeQuery", 8))
            {
                markupScheme.Scheme = SchemeName;
                FillMarkupDetails(markupScheme);
                if (markupScheme.PartMarkUp != null)
                    FillPartMarkupInfo(markupScheme.PartMarkUp);
                if (markupScheme.LaborMarkUp != null)
                    FillLaborMarkupInfo(markupScheme.LaborMarkUp);
                if (markupScheme.CommercialMarkUp != null)
                    FillCommercialMarkupInfo(markupScheme.CommercialMarkUp);
                _extendPage.VerifyRecordCreatedSuccess(_inputScheme, _inputSchemeDesc, SchemeName, "Scheme");
            }
            return SchemeName;
        }

        /// <summary>
        /// Update Markup Scheme
        /// </summary>
        /// <param name="markupScheme"></param>
        public void UpdateMarkupScheme(CreateMarkUpScheme markupScheme)
        {
            Settings.Logger.Info(" Update Markup Scheme ");
            _extendPage.ClickOnRefreshButton();
            FillMarkupDetails(markupScheme);
            if (markupScheme.PartMarkUp != null)
                FillPartMarkupInfo(markupScheme.PartMarkUp);
            if (markupScheme.LaborMarkUp != null)
                FillLaborMarkupInfo(markupScheme.LaborMarkUp);
            if (markupScheme.CommercialMarkUp != null)
                FillCommercialMarkupInfo(markupScheme.CommercialMarkUp);
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Fill Markup Scheme Details
        /// </summary>
        /// <param name="markupScheme"></param>
        public void FillMarkupDetails(CreateMarkUpScheme markupScheme)
        {
            Settings.Logger.Info(" Fill Markup Scheme Details ");
            _inputScheme.SetText(markupScheme.Scheme, "Scheme", Driver, _extendPage._contentFrame, "content frame");
            _extendPage.ActionRequiredWindow("Create");
            _extendPage.SwitchToContentFrame();
            _inputSchemeDesc.SetText(markupScheme.SchemeDesc, "Description");
            _disableScheme.SelectFilterValueHavingEqualValue(markupScheme.DisableScheme);
            Driver.WaitForReady();
            if (markupScheme.EffectiveDate != null)
            {
                if (!markupScheme.EffectiveDate.Contains('/'))
                {
                    markupScheme.EffectiveDate = markupScheme.EffectiveDate.ToLower() == "now" ? DateTime.Now.ToString("MM/dd/yyyy") : DateTime.Now.AddDays(Convert.ToDouble(markupScheme.EffectiveDate)).ToString("MM/dd/yyyy");
                }
                _effectiveDate.SetText(markupScheme.EffectiveDate, "Effective Date");
            }
            else
                _effectiveDate.SendKeys(Keys.Tab);
            Driver.SwitchTo().DefaultContent();
            _extendPage.ActionRequiredWindow("Create");
            _extendPage.SwitchToContentFrame();
            _jobReason.SetText(markupScheme.JobReason, "Job Reason");
            Driver.SwitchTo().DefaultContent();
            _extendPage.ActionRequiredWindow("Create");
            _extendPage.SwitchToContentFrame();
        }

        /// <summary>
        /// Fill Part Markup Info
        /// </summary>
        /// <param name="partMarkup"></param>
        public void FillPartMarkupInfo(List<PartMarkUp> partMarkup)
        {
            Settings.Logger.Info(" Fill Part Markup Info ");
            Driver.SwitchToFrame(_markupPartFrame, "Part frame");
            foreach (PartMarkUp markups in partMarkup)
            {
                _extendPage.GetTableActionElementByRelatedColumnValue(_markupSchemeTable, _headerTransaction, markups.KindOfTransaction,
                    "pmarkupPC").SetText(markups.MarkUpPercent, "Markup Percent");
                _extendPage.GetTableActionElementByRelatedColumnValue(_markupSchemeTable, _headerTransaction, markups.KindOfTransaction,
                    "pLimit").SetText(markups.MarkUpLimit, "Markup Limit");
            }
        }

        /// <summary>
        /// Fill Labor Markup Info
        /// </summary>
        /// <param name="laborMarkup"></param>
        public void FillLaborMarkupInfo(List<LaborMarkUp> laborMarkup)
        {
            Settings.Logger.Info(" Fill Labor Markup Rate Info ");
            Driver.SwitchTo().DefaultContent();
            _extendPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendPage.GetTabLinkByText("Labor Markup/Rate"), "Labor Markup/Rate Tab");
            Driver.SwitchToFrame(_markupLaborFrame, "Labor frame");
            foreach (LaborMarkUp markups in laborMarkup)
            {
                _extendPage.GetTableActionElementByRelatedColumnValue(_markupLaborTable, _headerTransaction, markups.KindOfTransaction,
                    "lmarkupPC").SetText(markups.MarkUpPercent, "Markup Percent");
                _extendPage.GetTableActionElementByRelatedColumnValue(_markupLaborTable, _headerTransaction, markups.KindOfTransaction,
                    "lLaborRate").SetText(markups.LaborRate, "Labor Rate");
                _extendPage.GetTableActionElementByRelatedColumnValue(_markupLaborTable, _headerTransaction, markups.KindOfTransaction,
                    "lLimit").SetText(markups.MarkUpLimit, "Markup Limit");
            }
        }

        /// <summary>
        /// Fill Commercial Markup Info
        /// </summary>
        /// <param name="commercialMarkup"></param>
        public void FillCommercialMarkupInfo(List<CommercialMarkUp> commercialMarkup)
        {
            Settings.Logger.Info(" Fill Commercial Markup Info ");
            Driver.SwitchTo().DefaultContent();
            _extendPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendPage.GetTabLinkByText("Commercial Markup"), "Commercial Markup Tab");
            Driver.SwitchToFrame(_markupCommFrame, "Commercial frame");
            foreach (CommercialMarkUp markups in commercialMarkup)
            {
                _extendPage.GetTableActionElementByRelatedColumnValue(_markupCommTable, _headerTransaction, markups.KindOfTransaction,
                    "cmarkupPC").SetText(markups.MarkUpPercent, "Markup Percent");
                _extendPage.GetTableActionElementByRelatedColumnValue(_markupCommTable, _headerTransaction, markups.KindOfTransaction,
                    "cLimit").SetText(markups.MarkUpLimit, "Markup Limit");
            }
        }

        /// <summary>
        /// Verify Markup Scheme Details
        /// </summary>
        /// <param name="markupScheme"></param>
        public void VerifyMarkupSchemeDetails(CreateMarkUpScheme markupScheme)
        {
            Settings.Logger.Info(" Verify Markup Scheme Details ");
            _extendPage.RefreshAndSetText(_inputScheme, markupScheme.Scheme, "Scheme");
            Driver.WaitForReady();
            if (markupScheme.EffectiveDate != null)
            {
                Driver.DoubleClick(_effectiveDate, "Effective Date");
                _lov.SearchAndClickElement(markupScheme.EffectiveDate);
                Driver.WaitForReady();
                _extendPage.SwitchToContentFrame();
            }
            _jobReason.SetText(markupScheme.JobReason, "Job Reason");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputSchemeDesc, "Description", markupScheme.SchemeDesc);
            CommonUtil.VerifyElementValue(_disableScheme, "Disable", markupScheme.DisableScheme, true);
            CommonUtil.VerifyElementValue(_effectiveDate, "Effective Date", markupScheme.EffectiveDate);
            CommonUtil.VerifyElementValue(_jobReason, "Job Reason", markupScheme.JobReason);
            if (markupScheme.PartMarkUp != null)
            {
                Driver.SwitchToFrame(_markupPartFrame, "Part frame");
                foreach (PartMarkUp Pmarkup in markupScheme.PartMarkUp)
                {
                    CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_markupSchemeTable, _headerTransaction,
                        Pmarkup.KindOfTransaction, "pmarkupPC"), "Markup Percent", Pmarkup.MarkUpPercent, false, "value");
                    CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_markupSchemeTable, _headerTransaction,
                        Pmarkup.KindOfTransaction, "pLimit"), "Markup Limit", Pmarkup.MarkUpLimit, false, "value");
                }
            }
            if (markupScheme.LaborMarkUp != null)
            {
                Driver.SwitchTo().DefaultContent();
                _extendPage.SwitchToContentFrame();
                Driver.ScrollIntoViewAndClick(_extendPage.GetTabLinkByText("Labor Markup/Rate"), "Labor Markup/Rate Tab");
                Driver.SwitchToFrame(_markupLaborFrame, "Labor frame");
                foreach (LaborMarkUp Lmarkup in markupScheme.LaborMarkUp)
                {
                    CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_markupLaborTable, _headerTransaction,
                        Lmarkup.KindOfTransaction, "lmarkupPC"), "Markup Percent", Lmarkup.MarkUpPercent, false, "value");
                    CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_markupLaborTable, _headerTransaction,
                        Lmarkup.KindOfTransaction, "lLaborRate"), "Labor Rate", Lmarkup.LaborRate, false, "value");
                    CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_markupLaborTable, _headerTransaction,
                        Lmarkup.KindOfTransaction, "lLimit"), "Markup Limit", Lmarkup.MarkUpLimit, false, "value");
                }
            }
            if (markupScheme.CommercialMarkUp != null)
            {
                Driver.SwitchTo().DefaultContent();
                _extendPage.SwitchToContentFrame();
                Driver.ScrollIntoViewAndClick(_extendPage.GetTabLinkByText("Commercial Markup"), "Commercial Markup Tab");
                Driver.SwitchToFrame(_markupCommFrame, "Commercial frame");
                foreach (CommercialMarkUp Cmarkup in markupScheme.CommercialMarkUp)
                {
                    CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_markupCommTable, _headerTransaction,
                        Cmarkup.KindOfTransaction, "cmarkupPC"), "Markup Percent", Cmarkup.MarkUpPercent, false, "value");
                    CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_markupCommTable, _headerTransaction,
                        Cmarkup.KindOfTransaction, "cLimit"), "Markup Limit", Cmarkup.MarkUpLimit, false, "value");
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Markup Scheme
        /// </summary>
        /// <param name="markupScheme"></param>
        public void DeleteMarkupScheme(CreateMarkUpScheme markupScheme)
        {
            Settings.Logger.Info(" Delete Markup Scheme ");
            _extendPage.RefreshAndSetText(_inputScheme, markupScheme.Scheme, "Scheme");
            Driver.WaitForReady();
            _effectiveDate.SetText(markupScheme.EffectiveDate, "Effective Date");
            Driver.WaitForReady();
            _jobReason.SetText(markupScheme.JobReason, "Job Reason");
            Driver.WaitForReady();
            _inputScheme.ClickElement("Scheme ID", Driver);
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnDeleteButton();
            _extendPage.ActionRequiredWindow("Delete");
            Driver.WaitForSomeTime();
            if (markupScheme.ErrorMsg != null)
            {
                string error = _extendPage.GetErrorMessage();
                CommonUtil.AssertTrue(markupScheme.ErrorMsg, error);
            }
        }

        /// <summary>
        /// Verify MarkUp Scheme Deletion
        /// </summary>
        /// <param name="SchemeID"></param>
        public void VerifyMarkUpSchemeDeletion(string SchemeID)
        {
            Settings.Logger.Info(" Verify MarkUp Scheme Deletion");
            _extendPage.RefreshAndSetText(_inputScheme, SchemeID, "MarkUp scheme ID");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Assert.IsTrue(_extendPage._createDialog.VerifyElementDisplay(" Action Required Dialog "));
            _extendPage.ActionRequiredWindow("Cancel");
            Settings.Logger.Info("  Verified MarkUp Scheme Deletion");
        }

        /// <summary>
        /// Copy Markup Scheme
        /// </summary>
        /// <param name="existingScheme"></param>
        /// <param name="markupScheme"></param>
        /// <returns></returns>
        public string CopyMarkupScheme(string existingScheme, CopyMarkUpScheme markupScheme)
        {
            Settings.Logger.Info(" Copy Existing Markup Scheme ");
            _extendPage.SwitchToContentFrame();
            _inputScheme.SetText(existingScheme, "Existing Scheme");
            Driver.WaitForReady();
            _copyAllDate.SelectCheckBox("CheckBox Copy All date", markupScheme.CopyAllDate);
            if (markupScheme.EffectiveDate != null)
            {
                if (!markupScheme.EffectiveDate.Contains('/'))
                {
                    markupScheme.EffectiveDate = markupScheme.EffectiveDate.ToLower() == "now" ? DateTime.Now.ToString("MM/dd/yyyy") : DateTime.Now.AddDays(Convert.ToDouble(markupScheme.EffectiveDate)).ToString("MM/dd/yyyy");
                }
                _effectiveDate.SetText(markupScheme.EffectiveDate, "Effective Date");
                Driver.WaitForReady();
            }
            _copyAllReason.SelectCheckBox("CheckBox Copy All Reason", markupScheme.CopyAllReasons);
            _jobReason.SetText(markupScheme.JobReason, "Job Reason");
            Driver.WaitForReady();
            if (markupScheme.NewScheme == null || markupScheme.NewScheme.ToLower() == "random")
                markupScheme.NewScheme = CommonUtil.GetRandomStringWithSpecialChars(8);
            _newScheme.SetText(markupScheme.NewScheme, "New Scheme ID");
            Driver.WaitForReady();
            _newSchemeDesc.SetText(markupScheme.NewSchemeDesc, "New Scheme Description");
            Driver.WaitForReady();
            _newReason.SetText(markupScheme.NewJobReason, "New Job Reason");
            _newDate.SelectCheckBox("New Date", markupScheme.NewDate);
            if (markupScheme.NewEffectiveDate != null)
            {
                if (!markupScheme.NewEffectiveDate.Contains('/'))
                {
                    markupScheme.NewEffectiveDate = markupScheme.NewEffectiveDate.ToLower() == "now" ? DateTime.Now.ToString("MM/dd/yyyy") : DateTime.Now.AddDays(Convert.ToDouble(markupScheme.NewEffectiveDate)).ToString("MM/dd/yyyy");
                }
                _newEffDate.SetText(markupScheme.NewEffectiveDate, "New Effective Date");
                Driver.WaitForReady();
            }
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnSaveButton();
            Driver.WaitForReady();
            return markupScheme.NewScheme;
        }
    }
}