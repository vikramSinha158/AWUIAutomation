﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class PriceTypesPageActions : PriceTypesPage
    {
        public PriceTypesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create new Price Type
        /// </summary>
        /// <param name="priceTypes"></param>
        /// <returns>code</returns>
        public string CreateNewPriceType(PriceTypesObjects priceTypes)
        {
            string code = string.Empty;
            Settings.Logger.Info(" Create new Price Type ");
            if (!ExtendedPage.CheckDataExistenceAndGetActionCode(priceTypes.Code, ref code, "PriceTypesQuery", 6))
            {
                ExtendedPage.SwitchToTableFrame(_framePriceTypes);
                _inputCode.SetText(code, "Code");
                Driver.WaitForReady();
                _inputDescription.SetText(priceTypes.Description, "Description");
                Driver.WaitForReady();
                _inputAdjustmentPC.SetText(priceTypes.AdjustmentPC, "Adjustment PC");
                Driver.WaitForReady();
                _inputDiscountPC.SetText(priceTypes.DiscountPC, "Discount PC");
                Driver.WaitForReady();
                _inputDiscountDays.SetText(priceTypes.DiscountDays, "Discount Days");
                Driver.WaitForReady();
                _inputShipTerms.SetText(priceTypes.ShipTerms, "Ship Terms");
                Driver.WaitForReady();
                _inputTaxFlag.SelectCheckBox("Tax Flag", priceTypes.TaxFlag);
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                ExtendedPage.ClickOnSaveButton();
                Driver.WaitForReady();
                ExtendedPage.ClickOnRefreshButton();
                ExtendedPage.SwitchToTableFrame(_framePriceTypes);
                ExtendedPage.VerifyTableColumnContainValue(_tablePriceTypes, "Code", code);
                Driver.SwitchTo().DefaultContent();
            }
            return code;
        }
    }
}
