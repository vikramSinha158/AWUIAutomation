﻿using OpenQA.Selenium;
using System.Collections.Generic;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.ServiceOrder;

namespace AssetWorks.UI.M5.TestAutomation.Actions.ServiceOrder
{
    internal class ServiceOrderPageActions : ServiceOrderPage
    {
        internal ServiceOrderPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Service Order
        /// </summary>
        /// <param name="order"></param>
        /// <returns>PONo</returns>
        public string CreateServiceOrder(ServiceOrderObjects order)
        {
            Settings.Logger.Info(" Creating Service Order ");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _buttonNewPo.ClickElement("New PO",Driver);
            Driver.WaitForReady();
            _inputPoRefNo.SetText(order.PORefNo, "PO Ref No");
            Driver.WaitForReady();
            _inputVendorNo.SetText(order.VendorNo, "Vendor No");
            Driver.WaitForReady();
            if (order.ServiceOrderDetail != null)
                FillOrderLines(order.ServiceOrderDetail);
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            order.PONo = _inputPoNo.GetAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            return order.PONo;
        }

        /// <summary>
        /// Fill Order Lines
        /// </summary>
        /// <param name="list"></param>
        public void FillOrderLines(IList<ServiceOrderDetail> list)
        {
            Settings.Logger.Info(" Add Service Order Details ");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Order Lines"), "Order Lines");
            Driver.SwitchToFrame(_frameServicePO, "Service PO frame");
            foreach(ServiceOrderDetail detail in list)
            {
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableServicePO, "Service", "", 
                    "servcode", "ovalue").SetText(detail.Service, "Service");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableServicePO, "Service", detail.Service,
                    "poCost", "ovalue").SetText(detail.POCost, "POCost");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableServicePO, "Service", detail.Service,
                    "neededBy", "ovalue").SetText(detail.NeededBy, "Needed By");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableServicePO, "Service", detail.Service,
                    "chargeCode", "ovalue").SelectFilterValueHavingEqualValue(detail.ResvCode);
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableServicePO, "Service", detail.Service,
                    "typeNum", "ovalue").SetText(detail.ResvRefNo, "Resv Ref No");
                Driver.WaitForReady();
                _extendedPage.AddNotes(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableServicePO, "Service",
                    detail.Service, "noteBtn", "ovalue"), detail.Note);
                _extendedPage.SwitchToTableFrame(_frameServicePO);
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Service Order Details
        /// </summary>
        /// <param name="order"></param>
        public void VerifyServiceOrderDetails(ServiceOrderObjects order)
        {
            Settings.Logger.Info(" Verify Service Order Details ");
            _extendedPage.RefreshAndSetText(_inputPoNo, order.PONo, "Po No");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputPoRefNo, "Po Ref No", order.PORefNo);
            CommonUtil.VerifyElementValue(_inputVendorNo, "Vendor No", order.VendorNo);
            if (order.ServiceOrderDetail != null)
                VerifyOrderLines(order.ServiceOrderDetail);
        }

        /// <summary>
        /// Verify Order Lines
        /// </summary>
        /// <param name="list"></param>
        public void VerifyOrderLines(IList<ServiceOrderDetail> list)
        {
            Settings.Logger.Info(" Verify Service Order Details ");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Order Lines"), "Order Lines");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameServicePO, "Service PO frame");
            foreach (ServiceOrderDetail detail in list)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableServicePO, "Service", 
                    detail.Service, "poCost"), "PO Cost", detail.POCost, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableServicePO, "Service", 
                    detail.Service, "chargeCode"), "Resv Code", detail.ResvCode, true, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableServicePO, "Service",
                    detail.Service, "typeNum"), "Resv Ref No", detail.ResvRefNo, false, "value");
                _extendedPage.VerifyAddedNotes(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableServicePO, "Service",
                    detail.Service, "noteBtn"), detail.Note);
                _extendedPage.SwitchToTableFrame(_frameServicePO);
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Service Order Details
        /// </summary>
        /// <param name="order"></param>
        public void DeleteOrderLines(ServiceOrderObjects order)
        {
            Settings.Logger.Info(" Delete Service Order Details ");
            _extendedPage.RefreshAndSetText(_inputPoNo, order.PONo, "Po No");
            Driver.WaitForReady();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Order Lines"), "Order Lines");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameServicePO, "Service PO frame");
            if (order.ServiceOrderDetail != null)
            {
                foreach (ServiceOrderDetail detail in order.ServiceOrderDetail)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableServicePO, "Service", detail.Service, "desc").Click();
                    Driver.WaitForReady();
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.ClickOnDeleteButton();
                    _extendedPage.SwitchToTableFrame(_frameServicePO);
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
                Driver.WaitForReady();
            }
            else
                Driver.SwitchTo().DefaultContent();
        }
    }
}
