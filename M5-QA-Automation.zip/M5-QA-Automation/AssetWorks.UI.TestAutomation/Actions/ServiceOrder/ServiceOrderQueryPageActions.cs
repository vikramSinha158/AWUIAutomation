﻿using OpenQA.Selenium;
using System.Collections.Generic;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.ServiceOrder;

namespace AssetWorks.UI.M5.TestAutomation.Actions.ServiceOrder
{
    internal class ServiceOrderQueryPageActions : ServiceOrderQueryPage
    {
        internal ServiceOrderQueryPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Service Order Query
        /// </summary>
        /// <param name="query"></param>
        public void CreateServiceOrderQuery(ServiceOrderQueryDetail query)
        {
            Settings.Logger.Info(" Creating Service Order Query ");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputLocation.SetText(query.Location, "Location");
            Driver.WaitForReady();
            _inputVendor.SetText(query.VendorNo, "Vendor No");
            Driver.WaitForReady();
            _selectStatus.SelectFilterValueHavingEqualValue(query.Status);
            Driver.WaitForReady();
            _inputServiceOrder.SetText(query.ServiceOrder, "Service Order");
            Driver.WaitForReady();
            _inputServiceCode.SetText(query.ServiceCode, "Service Code");
            Driver.WaitForReady();
            _selectResvCode.SelectFilterValueHavingEqualValue(query.ResvCode);
            Driver.WaitForReady();
            _inputPoFromDate.SetText(query.PoFromDate, "From Date");
            Driver.WaitForReady();
            _inputPoToDate.SetText(query.PoToDate, "To Date");
            Driver.WaitForReady();
            _buttonRetrieve.ClickElement("Retrieve", Driver);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Service Order List
        /// </summary>
        /// <param name="oList"></param>
        public void VerifyServiceOrderList(IList<SOList> oList)
        {
            Settings.Logger.Info(" Verifying Service Order List ");
            _extendedPage.SwitchToTableFrame(_frameServicePOQry);
            Driver.WaitForReady();
            if (oList != null)
            {
                foreach(SOList item in oList)
                {
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePOList, "Service\r\nOrder No",
                        item.ServiceOrderNo, "poLoc", "value", "div"), "Location", item.Location, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePOList, "Service\r\nOrder No",
                        item.ServiceOrderNo, "totpoCost", "value", "div"), "Service PO Amt", item.ServicePOAmt, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePOList, "Service\r\nOrder No",
                        item.ServiceOrderNo, "status", "value", "div"), "Status", item.Status, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePOList, "Service\r\nOrder No",
                        item.ServiceOrderNo, "Vendor", "value", "div"), "Vendor", item.Vendor, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tablePOList, "Service\r\nOrder No",
                        item.ServiceOrderNo, "PORef", "value", "div"), "PO Ref", item.PORef, false, "value");
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Clear On Service Order Query
        /// </summary>
        public void VerifyClearOnServiceOrderQuery()
        {
            Settings.Logger.Info(" Verifying Clear On Service Order Query ");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _buttonClear.ClickElement("Clear", Driver);
            Driver.WaitForReady();
            CommonUtil.AssertTrue(true, string.IsNullOrEmpty(_inputLocation.GetAttribute("ovalue")));
            CommonUtil.AssertTrue(true, string.IsNullOrEmpty(_inputVendor.GetAttribute("ovalue")));
            CommonUtil.AssertTrue(true, string.IsNullOrEmpty(_inputServiceOrder.GetAttribute("ovalue")));
            CommonUtil.AssertTrue(true, string.IsNullOrEmpty(_inputServiceCode.GetAttribute("ovalue")));
            Driver.SwitchTo().DefaultContent();
        }
    }
}
