﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.TestSuite;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.TestSuite
{
    internal class DirectTestSuiteResultPageActions : DirectTestSuiteResultPage
    {
        public DirectTestSuiteResultPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Direct Test Suite Result
        /// </summary>
        /// <param name="DataObject"></param>
        public void CreateDirectTestSuiteResult(DirectTestSuite DataObject)
        {
            LaunchDirectTestSuite(DataObject);
            if (DataObject.DirectTestSuiteTable != null)
            {
                FillDirectTestSuiteTable(DataObject);
            }
            if (DataObject.MeterInformation != null)
            {
                UpdateMeterInformation(DataObject.MeterInformation);
            }
            _extendpage.Save();
            Settings.Logger.Info("Created Direct Test Suite Resulte");
        }

        /// <summary>
        /// Launch Direct Test Suite
        /// </summary>
        /// <param name="DataObject"></param>
        public void LaunchDirectTestSuite(DirectTestSuite DataObject)
        {
            _extendpage.ClickOnRefreshButton();
            _extendpage.SwitchToContentFrame();
            _loc.SetText(DataObject.TestSuiteLocation, "TestSuiteLocation");
            Driver.WaitForReady();
            _itemName.ClickDropDownValuebyContainingText(DataObject.ItemName);
            Driver.WaitForReady();
            _unitNo.SetText(DataObject.ItemNo, "ItemNo");
            Driver.WaitForReady();
            _testSuiteName.SetText(DataObject.TestSuiteNo, "TestSuiteNo");
            Driver.WaitForReady();
            _refNo.SetText(DataObject.RefNo, "RefNo");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Fill Direct Test Suite Table
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillDirectTestSuiteTable(DirectTestSuite DataObject)
        {
            Driver.SwitchToFrame(_directTestResultsFrame, "Direct Test Results Frame");
            List<DirectTestSuiteTable> DirectTestSuiteTableRows = DataObject.DirectTestSuiteTable;
            foreach (DirectTestSuiteTable DirectTestSuiteTable in DirectTestSuiteTableRows)
            {
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_testTable, "ID Number", DirectTestSuiteTable.IDNumber, "recordedval").SetText(DirectTestSuiteTable.Value, "recordedval");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_testTable, "ID Number", DirectTestSuiteTable.IDNumber, "estcost").SetText(DirectTestSuiteTable.Estcost, "Estcost");
                if (!string.IsNullOrEmpty(DirectTestSuiteTable.Note))
                {
                    _extendpage.AddNotes(_extendpage.GetTableActionElementByRelatedColumnValue(_testTable, "ID Number", DirectTestSuiteTable.IDNumber, "NOTE"), DirectTestSuiteTable.Note);
                    _extendpage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_directTestResultsFrame, "Direct Test Results Frame");
                }
                if (DirectTestSuiteTable.AttachmentData != null)
                {
                    _extendpage.Save();
                    Driver.WaitForReady();
                    _extendpage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_directTestResultsFrame, "Direct Test Results Frame");
                    IWebElement AttachElement = _extendpage.GetTableActionElementByRelatedColumnValue(_testTable, "ID Number", DirectTestSuiteTable.IDNumber, "btn");
                    AttachElement.ClickElement("Attach Link", Driver);
                    Driver.WaitForReady();
                    _extendpage.AttachFile(DirectTestSuiteTable.AttachmentData);
                    Driver.SwitchToFrame(_directTestResultsFrame, "Direct Test Results Frame");
                }
            }
            if (DataObject.TestSuiteStatus != null)
            {
                _extendpage.ClickOnCompletionButton();
            }
        }

        /// <summary>
        /// Verify Direct Test Suite Result Page Actions
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyDirectTestSuiteResulte(DirectTestSuite DataObject)
        {
            int RowNum = 0;
            Driver.SwitchTo().DefaultContent();
            if(DataObject.TestSuiteResult != null) VerifyDirectTestSuiteResult(DataObject);
            if (DataObject.TestSuiteStatus != null) VerifyDirectTestSuiteStatus(DataObject);
            if (DataObject.LaunchDirectTestSuite) { LaunchDirectTestSuite(DataObject); }
            Driver.PageScrollUp();
            CommonUtil.VerifyElementValue(_loc, "TestSuiteLocation", DataObject.TestSuiteLocation);
            CommonUtil.VerifyElementValue(_itemName, $"ItemName { DataObject.ItemName}", DataObject.ItemName);
            CommonUtil.VerifyElementValue(_unitNo, $"ItemNo { DataObject.ItemNo}", DataObject.ItemNo);
            CommonUtil.VerifyElementValue(_testSuiteName, "_testSuiteName", DataObject.TestSuiteNo);
            CommonUtil.VerifyElementValue(_refNo, "RefNo", DataObject.RefNo);
            if (DataObject.MeterInformation != null) {
                CommonUtil.VerifyElementValue(_meterreading1, "_testSuiteName", DataObject.MeterInformation.MeterReading1);
                Driver.WaitForReady();
                CommonUtil.VerifyElementValue(_meterreading2, "RefNo", DataObject.MeterInformation.MeterReading2,false, "value");
                Settings.Logger.Info($"Successfully Verified MeterInformation in Direct Test Suite");
            }
            if (DataObject.DirectTestSuiteTable != null)
            {
                Driver.SwitchToFrame(_directTestResultsFrame, "Direct Test Results Frame");
                List<DirectTestSuiteTable> DirectTestSuiteTableRows = DataObject.DirectTestSuiteTable;
                foreach (DirectTestSuiteTable DirectTestSuiteTable in DirectTestSuiteTableRows)
                {
                    Driver.WaitForReady();
                    CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_testTable, "ID Number", DirectTestSuiteTable.IDNumber, "recordedval"), "recordedval", DirectTestSuiteTable.Value, false, "value");
                    if (DirectTestSuiteTable.VerifyWorkRequest)
                    {
                        string WorkRequestPath = $"passed${RowNum}";
                        VerifyWorkRequestGenerated(_extendpage.GetElementForInput(WorkRequestPath, "id", "div"), DirectTestSuiteTable.IsWorkRequestGenerated);
                    }
                    if (!string.IsNullOrEmpty(DirectTestSuiteTable.Note))
                    {
                        _extendpage.VerifyAddedNotes(_extendpage.GetTableActionElementByRelatedColumnValue(_testTable, "ID Number", DirectTestSuiteTable.IDNumber, "NOTE"), DirectTestSuiteTable.Note);
                        _extendpage.SwitchToContentFrame();
                        Driver.SwitchToFrame(_directTestResultsFrame, "Direct Test Results Frame");
                    }
                    if (DirectTestSuiteTable.AttachmentData != null)
                    {
                        string ActalIconState = _extendpage.GetTableActionElementByRelatedColumnValue(_testTable, "ID Number", DirectTestSuiteTable.IDNumber, "btn").GetAttribute("hasatt");
                        CommonUtil.AssertTrue<string>("Y", ActalIconState);
                        _extendpage.GetTableActionElementByRelatedColumnValue(_testTable, "ID Number", DirectTestSuiteTable.IDNumber, "btn").ClickElement("Attach Link", Driver);
                        Driver.WaitForReady();
                        _extendpage.VerifyAttachedDocs(DataObject.TotalAttachments);
                    }
                    RowNum++;
                }
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info($"Successfully Verified Direct Test Suite Result");
        }

        /// <summary>
        /// Delete Direct Test Suite Attachments
        /// </summary>
        /// <param name="DataObject"></param>
        public void DeleteDirectTestSuiteAttachments(DirectTestSuite DataObject)
        {
            Driver.SwitchTo().DefaultContent();
            LaunchDirectTestSuite(DataObject);
            Driver.SwitchToFrame(_directTestResultsFrame, "Direct Test Results Frame");
            List<DirectTestSuiteTable> DirectTestSuiteTableRows = DataObject.DirectTestSuiteTable;
            foreach (DirectTestSuiteTable DirectTestSuiteTable in DirectTestSuiteTableRows)
            {
                if (DirectTestSuiteTable.AttachmentData != null)
                {
                    //Check Attachment Link Icon shows Attachment Exists
                    string ActalIconState = _extendpage.GetTableActionElementByRelatedColumnValue(_testTable, "ID Number", DirectTestSuiteTable.IDNumber, "btn").GetAttribute("hasatt");
                    if (ActalIconState == "Y")
                    {
                        _extendpage.GetTableActionElementByRelatedColumnValue(_testTable, "ID Number", DirectTestSuiteTable.IDNumber, "btn").ClickElement("Attach Link", Driver);
                        _extendpage.DeleteAllAttachments();
                    }

                }
            }
            Settings.Logger.Info($"Successfully Deleted Attachement from Direct Test Suite Result Table");
        }

        /// <summary>
        /// Check And Delete Attachment Record
        /// </summary>
        /// <param name="DataObject"></param>
        public void CheckAndDeleteAttachmentRecord(DirectTestSuite DataObject)
        {
            LaunchDirectTestSuite(DataObject);
            Driver.SwitchToFrame(_directTestResultsFrame, "Direct Test Results Frame");
            List<DirectTestSuiteTable> DirectTestSuiteTableRows = DataObject.DirectTestSuiteTable;
            foreach (DirectTestSuiteTable DirectTestSuiteTable in DirectTestSuiteTableRows)
            {
                _extendpage.GetTableActionElementByRelatedColumnValue(_testTable, "ID Number", DirectTestSuiteTable.IDNumber, "recordedval").Clear();
                if (DirectTestSuiteTable.AttachmentData != null)
                {
                    IWebElement AttachElement = _extendpage.GetTableActionElementByRelatedColumnValue(_testTable, "ID Number", DirectTestSuiteTable.IDNumber, "btn");
                    string ActalIconState = _extendpage.GetTableActionElementByRelatedColumnValue(_testTable, "ID Number", DirectTestSuiteTable.IDNumber, "btn").GetAttribute("hasatt");
                    if (ActalIconState == "Y")
                    {
                        AttachElement.ClickElement("Attach Link", Driver);
                        _extendpage.DeleteAllAttachments();
                        Settings.Logger.Info($"Checked and deleted Attached file record ");
                    }
                }
            }
            _extendpage.Save();
        }

        /// <summary>
        /// Clear Value Record Fromm Direct Test Suite Result
        /// </summary>
        /// <param name="DataObject"></param>
        public void ClearValueRecordFrommDirectTestSuiteResult(DirectTestSuite DataObject)
        {
            Driver.SwitchTo().DefaultContent();
            LaunchDirectTestSuite(DataObject);
            Driver.SwitchToFrame(_directTestResultsFrame, "Direct Test Results Frame");
            List<DirectTestSuiteTable> DirectTestSuiteTableRows = DataObject.DirectTestSuiteTable;
            foreach (DirectTestSuiteTable DirectTestSuiteTable in DirectTestSuiteTableRows)
            {
                _extendpage.GetTableActionElementByRelatedColumnValue(_testTable, "ID Number", DirectTestSuiteTable.IDNumber, "recordedval").Clear();
                Driver.WaitForReady();
            }
            _extendpage.Save();
        }

        /// <summary>
        /// Verify Direct Test Suite Result
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyDirectTestSuiteResult(DirectTestSuite DataObject)
        {
            if (DataObject.TestSuiteResult != null)
            {
                Driver.PageScrollUp();
                _extendpage.SwitchToContentFrame();
                CommonUtil.VerifyElementValue(_testSuiteResult, "TestSuiteLocation", DataObject.TestSuiteResult);
                Settings.Logger.Info($"Verified Test Suite { DataObject.TestSuiteNo } Result as { DataObject.TestSuiteResult}");
                Driver.SwitchTo().DefaultContent();
            }
        }

        /// <summary>
        /// Verify Direct Test Suite Status
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyDirectTestSuiteStatus(DirectTestSuite DataObject)
        {
            if (DataObject.TestSuiteStatus != null)
            {
                Driver.PageScrollUp();
                _extendpage.SwitchToContentFrame();
                CommonUtil.VerifyElementValue(_testSuitStatus, "TestSuiteStatus", DataObject.TestSuiteStatus);
                Settings.Logger.Info($"Verified Test Suite { DataObject.TestSuiteNo } Status as { DataObject.TestSuiteStatus}");
            }
        }

        /// <summary>
        /// Verify Work Request Generated
        /// </summary>
        /// <param name="WRElement"></param>
        /// <param name="WaorkRwquestStatus"></param>
        public void VerifyWorkRequestGenerated(IWebElement WRElement, bool WaorkRwquestStatus)
        {
            Driver.PageScrollUp();
            string WorkRequestValue = WRElement.GetAttribute("value");
            if (WorkRequestValue != null) { Settings.TestSuiteWorkRequest.Add(WorkRequestValue); }
            Assert.AreEqual(String.IsNullOrEmpty(WorkRequestValue), WaorkRwquestStatus);
            Settings.Logger.Info($"Verified WorkRequest  { WorkRequestValue} for Failed results ");
        }

        /// <summary>
        /// Update Meter Information
        /// </summary>
        /// <param name="MeterInformation"></param>
        public void UpdateMeterInformation(MeterInformation MeterInformation)
        {
            Settings.Logger.Info($"Update  MeterInformation  ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _meterreading1.SetText(MeterInformation.MeterReading1, "_meterreading1");
            Driver.WaitForReady();
            _meterreading2.SetText(MeterInformation.MeterReading2, "MeterReading2");
        }
    }
}
