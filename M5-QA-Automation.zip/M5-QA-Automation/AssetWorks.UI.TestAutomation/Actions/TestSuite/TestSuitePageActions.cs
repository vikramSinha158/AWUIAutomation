﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.TestSuite;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions.TestSuite
{
    internal class TestSuitePageActions : TestSuitePage
    {
        public TestSuitePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Test Suite
        /// </summary>
        /// <param name="TestSuite"></param>
        /// <returns></returns>
        public string CreateTestSuite(TestSuiteDetails TestSuite)
        {
            string TestSuiteName = string.Empty;
            _extendpage.SwitchToContentFrame();
            if (!_extendpage.CheckDataExistenceAndGetActionCode(TestSuite.TestSuiteNo, ref TestSuiteName, "TestSuiteQuery"))
            {
                TestSuite.TestSuiteNo = TestSuiteName;
                FillTestSuiteDetails(TestSuite);
                if (TestSuite.TestSuiteTable != null)
                {
                    FillTestSuiteTable(TestSuite.TestSuiteTable);
                }
            }
            Driver.WaitForReady();
            _extendpage.Save();
            Driver.WaitForReady();
            Settings.Logger.Info($" Successfully Creatted Test Suite { TestSuiteName} ");
            return TestSuiteName;
        }

        /// <summary>
        /// Fill Test Suite Details
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillTestSuiteDetails(TestSuiteDetails DataObject)
        {
            Driver.WaitForReady();
            _testSuiteName.SetText(DataObject.TestSuiteNo, "TestSuite Name");
         
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow("Create");
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _testSuiteNameDesc.SetText(DataObject.TestSuiteNameDesc, "TestSuiteNameDesc");
            Driver.WaitForReady();
            _enabledFl.ClickDropDownValuebyContainingText(DataObject.EnabledFl);
            Driver.WaitForReady();
            _extendpage.SetTextWithLovOption(_nextTestSuiteName, DataObject.NextTestSuiteName);
            Driver.WaitForReady();
            _linkTestSuiteName.SetText(DataObject.LinkTestSuiteName, "LinkTestSuiteName");
            Driver.WaitForReady();
            _JobCode.SetText(DataObject.JobCode, "JobCode");
            Driver.WaitForReady();
            _jobReason.SetText(DataObject.JobReason, "JobReason");
            Driver.WaitForReady();
            _jobPriority.SetText(DataObject.JobPriority, "JobPriority");
            Settings.Logger.Info( " Added Test Suite Details ");
        }

        /// <summary>
        /// Fill Test Suite Table
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillTestSuiteTable(TestSuiteTable DataObject)
        {
            _extendpage.SwitchToContentFrameAndTabClick(_testTab);
            _extendpage.AddRecordsInTable(_testTable, _testSuiteTestsFrame, DataObject.TestSuiteTableKey);
            Settings.Logger.Info( " Added Test Suite Table ");
        }

        /// <summary>
        /// Verify Test Suite
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyTestSuite(TestSuiteDetails DataObject)
        {
            _extendpage.RefreshAndSetText(_testSuiteName, DataObject.TestSuiteNo, " TestSuite ");
            CommonUtil.VerifyElementValue(_testSuiteName, "TestSuite Name ", DataObject.TestSuiteNo);
            CommonUtil.VerifyElementValue(_testSuiteNameDesc, "TestSuiteNameDesc", DataObject.TestSuiteNameDesc);
            CommonUtil.VerifyElementValue(_enabledFl, "EnabledFl", DataObject.EnabledFl);
            CommonUtil.VerifyElementValue(_nextTestSuiteName, "NextTestSuiteName", DataObject.NextTestSuiteName);
            CommonUtil.VerifyElementValue(_linkTestSuiteName, "LinkTestSuiteName", DataObject.LinkTestSuiteName);
            CommonUtil.VerifyElementValue(_JobCode, "JobCode", DataObject.JobCode);
            CommonUtil.VerifyElementValue(_jobReason, "JobReason", DataObject.JobReason);
            CommonUtil.VerifyElementValue(_jobPriority, "JobReason", DataObject.JobPriority);
            if (DataObject.TestSuiteTable != null)
            {
                _extendpage.SwitchToContentFrameAndTabClick(_testTab);
                _extendpage.VerifyRecordsInTable(_testTable, _testSuiteTestsFrame, DataObject.TestSuiteTable.TestSuiteTableKey);
            }
            Settings.Logger.Info(" Successfully Verified TestSuiteDetails");
        }

        /// <summary>
        /// Verify Test Suite Deletion
        /// </summary>
        /// <param name="TestSuiteNumber"></param>
        public void VerifyTestSuiteDeletion(string TestSuiteNumber)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.VerifyCodeDeletion(_testSuiteName, TestSuiteNumber, "TestSuiteNumber");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// UpdateTestSuite
        /// </summary>
        /// <param name="DataObject"></param>
        /// <param name="TestSuiteName"></param>
        public void UpdateTestSuite(TestSuiteDetails DataObject, string TestSuiteName)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_testSuiteName, TestSuiteName, " TestSuiteName ");
            FillTestSuiteDetails(DataObject);
            if (DataObject.TestSuiteTable != null)
            {
                _extendpage.SwitchToContentFrameAndTabClick(_testTab);
                _extendpage.AddRecordsInTable(_testTable, _testSuiteTestsFrame, DataObject.TestSuiteTable.TestSuiteTableKey);
            }
            Driver.WaitForReady();
            _extendpage.Save();
            Driver.WaitForReady();
            Settings.Logger.Info(" Updated Test Suite ");
        }
    }  
}
