﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.TestSuite;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.TestSuite
{
    internal class TestSuiteGroupPageActions : TestSuiteGroupPage
    {
        public TestSuiteGroupPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Test Group
        /// </summary>
        /// <param name="TestSuitGroup"></param>
        /// <returns></returns>
        public string CreateTestGroup(TestSuitGroup TestSuitGroup)
        {
            Settings.Logger.Info(" Create a new Test Suit Group ");
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();        
            if (TestSuitGroup.TestGroupName == null)
                TestSuitGroup.TestGroupName = CommonUtil.GetRandomStringWithSpecialChars().ToUpper();
            _tSGroup.SetText(TestSuitGroup.TestGroupName, "TestGroupName");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow("Create");
            Driver.WaitForReady();
            _extendpage.Save();
            Settings.Logger.Info($" Successfully Creatted Test Suite Group { TestSuitGroup.TestGroupName} ");
            return TestSuitGroup.TestGroupName;
        }

        /// <summary>
        ///Move Test Suit Groupe List
        /// </summary>
        /// <param name="TestSuitGroup"></param>
        public void MoveTestSuitGroupeList(TestSuitGroup TestSuitGroup)
        {
            Settings.Logger.Info(" Moving  Test Suit List  Group ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_tSGroup, TestSuitGroup.TestGroupName, "TestGroupName");
            Driver.SwitchToFrame(_tSGroupMaintFrame, "Test suit Group List Frame");
            if (TestSuitGroup.TestSuitesNootincluded != null)
            {
                Driver.WaitForReady();
                _extendpage.SelectMultipleItemFromList(_tsgListLeft, _tsgListMoveRight, TestSuitGroup.TestSuitesNootincluded);
            }
            if (TestSuitGroup.TestSuitesinGroup != null)
            {
                Driver.WaitForReady();
                _extendpage.SelectMultipleItemFromList(_tsgListRight, _tsgListMoveLeft, TestSuitGroup.TestSuitesinGroup);
            }
            _extendpage.Save();
        }

        /// <summary>
        /// Verify Test Suit Groupe List
        /// </summary>
        /// <param name="TestSuitGroup"></param>
        public void VerifyTestSuitGroupeList(TestSuitGroup TestSuitGroup)
        {
            Settings.Logger.Info(" Verifying Test Suit List  Group ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_tSGroup, TestSuitGroup.TestGroupName, "TestGroupName");
            Driver.SwitchToFrame(_tSGroupMaintFrame, "Test suit Group List Frame");
            _tsgListRight.ClickElement("List", Driver);
            Driver.WaitForReady();
            List<string> ActualTSGListValues = _tsgListRight.GetDropdownValueList();
            if (ActualTSGListValues != null)
            {
                bool AsseInGroupStatus = CommonUtil.CompareList<string>(TestSuitGroup.ExpactedTestSuitesinGroup, ActualTSGListValues);
                Assert.IsTrue(AsseInGroupStatus, "Expacted in group data list does not match with Actual group list ");
            }
            else { Assert.Fail("Expacted in group data list does not match with Actual group list,Actual group lis found blank"); }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Test Suit Group Deletion
        /// </summary>
        /// <param name="TestGroupName"></param>
        public void VerifyTestSuitGroupDeletion(string TestGroupName)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.VerifyCodeDeletion(_tSGroup, TestGroupName, "TestGroupName");        
        }
    }
}
