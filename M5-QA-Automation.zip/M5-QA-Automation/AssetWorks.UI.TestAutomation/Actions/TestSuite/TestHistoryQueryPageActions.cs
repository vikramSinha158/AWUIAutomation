﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.TestSuite;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.TestSuite
{
    internal class TestHistoryQueryPageActions : TestHistoryQueryPage
    {
        public TestHistoryQueryPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Retrieve Test Query History
        /// </summary>
        /// <param name="DataObject"></param>
        public void RetrieveTestQueryHistory(TestHistoryQueryDetail DataObject)
        {
            Settings.Logger.Info($"Retrieve Test History Query");
            _extendpage.SwitchToContentFrame();
            _historyItemName.ClickDropDownValuebyContainingText(DataObject.HistoryItemNo);
            _historyItemNo.SetText(DataObject.HistoryItemNo, "ItemNo");
            Driver.WaitForReady();
            _testSuiteName.SetText(DataObject.TestSuiteNo, "TestSuiteNo");
            Driver.WaitForReady();
            _fromDate.SetText(CommonUtil.GenerateRandomDateString(-2), "FromDate");
            Driver.WaitForReady();
            _toDate.SetText(CommonUtil.GenerateRandomDateString(2), "ToDate");
            Driver.WaitForReady();
            _retrieve.ClickElement("Retrieve",Driver);
            Settings.Logger.Info("Retrieve Test Query History");
        }

        /// <summary>
        /// Verify Test History  Query
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyTestHistoryQuery(TestHistoryQueryDetail DataObject)
        {
            Settings.Logger.Info($"Verifying Test History Query");
            int RowNum = 0;
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_testHistoryFrame, "_testHistoryFrame");
            List<HistoryTestSuiteTable> TestHistoryQueryTableRows = DataObject.HistoryTestSuiteTable;
            foreach (HistoryTestSuiteTable TestHistoryQueryTable in TestHistoryQueryTableRows)
            {
                Driver.WaitForReady();
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_testHistoryTable, "Tested Label", TestHistoryQueryTable.TestedLabel, "iUnitNo"), "iUnitNo", TestHistoryQueryTable.ItemNo, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_testHistoryTable, "Tested Label", TestHistoryQueryTable.TestedLabel, "iTestSuiteName"), "TestSuiteName", DataObject.TestSuiteNo, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_testHistoryTable, "Tested Label", TestHistoryQueryTable.TestedLabel, "iPassedFl"), "Status", TestHistoryQueryTable.Status, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_testHistoryTable, "Tested Label", TestHistoryQueryTable.TestedLabel, "iLabel"), "TestedLabel", TestHistoryQueryTable.TestedLabel, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_testHistoryTable, "Tested Label", TestHistoryQueryTable.TestedLabel, "iRecordedVal"), "RecordedValue", TestHistoryQueryTable.RecordedValue, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_testHistoryTable, "Tested Label", TestHistoryQueryTable.TestedLabel, "iStatus"), "LabelStatus", TestHistoryQueryTable.LabelStatus, false, "value");
                if (TestHistoryQueryTable.LabelStatus.Equals("REJECTED"))
                {
                    string WorkRequestPath = $"WREQ${RowNum}";
                    string ActualWorkRequestNumber = _extendpage.GetElementForInput(WorkRequestPath, "id", "div").GetText("Workrequest");
                    CommonUtil.AssertTrue<string>(Settings.TestSuiteWorkRequest[RowNum].ToString(), ActualWorkRequestNumber);
                } 
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_testHistoryTable, "Tested Label", TestHistoryQueryTable.TestedLabel, "iRefNo"), "RefNo", DataObject.RefNo, false, "value");
                RowNum++;
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info($"Successfully Verified Test History Query");
        }
    }
    
}
