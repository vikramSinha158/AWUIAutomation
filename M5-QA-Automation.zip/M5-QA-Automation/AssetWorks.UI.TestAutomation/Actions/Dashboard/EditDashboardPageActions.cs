﻿using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Dashboard;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Dashboard
{
    internal class EditDashboardPageActions : EditDashboardPage
    {
        internal EditDashboardPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create User/Role For Dashboards
        /// </summary>
        /// <param name="dataobject"></param>
        /// <returns></returns>
        public EditDashboardObjects CreateUserRoleForDashboards(EditDashboardObjects dataobject)
        {            
            string[] queryparam = { dataobject.UserRole, dataobject.DashboardName };         
            if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection,
                "EditDashboardQuery", queryparam, Settings.DBType))
            {
                Settings.Logger.Info($" Creating a UserRole:{dataobject.UserRole},DashboardName:{dataobject.DashboardName}");
                _extendedPage.SwitchToContentFrame();
                Driver.WaitForReady();
                _userRole.SendKeys(dataobject.UserRole);
                Driver.WaitForReady();
                _userRole.SendKeys(Keys.Enter);
                Driver.WaitForReady();
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                _applicationUser.ClickElement("Application User", Driver);              
                _lov.SelectFirstTableRecord();
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
                _newDashBtn.ClickElement("", Driver);
                Driver.SwitchTo().DefaultContent();
                _dashNamePopup.SetText(dataobject.DashboardName, "");
                _extendedPage._OkBtn.ClickElement("Ok", Driver);
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_dashFrame, "Dashboard frame");
                int i=0;
                foreach (KPITable tabledata in dataobject.KPITable)
                {
                    _extendedPage.GetElementForInput($"{KPI}{i}").SetText(tabledata.KPI, "KPI");
                    Driver.WaitForReady();
                    _extendedPage.GetElementForInput($"{Title}{i}").SetText(tabledata.Title, "Title");
                    i++;
                }               
                _extendedPage.Save();             
                Assert.IsFalse(CommonUtil.CheckDataExistWithMultipleParams(Settings.connection,
                "EditDashboardQuery", queryparam, Settings.DBType));
                Settings.Logger.Info($"  UserRole:{dataobject.UserRole} DashboardName:{dataobject.DashboardName} created successfully");
            }
            else
            {
                Settings.Logger.Info($"Data already exists for  User:{dataobject.UserRole} and DashboardName:{dataobject.DashboardName}");

            }
            return dataobject;
        }

    }
}
