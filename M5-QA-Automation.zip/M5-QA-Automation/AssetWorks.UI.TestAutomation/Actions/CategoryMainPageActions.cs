﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class CategoryMainPageActions : CategoryMainPage
    {
        public CategoryMainPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Category Code
        /// </summary>
        /// <param name="categoryObj"></param>
        /// <returns>Category Code</returns>
        public string CreateCategoryCode(CategoryMainObjects categoryObj)
        {
            string code = string.Empty;
            if (!ExtendedPage.CheckDataExistenceAndGetActionCode(categoryObj.CategoryCode, ref code, "CategoryCodeQuery", 10))
            {
                Settings.Logger.Info(" Creating a new Category ");
                _inputCategoryCode.SetText(code, "Category Code", Driver, ExtendedPage._contentFrame, "content frame");
                Driver.WaitForReady();
                if (ExtendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                    ExtendedPage.ClickOnDialogBoxButton("Create");
                ExtendedPage.SwitchToContentFrame();
                _inputCategoryDesc.SetText(categoryObj.CategoryDesc, "Category Desc");
                Driver.WaitForReady();
                _selectDisabled.SelectFilterValueHavingEqualValue(categoryObj.CateDisabled);
                Driver.WaitForReady();
                if (categoryObj.DetailsInformation != null)
                    UpdateDetailsInformationTab(categoryObj.DetailsInformation);
                ExtendedPage.VerifyRecordCreatedSuccess(_inputCategoryCode, _inputCategoryDesc, code, "Category No");
            }
            return code;
        }

        /// <summary>
        /// Update Details Information Tab
        /// </summary>
        /// <param name="detailsObj"></param>
        public void UpdateDetailsInformationTab(DetailsInformation detailsObj)
        {
            Settings.Logger.Info(" Updating Category Details Information ");
            _inputMaintRepairUnits.SetText(detailsObj.MaintRepairUnits, "Maint Repair Units");
            Driver.WaitForReady();
            _inputOffRoadUse.SetText(detailsObj.OffRoadUse, "Off Road Use");
            Driver.WaitForReady();
            _inputAge.SetText(detailsObj.Age, "Age");
            Driver.WaitForReady();
            _inputMeter1.SetText(detailsObj.Meter1, "Meter 1");
            Driver.WaitForReady();
            _inputMeter2.SetText(detailsObj.Meter2, "Meter 2");
            Driver.WaitForReady();
            _inputLTDMaintCost.SetText(detailsObj.LTDMaintCost, "LTD Maint Cost");
            Driver.WaitForReady();
            _inputBaseUnitCost.SetText(detailsObj.BaseUnitCost, "Base Unit Cost");
            Driver.WaitForReady();
            _inputInflationFactor.SetText(detailsObj.InflationFactor, "Inflation Factor");
            Driver.WaitForReady();
            _inputLeadTime.SetText(detailsObj.LeadTime, "Lead Time");
            Driver.WaitForReady();
            _inputDepreciationTerm.SetText(detailsObj.DepreciationTerm, "Depreciation Term");
            Driver.WaitForReady();
            _inputSalvage.SetText(detailsObj.Salvage, "Salvage");
            Driver.WaitForReady();
            _selectDepreciationType.SelectFilterValueHavingEqualValue(detailsObj.DepreciationType);
            Driver.WaitForReady();
            _inputRate.SetText(detailsObj.Rate, "Rate");
            Driver.WaitForReady();
            _inputFinancingTerm.SetText(detailsObj.FinancingTerm, "Financing Term");
            Driver.WaitForReady();
            _selectInterestType.SelectFilterValueHavingEqualValue(detailsObj.InterestType);
            Driver.WaitForReady();
        }
    }
}
