﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Zone;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Zone
{
    internal class ZoneClassMaintenancePageActions : ZoneClassMaintenancePage
    {
        public ZoneClassMaintenancePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Move All Asset Class Codes Right
        /// </summary>
        /// <param name="ZoneClass"></param>
        public void MoveAllAssetClassCodesRight(string ZoneClass)
        {
            MoveAllZoneClassMaintenance(ZoneClass, _zoneCLASSFrame, _catClassListLeft, _catClassListMoveRight);
            Settings.Logger.Info(" Move All Asset Class Codes Right");
        }

        /// <summary>
        /// Move All Asset Class Codes Left
        /// </summary>
        /// <param name="ZoneClass"></param>
        public void MoveAllAssetClassCodesLeft(string ZoneClass)
        {
            MoveAllZoneClassMaintenance(ZoneClass, _zoneCLASSFrame, _catClassListRight, _catClassListMoveLeft);
            Settings.Logger.Info("  Move All Asset Class Codes Left ");
        }

        /// <summary>
        /// Move All Category Codes Right
        /// </summary>
        /// <param name="ZoneClass"></param>
        public void MoveAllCategoryCodesRight(string ZoneClass)
        {
            MoveAllZoneClassMaintenance(ZoneClass, _zoneCategoryFrame, _categoryListLeft, _categoryListMoveRight,true);
            Settings.Logger.Info("  Move All Category Codes Right ");
        }

        /// <summary>
        /// Verify Category Codes Move Right
        /// </summary>
        /// <param name="ZoneClass"></param>
        public void VerifyCategoryCodesMoveRight(string ZoneClass)
        {
            VerifyZoneClassMaintenanceMoveCodes(ZoneClass, _zoneCategoryFrame, _categoryListLeft,true);
            Settings.Logger.Info(" Successfully Verified Category Codes Moved Right ");
        }

        /// <summary>
        /// Move All Category Codes Left
        /// </summary>
        /// <param name="ZoneClass"></param>
        public void MoveAllCategoryCodesLeft(string ZoneClass)
        {
            MoveAllZoneClassMaintenance(ZoneClass, _zoneCategoryFrame, _categoryListRight, _categoryListMoveLeft, true);
            Settings.Logger.Info("  Move All Category Codes Left ");
        }

        /// <summary>
        /// Verify Category Codes Move Left
        /// </summary>
        /// <param name="ZoneClass"></param>
        public void VerifyCategoryCodesMoveLeft(string ZoneClass)
        {
            VerifyZoneClassMaintenanceMoveCodes(ZoneClass, _zoneCategoryFrame, _categoryListRight, true);
            Settings.Logger.Info(" Successfully Verified Category Codes Moved Left");
        }

        /// <summary>
        /// Verify Asset Class Codes Move Right
        /// </summary>
        /// <param name="ZoneClass"></param>
        public void VerifyAssetClassCodesMoveRight(string ZoneClass)
        {
            VerifyZoneClassMaintenanceMoveCodes(ZoneClass, _zoneCLASSFrame, _catClassListLeft);
            Settings.Logger.Info(" Successfully Verified  Asset Class Codes Moved Right ");
        }

        /// <summary>
        /// Verify Asset Class Codes Move Left
        /// </summary>
        /// <param name="ZoneClass"></param>
        public void VerifyAssetClassCodesMoveLeft(string ZoneClass)
        {
            VerifyZoneClassMaintenanceMoveCodes(ZoneClass, _zoneCLASSFrame, _catClassListRight);
            Settings.Logger.Info(" Successfully Verified  Asset Class Codes Moved Left");
        }

        /// <summary>
        /// Verify Zone Class Maintenance Move Codes
        /// </summary>
        /// <param name="ZoneClass"></param>
        /// <param name="FrameElement"></param>
        /// <param name="TargetListElement"></param>
        /// <param name="MoveDown"></param>
        public void VerifyZoneClassMaintenanceMoveCodes(string ZoneClass,IWebElement FrameElement, IWebElement TargetListElement,bool MoveDown=false)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_zoneClass, ZoneClass, "Zone Class");
            if (MoveDown)
            {
                Driver.SwitchTo().DefaultContent();
                Driver.PageScrollDown();
                _extendpage.SwitchToContentFrame();
            }
            _extendpage.verifyGroupListCount(FrameElement, TargetListElement, 0);
            Settings.Logger.Info(" Successfully Verified  Zone Class Maintenance ");
        }

        /// <summary>
        /// Move All Zone Class Maintenance
        /// </summary>
        /// <param name="ZoneClass"></param>
        /// <param name="FrameElement"></param>
        /// <param name="TargetListElement"></param>
        /// <param name="MoveListElementButton"></param>
        /// <param name="MoveDown"></param>
        public void MoveAllZoneClassMaintenance(string ZoneClass, IWebElement FrameElement, IWebElement TargetListElement, IWebElement MoveListElementButton, bool MoveDown = false)
        {
            Settings.Logger.Info(" Move All Asset Class Codes ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_zoneClass, ZoneClass, "Zone Class");
            if (MoveDown)
            {
                Driver.SwitchTo().DefaultContent();
                Driver.PageScrollDown();
                _extendpage.SwitchToContentFrame();
            }
            _extendpage.SelectAllAndMoveGroupListElements(FrameElement, TargetListElement, MoveListElementButton);
            _extendpage.Save();
        }

        /// <summary>
        /// Check And Reset Zone Class Maintenance
        /// </summary>
        /// <param name="ZoneClass"></param>
        public void CheckAndResetZoneClassMaintenance(string ZoneClass)
        {
            MoveAllAssetClassCodesLeft(ZoneClass);
            MoveAllCategoryCodesLeft(ZoneClass);
        }

    }
}
