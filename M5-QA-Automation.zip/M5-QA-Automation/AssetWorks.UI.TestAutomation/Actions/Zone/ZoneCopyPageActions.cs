﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Zone;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Zone
{
    internal class ZoneCopyPageActions : ZoneCopyPage
    {
        public ZoneCopyPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Copy Existing Zone
        /// </summary>
        /// <param name="Zones"></param>
        /// <returns></returns>
        public string CopyExistingZone(Zones Zones)
        {
            Settings.Logger.Info(" Copy Existing Zone ");
            _extendpage.SwitchToContentFrame();
            _zone.SetText(Zones.ZoneCode, "Existing Zone");
            string NewZoneName= CommonUtil.GetRandomStringWithSpecialChars(7);
            Driver.WaitForReady();
            _newZone.SetText(NewZoneName, "New Zone Name");
            Driver.WaitForReady();
            _newZoneDesc.SetText(Zones.ZoneCodesDesc, "ZoneCodesDesc");
            _extendpage.Save();
            Driver.WaitForReady();
            Settings.Logger.Info($"Successfully created the Zone Copy {NewZoneName}");
            Driver.SwitchTo().DefaultContent();
            return NewZoneName;
        }
    }
}
