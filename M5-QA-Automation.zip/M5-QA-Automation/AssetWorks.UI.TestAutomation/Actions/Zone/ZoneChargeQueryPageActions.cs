﻿using AssetWorks.UI.M5.TestAutomation.PagesObject.Zone;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Zone
{
    internal class ZoneChargeQueryPageActions : ZoneChargeQueryPage
    {
        public ZoneChargeQueryPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Retrive And Edit
        /// </summary>
        /// <param name="ZoneQueryResult"></param>
        public void RetriveZoneChargeQueryresult(ZoneQueryResult ZoneQueryResult)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _queryZone.SetText(ZoneQueryResult.ZoneCode, "ZoneCode");
            Driver.WaitForReady();
            _unitNo.SetText(ZoneQueryResult.UnitNumber, "UnitNumber");
            Driver.WaitForReady();
            _respDeptNo.SetText(ZoneQueryResult.Department, "Department");
            Driver.WaitForReady();
            _chargeCode.SetText(ZoneQueryResult.ChargeCode, "ChargeCode");
            Driver.WaitForReady();
            _assetClass.SetText(ZoneQueryResult.AssetClass, "AssetClass");
            Driver.WaitForReady();
            _assetCategory.SetText(ZoneQueryResult.AssetCategory, "AssetCategory");
            Driver.WaitForReady();
            _licenseClass.SetText(ZoneQueryResult.LicenseClass, "LicenseClass");
            Driver.WaitForReady();
            _priProdType.SelectFilterValueHavingEqualValue(ZoneQueryResult.PrimaryFuelType);
            Driver.WaitForReady();
            _secProdType.SelectFilterValueHavingEqualValue(ZoneQueryResult.PrimaryFuelType);
            Driver.WaitForReady();
            _class1.SetText(ZoneQueryResult.Class1, "Class1");
            Driver.WaitForReady();
            _class2.SetText(ZoneQueryResult.Class2, "Class2");
            Driver.WaitForReady();
            _class3.SetText(ZoneQueryResult.Class3, "Class3");
            Driver.WaitForReady();
            _class4.SetText(ZoneQueryResult.Class4, "Class4");
            Driver.WaitForReady();
            _class5.SetText(ZoneQueryResult.Class5, "Class5");
            Driver.WaitForReady();
            _VisionRating.SetText(ZoneQueryResult.VisionRating, "VisionRating");
            Driver.WaitForReady();
            _emissionsRating.SetText(ZoneQueryResult.tEmissionsRating, "tEmissionsRating");
            Driver.WaitForReady();
            _co.SetText(ZoneQueryResult.CO, "CO");
            Driver.WaitForReady();
            _nox.SetText(ZoneQueryResult.NOX, "NOX");
            Driver.WaitForReady();
            _maxRange.SetText(ZoneQueryResult.MaxRange, "MaxRange");
            Driver.WaitForReady();
            _batteryRange.SetText(ZoneQueryResult.BatteryRange, "BatteryRange");
            Driver.WaitForReady();
            _compliantYear.SetText(ZoneQueryResult.CompliantYear, "CompliantYear");
            Driver.WaitForReady();
            _fromChgDate.SetText(ZoneQueryResult.FromChargeDate, "FromChargeDate");
            Driver.WaitForReady();
            _toChgDate.SetText(ZoneQueryResult.ToChargeDate, "ToChargeDate");
            Driver.WaitForReady();
            _retrieve.ClickElement("retrieve", Driver);
            Driver.WaitForReady();
            Settings.Logger.Info("Retrieved Charge Query ");
        }

        public void EditChargeQuery(ZoneQueryResult ZoneQueryResult)
        {
            Driver.SwitchTo().DefaultContent();
           _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            Driver.SwitchToFrame(_zoneChargeQueryFrame, "zoneChargeQueryFrame");
            foreach (ZoneResult ZoneResult in ZoneQueryResult.ZoneResult)
            {
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeQueryTable, "Zone", ZoneResult.ZoneCode, "zChargeAmount"));
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeQueryTable, "Zone", ZoneResult.ZoneCode, "zChargeAmount").SetText(ZoneResult.ChargeAmount, "ChargeAmount");
                Driver.WaitForReady();
            }
            _extendpage.Save();
            Settings.Logger.Info("Edit  Charge Amount ");
        }

        /// <summary>
        /// Verify Charge Query
        /// </summary>
        /// <param name="ZoneQueryResult"></param>
        public void VerifyChargeQuery(ZoneQueryResult ZoneQueryResult)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            Driver.SwitchToFrame(_zoneChargeQueryFrame, "zoneChargeQueryFrame");
            foreach (ZoneResult ZoneResult in ZoneQueryResult.ZoneResult)
            {
                Driver.WaitForReady();
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeQueryTable, "Zone", ZoneResult.ZoneCode, "zoneNo"), "zoneNo", ZoneResult.ZoneCode, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeQueryTable, "Zone", ZoneResult.ZoneCode, "zUnitNo"), "UnitNumber", ZoneResult.UnitNumber, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeQueryTable, "Zone", ZoneResult.ZoneCode, "zDeptNo"), "Department", ZoneResult.Department, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeQueryTable, "Zone", ZoneResult.ZoneCode, "zChargeCode"), "Department", ZoneResult.ChargeCode, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeQueryTable, "Zone", ZoneResult.ZoneCode, "zChargeAmount"), "ChargeAmount", ZoneResult.ChargeAmount, false, "value");
            }
            Settings.Logger.Info("Verified Charge Query ");
        }
    }
}
