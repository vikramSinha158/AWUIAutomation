﻿using AssetWorks.UI.M5.TestAutomation.PagesObject.Zone;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.Core.Extensions;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Zone
{
    internal class ZonesTimePageActions : ZonesTimePage
    {
        public ZonesTimePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Time Zone
        /// </summary>
        /// <param name="TimeZoneObject"></param>
        /// <returns></returns>
        public string CreateTimeZone(TimeZoneCode TimeZoneObject)
        {          
            _extendpage.SwitchToContentFrame();
            string TimeZoneCode = string.Empty;
            Driver.SwitchToFrame(_timeZoneFrame, "timeZoneFrame");
            if (!_extendpage.CheckDataExistenceAndGetActionCode(TimeZoneObject.TimeZoneCodes, ref TimeZoneCode, "", 5))
            {
                TimeZoneObject.TimeZoneCodes = TimeZoneCode;
                _extendpage.GetTableActionElementByRelatedColumnValue(_timeZoneTable, "Code", "", "code").SetText(TimeZoneObject.TimeZoneCodes, "TimeZoneCodes");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_timeZoneTable, "Code", TimeZoneObject.TimeZoneCodes, "description").SetText(TimeZoneObject.TtimeZoneCodesesc, "TtimeZoneCodesesc");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_timeZoneTable, "Code", TimeZoneObject.TimeZoneCodes, "offset").SetText(TimeZoneObject.DatabaseServer, "DatabaseServer");
                _extendpage.Save();
                Driver.WaitForSomeTime();
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Created Time Zone");
            return TimeZoneObject.TimeZoneCodes;
        }

        /// <summary>
        /// Verify Time Zone
        /// </summary>
        /// <param name="TimeZoneObject"></param>
        public void VerifyTimeZone(TimeZoneCode TimeZoneObject)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            _extendpage.RefreshAndSwitchToTable(_timeZoneFrame, "Table frame");
            _extendpage.ActionRequiredWindow("Leave");
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_timeZoneTable, "Code", TimeZoneObject.TimeZoneCodes, "code"), "TimeZoneCodes", TimeZoneObject.TimeZoneCodes, false, "value");
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_timeZoneTable, "Code", TimeZoneObject.TimeZoneCodes, "description"), "TtimeZoneCodesesc", TimeZoneObject.TtimeZoneCodesesc, false, "value");
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_timeZoneTable, "Code", TimeZoneObject.TimeZoneCodes, "offset"), "TtimeZoneCodesesc", TimeZoneObject.DatabaseServer, false, "value");
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("verified Time Zone Details for : " + TimeZoneObject.TimeZoneCodes);
        }

        /// <summary>
        /// Update Time Zone
        /// </summary>
        /// <param name="TimeZoneObject"></param>
        public void UpdateTimeZone(TimeZoneCode TimeZoneObject)
        {
            _extendpage.RefreshAndSwitchToTable(_timeZoneFrame, "Table frame");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_timeZoneTable, "Code", TimeZoneObject.TimeZoneCodes, "description").SetText(TimeZoneObject.TtimeZoneCodesesc, "TtimeZoneCodesesc");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_timeZoneTable, "Code", TimeZoneObject.TimeZoneCodes, "offset").SetText(TimeZoneObject.DatabaseServer, "DatabaseServer");
            _extendpage.Save();
            Driver.WaitForReady();
            Settings.Logger.Info(" Updated Time Zone Codes");
        }

        /// <summary>
        /// Delete Time Zone
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteTimeZone(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_timeZoneFrame, "Table frame");
            _extendpage.GetTableActionElementByRelatedColumnValue(_timeZoneTable, "Code", CodeVal, "code").Click();
            Driver.WaitForReady();
            _extendpage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Deleted Time Zone : " + CodeVal);
        }

        /// <summary>
        /// Verify Deleted Time Zone
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedTimeZone(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_timeZoneFrame, "Table frame");
            Settings.Logger.Info("Verify Time Zone  is Deleted for : " + CodeVal);
            _extendpage.VerifyTableColumnDoesNotContainValue(_timeZoneTable, "Code", CodeVal);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verified Time Zone Deletetion : " + CodeVal);
        }
    }
}
