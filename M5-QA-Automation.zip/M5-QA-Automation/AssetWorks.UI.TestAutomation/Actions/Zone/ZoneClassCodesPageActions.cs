﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Zone;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Zone
{
    internal class ZoneClassCodesPageActions : ZoneClassCodesPage
    {
        public ZoneClassCodesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Zone Class Codes
        /// </summary>
        /// <param name="ZoneClassCodeDetail"></param>
        /// <returns></returns>
        public string CreateZoneClassCodes(ZoneClassCode ZoneClassCodeDetail)
        {
            Settings.Logger.Info(" Creating Zone Class Codes");
            _extendpage.SwitchToContentFrame();          
            string ZoneCodes = string.Empty;
            Driver.SwitchToFrame(_zoneClassCodesFrame, "zoneClassCodesFrame");
            if (!_extendpage.CheckDataExistenceAndGetActionCode(ZoneClassCodeDetail.ZoneClassCodes, ref ZoneCodes, "ZoneClassCodesQuery", 5))
            {
                ZoneClassCodeDetail.ZoneClassCodes = ZoneCodes;
                _extendpage.GetTableActionElementByRelatedColumnValue(_zoneClassTable, "Class", "", "zoneClass").SetText(ZoneClassCodeDetail.ZoneClassCodes, "ZoneClassCodes");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_zoneClassTable, "Class", ZoneClassCodeDetail.ZoneClassCodes, "desc").SetText(ZoneClassCodeDetail.ZoneClassCodesDesc, "ZoneClassCodesDesc");
                Driver.WaitForReady();
                _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneClassTable, "Class", ZoneClassCodeDetail.ZoneClassCodes, "disabled"), "ZoneClassCodesFlag", ZoneClassCodeDetail.ZoneClassCodesFlag);
                _extendpage.Save();
                Driver.WaitForSomeTime();
            }
            Driver.SwitchTo().DefaultContent();
            return ZoneClassCodeDetail.ZoneClassCodes;
        }

        /// <summary>
        /// Verify Zone Class Codes
        /// </summary>
        /// <param name="ZoneClassCodeDetail"></param>
        public void VerifyZoneClassCodes(ZoneClassCode ZoneClassCodeDetail)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            _extendpage.ActionRequiredWindow("Leave");
            Driver.WaitForReady();
            _extendpage.RefreshAndSwitchToTable(_zoneClassCodesFrame, "Table frame");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneClassTable, "Class", ZoneClassCodeDetail.ZoneClassCodes, "zoneClass"), "Desc", ZoneClassCodeDetail.ZoneClassCodes, false, "value");
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneClassTable, "Class", ZoneClassCodeDetail.ZoneClassCodes, "desc"), "ZoneClassCodesDesc", ZoneClassCodeDetail.ZoneClassCodesDesc, false, "value");
            CommonUtil.VerifyCheckboxState(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneClassTable, "Class", ZoneClassCodeDetail.ZoneClassCodes, "disabled"), "ZoneClassCodesFlag", ZoneClassCodeDetail.ZoneClassCodesFlag);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("verified Zone Class Code Details for : " + ZoneClassCodeDetail.ZoneClassCodes);
        }

        /// <summary>
        /// Delete Zone Class Codes
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteZoneClassCodes(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();          
            _extendpage.RefreshAndSwitchToTable(_zoneClassCodesFrame, "Table frame");
            _extendpage.GetTableActionElementByRelatedColumnValue(_zoneClassTable, "Class", CodeVal, "zoneClass").Click();
            Driver.WaitForReady();
            _extendpage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Deleted Zone Class Code : " + CodeVal);
        }

        /// <summary>
        /// Verify Deleted Zone Class Codes
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedZoneClassCodes(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();         
            _extendpage.RefreshAndSwitchToTable(_zoneClassCodesFrame, "Table frame");
            Settings.Logger.Info("Verify Zone Class Code  is Deleted for : " + CodeVal);
            _extendpage.VerifyTableColumnDoesNotContainValue(_zoneClassTable, "Class", CodeVal);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verified Zone Class Code Deletetion : " + CodeVal);
        }

        /// <summary>
        /// Update Zone Class Codes
        /// </summary>
        /// <param name="ZoneClassCodeDetail"></param>
        public void UpdateZoneClassCodes(ZoneClassCode ZoneClassCodeDetail)
        {           
            _extendpage.RefreshAndSwitchToTable(_zoneClassCodesFrame, "Table frame");
            _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneClassTable, "Class", ZoneClassCodeDetail.ZoneClassCodes, "disabled"), "ZoneClassCodesFlag", ZoneClassCodeDetail.ZoneClassCodesFlag);
            _extendpage.Save();
            _extendpage.RefreshAndSwitchToTable(_zoneClassCodesFrame, "Table frame");      
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_zoneClassTable, "Class", ZoneClassCodeDetail.ZoneClassCodes, "desc").SetText(ZoneClassCodeDetail.ZoneClassCodesDesc, "ZoneClassCodesDesc");
            _extendpage.Save();
            Driver.WaitForReady();
            Settings.Logger.Info(" Updated Zone Class Codes");
        }

    }
}
