﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Zone;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Zone
{
    internal class ZoneChargeCodesPagecsActions : ZoneChargeCodesPagecs
    {
        public ZoneChargeCodesPagecsActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Zeone Charge Codes
        /// </summary>
        /// <param name="ZoneChargeCodes"></param>
        /// <returns></returns>
        public string CreateZeoneChargeCodes(ZoneChargeCodes ZoneChargeCodes)
        {
            _extendpage.SwitchToContentFrame();
            string ZoneCharge = string.Empty;
            Driver.SwitchToFrame(_zoneChargeCodesFrame, "zoneChargeCodesFrame");
            if (!_extendpage.CheckDataExistenceAndGetActionCode(ZoneChargeCodes.ZoneChargeCode, ref ZoneCharge, "ZoneChargeCodesQuery", 5))
            {
                ZoneChargeCodes.ZoneChargeCode = ZoneCharge;
                _extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeCodesTable, "Code", "", "code").SetText(ZoneChargeCodes.ZoneChargeCode, "ZoneChargeCode");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeCodesTable, "Code", ZoneChargeCodes.ZoneChargeCode, "desc").SetText(ZoneChargeCodes.ZoneChargeCodesDesc, "ZoneChargeCodesDesc");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeCodesTable, "Code", ZoneChargeCodes.ZoneChargeCode, "billItem").SetText(ZoneChargeCodes.BillingItem, "BillingItem");
                Driver.WaitForReady();
                _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeCodesTable, "Code", ZoneChargeCodes.ZoneChargeCode, "disabled"), "ZoneChargeCodesFlag", ZoneChargeCodes.ZoneChargeCodesFlag);
                _extendpage.Save();
               
            }
            Settings.Logger.Info(" Created Zeone Charge Codes");
            return ZoneChargeCodes.ZoneChargeCode;
        }

        /// <summary>
        /// Verify Zone Charge Codes
        /// </summary>
        /// <param name="ZoneChargeCodes"></param>
        public void VerifyZoneChargeCodes(ZoneChargeCodes ZoneChargeCodes)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_zoneChargeCodesFrame, "Table frame");
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeCodesTable, "Code", ZoneChargeCodes.ZoneChargeCode, "code"), "ZoneChargeCode",ZoneChargeCodes.ZoneChargeCode,false, "value");
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeCodesTable, "Code", ZoneChargeCodes.ZoneChargeCode, "desc"), "ZoneChargeCodesDesc",ZoneChargeCodes.ZoneChargeCodesDesc, false, "value");
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeCodesTable, "Code", ZoneChargeCodes.ZoneChargeCode, "billItem"), "BillingItem",ZoneChargeCodes.BillingItem, false, "value");
            CommonUtil.VerifyCheckboxState(_extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeCodesTable, "Code", ZoneChargeCodes.ZoneChargeCode, "disabled"), "ZoneChargeCodesFlag", ZoneChargeCodes.ZoneChargeCodesFlag);           
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("verified Zone Charge Codes Details for : " + ZoneChargeCodes.ZoneChargeCode);
        }

        /// <summary>
        /// Update Zone Charge Codess
        /// </summary>
        /// <param name="ZoneChargeCodes"></param>
        public void UpdateZoneChargeCodess(ZoneChargeCodes ZoneChargeCodes)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_zoneChargeCodesFrame, "Table frame");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeCodesTable, "Code", ZoneChargeCodes.ZoneChargeCode, "desc").SetText(ZoneChargeCodes.ZoneChargeCodesDesc, "ZoneChargeCodesDesc");
            Driver.WaitForReady();
            Driver.WaitForReady();
            Settings.Logger.Info(" Updated Zone Class Codes");
        }

        /// <summary>
        /// Delete Zone Charge Codess
        /// </summary>
        /// <param name="ZoneChargeCodess"></param>
        public void DeleteZoneChargeCodess(List<string> ZoneChargeCodess)
        {                 
            foreach (string ZoneChargeCodessItem in ZoneChargeCodess)
            {
                Driver.SwitchTo().DefaultContent();
                _extendpage.RefreshAndSwitchToTable(_zoneChargeCodesFrame, "Table frame");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_zoneChargeCodesTable, "Code", ZoneChargeCodessItem, "code").Click();
                _extendpage.DeleteAndSave();
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Deleted Zone Charge Codess  ");
        }

        /// <summary>
        /// Verify Zone Charge Codes Deletion
        /// </summary>
        /// <param name="ZoneChargeCodess"></param>
        public void VerifyZoneChargeCodesDeletion(List<string> ZoneChargeCodess)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_zoneChargeCodesFrame, "Table frame");
            Driver.WaitForReady();
            foreach (string ZoneChargeCodessItem in ZoneChargeCodess)
            {
                _extendpage.VerifyTableColumnDoesNotContainValue(_zoneChargeCodesTable, "Code", ZoneChargeCodessItem);
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verified Deleted Zone Charge Codess  ");
        }
    }
}
