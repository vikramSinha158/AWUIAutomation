﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Zone;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Zone
{
    internal class ZonePageActions : ZonePage
    {
        public ZonePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Zone
        /// </summary>
        /// <param name="Zones"></param>
        /// <returns></returns>
        public string CreateZone(Zones Zones)
        {
            string ZoneC = string.Empty;          
            if (!_extendpage.CheckDataExistenceAndGetActionCode(Zones.ZoneCode, ref ZoneC, "ZoneQuery"))
            {
                Zones.ZoneCode= ZoneC;
                FillZoneSelection(Zones);
                Driver.WaitForReady();
                if (Zones.ZonesTable != null)
                {
                    FillZonesTable(Zones);
                }
                if (Zones.UnitTable != null)
                {
                    FillUnitTable(Zones);
                }
                if (Zones.ChargesTable != null)
                {
                    FillChargesTable(Zones);
                }
                _extendpage.Save();
                Settings.Logger.Info(" Creating zone Code   ");
            }
            return Zones.ZoneCode;
        }

        /// <summary>
        /// Fill Zone Selection
        /// </summary>
        /// <param name="Zones"></param>
        public void FillZoneSelection(Zones Zones)
        {
            _extendpage.SwitchToContentFrame();
            _zone.SetText(Zones.ZoneCode, " Zones Code ");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow("Create");
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _description.SetText(Zones.ZoneCodesDesc, " ZoneCodesDesc ");
            Driver.WaitForReady();
            _department.SetText(Zones.Department, " Department ");
            Driver.WaitForReady();
            _location.SetText(Zones.Location, " Location ");
            _extendpage.Save();
        }

        /// <summary>
        /// Fill Zones Table
        /// </summary>
        /// <param name="Zones"></param>
        public void FillZonesTable(Zones Zones)
        {
            Driver.SwitchTo().DefaultContent(); 
            _extendpage.RefreshAndSetText(_zone, Zones.ZoneCode, "Zone");
            _extendpage.GetTabLinkByText("Zones").ClickElement("Zones", Driver); ;
            Driver.WaitForReady();
            Driver.SwitchToFrame(_zoneFrame, "zoneClassCodesFrame");
            foreach(ZonesTable zonesTable in Zones.ZonesTable)
            {
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", "", "department"));
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", "", "department").SetText(zonesTable.Department, "Department");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "location"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "location").SetText(zonesTable.Location, "Location");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "assetClass"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "assetClass").SetText(zonesTable.AssetClass, "AssetClass");
                Driver.WaitForReady();
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "assetCategory"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "assetCategory").SetText(zonesTable.AssetCategory, "AssetCategory");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "emissionsRating"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "emissionsRating").SetText(zonesTable.tEmissionsRating, "AssetCategory");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "primaryFuel").SelectFilterValueHavingEqualValue(zonesTable.PrimaryFuelType);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "secondaryFuel").SelectFilterValueHavingEqualValue(zonesTable.SecondaryFuel);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "hybrid").SelectFilterValueHavingEqualValue(zonesTable.Hybrid);
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "maxRange"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "maxRange").SetText(zonesTable.MaxRange, "MaxRange");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "batteryRange"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "batteryRange").SetText(zonesTable.BatteryRange, "BatteryRange");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "licenseClass"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "licenseClass").SetText(zonesTable.LicenseClass, "LicenseClass");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "visionRating"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "visionRating").SetText(zonesTable.VisionRating, "VisionRating");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "directVisionPermit").SelectFilterValueHavingEqualValue(zonesTable.DirectVisionPermit);
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "camera").SelectFilterValueHavingEqualValue(zonesTable.Camera);
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "compliantYear"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "compliantYear").SetText(zonesTable.CompliantYear, "CompliantYear");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "CO"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "CO").SetText(zonesTable.CO, "CO");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "CO2"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "CO2").SetText(zonesTable.CO2, "CO2");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "CO2A"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "CO2A").SetText(zonesTable.CO2A, "CO2A");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "NOX"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "NOX").SetText(zonesTable.NOX, "NOX");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "HC"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "HC").SetText(zonesTable.HC, "HC");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "PM"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "PM").SetText(zonesTable.PM, "PM");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "PM10"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "PM10").SetText(zonesTable.PM10, "PM10");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "zoneClass"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "zoneClass").SetText(zonesTable.ZoneClass, "ZoneClass");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "class1"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "class1").SetText(zonesTable.Class1, "Class1");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "class2"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "class2").SetText(zonesTable.Class2, "Class2");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "class3"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "class3").SetText(zonesTable.Class3, "Class3");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "class4"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "class4").SetText(zonesTable.Class4, "Class4");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "class5"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "class5").SetText(zonesTable.Class5, "Class5");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "chargeCode"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "chargeCode").SetText(zonesTable.ChargeCode, "ChargeCode");
                Driver.WaitForReady();
                _extendpage.SelectAllAndClearField(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "chargeAmount"));
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "chargeAmount").SetText(zonesTable.ChargeAmount, "ChargeAmount");
                Driver.WaitForReady();
            }
            _extendpage.Save();
        }

        /// <summary>
        /// Fill Unit Table
        /// </summary>
        /// <param name="Zones"></param>
        public void FillUnitTable(Zones Zones)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_zone, Zones.ZoneCode, "Zone");
            _extendpage.GetTabLinkByText("Units").ClickElement("Units",Driver);
            Driver.WaitForReady();
            Driver.SwitchToFrame(_zonesUnitFrame, "zonesUnitFrame");
            foreach (UnitTable UnitTable in Zones.UnitTable)
            {
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesUnitTable, "Unit Number", "", "unitNo").SetText(UnitTable.UnitNumber, "UnitNumber");
                Driver.WaitForReady();

            }
            _extendpage.Save();
        }

        /// <summary>
        /// Fill Charges Table
        /// </summary>
        /// <param name="Zones"></param>
        public void FillChargesTable(Zones Zones)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_zone, Zones.ZoneCode, "Zone");
            _extendpage.GetTabLinkByText("Charges").ClickElement("Charges", Driver); ;
            Driver.WaitForReady();
            Driver.SwitchToFrame(_zonesChargeFrame, "zonesChargeFrame");
            foreach (ChargesTable ChargesTable in Zones.ChargesTable)
            {
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesChargeTable, "Unit Number", "", "zcfUnitNo").SetText(ChargesTable.UnitNumber, "UnitNumber");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesChargeTable, "Unit Number", ChargesTable.UnitNumber, "zcfChargeDate").SetText(ChargesTable.ChargeDate, "ChargeDate");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesChargeTable, "Unit Number", ChargesTable.UnitNumber, "zcfChargeCode").SetText(ChargesTable.ChargeCode, "ChargeCode");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_zonesChargeTable, "Unit Number", ChargesTable.UnitNumber, "zcfChargeAmount").SetText(ChargesTable.ChargeAmount, "ChargeAmount");
                Driver.WaitForReady();
            }
            _extendpage.Save();
        }

        /// <summary>
        /// Verify Zone
        /// </summary>
        /// <param name="Zones"></param>
        public void VerifyZone(Zones Zones)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_zone, Zones.ZoneCode, "Zone");
            Driver.WaitForReady();
            if (Zones.ZonesTable != null)
            {
                VerifyZonesTable(Zones);
            }
            if (Zones.UnitTable != null)
            {
                VerifyZoneUnit(Zones.ZoneCode);
            }
            if (Zones.ChargesTable != null)
            {
                VerifyChargesTable(Zones.ZoneCode);
            }
            Settings.Logger.Info(" Verified Zones  ");
        }

        /// <summary>
        /// Verify Zone Unit
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyZoneUnit(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _extendpage.GetTabLinkByText("Units").ClickElement("Units", Driver);
            Driver.WaitForReady();
            _extendpage.VerifyTableRowDeletion(_zonesUnitFrame, _zonesUnitTableRows, "zonesUnitTableRows", 1);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verified zones Unit Table  " + CodeVal);
        }

        /// <summary>
        /// Verify Charges Table
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyChargesTable(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _extendpage.GetTabLinkByText("Charges").ClickElement("Charges", Driver); ;
            Driver.WaitForReady();
            _extendpage.VerifyTableRowDeletion(_zonesChargeFrame, _zonesChargeTableRows, "zonesChargeFrame", 1);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verified zones Charge Table  " + CodeVal);
        }

        /// <summary>
        /// Verify Zones Table
        /// </summary>
        /// <param name="Zones"></param>
        public void VerifyZonesTable(Zones Zones)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _extendpage.GetTabLinkByText("Zones").ClickElement("Zones", Driver); ;
            Driver.WaitForReady();
            Driver.SwitchToFrame(_zoneFrame, "zoneClassCodesFrame");
            foreach (ZonesTable zonesTable in Zones.ZonesTable)
            {              
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "department"), "Department",zonesTable.Department, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "location"), "Location",zonesTable.Location, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "assetClass"), "AssetClass",zonesTable.AssetClass, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "assetClass"), "AssetClass",zonesTable.AssetClass, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "assetCategory"), "AssetCategory",zonesTable.AssetCategory, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "emissionsRating"), "AssetCategory",zonesTable.tEmissionsRating, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "primaryFuel"), "PrimaryFuelType", zonesTable.PrimaryFuelType,true, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "secondaryFuel"), "SecondaryFuel", zonesTable.SecondaryFuel, true, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "hybrid"),"Hybrid",zonesTable.Hybrid, true, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "maxRange"), "MaxRange",zonesTable.MaxRange,false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "batteryRange"), "BatteryRange",zonesTable.BatteryRange,false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "licenseClass"), "LicenseClass",zonesTable.LicenseClass, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "visionRating"), "VisionRating",zonesTable.VisionRating, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "directVisionPermit"), "DirectVisionPermit", zonesTable.DirectVisionPermit, true, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "camera"), "Camera",zonesTable.Camera, true, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "compliantYear"), "CompliantYear",zonesTable.CompliantYear, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "CO"), "CO",zonesTable.CO, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "CO2"),"CO2",zonesTable.CO2, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "CO2A"), "CO2A",zonesTable.CO2A, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "NOX"), "NOX",zonesTable.NOX, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "HC"), "HC",zonesTable.HC, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "PM"), "PM",zonesTable.PM, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "PM10"), "PM10",zonesTable.PM10, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "zoneClass"), "ZoneClass",zonesTable.ZoneClass, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "class1"), "Class1",zonesTable.Class1, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "class2"), "Class2",zonesTable.Class2, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "class3"), "Class3",zonesTable.Class3, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "class4"), "Class4",zonesTable.Class4, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "class5"), "Class5",zonesTable.Class5, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "chargeCode"), "ChargeCode",zonesTable.ChargeCode, false, "value");
                CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_zonesTable, "Department/Department Group", zonesTable.Department, "chargeAmount"), "ChargeAmount",zonesTable.ChargeAmount, false, "value");
                Settings.Logger.Info("Verified zones Table  " + Zones.ZoneCode);
            }
        }

        /// <summary>
        /// Verify Zone Deletion
        /// </summary>
        /// <param name="ZoneCode"></param>
        public void VerifyZoneDeletion(string ZoneCode)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            _extendpage.ActionRequiredWindow("Leave");
            _extendpage.VerifyCodeDeletion(_zone, ZoneCode, "Zone Code");
        }

        /// <summary>
        /// Delete Zone Table
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteZoneTable(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            _extendpage.ActionRequiredWindow("Leave");
            _extendpage.RefreshAndSetText(_zone, CodeVal, "Zone");
            _extendpage.GetTabLinkByText("Zones").ClickElement("Zones", Driver); ;
            Driver.WaitForReady();
            Driver.SwitchToFrame(_zoneFrame, "zoneClassCodesFrame");
            _extendpage.DeleteTableRowsUsingColumnName(_zonesTable, "Department/Department Group", "department", _zoneFrame);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Deleted ZoneTable for Zone Code : " + CodeVal);
        }

        /// <summary>
        /// Update Zone
        /// </summary>
        /// <param name="Zones"></param>
        public void UpdateZone(Zones Zones)
        {
            FillZoneSelection(Zones);
            Driver.WaitForReady();
            if (Zones.ZonesTable != null)
            {
                FillZonesTable(Zones);
            }
            if (Zones.UnitTable != null)
            {
                FillUnitTable(Zones);
            }
            if (Zones.ChargesTable != null)
            {
                FillChargesTable(Zones);
            }
            _extendpage.Save();
            Settings.Logger.Info(" Update Zone  ");           
        }
    }
}
