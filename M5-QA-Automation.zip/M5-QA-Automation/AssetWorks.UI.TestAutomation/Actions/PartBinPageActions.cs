﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class PartBinPageActions : PartBinPage
    {
        public PartBinPageActions(IWebDriver Driver) : base(Driver) { }       
        public static Dictionary<string, PartValue> BinInfoDict =  new Dictionary<string, PartValue>();
        string binCode = string.Empty;

        /// <summary>
        /// Create Part Bin
        /// </summary>
        /// <param name="ObjectKey"></param>
        /// <returns></returns>
        public Dictionary<string, PartValue> CreatePartBin(string ObjectKey)
        {
            BinInfoDict.Clear();
            _createPartBinObject = CommonUtil.DataObjectForKey(ObjectKey).ToObject<CreatePartPin>();
            string BilCodeToRetrieve = _createPartBinObject.BinCode;            
            AddBinCodeAndRetrieve(BilCodeToRetrieve);           
            Settings.Logger.Info("Creating Part Bin with Bin Code as:" + binCode);
            Driver.SwitchToFrame(_framePartBin, "Table frame");
            for (int i = 0; i < _createPartBinObject.BinInformation.Count; i++)
            {
                AddBinInfoData(i, _createPartBinObject.BinInformation[i].Bin, _createPartBinObject.BinInformation[i].Description, _createPartBinObject.BinInformation[i].Disabled);

            }
            _extendpage.SaveAndChackWarning();
            return BinInfoDict;

        }


        /// <summary>
        /// Enter and Retrieve Part Bin Data
        /// </summary>
        /// <param name="BinCode"></param>
        public void AddBinCodeAndRetrieve(string BinCode)
        {
            _extendpage.SwitchToContentFrame();
            _binCodeInput.SetText(BinCode, "Bin code");
            _retrieveBtn.ClickElement("Retrieve Button", Driver);
        }


       /// <summary>
       /// Add Bin Data
       /// </summary>
       /// <param name="RowNum"></param>
       /// <param name="BinCode"></param>
       /// <param name="BinDesc"></param>
       /// <param name="disabled"></param>
        public void AddBinInfoData(int RowNum, string BinCode, string BinDesc, bool disabled)
        {            
            string bin = BinCode.ToLower().Equals("random") ? CommonUtil.GetRandomStringWithSpecialChars(5).ToUpper() : BinCode;
            string desc = BinDesc.ToLower().Equals("random") ? $"{bin} Description" : BinDesc;
            _extendpage.GetInputElementAndSetValue($"{_binLocator}{RowNum}", bin, "name");          
            Driver.WaitForReady();
            _extendpage.GetInputElementAndSetValue($"{_descriptionLocator}{RowNum}", desc, "name");
            _extendpage.GetElementForInput($"{_disabledLocator}{RowNum}", "name").SelectCheckBox("Disabled", disabled);
            PartValue partValue = new PartValue();
            partValue.Description=desc;
            partValue.Disabled=disabled;
            BinInfoDict.Add(bin,partValue);         
        }

        /// <summary>
        /// Verify Part Bin Data
        /// </summary>
        /// <param name="BinCode"></param>
        /// <param name="BinDesc"></param>
        /// <param name="disabled"></param>
        public void VerifyPartBinData(string BinCode, string BinDesc,bool disabled)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_binCodeInput, BinCode, "Part Bin");
            _retrieveBtn.ClickElement("Retrieve Button", Driver);
            Driver.SwitchToFrame(_framePartBin, "Table frame");
            IWebElement binElement = _extendpage.GetElementForInput("bin$0", "name");
            CommonUtil.VerifyElementValue(binElement, "Bin Code", BinCode, false, "value");
            IWebElement descElement = _extendpage.GetElementForInput("desc$0", "name");
            CommonUtil.VerifyElementValue(descElement, "Bin Description", BinDesc, false, "value");
            bool chkActaulValue = _extendpage.GetElementForInput("disabled$0", "name").GetAttribute("value") == "Y" ? true : false;
            CommonUtil.AssertTrue<bool>(disabled, chkActaulValue);
        }

        public void UpdateAndVerifyPartBinData(int rowNum,string BinCode, string objectKey)
        {
            AddBinCodeAndRetrieve(BinCode);
            CreatePartPin _updatePartBinObject = CommonUtil.DataObjectForKey(objectKey).ToObject<CreatePartPin>();
            Driver.SwitchToFrame(_framePartBin, "Table frame");           
            string DescToUpdate = _updatePartBinObject.UpdateBinInformation[rowNum].Description.ToLower().Equals("random") ? $"{BinCode} Desc Updated" : _updatePartBinObject.UpdateBinInformation[rowNum].Description;
            Settings.Logger.Info("Update Part Bin Data for : " + BinCode);
            _extendpage.GetTableActionElementByRelatedColumnValue(_tablePartBin, "Bin", BinCode, "desc").Clear();
            _extendpage.GetTableActionElementByRelatedColumnValue(_tablePartBin, "Bin", BinCode, "desc").SendKeys(DescToUpdate);
            _extendpage.GetTableActionElementByRelatedColumnValue(_tablePartBin,"Bin", BinCode, "disabled").SelectCheckBox("Disabled Check Box", _updatePartBinObject.UpdateBinInformation[rowNum].Disabled);           
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnSaveButton();
            VerifyPartBinData(BinCode, DescToUpdate, _updatePartBinObject.UpdateBinInformation[rowNum].Disabled);
        }

        /// <summary>
        /// Delete Part Bin
        /// </summary>
        /// <param name="bin"></param>
        public void DeletePartBin(string bin)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_binCodeInput, bin, "Bin");
            _retrieveBtn.ClickElement("Retrieve Button", Driver);
            Driver.SwitchToFrame(_framePartBin, "Table frame");
            _extendpage.GetElementForInput("bin$0", "name").ClickElement("Bin", Driver);
            _extendpage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Delete Part Bin
        /// </summary>
        /// <param name="binInfoDict"></param>
        public void VerifyDeletePartBin(Dictionary<string, PartValue> binInfoDict)
        {
            foreach (KeyValuePair<string, PartValue> partBinInfo in binInfoDict)
            {
                DeletePartBin(partBinInfo.Key);
                 _extendpage.RefreshAndSetText(_binCodeInput, partBinInfo.Key, "Bin");
                _retrieveBtn.ClickElement("Retrieve Button", Driver);
                _extendpage.VerifyTableRowDeletion(_framePartBin, _tablerows, "Bin Main Table");
            }
        }
    }
}
