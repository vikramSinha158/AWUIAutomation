﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Units;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Units
{
    internal class NonCompanyUnitMainPageActions : NonCompanyUnitMainPage
    {
        public NonCompanyUnitMainPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Non Company Unit
        /// </summary>
        /// <param name="NCUnit"></param>
        /// <returns>NCUnitNo</returns>
        public string CreateNonCompanyUnit(NonCompanyUnit NCUnit)
        {
            Settings.Logger.Info(" Creating new Non Company Unit ");
            if (NCUnit.NCUnitNo == null)
                NCUnit.NCUnitNo = CommonUtil.GetRandomStringWithSpecialChars().ToUpper();
                
            _inputNCUnitNo.SetText(NCUnit.NCUnitNo, "Unit No", Driver, _extendedPage._contentFrame, "content frame");
            if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                _extendedPage.ClickOnDialogBoxButton("Create");
            Driver.WaitForReady();
            FillNonCompanyUnitDetails(NCUnit);
            _extendedPage.VerifyCreatedActionNumber(_inputNCUnitNo, NCUnit.NCUnitNo);
            return NCUnit.NCUnitNo;
        }

        /// <summary>
        /// Update Non Company Unit
        /// </summary>
        /// <param name="NCUnit"></param>
        public void UpdateNonCompanyUnit(NonCompanyUnit NCUnit)
        {
            Settings.Logger.Info(" Updating Non Company Unit ");
            RetrieveNonCompanyUnit(NCUnit.NCUnitNo);
            FillNonCompanyUnitDetails(NCUnit);
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Fill Non Company Unit Details
        /// </summary>
        /// <param name="NCUnit"></param>
        public void FillNonCompanyUnitDetails(NonCompanyUnit NCUnit)
        {
            Settings.Logger.Info(" Filling Non Company Unit ");
            _extendedPage.SwitchToContentFrame();
            _selectNCUStatus.SelectFilterValueHavingEqualValue(NCUnit.NCUStatus);
            Driver.WaitForReady();
            _inputNCUDesc.SetText(NCUnit.NCUDesc, "Unit Desc");
            Driver.WaitForReady();
            _inputNCUYear.SetText(NCUnit.NCUYear, "Year");
            Driver.WaitForReady();
            _inputNCUManufacturer.SetText(NCUnit.NCUManufacturer, "Manufacturer");
            Driver.WaitForReady();
            _inputNCUMake.SetText(NCUnit.NCUMake, "Make");
            Driver.WaitForReady();
            _inputNCUModel.SetText(NCUnit.NCUModel, "Model");
            Driver.WaitForReady();
            Driver.DoubleClick(_inputNCUCategoryNo, "Category No");
            _lov.SearchAndClickElement(NCUnit.NCUCategoryNo);
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputNCUGPW.SetText(NCUnit.NCUGPW, "GPW");
            Driver.WaitForReady();
            _inputNCUMeter.SetText(NCUnit.NCUMeter, "Meter");
            Driver.WaitForReady();
            _inputNCUMeterDate.SetText(NCUnit.NCUMeterDate, "Meter Date");
            Driver.WaitForReady();
            _inputNCUUsingDept.SetText(NCUnit.NCUUsingDept, "Using Dept");
            Driver.WaitForReady();
            _inputNCUParkingLocation.SetText(NCUnit.NCUParkingLocation, "Parking Location");
            Driver.WaitForReady();
            _inputNCULicenseClass.SetText(NCUnit.NCULicenseClass, "License Class");
            Driver.WaitForReady();
            _selectNCULicenseCategory.SelectFilterValueHavingEqualValue(NCUnit.NCULicenseCategory);
            Driver.WaitForReady();
            _inputNCUColor.SetText(NCUnit.NCUColor, "Color");
            Driver.WaitForReady();
            _inputNCUSeatingCap.SetText(NCUnit.NCUSeatingCap, "Seating Cap");
            Driver.WaitForReady();
            _inputNCUFuelProduct.SetText(NCUnit.NCUFuelProduct, "Fuel Product");
            Driver.WaitForReady();
            _inputNCUVehicleRef.SetText(NCUnit.NCUVehicleRef, "Vehicle Ref");
            Driver.WaitForReady();
            _inputNCUVehicleOwner.SetText(NCUnit.NCUVehicleOwner, "Vehicle Owner");
            Driver.WaitForReady();
            _selectNCUDriverType.SelectFilterValueHavingEqualValue(NCUnit.NCUDriverType);
            Driver.WaitForReady();
            _inputNCUDriverNo.SetText(NCUnit.NCUDriverNo, "Driver No");
            Driver.WaitForReady();
            _inputNCURegistrationRef.SetText(NCUnit.NCURegistrationRef, "Registration Ref");
            Driver.WaitForReady();
            _inputNCURegExpiry.SetText(NCUnit.NCURegExpiry, "Reg Expiry");
            Driver.WaitForReady();
            _inputNCUInspectionCert.SetText(NCUnit.NCUInspectionCert, "Inspection Cert");
            Driver.WaitForReady();
            _inputNCUInspExpiry.SetText(NCUnit.NCUInspExpiry, "Insp Expiry");
            Driver.WaitForReady();
            _inputNCUInspectionRef.SetText(NCUnit.NCUInspectionRef, "Inspection Ref");
            Driver.WaitForReady();
            _inputNCUServiceRef.SetText(NCUnit.NCUServiceRef, "Service Ref");
            Driver.WaitForReady();
            _inputNCULastServiceDt.SetText(NCUnit.NCULastServiceDt, "Last Service Date");
            Driver.WaitForReady();
            _inputNCUServiceDueDt.SetText(NCUnit.NCUServiceDueDt, "Service Due Date");
            Driver.WaitForReady();
            _inputNCUInsuranceCo.SetText(NCUnit.NCUInsuranceCo, "Insurance Co");
            Driver.WaitForReady();
            _inputNCUInsurancePolicy.SetText(NCUnit.NCUInsurancePolicy, "Insurance Policy");
            Driver.WaitForReady();
            _inputNCUInsuranceRef.SetText(NCUnit.NCUInsuranceRef, "Insurance Ref");
            Driver.WaitForReady();
            _inputNCUInsuranceExpiry.SetText(NCUnit.NCUInsuranceExpiry, "Insurance Expiry");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Non Company Unit
        /// </summary>
        /// <param name="UnitNo"></param>
        /// <param name="NCUnit"></param>
        public void VerifyNonCompanyUnit(string UnitNo, NonCompanyUnit NCUnit)
        {
            Settings.Logger.Info(" Verify Non Company Unit ");
            _extendedPage.RefreshAndSetText(_inputNCUnitNo, UnitNo, "Unit No");
            Driver.WaitForReady();
            if (NCUnit.NCUStatus != null)
            {
                string actualStatus = _selectNCUStatus.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUStatus.Substring(0,1), actualStatus);
            }
            if (NCUnit.NCUStatusChangeDate != null)
            {
                if (NCUnit.NCUStatusChangeDate.ToLower() == "now")
                    _extendedPage.VerifySystemDateContainAppdate(_inputNCUStatusChangeDate, "Status Change Date");
                else
                {
                    string actualStatus = _inputNCUStatusChangeDate.GetElementValueByAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(NCUnit.NCUStatusChangeDate, actualStatus);
                }
            }
            if (NCUnit.NCUDesc != null)
            {
                string actualDesc = _inputNCUDesc.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUDesc, actualDesc);
            }
            if (NCUnit.NCUYear != null)
            {
                string actualYear = _inputNCUYear.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUYear, actualYear);
            }
            if (NCUnit.NCUManufacturer != null)
            {
                string actualManufacturer = _inputNCUManufacturer.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUManufacturer, actualManufacturer);
            }
            if (NCUnit.NCUMake != null)
            {
                string actualMake = _inputNCUMake.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUMake, actualMake);
            }
            if (NCUnit.NCUModel != null)
            {
                string actualModel = _inputNCUModel.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUModel, actualModel);
            }
            if (NCUnit.NCUCategoryNo != null)
            {
                string actualCategoryNo = _inputNCUCategoryNo.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUCategoryNo, actualCategoryNo);
                if (NCUnit.NCUCategoryNumDesc != null)
                {
                    string actualCategoryDesc = _inputNCUCategoryDesc.GetElementValueByAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(NCUnit.NCUCategoryNumDesc, actualCategoryDesc);
                }
            }
            if (NCUnit.NCUGPW != null)
            {
                string actualGPW = _inputNCUGPW.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUGPW, actualGPW);
            }
            if (NCUnit.NCUMeter != null)
            {
                string actualMeter = _inputNCUMeter.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUMeter, actualMeter);
            }
            if (NCUnit.NCUMeterDate != null)
            {
                if (NCUnit.NCUMeterDate.ToLower() == "now")
                    _extendedPage.VerifySystemDateContainAppdate(_inputNCUMeterDate, "Meter Date");
                else
                {
                    string actualMeterDate = _inputNCUMeterDate.GetElementValueByAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(NCUnit.NCUMeterDate, actualMeterDate);
                }
            }
            if (NCUnit.NCUUsingDept != null)
            {
                string actualUsingDept = _inputNCUUsingDept.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUUsingDept, actualUsingDept);
                if (NCUnit.NCUUsingDeptDesc != null)
                {
                    string actualUsingDeptDesc = _inputNCUUsingDeptDesc.GetElementValueByAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(NCUnit.NCUUsingDeptDesc, actualUsingDeptDesc);
                }
            }
            if (NCUnit.NCUParkingLocation != null)
            {
                string actualParkingLocation = _inputNCUParkingLocation.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUParkingLocation, actualParkingLocation);
                if (NCUnit.NCUParkingLocDesc != null)
                {
                    string actualParkingLocDesc = _inputNCUParkingLocationDesc.GetElementValueByAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(NCUnit.NCUParkingLocDesc, actualParkingLocDesc);
                }
            }
            if (NCUnit.NCULicenseClass != null)
            {
                string actualLicenseClass = _inputNCULicenseClass.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCULicenseClass, actualLicenseClass);
                if (NCUnit.NCULicenseClassDesc != null)
                {
                    string actualLicenseClassDesc = _inputNCULicenseClassName.GetElementValueByAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(NCUnit.NCULicenseClassDesc, actualLicenseClassDesc);
                }
            }
            if (NCUnit.NCULicenseCategory != null)
            {
                string actualLicenseCategory = _selectNCULicenseCategory.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCULicenseCategory.Substring(0, 1), actualLicenseCategory);
            }
            if (NCUnit.NCUColor != null)
            {
                string actualColor = _inputNCUColor.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUColor, actualColor);
            }
            if (NCUnit.NCUSeatingCap != null)
            {
                string actualSeatingCap = _inputNCUSeatingCap.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUSeatingCap, actualSeatingCap);
            }
            if (NCUnit.NCUFuelProduct != null)
            {
                string actualFuelProduct = _inputNCUFuelProduct.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUFuelProduct, actualFuelProduct);
                if (NCUnit.NCUFuelProductName != null)
                {
                    string actualFuelProductName = _inputNCUFuelName.GetElementValueByAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(NCUnit.NCUFuelProductName, actualFuelProductName);
                }
            }
            if (NCUnit.NCUVehicleRef != null)
            {
                string actualVehicleRef = _inputNCUVehicleRef.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUVehicleRef, actualVehicleRef);
            }
            if (NCUnit.NCUVehicleOwner != null)
            {
                string actualVehicleOwner = _inputNCUVehicleOwner.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUVehicleOwner, actualVehicleOwner);
            }
            if (NCUnit.NCUDriverType != null)
            {
                string actualDriverType = _selectNCUDriverType.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUDriverType.Substring(0, 1), actualDriverType);
            }
            if (NCUnit.NCUDriverNo != null)
            {
                string actualDriverNo = _inputNCUDriverNo.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUDriverNo, actualDriverNo);
                if (NCUnit.NCUDriverDesc != null)
                {
                    string actualDriverDesc = _inputNCUDriverDesc.GetElementValueByAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(NCUnit.NCUDriverDesc, actualDriverDesc);
                }
            }
            if (NCUnit.NCURegistrationRef != null)
            {
                string actualRegistrationRef = _inputNCURegistrationRef.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCURegistrationRef, actualRegistrationRef);
            }
            if (NCUnit.NCURegExpiry != null)
            {
                if (NCUnit.NCURegExpiry.ToLower() == "now")
                    _extendedPage.VerifySystemDateContainAppdate(_inputNCURegExpiry, "Registration Expiry");
                else
                {
                    string actualRegExpiry = _inputNCURegExpiry.GetElementValueByAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(NCUnit.NCURegExpiry, actualRegExpiry);
                }
            }
            if (NCUnit.NCUInspectionCert != null)
            {
                string actualInspectionCert = _inputNCUInspectionCert.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUInspectionCert, actualInspectionCert);
            }
            if (NCUnit.NCUInspExpiry != null)
            {
                if (NCUnit.NCUInspExpiry.ToLower() == "now")
                    _extendedPage.VerifySystemDateContainAppdate(_inputNCUInspExpiry, "Inspection Expiry");
                else
                {
                    string actualInspExpiry = _inputNCUInspExpiry.GetElementValueByAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(NCUnit.NCUInspExpiry, actualInspExpiry);
                }
            }
            if (NCUnit.NCUInspectionRef != null)
            {
                string actualInspectionRef = _inputNCUInspectionRef.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUInspectionRef, actualInspectionRef);
            }
            if (NCUnit.NCUServiceRef != null)
            {
                string actualServiceRef = _inputNCUServiceRef.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUServiceRef, actualServiceRef);
            }
            if (NCUnit.NCULastServiceDt != null)
            {
                if (NCUnit.NCULastServiceDt.ToLower() == "now")
                    _extendedPage.VerifySystemDateContainAppdate(_inputNCULastServiceDt, "Last Service Date");
                else
                {
                    string actualLastServiceDt = _inputNCULastServiceDt.GetElementValueByAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(NCUnit.NCULastServiceDt, actualLastServiceDt);
                }
            }
            if (NCUnit.NCUServiceDueDt != null)
            {
                if (NCUnit.NCUServiceDueDt.ToLower() == "now")
                    _extendedPage.VerifySystemDateContainAppdate(_inputNCUServiceDueDt, "Service Due Date");
                else
                {
                    string actualServiceDueDt = _inputNCUServiceDueDt.GetElementValueByAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(NCUnit.NCUServiceDueDt, actualServiceDueDt);
                }
            }
            if (NCUnit.NCUInsuranceCo != null)
            {
                string actualInsuranceCo = _inputNCUInsuranceCo.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUInsuranceCo, actualInsuranceCo);
            }
            if (NCUnit.NCUInsurancePolicy != null)
            {
                string actualInsurancePolicy = _inputNCUInsurancePolicy.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUInsurancePolicy, actualInsurancePolicy);
            }
            if (NCUnit.NCUInsuranceRef != null)
            {
                string actualInsuranceRef = _inputNCUInsuranceRef.GetElementValueByAttribute("ovalue");
                CommonUtil.AssertTrue<string>(NCUnit.NCUInsuranceRef, actualInsuranceRef);
            }
            if (NCUnit.NCUInsuranceExpiry != null)
            {
                if (NCUnit.NCUInsuranceExpiry.ToLower() == "now")
                    _extendedPage.VerifySystemDateContainAppdate(_inputNCUInsuranceExpiry, "Insurance Expiry");
                else
                {
                    string actualInsuranceExpiry = _inputNCUInsuranceExpiry.GetElementValueByAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(NCUnit.NCUInsuranceExpiry, actualInsuranceExpiry);
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Retrieve Non Company Unit
        /// </summary>
        /// <param name="UnitNo"></param>
        public void RetrieveNonCompanyUnit(string UnitNo)
        {
            Settings.Logger.Info(" Retrieve Non Company Unit ");
            _extendedPage.RefreshAndSetText(_inputNCUnitNo, UnitNo, "Unit No");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValueNotBlank(_inputNCUStatusChangeDate, "Status Change Date");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Deactivate Non Company Unit
        /// </summary>
        /// <param name="UnitNo"></param>
        public void DeactivateNonCompanyUnit(string UnitNo)
        {
            Settings.Logger.Info(" Deactivate Non Company Unit ");
            _extendedPage.SwitchToContentFrame();
            _selectNCUStatus.SelectFilterValueHavingEqualValue("INACTIVE");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.RefreshAndSetText(_inputNCUnitNo, UnitNo, "Unit No");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_selectNCUStatus, "Status", "I");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Non Company Unit Deletion
        /// </summary>
        /// <param name="UnitNo"></param>
        public void VerifyNonCompanyUnitDeletion(string UnitNo)
        {
            _extendedPage.VerifyCodeDeletion(_inputNCUnitNo, UnitNo, "Unit No");
            Driver.SwitchTo().DefaultContent();
        }
    }
}
