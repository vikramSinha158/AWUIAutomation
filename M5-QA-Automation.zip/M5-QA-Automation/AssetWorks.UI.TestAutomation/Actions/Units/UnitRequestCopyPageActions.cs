﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Units;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Units
{
    internal class UnitRequestCopyPageActions : UnitRequestCopyPage
    {
        public UnitRequestCopyPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Unit Request Copy
        /// </summary>
        /// <param name="ReqNo"></param>
        /// <returns>UnitRequestPageActions, RequestNo</returns>
        public (UnitRequestPageActions, string) CreateUnitRequestCopy(string ReqNo = "random")
        {
            Settings.Logger.Info(" Creating new unit request copy");
            if (ReqNo.ToLower().Equals("random"))
                _newRequestNo = CommonUtil.GetRandomStringWithSpecialChars(8, false, false).ToUpper();
            else
                _newRequestNo = ReqNo.ToUpper();

            _extendedPage.SwitchToContentFrame();
            Driver.DoubleClick(_inputRequestNo, "Request No");
            Driver.WaitForReady();
            _lov.EnterDesiredFilterKeywordAndSelectRecord(CommonUtil.DataForKey("ReqStatus"), "Status", "Select");
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            _inputNoOfCopies.SetText(CommonUtil.DataForKey("ReqCopies"), "No of Copies");
            _inputNewReqNo.SetText(_newRequestNo, "New Request No");
            Driver.WaitForReady();
            string _addNew = CommonUtil.DataObjectForKey("IsAddNew").ToString();
            if (_addNew.ToLower().Equals("yes"))
            {
                _buttonAddNew.Click();
                Settings.Logger.Info(" Clicked on Add New button.");
                Driver.WaitForReady();
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForInvisibility(By.Id("NewReqNo"), " New Request No ");
            _newRequestNo = _newRequestNo + "1";
            return (new UnitRequestPageActions(Driver), _newRequestNo);
        }
    }
}
