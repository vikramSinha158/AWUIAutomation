﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Units;
using NUnit.Framework;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Units
{
    internal class UnitDisposalPageActions : UnitDisposalPage
    {
        public UnitDisposalPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Perform Unit Disposal
        /// </summary>
        /// <param name="disposalObj"></param>
        public void PerformUnitDisposal(UnitDisposalObj disposalObj)
        {
            Settings.Logger.Info($" Perform Unit Disposal for - {disposalObj.UnitNo}");
            _extendedPage.SwitchToContentFrame();
            _inputUnitNo.SetText(disposalObj.UnitNo, "Unit No");
            Driver.WaitForReady();
            _selectDisposalStatus.SelectFilterValueHavingEqualValue(disposalObj.DisposalStatus);
            Driver.WaitForReady();
            _selectDisposalStatus.SendKeys(Keys.Tab);
            Driver.WaitForSomeTime();
            Driver.AcceptAlert();
            _inputDisposalReason.SetText(disposalObj.DisposalReason, "Disposal Reason");
            Driver.WaitForReady();
            _selectDisposalCause.SelectFilterValueHavingEqualValue(disposalObj.DisposalCause);
            Driver.WaitForReady();
            _inputEstimatedDate.SetText(disposalObj.EstimatedDate, "Estimated Date");         
            Driver.WaitForReady();
            _authorizedby.SetText(disposalObj.AuthorizedBy, "AuthorizedBy");
            Driver.WaitForReady();
            if(disposalObj.Employee!=null) _extendedPage.SelectAllAndClearField(_empNo);
            _empNo.SetText(disposalObj.Employee, "Employee");
            Driver.WaitForReady();
            _replacementUnit.SetText(disposalObj.ReplacementUnit, "ReplacementUnit");
            if (disposalObj.DisposalDate!=null) 
            {
                Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Sale Info"), "Sale Info Tab");
                Driver.WaitForReady();
                _inputDisposalDate.SetText(disposalObj.DisposalDate, "Disposal Date");
                Driver.WaitForReady();
            }
            if (disposalObj.BillingDeptNote!=null)
            {
                FillBillingDeptNote(disposalObj);
            }
            if (disposalObj.PreSale != null)
            {
                FillPresales(disposalObj);
            }
            if (disposalObj.SaleInfo != null)
            {
                FillSaleInfo(disposalObj);
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Fill Billing Dept Note
        /// </summary>
        /// <param name="disposalObj"></param>
        public void FillBillingDeptNote(UnitDisposalObj disposalObj)
        {
            Settings.Logger.Info($" Filling BillingDeptNote - {disposalObj.UnitNo}");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Billing/Dept/Notes"), "Billing/Dept/Notes");
            Driver.WaitForReady();
            _newBillingCode.SetText(disposalObj.BillingDeptNote.NewBilling, "NewBilling");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_newEffectiveDatet);
            _newEffectiveDatet.SetText(disposalObj.BillingDeptNote.EffDate, "EffDate");
            Driver.WaitForReady();
            _notes.SetText(disposalObj.BillingDeptNote.Note, "Note");
        }

        /// <summary>
        /// Fill Sale Info
        /// </summary>
        /// <param name="disposalObj"></param>
        public void FillSaleInfo(UnitDisposalObj disposalObj)
        {
            Settings.Logger.Info($" Filling SaleInfo - {disposalObj.UnitNo}");
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendedPage.SwitchToContentFrame();
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Sale Info"), "Sale Info");
            Driver.WaitForReady();
            _referenceNumber.SetText(disposalObj.SaleInfo.ReferenceNumber, "ReferenceNumber");
            Driver.WaitForReady();
            _referenceDate.SetText(disposalObj.SaleInfo.ReferenceDate, "ReferenceDate");
            Driver.WaitForReady();
            _disposalTo.SetText(disposalObj.SaleInfo.DisposalTo, "DisposalTo");
            Driver.WaitForReady();
            _inputDisposalDate.SetText(disposalObj.SaleInfo.DisposalDate, "DisposalDate");
            Driver.WaitForReady();
            _pickupDate.SetText(disposalObj.SaleInfo.PickupDate, "PickupDate");
            Driver.WaitForReady();
            _signedReleaseDate.SetText(disposalObj.SaleInfo.SignedReleaseDate, "SignedReleaseDate");
            Driver.WaitForReady();
            _driverLicenseReceivedDate.SetText(disposalObj.SaleInfo.DriverLicenseReceivedDate, "DriverLicenseReceivedDate");
            Driver.WaitForReady();
            _saleAgreementDate.SetText(disposalObj.SaleInfo.SaleAgreementDate, "SaleAgreementDate");
            Driver.WaitForReady();
            _soldBy.SetText(disposalObj.SaleInfo.SoldBy, "SoldBy");
            Driver.WaitForReady();
            _financier.SetText(disposalObj.SaleInfo.Financier, "Financier");
            Driver.WaitForReady();
            _cashReceivedBy.SetText(disposalObj.SaleInfo.CashReceivedBy, "CashReceivedBy");
            Driver.WaitForReady();
            _paidDate.SetText(disposalObj.SaleInfo.PaidDate, "PaidDate");
            Driver.WaitForReady();
            _bankIssuingCheck.SetText(disposalObj.SaleInfo.BankIssuingCheck, "BankIssuingCheck");
        }

        /// <summary>
        /// Fill Pre sales
        /// </summary>
        /// <param name="disposalObj"></param>
        public void FillPresales(UnitDisposalObj disposalObj)
        {
            Settings.Logger.Info($" Filling Presales - {disposalObj.UnitNo}");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Pre-sale"), "Pre-sale");
            Driver.WaitForReady();
            _dropDate.SetText(disposalObj.PreSale.DropDate, "DropDate");
            Driver.WaitForReady();
            _dropLocation.SetText(disposalObj.PreSale.DropLocation, "DropLocation");
            Driver.WaitForReady();
            _dropAuctionDate.SetText(disposalObj.PreSale.DropAuctionDate, "DropAuctionDate");
            Driver.WaitForReady();
            _dropAuctionLocation.SetText(disposalObj.PreSale.DropAuctionLocation, "DropAuctionLocation");
            Driver.WaitForReady();
            _salesClass.SelectFilterValueHavingEqualValue(disposalObj.PreSale.SalesClass);
            Driver.WaitForReady();           
            _saleReadyDate.SetText(disposalObj.PreSale.SaleReadyDate, "SaleReadyDate");
            Driver.WaitForReady();
            _extendedPage.SetCheckBox(_onHold, "OnHold", disposalObj.PreSale.OnHold);
            Driver.WaitForReady();
            _extendedPage.SetCheckBox(_returningTires, "ReturningTires", disposalObj.PreSale.ReturningTires);
            Driver.WaitForReady();
            _extendedPage.SetCheckBox(_tiresReturned, "TiresReturned", disposalObj.PreSale.TiresReturned);
        }


        /// <summary>
        /// Verify Unit Disposal
        /// </summary>
        /// <param name="disposalObj"></param>
        public void VerifyUnitDisposal(UnitDisposalObj disposalObj)
        {
            Settings.Logger.Info($" Verify Unit Disposal for - {disposalObj.UnitNo}");
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            _inputUnitNo.SetText(disposalObj.UnitNo, "Unit No");
            Driver.WaitForSomeTime();
            Driver.AcceptAlert();
            CommonUtil.VerifyElementValue(_inputStatus, "Status", disposalObj.Status);
            CommonUtil.VerifyElementValue(_selectDisposalStatus, "Disposal Status", disposalObj.DisposalStatus, true);
            CommonUtil.VerifyElementValue(_inputDisposalReason, "Disposal Reason", disposalObj.DisposalReason);
            CommonUtil.VerifyElementValue(_selectDisposalCause, "Disposal Cause", disposalObj.DisposalCause, true);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Unit Deletion From Unit Disposal
        /// </summary>
        /// <param name="unitNo"></param>
        public void UnitDeletionFromUnitDisposal(string unitNo)
        {
            _extendedPage.VerifyCodeDeletion(_inputUnitNo, unitNo, "unit No");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Error Message Popup Displayed
        /// </summary>
        public void VerifyErrorMessagePopupDisplayed()
        {
            Assert.IsTrue(_extendedPage.GetErrorMessage().Contains("since it has 1 open Work Order"));
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.ActionRequiredWindow("Leave");
            Settings.Logger.Info($" Verified Error Message Popup Displayed ");
        }
    }
}
