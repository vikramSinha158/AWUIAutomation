﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Units;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Units
{
    internal class UnitPurchaseRequisitionsPageActions : UnitPurchaseRequisitionsPage
    {
        public UnitPurchaseRequisitionsPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Unit Purchase Requisition
        /// </summary>
        /// <param name="UPReq"></param>
        /// <returns></returns>
        public string CreateUnitPurchaseRequisition(UnitPurchaseRequisition UPReq)
        {
            Settings.Logger.Info(" Create a new Unit Purchase Requisition");
            if (UPReq.IsAddNew)
            {
                Settings.Logger.Info(" Clicking on Add New button ");
                _extendedPage.SwitchToContentFrame();
                _buttonAddNew.Click();
            }
            else
            {
                if (UPReq.UnitNo == null)
                {
                    UPReq.UnitNo = CommonUtil.GetRandomStringWithSpecialChars().ToUpper();
                    _inputUnitNo.SetText(UPReq.UnitNo, "Unit No", Driver, _extendedPage._contentFrame, "content frame");
                    if (UPReq.IsCancel)
                    {
                        _extendedPage.ClickOnDialogBoxButton("Cancel");
                        Driver.WaitForReady();
                        _inputUnitNo.SetText(UPReq.UnitNo, "Unit No", Driver, _extendedPage._contentFrame, "content frame");
                    }
                    _extendedPage.ClickOnDialogBoxButton("Create");
                }
                else
                    _inputUnitNo.SetText(UPReq.UnitNo, "Unit No", Driver, _extendedPage._contentFrame, "content frame");
                _extendedPage.SwitchToContentFrame();
            }
            if (UPReq.DetailTab != null)
                FillDetailTabInformation(UPReq.DetailTab);
            if (UPReq.POListTab != null)
                FillPOListTabInformation(UPReq.POListTab);
            if (UPReq.CategoryOptionsTab != null)
                FillCategoryOptionsTabInformation(UPReq.CategoryOptionsTab);
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            UPReq.UnitNo = _inputUnitNo.GetElementValueByAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            return UPReq.UnitNo;
        }

        /// <summary>
        /// Update Unit Purchase Requisition
        /// </summary>
        /// <param name="UPReq"></param>
        public void UpdateUnitPurchaseRequisition(UnitPurchaseRequisition UPReq)
        {
            Settings.Logger.Info(" Update a Unit Purchase Requisition");
            _extendedPage.RefreshAndSetText(_inputUnitNo, UPReq.UnitNo, "Unit No");
            if (UPReq.DetailTab != null)
                FillDetailTabInformation(UPReq.DetailTab);
            if (UPReq.POListTab != null)
                FillPOListTabInformation(UPReq.POListTab);
            if (UPReq.CategoryOptionsTab != null)
                FillCategoryOptionsTabInformation(UPReq.CategoryOptionsTab);
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Fill Detail Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillDetailTabInformation(UPRDetailTab DataObject)
        {
            Settings.Logger.Info(" Update Detail Information");
            _extendedPage.GetTabLinkByText("Detail").Click();
            Settings.Logger.Info("Clicked on Detail Tab");
            Driver.WaitForReady();
            _inputRequisitionNo.SetText(DataObject.RequisitionNo, "Requisition No");
            Driver.WaitForReady();
            _inputBudgetYear.SetText(DataObject.BudgetYear, "Budget Year");
            Driver.WaitForReady();
            _inputRequestedDate.SetText(DataObject.Requested, "Requested Date");
            Driver.WaitForReady();
            _inputExpectedDelivery.SetText(DataObject.ExpectedDelivery, "Expected Delivery");
            Driver.WaitForReady();
            _inputReplacementFund.SetText(DataObject.ReplacementFund, "Replacement Fund");
            Driver.WaitForReady();
            _inputOwnerDept.SetText(DataObject.OwnerDept, "Owner Dept");
            Driver.WaitForReady();
            _inputUsingDept.SetText(DataObject.UsingDept, "Using Dept");
            Driver.WaitForReady();
            if (DataObject.DeliveryLocation != null)
                _inputDelLoc.SetText(DataObject.DeliveryLocation, "Delivery Location");
            else
                _inputDelLoc.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            _inputCustomerNotes.SetText(DataObject.CustomerNotes, "Customer Notes");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Fill PO List Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillPOListTabInformation(UPRPOListTab DataObject)
        {
            Settings.Logger.Info(" Update P.O. List Information");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("P.O. List"), "P.O. List");
            Settings.Logger.Info("Clicked on P.O. List Tab");
            Driver.WaitForReady();
            if (DataObject.POList != null)
            {
                int row = 0;
                IWebElement poNo;
                Driver.SwitchToFrame(_framePONumbers, "PO Numbers");
                foreach (POList list in DataObject.POList)
                {
                    if (list.PONumber != null)
                    {
                        if (list.FromLOV)
                        {
                            poNo = _extendedPage.GetElementForInput("PoNumber$new_" + row.ToString());
                            Driver.DoubleClick(poNo, "PO Number");
                            _lov.SearchAndSelectFirstRowData(list.PONumber);
                            Driver.WaitForReady();
                            _extendedPage.SwitchToTableFrame(_framePONumbers);
                        }
                        else
                        {
                            poNo = _extendedPage.GetElementForInput("PoNumber$new_" + row.ToString());
                            poNo.SetText(list.PONumber, "PO Number");
                            Driver.WaitForReady();
                        }
                        if (list.PrimaryPO)
                        {
                            _extendedPage.GetElementForInput("PrimaryPO$new_" + row.ToString()).Click();
                            Driver.WaitForReady();
                        }
                        _extendedPage.GetElementForInput("PurchaseDo$new_" + row.ToString()).SetText(list.PurchaseAmount, "Purchase Amount");
                        Driver.AcceptAlert();
                        _extendedPage.GetElementForInput("ChangeOrder$new_" + row.ToString()).SetText(list.ChangeOrder, "Change Order");
                        Driver.AcceptAlert();
                    }
                    row++;
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Fill Category Options Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void FillCategoryOptionsTabInformation(UPRCategoryOptionsTab DataObject)
        {
            Settings.Logger.Info(" Update Category Options Information");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Category Options"), "Category Options");
            Settings.Logger.Info("Clicked on Category Options Tab");
            Driver.WaitForReady();
            _inputCategoryCode.SetText(DataObject.CategoryCode, "Category Code");
            Driver.WaitForReady();
            if (DataObject.OptionSelections)
            {
                Driver.SwitchToFrame(_frameNewUnit, "Table frame");
                _checkboxSelected.Click();
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Unit Purchase Requisition Information
        /// </summary>
        /// <param name="UnitNo"></param>
        /// <param name="UPReq"></param>
        public void VerifyUnitPurchaseRequisitionInformation(string UnitNo, UnitPurchaseRequisition UPReq)
        {
            Settings.Logger.Info(" Verify Unit Purchase Requisition Information");
            _extendedPage.RefreshAndSetText(_inputUnitNo, UnitNo, "Unit No");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputNewUnitDesc, "New Unit Desc", UPReq.UnitDesc);
            if (UPReq.DetailTab != null)
                VerifyDetailTabInformation(UPReq.DetailTab);
            if (UPReq.CategoryOptionsTab != null)
                VerifyCategoryOptionsTabInformation(UPReq.CategoryOptionsTab);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Detail Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyDetailTabInformation(UPRDetailTab DataObject)
        {
            Settings.Logger.Info(" Verify Detail Information");
            _extendedPage.GetTabLinkByText("Detail").Click();
            Settings.Logger.Info("Clicked on Detail Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputRequisitionNo, "Requisition No", DataObject.RequisitionNo);
            CommonUtil.VerifyElementValue(_inputBudgetYear, "Budget Year", DataObject.BudgetYear);
            if (DataObject.ExpectedDelivery == "now")
                _extendedPage.VerifySystemDateContainAppdate(_inputExpectedDelivery, "Expected Delivery");
            else
                CommonUtil.VerifyElementValue(_inputExpectedDelivery, "Expected Delivery", DataObject.ExpectedDelivery);
            CommonUtil.VerifyElementValue(_inputReplacementFund, "Replacement Fund", DataObject.ReplacementFund);
            CommonUtil.VerifyElementValue(_inputOwnerDept, "Owner Dept", DataObject.OwnerDept);
            CommonUtil.VerifyElementValue(_inputUsingDept, "Using Dept", DataObject.UsingDept);
            CommonUtil.VerifyElementValue(_inputDelLoc, "Delivery Location", DataObject.DeliveryLocation);
            CommonUtil.VerifyElementValue(_inputCustomerNotes, "Customer Notes", DataObject.CustomerNotes);
        }

        /// <summary>
        /// Verify Category Options Tab Information
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyCategoryOptionsTabInformation(UPRCategoryOptionsTab DataObject)
        {
            Settings.Logger.Info(" Verify Category Options Information");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Category Options"), "Category Options");
            Settings.Logger.Info("Clicked on Category Options Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputCategoryCode, "Category Code", DataObject.CategoryCode);
        }

        /// <summary>
        /// Verify UnitRequisitionIn Deletion
        /// </summary>
        /// <param name="UnitNo"></param>
        public void VerifyUnitRequisitionInDeletion(string UnitNo)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.VerifyCodeDeletion(_inputUnitNo, UnitNo, "Unit No ");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Cance lUnit RequisitionIn Deletion
        /// </summary>
        /// <param name="UnitNo"></param>
        public void VerifyCancelUnitRequisitionInDeletion(string UnitNo)
        {
            _extendedPage.RefreshAndSetText(_inputUnitNo, UnitNo, "UnitNo");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClickOnDialogBoxButton("Cancel");
            Settings.Logger.Info(" Successfully Verified Cancel Unit RequisitionIn Deletion  ");
        }
    }
}