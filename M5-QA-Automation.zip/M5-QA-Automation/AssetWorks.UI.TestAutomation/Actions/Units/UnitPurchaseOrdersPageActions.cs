﻿using OpenQA.Selenium;
using System.Collections.Generic;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Units;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Units
{
    internal class UnitPurchaseOrdersPageActions : UnitPurchaseOrdersPage
    {
        public UnitPurchaseOrdersPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Unit Purchase Order
        /// </summary>
        /// <param name="unitPO"></param>
        /// <returns>PONo</returns>
        public string CreateUnitPurchaseOrder(UnitPurchaseOrder unitPO)
        {
            Settings.Logger.Info(" Creating new unit purchase order ");
            if (unitPO.PONo == null)
                unitPO.PONo = CommonUtil.GetRandomStringWithSpecialChars().ToUpper();
            _inputPurchaseOrderNo.SetText(unitPO.PONo, "Purchase Order No", Driver, 
                _extendedPage._contentFrame, "content frame");
            if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                _extendedPage.ClickOnDialogBoxButton("Create");
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            _inputPurchaseOrderDesc.SetText(unitPO.PODesc, "Purchase Order Desc");
            Driver.WaitForReady();
            if (unitPO.PODetail != null)
                FillDetailTabInformation(unitPO.PODetail);
            if (unitPO.POUnits != null)
                FillUnitsTabInformation(unitPO.POUnits);
            if (unitPO.POPayments != null)
                FillPaymentTabInformation(unitPO.POPayments);
            if (unitPO.PONonUnitCharges != null)
                FillNonUnitChargesTabInformation(unitPO.PONonUnitCharges);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.VerifyCreatedActionNumber(_inputPurchaseOrderNo, unitPO.PONo);
            return unitPO.PONo;
        }

        /// <summary>
        /// Update Unit Purchase Order
        /// </summary>
        /// <param name="unitPO"></param>
        public void UpdateUnitPurchaseOrder(UnitPurchaseOrder unitPO)
        {
            Settings.Logger.Info(" Updating unit purchase order ");
            _extendedPage.RefreshAndSetText(_inputPurchaseOrderNo, unitPO.PONo, "Purchase Order No");
            Driver.WaitForReady();
            _inputPurchaseOrderDesc.SetText(unitPO.PODesc, "Purchase Order Desc");
            Driver.WaitForReady();
            _selectPurchaseOrderStatus.SelectFilterValueHavingEqualValue(unitPO.POStatus);
            Driver.WaitForReady();
            if (unitPO.PODetail != null)
                FillDetailTabInformation(unitPO.PODetail);
            if (unitPO.POUnits != null)
                FillUnitsTabInformation(unitPO.POUnits);
            if (unitPO.POPayments != null)
                FillPaymentTabInformation(unitPO.POPayments);
            if (unitPO.PONonUnitCharges != null)
                FillNonUnitChargesTabInformation(unitPO.PONonUnitCharges);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Fill Detail Tab Information
        /// </summary>
        /// <param name="detail"></param>
        public void FillDetailTabInformation(PODetail detail)
        {
            Settings.Logger.Info(" Fillig Detail Tab Information ");
            _extendedPage.GetTabLinkByText("Detail").Click();
            Settings.Logger.Info("Clicked on Detail Tab");
            Driver.WaitForReady();
            Driver.DoubleClick(_inputVendorNo, "Customer");
            _lov.SearchAndSelectFirstRowData(detail.POVendorNo);
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            _inputTenderNo.SetText(detail.POTenderNo, "Tender No");
            Driver.WaitForReady();
            _inputPhoneNo.SetText(detail.POPhone, "Phone No");
            Driver.WaitForReady();
            _inputPhoneEx.SetText(detail.POPhoneEx, "Phone Ex");
            Driver.WaitForReady();
            _inputPurchaseOrderLimit.SetText(detail.POLimit, "Purchase Order Limit");
            Driver.WaitForReady();
            _inputTechSpecNo.SetText(detail.POTechSpecNo, "Tech Spec No");
            Driver.WaitForReady();
            _inputCreation.SetText(detail.POCreation, "Creation");
            Driver.WaitForReady();
            _inputExpiration.SetText(detail.POExpiration, "Expiration");
            Driver.WaitForReady();
            _inputNotes.SetText(detail.PONotes, "Notes");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Fill Units Tab Information
        /// </summary>
        /// <param name="units"></param>
        public void FillUnitsTabInformation(List<POUnit> units)
        {
            Settings.Logger.Info(" Update PO Units Information");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Units"), "Units");
            Settings.Logger.Info("Clicked on Units Tab");
            Driver.WaitForReady();
            if (units != null)
            {
                int row = 0;
                Driver.SwitchToFrame(_frameUnits, "Units");
                foreach (POUnit list in units)
                {
                    if (list.POUnitNo != null)
                    {
                        _extendedPage.GetTableActionElementByRelatedColumnValue(_tableUnits, "Unit No.", 
                            list.POUnitNo, "delivery_date").SetText(list.PODeliveryDate, "Delivery Date");
                        Driver.WaitForReady();
                    }
                    row++;
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Fill Payment Tab Information
        /// </summary>
        /// <param name="payments"></param>
        public void FillPaymentTabInformation(List<POPayment> payments)
        {
            Settings.Logger.Info(" Update PO Payment Information");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Payment"), "Payment");
            Settings.Logger.Info("Clicked on Payment Tab");
            Driver.WaitForReady();
            if (payments != null)
            {
                int row = 0;
                Driver.SwitchToFrame(_framePayment, "Payment");
                foreach (POPayment list in payments)
                {
                    if (list.addNew)
                    {
                        _extendedPage.GetElementForInput("inv_no$new_" + row.ToString()).SetText(list.POInvoiceNo, "Invoice No");
                        Driver.WaitForReady();
                        _extendedPage.GetElementForInput("pay_date$new_" + row.ToString()).SetText(list.POPaymentDate, "Payment Date");
                        Driver.WaitForReady();
                        _extendedPage.GetElementForInput("unit_no_2$new_" + row.ToString()).SetText(list.POUnitNo, "Unit No");
                        Driver.WaitForReady();
                        _extendedPage.GetElementForInput("pay_amt$new_" + row.ToString()).SetText(list.POPaymentAmt, "Payment Amt");
                        Driver.WaitForReady();
                        _extendedPage.GetElementForInput("checkNo$new_" + row.ToString()).SetText(list.POCheckNo, "Check No");
                        Driver.WaitForReady();
                        _extendedPage.GetElementForInput("voucher$new_" + row.ToString()).SetText(list.POVoucherNo, "Voucher No");
                        Driver.WaitForReady();
                        _extendedPage.GetElementForInput("packslip$new_" + row.ToString()).SetText(list.POPackingSlip, "Packing Slip");
                        Driver.WaitForReady();
                        _extendedPage.AddNotes(_extendedPage.GetElementForInput("note$new_" + row.ToString(), "id", "button"), list.PONote);
                        Driver.WaitForReady();
                    }
                    row++;
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Fill Non Unit Charges Tab Information
        /// </summary>
        /// <param name="charges"></param>
        public void FillNonUnitChargesTabInformation(List<PONonUnitCharge> charges)
        {
            Settings.Logger.Info(" Update PO Non-Unit Charges Information");
            Driver.ScrollIntoViewAndClick(_extendedPage.GetTabLinkByText("Non-Unit Charges"), "Non-Unit Charges");
            Settings.Logger.Info("Clicked on Non-Unit Charges Tab");
            Driver.WaitForReady();
            if (charges != null)
            {
                int row = 0;
                Driver.SwitchToFrame(_frameCharges, "Charges");
                foreach (PONonUnitCharge list in charges)
                {
                    if (list.addNew)
                    {
                        _extendedPage.GetElementForInput("inv_no1$new_" + row.ToString()).SetText(list.POInvoiceNo, "Invoice No");
                        Driver.WaitForReady();
                        _extendedPage.GetElementForInput("pay_date1$new_" + row.ToString()).SetText(list.POPaymentDate, "Payment Date");
                        Driver.WaitForReady();
                        _extendedPage.GetElementForInput("pay_amt1$new_" + row.ToString()).SetText(list.POPaymentAmt, "Payment Amt");
                        Driver.WaitForReady();
                        _extendedPage.GetElementForInput("checkNo1$new_" + row.ToString()).SetText(list.POCheckNo, "Check No");
                        Driver.WaitForReady();
                        _extendedPage.AddNotes(_extendedPage.GetElementForInput("note1$new_" + row.ToString(), "id", "button"), list.PONote);
                        Driver.WaitForReady();
                    }
                    row++;
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Verify Unit Purchase Order
        /// </summary>
        /// <param name="PONo"></param>
        /// <param name="unitPO"></param>
        public void VerifyUnitPurchaseOrder(string PONo, UnitPurchaseOrder unitPO)
        {
            Settings.Logger.Info(" Verify Unit Purchase Order ");
            _extendedPage.RefreshAndSetText(_inputPurchaseOrderNo, PONo, "Purchase Order No");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputPurchaseOrderDesc, "Desc", unitPO.PODesc);
            if (unitPO.POStatus != null)
                CommonUtil.AssertTrue(unitPO.POStatus.Substring(0,1), 
                    _selectPurchaseOrderStatus.GetElementValueByAttribute("ovalue"));
            if (unitPO.PODetail != null)
                VerifyDetailTabInformation(unitPO.PODetail);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Detail Tab Information
        /// </summary>
        /// <param name="detail"></param>
        public void VerifyDetailTabInformation(PODetail detail)
        {
            Settings.Logger.Info(" Fillig Detail Tab Information ");
            _extendedPage.GetTabLinkByText("Detail").Click();
            Settings.Logger.Info("Clicked on Detail Tab");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputVendorNo, "Vendor No", detail.POVendorNo);
            CommonUtil.VerifyElementValue(_inputVendorName, "Vendor Name", detail.POVendorName);
            CommonUtil.VerifyElementValue(_inputTenderNo, "Tender No", detail.POTenderNo);
            CommonUtil.VerifyElementValue(_inputAddress, "Address", detail.POAddress);
            CommonUtil.VerifyElementValue(_inputPhoneNo, "Phone No", detail.POPhone);
            CommonUtil.VerifyElementValue(_inputPhoneEx, "Phone Ex", detail.POPhoneEx);
            CommonUtil.VerifyElementValue(_inputCity, "City", detail.POCity);
            CommonUtil.VerifyElementValue(_inputState, "State", detail.POState);
            CommonUtil.VerifyElementValue(_inputPurchaseOrderLimit, "Purchase Order Limit", detail.POLimit);
            CommonUtil.VerifyElementValue(_inputTechSpecNo, "Tech Spec No", detail.POTechSpecNo);
            CommonUtil.VerifyElementValue(_inputTechSpecDesc, "Tech Spec Desc", detail.POTechSpecDesc);
            CommonUtil.VerifyElementValue(_inputExpiration, "Expiration", detail.POExpiration);
            CommonUtil.VerifyElementValue(_inputNotes, "Notes", detail.PONotes);
        }

        /// <summary>
        /// Verify Unit Purchase Order Deletion
        /// </summary>
        /// <param name="PONo"></param>
        public void VerifyUnitPurchaseOrderDeletion(string PONo, string ErrorMsg = "N/A")
        {
            Settings.Logger.Info($" Deleting Unit Purchase Order - {PONo}.");
            _extendedPage.RefreshAndSetText(_inputPurchaseOrderNo, PONo, "Purchase Order No");
            _inputPurchaseOrderNo.ClickElement(PONo, Driver);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ActionRequiredWindow("Delete");
            Driver.WaitForSomeTime();
            Driver.AcceptAlert();
            if (ErrorMsg != "N/A")
            {
                Settings.Logger.Info(" Verifying warning message ");
                CommonUtil.AssertTrue(ErrorMsg, _extendedPage.GetErrorMessage());
                _extendedPage.ClickOnRefreshButton();
                _extendedPage.ActionRequiredWindow("Leave");
            }
            else
            {
                Driver.WaitForReady();
                _extendedPage.VerifyCodeDoesNotExist(_inputPurchaseOrderNo, PONo, "Purchase Order No");
                Settings.Logger.Info($"Purchase Order No - {PONo} Deleted successfully  ");
            }
            Driver.SwitchTo().DefaultContent();
        }

    }
}
