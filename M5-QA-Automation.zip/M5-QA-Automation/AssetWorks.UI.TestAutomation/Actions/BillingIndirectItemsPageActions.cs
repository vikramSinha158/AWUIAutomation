﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class BillingIndirectItemsPageActions : BillingIndirectItemsPage
    {
        public BillingIndirectItemsPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Add Indirect Accounts Bill Items
        /// </summary>
        /// <param name="BillingIndirectItems"></param>
        public void AddIndirectAccountsBillItems(BillingIndirectItems BillingIndirectItems)
        {
            _extendpage.SwitchToContentFrame();
            _billingCodeInput.SetText(BillingIndirectItems.BillCode, "BillCode");
            if (BillingIndirectItems.BillIndirectAccountsBillItems != null)
            {
                FillIndirectAccountsBillItem(BillingIndirectItems.BillIndirectAccountsBillItems);
            }
            _extendpage.Save();
            Settings.Logger.Info("Added Indirect Accounts BillI tems");
        }

        /// <summary>
        /// Fill Indirect Accounts BillItem
        /// </summary>
        /// <param name="AccountsBillItems"></param>
        public void FillIndirectAccountsBillItem(BillIndirectAccountsBillItems AccountsBillItems)
        {
           _extendpage.AddRecordsInTable(_billIndAcctTable, _billIndAcctFrame, AccountsBillItems.IndirectAccountsBillItemsTableKey);        
        }

        /// <summary>
        /// Delete Indirect Accounts BillItem
        /// </summary>
        /// <param name="BillingIndirectItems"></param>
        public void DeleteIndirectAccountsBillItem(BillingIndirectItems BillingIndirectItems)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_billingCodeInput, BillingIndirectItems.BillCode, "billingCodeInput");
            _extendpage.DeleteRecordsFromTable(_billIndAcctTable, _billIndAcctFrame, BillingIndirectItems.BillIndirectAccountsBillItems.IndirectAccountsBillItemsTableKey, "value",3);     
            Settings.Logger.Info("deleted Indirect Accounts BillI tems");
        }

        /// <summary>
        /// Verify Indirect Accounts BillItem
        /// </summary>
        /// <param name="BillingIndirectItems"></param>
        public void VerifyIndirectAccountsBillItem(BillingIndirectItems BillingIndirectItems)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_billingCodeInput, BillingIndirectItems.BillCode, "billingCodeInput");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_billingCodeInput, "billingCodeInput", BillingIndirectItems.BillCode);
            if (BillingIndirectItems.BillIndirectAccountsBillItems != null)
            {
                _extendpage.VerifyRecordsInTable(_billIndAcctTable, _billIndAcctFrame, BillingIndirectItems.BillIndirectAccountsBillItems.IndirectAccountsBillItemsTableKey);
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Successfully Verified Indirect Accounts Bill Item");
        }

        /// <summary>
        /// Verify Delete Indirect Accounts BillItem
        /// </summary>
        /// <param name="BillingIndirectItems"></param>
        public void VerifyDeleteIndirectAccountsBillItem(BillingIndirectItems BillingIndirectItems)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_billingCodeInput, BillingIndirectItems.BillCode, "billingCodeInput");
            Driver.WaitForReady();
            _extendpage.VerifyRecordDeletionFromTable(_billIndAcctTable, _billIndAcctFrame, BillingIndirectItems.BillIndirectAccountsBillItems.IndirectAccountsBillItemsTableKey);
            Settings.Logger.Info(" Successfully Verified  Indirect Accounts Bill Item Deletion ");
        }
    }
}
