﻿using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class AppUserMaintenancePageActions : AppUserMaintenanceMainPage
    {
        public AppUserMaintenancePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Application User
        /// </summary>
        /// <param name="applicationUser"></param>
        /// <returns></returns>
        public string CreateApplicationUser(ApplicationUser applicationUser)
        {
            string User = string.Empty;
            Settings.Logger.Info(" Creating Application User ");
            if (!_extendPage.CheckDataExistenceAndGetActionCode(applicationUser.User, ref User, "ApplicationUserQuery", 6))
            {
                _extendPage.SwitchToContentFrame();
                _appUser.SetText(User, " Application User ");
                Driver.SwitchTo().DefaultContent();
                _extendPage.ActionRequiredWindow("Create");
                _extendPage.SwitchToContentFrame();
                FillApplicationUserMaintenanceDetail(applicationUser);
                _extendPage.VerifyCreatedActionNumber(_appUser, User);
                applicationUser.User = User;
            }
            return User;
        }

        /// <summary>
        /// Fill User Details
        /// </summary>
        /// <param name="AppUser"></param>
        public void FillApplicationUserMaintenanceDetail(ApplicationUser applicationUser)
        {
            Settings.Logger.Info(" Updating Application User Details ");
            _allowWebAccessChb.SelectCheckBox(" Allow Web Access ", applicationUser.AllowWebAccess);
            Driver.WaitForReady();
            _appPassword.SetText(applicationUser.Password, "Password");
            Driver.WaitForReady();
            _allowChangePasswordChb.SelectCheckBox(" User Can Change Password ", applicationUser.UserCanChangePassword);
            _allowMobileAccessChb.SelectCheckBox(" Allow Mobile Access ", applicationUser.AllowMobileAccess);
            Driver.WaitForReady();
            _mobilePassword.SetText(applicationUser.Password, "Mobile Password");
            Driver.WaitForReady();
            _adhocAccess.SelectFilterValueHavingEqualValue(applicationUser.AdhocAccess);
            Driver.WaitForReady();
            _adhocStartingFolder.SetText(applicationUser.StartingFolder, "Starting Folder");
            Driver.WaitForReady();
            _userRole.SetText(applicationUser.UserRole, "User Role");
            Driver.WaitForReady();
            _userDashboardChb.SetCheckBox("User Dashboard", applicationUser.UserDashboard);
            _idleTimeout.SetText(applicationUser.IdleTimeout, "Idle Timeout");
            Driver.WaitForReady();
            _pooledChb.SetCheckBox("Pooled", applicationUser.Pooled);
            _crystalEnterpriseOutputPath.SetText(applicationUser.CrystalEnterprise, "Crystal Enterprise");
            Driver.WaitForReady();
            _stylesheetDirectory.SetText(applicationUser.StylesheetDirectory, "Stylesheet Directory");
            Driver.WaitForReady();
            _homePage.SetText(applicationUser.HomePage, "Home Page");
            Driver.WaitForReady();
            _startingPMM.SetText(applicationUser.StartingPMM, "Starting PMM");
            Driver.WaitForReady();
            _userName.SetText(applicationUser.UserName, "User Name");
            Driver.WaitForReady();
            if (applicationUser.UniqueId != null)
            {
                _extendPage.SelectAllAndClearField(_uniqueID);
                _uniqueID.SetText(applicationUser.UniqueId, "Unique Id");
            }
            else
                _uniqueID.SendKeys(Keys.Tab);
            _userEmpNo.SetText(applicationUser.EmployeeNo, "Employee No");
            Driver.WaitForReady();
            _userDivision.SetText(applicationUser.Division, "Division");
            Driver.WaitForReady();
            _department.SetText(applicationUser.Department, "Department");
            Driver.WaitForReady();
            _phone.SetText(applicationUser.Phone, "Phone");
            Driver.WaitForReady();
            _deptGroup.SetText(applicationUser.DepartmentGroup, "Department Group");
            Driver.WaitForReady();
            _email.SetText(applicationUser.Email, "Email");
            Driver.WaitForReady();
            _vendorNo.SetText(applicationUser.Vendor, "Vendor");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }


        /// <summary>
        /// Verify Application User Data
        /// </summary>
        /// <param name="applicationUser"></param>
        public void VerifyApplicationUserMaintenanceDetail(ApplicationUser applicationUser)
        {
            Settings.Logger.Info(" Verifying Application User Maintenance Data ");
            _extendPage.RefreshAndSetText(_appUser, applicationUser.User, " Application User ");
            Driver.WaitForReady();
            CommonUtil.VerifyCheckboxState(_allowWebAccessChb, "AllowWebAccess", applicationUser.AllowWebAccess);
            Assert.IsFalse(string.IsNullOrEmpty(_appPassword.GetElementValueByAttribute("ovalue")), "Password is Null");
            CommonUtil.VerifyCheckboxState(_allowMobileAccessChb, "AllowMobileAccess", applicationUser.AllowMobileAccess);
            CommonUtil.VerifyElementValue(_adhocAccess, "Adhoc Access", applicationUser.AdhocAccess, true);
            CommonUtil.VerifyElementValue(_adhocStartingFolder, "Starting Folder", applicationUser.StartingFolder);
            CommonUtil.VerifyElementValue(_userRole, "User Role", applicationUser.UserRole);
            CommonUtil.VerifyElementValue(_idleTimeout, "Idle Timeout", applicationUser.IdleTimeout);
            CommonUtil.VerifyElementValue(_crystalEnterpriseOutputPath, "Crystal Enterprise", applicationUser.CrystalEnterprise);
            CommonUtil.VerifyElementValue(_stylesheetDirectory, "Stylesheet Directory", applicationUser.StylesheetDirectory);
            CommonUtil.VerifyElementValue(_homePage, "Home Page", applicationUser.HomePage);
            CommonUtil.VerifyElementValue(_startingPMM, "Starting PMM", applicationUser.StartingPMM);
            CommonUtil.VerifyElementValue(_userName, "User Name", applicationUser.UserName);
            CommonUtil.VerifyElementValue(_uniqueID, "Unique ID", applicationUser.UniqueId);
            CommonUtil.VerifyElementValue(_userEmpNo, "Employee No", applicationUser.EmployeeNo);
            CommonUtil.VerifyElementValue(_userDivision, "Division", applicationUser.Division);
            CommonUtil.VerifyElementValue(_department, "Department", applicationUser.Department);
            CommonUtil.VerifyElementValue(_phone, "Phone", applicationUser.Phone);
            CommonUtil.VerifyElementValue(_deptGroup, "Department Group", applicationUser.DepartmentGroup);
            CommonUtil.VerifyElementValue(_email, "Email", applicationUser.Email);
            CommonUtil.VerifyElementValue(_vendorNo, "Vendor", applicationUser.Vendor);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Open Application User
        /// </summary>
        /// <param name="AppUser"></param>
        public void VerifyApplicationUserDeletion(string AppUser)
        {
            Driver.SwitchTo().DefaultContent();
            _extendPage.VerifyCodeDeletion(_appUser, AppUser, "Application User");
        }

        /// <summary>
        /// Edit Application User Maintenance Detail
        /// </summary>
        /// <param name="DataObjectKey"></param>
        public void EditApplicationUserDetail(ApplicationUser applicationUser)
        {
            Settings.Logger.Info(" Edit User Details ");
            _extendPage.RefreshAndSetText(_appUser, applicationUser.User, " Application User ");
            FillApplicationUserMaintenanceDetail(applicationUser);
            _extendPage.ClicKSave();
        }
    }
}
