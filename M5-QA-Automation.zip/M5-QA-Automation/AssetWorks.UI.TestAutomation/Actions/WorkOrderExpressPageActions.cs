﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class WorkOrderExpressPageActions : WorkOrderExpressPage
    {
        public WorkOrderExpressPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Work Order Express
        /// </summary>
        /// <param name="WorkOrderExpress"></param>
        /// <param name="ItemNo"></param>
        /// <returns></returns>
        public string CreateWorkOrderExpress(WorkOrderExpress WorkOrderExpress, string ItemNo)
        {
            Settings.Logger.Info($"Creating work order Express ");
            string WorkOrderNo = String.Empty;
            Driver.SwitchTo().DefaultContent();
            _extendpage.SwitchToContentFrame();
            _woNumberInput.SetText(ItemNo, "");
            Driver.WaitForReady();
            _buildbutton.ClickElement("BuildButton", Driver);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow("Continue");
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _visitReq.SetText(WorkOrderExpress.Reason, "visitReq");
            Driver.WaitForReady();
            _extendpage.Save();
            Driver.WaitForReady();
            _extendpage.SwitchToContentFrame();
            WorkOrderNo = _WoNo.GetElementValueByAttribute("ovalue");
            WorkOrderExpress.WorkOrderNo = WorkOrderNo;
            if (WorkOrderExpress.AddJobWorkOrderExpress != null)
            {
                FillJobWorkOrderExpress(WorkOrderExpress);
            }
            Settings.Logger.Info($" Created the  WorkOrder Express { WorkOrderExpress.WorkOrderNo }");
            Driver.WaitForReady();
            return WorkOrderExpress.WorkOrderNo;
        }

        /// <summary>
        /// Fill Job Work Order Express
        /// </summary>
        /// <param name="WorkOrderExpress"></param>
        public void FillJobWorkOrderExpress(WorkOrderExpress WorkOrderExpress)       
        {
            Settings.Logger.Info($"Adding the  Job to work order Express{WorkOrderExpress.WorkOrderNo}");
            Driver.WaitForReady();
            List<AddJobWorkOrderExpress> AddJobList = WorkOrderExpress.AddJobWorkOrderExpress;
            foreach (AddJobWorkOrderExpress AddJob in AddJobList)
            {
                Driver.SwitchToFrame(_mreJobFrame, "job frame ");
                Driver.ScrollInView(_mreJobTable);
                _extendpage.GetTableActionElementByRelatedColumnValue(_mreJobTable, "Job", "", "wjJob").SetText(AddJob.JobCode, "JobCode");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_mreJobTable, "Job", AddJob.JobCode, "wjStatus").SendKeys(Keys.Tab);
                Driver.WaitForSomeTime();
                _extendpage.GetTableActionElementByRelatedColumnValue(_mreJobTable, "Job", AddJob.JobCode, "wjJobReason").SetText(AddJob.JobReason, "JobCode");
                if (String.IsNullOrEmpty(_extendpage.GetTableActionElementByRelatedColumnValue(_mreJobTable, "Job", AddJob.JobCode, "wjJobReason").GetAttribute("value")))
                {
                    IWebElement JobElement = _extendpage.GetTableActionElementByRelatedColumnValue(_mreJobTable, "Job", AddJob.JobCode, "wjJobReason");
                    Driver.WaitForReady();
                    JobElement.SendKeys(AddJob.JobReason);
                    Driver.WaitForReady();
                    JobElement.SendKeys(Keys.Tab);
                }
                Driver.WaitForReady();
                _extendpage.Save();
                Driver.WaitForReady();
                _extendpage.SwitchToContentFrame();
            }
            Driver.WaitForReady();
            _completeBtn.ClickElement("Complete Element", Driver);
            Driver.WaitForReady();
            _closeBtn.ClickElement("Complete Element", Driver);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify WorkOrder Job Tab
        /// </summary>
        /// <param name="WorkOrderExpress"></param>
        public void VerifyWorkOrderExpress(WorkOrderExpress WorkOrderExpress)
        {
            Settings.Logger.Info($"Verifying Work Order Express  {WorkOrderExpress.WorkOrderNo}");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendpage.RefreshAndSetText(_woNumberInput, WorkOrderExpress.WorkOrderNo, "WorkOrderNo");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_wonumber, "WorkOrderNo", WorkOrderExpress.WorkOrderNo);
            CommonUtil.VerifyElementValue(_compDeptUnitNo, "compDeptUnitNo", WorkOrderExpress.UnitDepComp);
            CommonUtil.VerifyElementValue(_woLocation, "compDeptUnitNo", WorkOrderExpress.Location);
            CommonUtil.VerifyElementValue(_woStatus, "compDeptUnitNo", WorkOrderExpress.WOStatus);
            Driver.WaitForReady();
            if (WorkOrderExpress.AddJobWorkOrderExpress != null)
            {
                VerifyWorkOrderExpressJobTab(WorkOrderExpress);
            }
            Settings.Logger.Info($"Successfully verified Work Order Express  {WorkOrderExpress.WorkOrderNo}");
        }

        /// <summary>
        /// Verify Work Order Express Job Tab
        /// </summary>
        /// <param name="WorkOrderExpress"></param>
        public void VerifyWorkOrderExpressJobTab(WorkOrderExpress WorkOrderExpress)
        {
            Settings.Logger.Info($"Verifying the  Job Tab to Work Order Express {WorkOrderExpress.WorkOrderNo}");
            Driver.SwitchToFrame(_mreJobFrame, "job frame ");
            Driver.ScrollInView(_mreJobTable);
            List<AddJobWorkOrderExpress> AddJobList = WorkOrderExpress.AddJobWorkOrderExpress;
            foreach (AddJobWorkOrderExpress AddJob in AddJobList)
            {
                IWebElement JobCode = _extendpage.GetTableActionElementByRelatedColumnValue(_mreJobTable, "Job", AddJob.JobCode, "wjJob");
                CommonUtil.VerifyElementValue(JobCode, "JobCode", AddJob.JobCode);
                IWebElement WOJobStatus = _extendpage.GetTableActionElementByRelatedColumnValue(_mreJobTable, "Job", AddJob.JobCode, "wjStatus");
                CommonUtil.VerifyElementValue(WOJobStatus, "WOJobStatus", AddJob.WOJobStatus);
                IWebElement JobReason = _extendpage.GetTableActionElementByRelatedColumnValue(_mreJobTable, "Job", AddJob.JobCode, "wjJobReason");
                CommonUtil.VerifyElementValue(JobReason, "JobReason", AddJob.JobReason);
            }
        }
    }
}
