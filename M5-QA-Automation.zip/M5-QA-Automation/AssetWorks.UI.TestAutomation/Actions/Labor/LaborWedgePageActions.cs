﻿using OpenQA.Selenium;
using System.Collections.Generic;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions.Parts;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Labor;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Labor
{
    internal class LaborWedgePageActions : LaborWedgePage
    {
        internal LaborWedgePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Add Employee Labor Wedge
        /// </summary>
        /// <param name="wedge"></param>
        public void AddEmployeeLaborWedge(EmpLaborWedge wedge)
        {
            Settings.Logger.Info(" Add Employee Labor Wedge ");
            _extendedPage.SwitchToContentFrame();
            _inputEmployeeNo.SetText(wedge.EmployeeNo, "Employee No");
            Driver.WaitForReady();
            _inputPin.SetText(wedge.Pin, "Pin");
            Driver.WaitForReady();
            _inputNWOIndCode.SetText(wedge.NWOIndCode, "NWO Indirect Code");
            Driver.WaitForReady();
            if (wedge.AddJobs != null)
            {
                _addJobs.ClickElement("Add Jobs", Driver);
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                AddJobsToWorkOrder(wedge.AddJobs);
                _extendedPage.SwitchToContentFrame();
            }
            _inputNewJobCode.SetText(wedge.NewJobCode, "New Job Code");
            Driver.WaitForReady();
            if (wedge.NewPosition != null)
            {
                _extendedPage.SelectAllAndClearField(_inputNewPosition);
                _inputNewPosition.SetText(wedge.NewPosition, "New Position");
                Driver.WaitForReady();
            }
            if (wedge.WoTimeType != null)
            {
                _extendedPage.SelectAllAndClearField(_inputWoTimeType);
                _inputWoTimeType.SetText(wedge.WoTimeType, "Wo Time Type");
                Driver.WaitForReady();
            }
            _inputWoPayClass.SetText(wedge.WoPayClass, "Wo Pay Class");
            Driver.WaitForReady();
            if (wedge.WoPayStep != null)
            {
                _extendedPage.SelectAllAndClearField(_inputWoPayStep);
                _inputWoPayStep.SetText(wedge.WoPayStep, "Wo Pay Step");
                Driver.WaitForReady();
            }
            _inputNewPunchTime.SetText(wedge.NewPunchTime, "New Punch Time");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Added Labor Wedge
        /// </summary>
        /// <param name="wedge"></param>
        public void VerifyAddedLaborWedge(EmpLaborWedge wedge)
        {
            Settings.Logger.Info(" Verify Added Labor Wedge ");
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForSomeTime();
            _extendedPage.SwitchToTableFrame(_frameCurrentLabor);
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCurrentLabor, "Employee",
                wedge.EmployeeNo, "empID"), "Employee No", wedge.EmployeeNo, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCurrentLabor, "Employee",
                wedge.EmployeeNo, "Dept"), "Unit No", wedge.NWOUnitNo, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCurrentLabor, "Employee",
                wedge.EmployeeNo, "Ind"), "Indirect Code", wedge.IndirectCode, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCurrentLabor, "Employee",
                wedge.EmployeeNo, "WONo"), "WO Number", wedge.WoNumber, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableCurrentLabor, "Employee",
                wedge.EmployeeNo, "JobCode"), "Job Code", wedge.NewJobCode, false, "value");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Remove Employee Labor Wedge
        /// </summary>
        /// <param name="wedge"></param>
        public void RemoveEmployeeLaborWedge(EmpLaborWedge wedge)
        {
            Settings.Logger.Info(" Remove Employee Labor Wedge ");
            UpdateEmployeeLaborWedge(wedge);
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_frameCurrentLabor);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_tableCurrentLabor, "Employee", wedge.EmployeeNo);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Employee Labor Wedge
        /// </summary>
        /// <param name="wedge"></param>
        public void UpdateEmployeeLaborWedge(EmpLaborWedge wedge)
        {
            Settings.Logger.Info(" Update Employee Labor Wedge ");
            _extendedPage.RefreshAndSetText(_inputEmployeeNo, wedge.EmployeeNo, "Employee No");
            Driver.WaitForReady();
            _inputPin.SetText(wedge.Pin, "Pin");
            Driver.WaitForReady();
            _inputJobStatus.SetText(wedge.JobStatus, "Job Status");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_inputNWOIndCode);
            _inputNWOIndCode.SetText(wedge.NWOIndCode, "NWO Indirect Code");
            Driver.WaitForReady();
            if (wedge.NewPunchTime != null)
            {
                _inputNewPunchTime.SetText(wedge.NewPunchTime, "New Punch Time");
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
            }
            else
            {
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
                Driver.WaitForSomeTime();
            }
        }

        /// <summary>
        /// Complete Last Job On Work Order
        /// </summary>
        /// <param name="WorkOrder"></param>
        public void CompleteLastJobOnWorkOrder(WorkOrderMain WorkOrder, string EmployeeNo)
        {
            Settings.Logger.Info(" Complete Last Job On Work Order ");
            Driver.WaitForSomeTime();
            _extendedPage.ActionRequiredWindow("Yes");
            Driver.WaitForSomeTime(10);
            string parentWindow = Driver.SwitchToNewWindow();
            WorkOrderMainPageActions WO = new WorkOrderMainPageActions(Driver);
            WO.VerifyWorkOrderJobTab(WorkOrder);
            Driver.SwitchTo().DefaultContent();
            Driver.Close();
            Driver.SwitchTo().Window(parentWindow);
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_frameCurrentLabor);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_tableCurrentLabor, "Employee", EmployeeNo);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Add Jobs to Work Order
        /// </summary>
        /// <param name="Jobs"></param>
        public void AddJobsToWorkOrder(List<AddJobs> Jobs)
        {
            Settings.Logger.Info(" Add Jobs to Work Order ");
            int row = 0;
            Driver.SwitchToFrame(_extendedPage._contentFrame2, "Content");
            Driver.SwitchToFrame(_frameAddJobs, "Add Jobs");
            foreach (AddJobs job in Jobs)
            {
                _inputNewJob(row).SetText(job.JobCode, "Job");
                Driver.WaitForReady();
                if (job.Status != null)
                {
                    _extendedPage.SelectAllAndClearField(_inputNewStatus(row));
                    _inputNewStatus(row).SetText(job.Status, "Status");
                    Driver.WaitForReady();
                }
                else
                    _inputNewStatus(row).SendKeys(Keys.Tab);
                _inputNewJobReason(row).SetText(job.JobReason, "Job Reason");
                row++;
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// View My Job Assignments
        /// </summary>
        /// <param name="wedge"></param>
        public void ViewMyJobAssignments(EmpLaborWedge wedge)
        {
            Settings.Logger.Info(" Add Employee Labor by View My Job Assignments ");
            _extendedPage.SwitchToContentFrame();
            _inputEmployeeNo.SetText(wedge.EmployeeNo, "Employee No");
            Driver.WaitForReady();
            _inputPin.SetText(wedge.Pin, "Pin");
            Driver.WaitForReady();
            Driver.MouseHover(_jobAssignments, "View My Job Assignments");
            _linkAddJob(wedge.WoNumber).ClickElement("Add", Driver);
            Driver.WaitForReady();
            _inputNewJobCode.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            if (wedge.NewPosition != null)
            {
                _extendedPage.SelectAllAndClearField(_inputNewPosition);
                _inputNewPosition.SetText(wedge.NewPosition, "New Position");
                Driver.WaitForReady();
            }
            if (wedge.WoTimeType != null)
            {
                _extendedPage.SelectAllAndClearField(_inputWoTimeType);
                _inputWoTimeType.SetText(wedge.WoTimeType, "Wo Time Type");
                Driver.WaitForReady();
            }
            _inputWoPayClass.SetText(wedge.WoPayClass, "Wo Pay Class");
            Driver.WaitForReady();
            if (wedge.WoPayStep != null)
            {
                _extendedPage.SelectAllAndClearField(_inputWoPayStep);
                _inputWoPayStep.SetText(wedge.WoPayStep, "Wo Pay Step");
                Driver.WaitForReady();
            }
            _inputNewPunchTime.SetText(wedge.NewPunchTime, "New Punch Time");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Add Part Request on Work Order
        /// </summary>
        /// <param name="wedge"></param>
        /// <param name="request"></param>
        public void AddPartRequestOnWorkOrder(EmpLaborWedge wedge, PartRequestObjects request)
        {
            Settings.Logger.Info(" Add Part Request on Work Order ");
            _extendedPage.SwitchToContentFrame();
            _inputEmployeeNo.SetText(wedge.EmployeeNo, "Employee No");
            Driver.WaitForReady();
            _inputPin.SetText(wedge.Pin, "Pin");
            Driver.WaitForReady();
            _addPartRequest.ClickElement("Add Part Request", Driver);
            Driver.WaitForSomeTime();
            string parentWindow = Driver.SwitchToNewWindow();
            PartRequestPageActions PR = new PartRequestPageActions(Driver);
            PR.AddPartToPartRequest(request);
            Driver.Close();
            Driver.SwitchTo().Window(parentWindow);
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            _inputEmployeeNo.SetText(wedge.EmployeeNo, "Employee No");
            Driver.WaitForReady();
            _inputPin.SetText(wedge.Pin, "Pin");
            Driver.WaitForReady();
            _partHoverTable.Click();
            Driver.MouseHover(_partHoverTable, "Part Request");
            string partNo = _partAssign.GetText("Part No");
            CommonUtil.AssertTrue(request.Requests[0].PartNo, partNo);
            Driver.SwitchTo().DefaultContent();
        }
    }
}
