﻿using System;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Labor;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Labor
{
    internal class LaborTimeCardPageActions : LaborTimeCardPage
    {
        internal LaborTimeCardPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Add Time Entry For Employee
        /// </summary>
        /// <param name="laborTime"></param>
        public void AddTimeEntryForEmployee(LaborTimeEntry laborTime)
        {
            Settings.Logger.Info(" Add Time Entry For Employee ");
            _extendedPage.SwitchToContentFrame();
            _inputEmployeeNo.SetText(laborTime.Employee, "Employee No");
            Driver.WaitForReady();
            _inputPin.SetText(laborTime.PinNumber, "Pin");
            Driver.WaitForReady();
            if (laborTime.PayrollDate != null)
            {
                _extendedPage.SelectAllAndClearField(_inputPayrollDate);
                _inputPayrollDate.SetText(laborTime.PayrollDate, "Payroll Date");
            }
            else
                _inputPayrollDate.SendKeys(Keys.Tab);
            Driver.WaitForSomeTime();
            Driver.AcceptAlert();
            laborTime.PayrollDate = _inputPayrollDate.GetAttribute("ovalue");
            Driver.SwitchToFrame(_frameTimeEntry, "time entry");
            DateTime result;
            int count = laborTime.Entries.Count;
            for (int row = 0; row < laborTime.Entries.Count; row++)
            {
                var entry = laborTime.Entries[row];
                entry.TimeIn = DateTime.Now.AddMinutes(-(count * 5)).ToString("MM/dd/yyyy HH:mm:ss");
                if (DateTime.TryParse(entry.TimeIn, out result))
                    entry.TimeOut = result.AddMinutes(+5).ToString("MM/dd/yyyy HH:mm:ss");
                else
                    entry.TimeOut = DateTime.Now.AddMinutes(-(count * 5)).ToString("MM/dd/yyyy HH:mm:ss");
                count--;
                _selectType(row).SelectFilterValueHavingEqualValue(entry.Type);
                Driver.WaitForReady();
                _extendedPage.SelectAllAndClearField(_inputWorkOrder(row));
                _inputWorkOrder(row).SetText(entry.IndirectWorkOrder, "Indirect Account/ Work Order");
                Driver.WaitForReady();
                _inputJob(row).SetText(entry.Job, "Job");
                Driver.WaitForReady();
                _extendedPage.SelectAllAndClearField(_inputTimeIn(row));
                _inputTimeIn(row).SetText(entry.TimeIn, "Time In");
                Driver.WaitForReady();
                _inputTimeOut(row).SetText(entry.TimeOut, "Time Out");
                Driver.WaitForReady();
                _inputTimeType(row).SetText(entry.TimeType, "Time Type");
                Driver.WaitForReady();
                _inputPayClass(row).SetText(entry.PayClass, "Pay Class");
                Driver.WaitForReady();
                _inputPayStep(row).SetText(entry.PayStep, "Pay Step");
                Driver.WaitForReady();
                if (entry.Union != null)
                    _inputUnion(row).SetText(entry.Union, "Union");
                else
                    _inputUnion(row).SendKeys(Keys.Tab);
                Driver.WaitForReady();
                _inputPosition(row).SetText(entry.Position, "Position");
                Driver.WaitForReady();
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForSomeTime();
        }

        /// <summary>
        /// Verify Time Entry For Employee
        /// </summary>
        /// <param name="laborTime"></param>
        public void VerifyTimeEntryForEmployee(LaborTimeEntry laborTime)
        {
            Settings.Logger.Info(" Verify Time Entry For Employee ");
            _extendedPage.RefreshAndSetText(_inputEmployeeNo, laborTime.Employee, "Employee No");
            Driver.WaitForReady();
            _inputPin.SetText(laborTime.PinNumber, "Pin");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_inputPayrollDate);
            _inputPayrollDate.SetText(laborTime.PayrollDate, "Payroll Date");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameTimeEntry, "time entry");
            foreach (var entry in laborTime.Entries)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableTimeEntry, _headerIWO,
                    entry.IndirectWorkOrder, "Job"), "Job", entry.Job, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableTimeEntry, _headerIWO,
                    entry.IndirectWorkOrder, "TimeType"), "Time Type", entry.TimeType, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableTimeEntry, _headerIWO,
                    entry.IndirectWorkOrder, "PayClass"), "Pay Class", entry.PayClass, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableTimeEntry, _headerIWO,
                    entry.IndirectWorkOrder, "PayStep"), "Pay Step", entry.PayStep, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableTimeEntry, _headerIWO,
                    entry.IndirectWorkOrder, "Position"), "Position", entry.Position, false, "value");
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Time Entry For Employee
        /// </summary>
        /// <param name="laborTime"></param>
        public void UpdateTimeEntryForEmployee(LaborTimeEntry laborTime)
        {
            Settings.Logger.Info(" Update Time Entry For Employee ");
            _extendedPage.RefreshAndSetText(_inputEmployeeNo, laborTime.Employee, "Employee No");
            Driver.WaitForReady();
            _inputPin.SetText(laborTime.PinNumber, "Pin");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_inputPayrollDate);
            _inputPayrollDate.SetText(laborTime.PayrollDate, "Payroll Date");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameTimeEntry, "time entry");
            foreach (var entry in laborTime.Entries)
            {
                entry.TimeOut = DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableTimeEntry, _headerIWO, entry.IndirectWorkOrder,
                    "timeout").SetText(entry.TimeOut, "Time Out");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableTimeEntry, _headerIWO, entry.IndirectWorkOrder,
                        "TimeType").SetText(entry.TimeType, "Time Type");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableTimeEntry, _headerIWO, entry.IndirectWorkOrder,
                        "PayClass").SetText(entry.PayClass, "Pay Class");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableTimeEntry, _headerIWO, entry.IndirectWorkOrder,
                        "PayStep").SetText(entry.PayStep, "Pay Step");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableTimeEntry, _headerIWO, entry.IndirectWorkOrder,
                        "Position").SetText(entry.Position, "Position");
                Driver.WaitForReady();
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForSomeTime();
        }

        /// <summary>
        /// Delete Time Entry For Employee
        /// </summary>
        /// <param name="laborTime"></param>
        public void DeleteTimeEntryForEmployee(LaborTimeEntry laborTime)
        {
            Settings.Logger.Info(" Delete Time Entry For Employee ");
            _extendedPage.RefreshAndSetText(_inputEmployeeNo, laborTime.Employee, "Employee No");
            Driver.WaitForReady();
            _inputPin.SetText(laborTime.PinNumber, "Pin");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_inputPayrollDate);
            _inputPayrollDate.SetText(laborTime.PayrollDate, "Payroll Date");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameTimeEntry, "time entry");
            foreach (var entry in laborTime.Entries)
            {
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableTimeEntry, _headerIWO, entry.IndirectWorkOrder,
                    "wonumber").Click();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnDeleteButton();
                _extendedPage.SwitchToTableFrame(_frameTimeEntry);
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToTableFrame(_frameTimeEntry);
            foreach (var entry in laborTime.Entries)
                _extendedPage.VerifyTableColumnDoesNotContainValue(_tableTimeEntry, _headerIWO, entry.IndirectWorkOrder);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Clean Time Entry For Employee
        /// </summary>
        /// <param name="laborTime"></param>
        public void CleanTimeEntryForEmployee(LaborTimeEntry laborTime)
        {
            Settings.Logger.Info(" Clean Time Entries For Employee ");
            _extendedPage.SwitchToContentFrame();
            _inputEmployeeNo.SetText(laborTime.Employee, "Employee No");
            Driver.WaitForReady();
            _inputPin.SetText(laborTime.PinNumber, "Pin");
            Driver.WaitForReady();
            if (laborTime.PayrollDate != null)
            {
                _extendedPage.SelectAllAndClearField(_inputPayrollDate);
                _inputPayrollDate.SetText(laborTime.PayrollDate, "Payroll Date");
            }
            else
                _inputPayrollDate.SendKeys(Keys.Tab);
            Driver.WaitForSomeTime();
            Driver.SwitchToFrame(_frameTimeEntry, "time entry");
            int TotalRows = _tableTimeEntryTotalRows.Count - 1;
            while (TotalRows > 0)
            {
                _inputEntry(TotalRows - 1).ClickElement("Indirect Account/ Work Order", Driver);
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnDeleteButton();
                Driver.WaitForReady();
                _extendedPage.SwitchToTableFrame(_frameTimeEntry);
                TotalRows--;
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
        }
    }
}
