﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Labor;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Labor
{
    internal class PayrollLaborApprovalPageActions : PayrollLaborApprovalPage
    {
        internal PayrollLaborApprovalPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Retrieve Payroll Labor Entries
        /// </summary>
        /// <param name="labor"></param>
        public void RetrievePayrollLaborEntries(LaborApproval labor)
        {
            Settings.Logger.Info(" Retrieve Employee Payroll Labor Entries ");
            _extendedPage.SwitchToContentFrame();
            _inputSupervisorNo.SetText(labor.SupervisorNo, "Supervisor/Timekeeper No");
            Driver.WaitForReady();
            _selectTitle.SelectFilterValueHavingEqualValue(labor.Title);
            Driver.WaitForSomeTime();
            Driver.AcceptAlert();
            _inputFromDate.SetText(labor.FromDate, "From Date");
            Driver.WaitForReady();
            _inputToDate.SetText(labor.ToDate, "To Date");
            Driver.WaitForReady();
            _inputUnion.SetText(labor.Union, "Union");
            Driver.WaitForReady();
            _inputEmpLocation.SetText(labor.EmpLocation, "Emp Location");
            Driver.WaitForReady();
            _btnRetrieve.ClickElement("Retrieve", Driver);
            Driver.WaitForSomeTime();
        }

        /// <summary>
        /// Approve Payroll Labor Entries
        /// </summary>
        /// <param name="labor"></param>
        public void ApprovePayrollLaborEntries(LaborApproval labor)
        {
            Settings.Logger.Info(" Approve Employee Payroll Labor Entries ");
            RetrievePayrollLaborEntries(labor);
            Driver.SwitchToFrame(_frameLaborApproval, "Labor Approval");
            foreach(var entry in labor.Entries)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableLaborApproval, _headerEmployeeNo,
                    entry.EmployeeNo, "Shift"), "Shift", entry.ShiftCode, false, "value");
                entry.ShiftStart = _extendedPage.GetTableActionElementByRelatedColumnValue(_tableLaborApproval, _headerEmployeeNo, entry.EmployeeNo,
                    "ShiftStart").GetAttribute("value");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableLaborApproval, _headerEmployeeNo, entry.EmployeeNo,
                    "TimeApprove").SetText(entry.TimeApprove, "Time Approve");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableLaborApproval, _headerEmployeeNo, entry.EmployeeNo,
                    "SVApproveFl").SetCheckBox("Supervisor Approve", entry.SupervisorApprove);
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableLaborApproval, _headerEmployeeNo, entry.EmployeeNo,
                    "TKApproveFl").SetCheckBox("Time Keeper Approve", entry.TimeKeeperApprove);
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableLaborApproval, _headerEmployeeNo, entry.EmployeeNo,
                    "TKRejectFl").SetCheckBox("Time Keeper Reject", entry.TimeKeeperReject);
            }
            if (labor.ApproveAll)
            {
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
                _btnApproveAll.ClickElement("Approve All", Driver);
                Driver.WaitForReady();
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForSomeTime();
        }

        /// <summary>
        /// Verify Approved Payroll Labor Entries
        /// </summary>
        /// <param name="labor"></param>
        public void VerifyApprovedPayrollLaborEntries(LaborApproval labor)
        {
            string msg;
            Settings.Logger.Info(" Verify Approved Employee Payroll Labor Entries ");
            _extendedPage.ClickOnRefreshButton();
            RetrievePayrollLaborEntries(labor);
            Driver.SwitchToFrame(_frameLaborApproval, "Labor Approval");
            if (_tableLaborApproval.VerifyElementDisplay("Labor Table"))
            {
                foreach (var entry in labor.Entries)
                    _extendedPage.VerifyTableColumnDoesNotContainValue(_tableLaborApproval, _headerShiftStart, entry.ShiftStart);
            }
            else if (labor.Title == "Timekeeper")
            {
                msg = "No records returned.";
                CommonUtil.VerifyElementText(_tableMsg, "Message", msg);
            }
            else
            {
                msg = "No records need to be approved.";
                CommonUtil.VerifyElementText(_tableMsg, "Message", msg);
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Payroll Labor Entries
        /// </summary>
        /// <param name="labor"></param>
        public void VerifyPayrollLaborEntries(LaborApproval labor)
        {
            Settings.Logger.Info(" Verify Employee Payroll Labor Entries ");
            _extendedPage.ClickOnRefreshButton();
            RetrievePayrollLaborEntries(labor);
            Driver.SwitchToFrame(_frameLaborApproval, "Labor Approval");
            foreach (var entry in labor.Entries)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableLaborApproval, _headerShiftStart,
                    entry.ShiftStart, "Shift"), "Shift", entry.ShiftCode, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableLaborApproval, _headerShiftStart,
                    entry.ShiftStart, "EmpNo"), "Employee No", entry.EmployeeNo, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableLaborApproval, _headerShiftStart,
                    entry.ShiftStart, "EmpName"), "Employee Name", entry.EmployeeName, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableLaborApproval, _headerShiftStart,
                    entry.ShiftStart, "TimeType"), "Time Type", entry.TimeType, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableLaborApproval, _headerShiftStart,
                    entry.ShiftStart, "PayClass"), "Pay Class", entry.PayClass, false, "value");
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableLaborApproval, _headerShiftStart,
                    entry.ShiftStart, "TimeApprove"), "Time Approve", entry.TimeApprove, false, "value");
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
