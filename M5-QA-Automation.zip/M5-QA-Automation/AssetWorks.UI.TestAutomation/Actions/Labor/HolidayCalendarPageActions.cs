﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Labor;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Labor
{
    internal class HolidayCalendarPageActions : HolidayCalendarPage
    {
        internal HolidayCalendarPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Get Holiday Calendar Dates
        /// </summary>
        /// <param name="holiday"></param>
        /// <param name="holidaysEdit"></param>
        /// <returns></returns>
        public Holiday GetHolidayCalendarDates(Holiday holiday, Holiday holidaysEdit)
        {
            int row = 0;
            foreach (HolidayList item in holiday.Holidays)
            {
                if (item.Date.Contains('+'))
                    item.Date = _extendedPage.GetDateInAppTimeZone(item.Date);
            }
            holidaysEdit.FiscalYear = holiday.FiscalYear = holiday.Holidays[row].Date[6..];
            foreach (HolidayList items in holidaysEdit.Holidays)
            {
                items.Date = holiday.Holidays[row].Date;
                row++;
            }
            CleanHolidayCalendar(holiday);
            return holidaysEdit;
        }

        /// <summary>
        /// Clean Holiday Calendar
        /// </summary>
        /// <param name="holiday"></param>
        public void CleanHolidayCalendar(Holiday holiday)
        {
            Settings.Logger.Info($" Clean Holiday Calendar for Year : {holiday.FiscalYear}");
            _extendedPage.SwitchToContentFrame();
            _inputFiscalYear.SetText(holiday.FiscalYear, "Fiscal Year");
            Driver.WaitForReady();
            if (holiday.Holidays != null)
            {
                Driver.SwitchToFrame(_frameHoliday, "Holiday");
                foreach (HolidayList item in holiday.Holidays)
                {
                    if (_extendedPage.CheckTableColumnContainValue(_tableHoliday, _headerDate, item.Date))
                    {
                        _extendedPage.GetTableActionElementByRelatedColumnValue(_tableHoliday, _headerDate, item.Date, "indacct").Click();
                        Driver.SwitchTo().DefaultContent();
                        _extendedPage.ClickOnDeleteButton();
                        _extendedPage.ClickOnSaveButton();
                        Driver.WaitForReady();
                        _extendedPage.SwitchToTableFrame(_frameHoliday);
                    }
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Create Holiday Calendar
        /// </summary>
        /// <param name="holiday"></param>
        public void CreateHolidayCalendar(Holiday holiday)
        {
            Settings.Logger.Info($" Create Holiday Calendar for Year : {holiday.FiscalYear}");
            _extendedPage.SwitchToContentFrame();
            _inputFiscalYear.SetText(holiday.FiscalYear, "Fiscal Year");
            Driver.WaitForReady();
            if (holiday.Holidays != null)
            {
                int rowId = 0;
                Driver.SwitchToFrame(_frameHoliday, "Holiday");
                foreach (HolidayList item in holiday.Holidays)
                {
                    _inputNewDate(rowId).SetText(item.Date, "Date");
                    Driver.WaitForReady();
                    _inputNewIndirectAccount(rowId).SetText(item.IndirectAccount, "Indirect Account");
                    Driver.WaitForReady();
                    _inputNewHolidayDescription(rowId).SetText(item.HolidayDescription, "Holiday Description");
                    Driver.WaitForReady();
                    item.Date = _inputNewDate(rowId).GetAttribute("ovalue");
                    rowId++;
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Update Holiday Calendar
        /// </summary>
        /// <param name="holiday"></param>
        public void UpdateHolidayCalendar(Holiday holiday)
        {
            Settings.Logger.Info($" Update Holiday Calendar for Year : {holiday.FiscalYear}");
            _extendedPage.RefreshAndSetText(_inputFiscalYear, holiday.FiscalYear, "Fiscal Year");
            Driver.WaitForReady();
            if (holiday.Holidays != null)
            {
                Driver.SwitchToFrame(_frameHoliday, "Holiday");
                foreach (HolidayList item in holiday.Holidays)
                {
                    if (item.IndirectAccount != null)
                    {
                        _extendedPage.SelectAllAndClearField(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableHoliday, _headerDate,
                            item.Date, "indacct"));
                        _extendedPage.GetTableActionElementByRelatedColumnValue(_tableHoliday, _headerDate, item.Date,
                            "indacct").SetText(item.IndirectAccount, "Indirect Account");
                        Driver.WaitForReady();
                    }
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableHoliday, _headerDate, item.Date,
                        "description").SetText(item.HolidayDescription, "Holiday Description");
                    Driver.WaitForReady();
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Verify Holiday Calendar
        /// </summary>
        /// <param name="holiday"></param>
        public void VerifyHolidayCalendar(Holiday holiday)
        {
            Settings.Logger.Info($" Verify Holiday Calendar for Year : {holiday.FiscalYear}");
            _extendedPage.RefreshAndSetText(_inputFiscalYear, holiday.FiscalYear, "Fiscal Year");
            Driver.WaitForReady();
            if (holiday.Holidays != null)
            {
                Driver.SwitchToFrame(_frameHoliday, "Holiday");
                foreach (HolidayList item in holiday.Holidays)
                {
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableHoliday, _headerDate, item.Date,
                        "indacct"), "Indirect Account", item.IndirectAccount, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableHoliday, _headerDate, item.Date,
                        "description"), "Holiday Description", item.HolidayDescription, false, "value");
                }
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Holidays from Calendar
        /// </summary>
        /// <param name="holiday"></param>
        public void DeleteHolidaysFromCalendar(Holiday holiday)
        {
            Settings.Logger.Info($" Delete Holidays from Calendar for Year : {holiday.FiscalYear}");
            if (holiday.Holidays != null)
            {
                foreach (HolidayList item in holiday.Holidays)
                {
                    _extendedPage.SwitchToTableFrame(_frameHoliday);
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableHoliday, _headerDate, item.Date, "indacct").Click();
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.ClickOnDeleteButton();
                }
            }
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.RefreshAndSetText(_inputFiscalYear, holiday.FiscalYear, "Fiscal Year");
            if (holiday.Holidays != null)
            {
                Driver.SwitchToFrame(_frameHoliday, "Holiday");
                foreach (HolidayList item in holiday.Holidays)
                {
                    _extendedPage.VerifyTableColumnDoesNotContainValue(_tableHoliday, _headerDate, item.Date);
                }
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
