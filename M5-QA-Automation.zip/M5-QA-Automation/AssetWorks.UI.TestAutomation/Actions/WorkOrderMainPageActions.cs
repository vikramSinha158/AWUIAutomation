﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class WorkOrderMainPageActions: WorkOrderMainPage
    {
        public WorkOrderMainPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Verify Work Order Title
        /// </summary>
        public void VerifyWorkOrderTitle()
        {
            Settings.Logger.Info("Verifying work order page to display");
            _extendedPage.SwitchToContentFrame();
            Assert.True(_workOrderTitle.VerifyElementDisplay(" Workorder page title "), "WorkOrder Page Not Dispalyed");
            Settings.Logger.Info("Verified work order page successfully");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Search for work order
        /// </summary>
        public void SearchForWorkOrder()
        {
            Settings.Logger.Info("Creating workorder");
            ClickActionLOVForWorkOrder(_searchLinkWorkOrderNo);
        }

        /// <summary>
        /// Search For UnitNo
        /// </summary>
        public void SearchForUnitNo()
        {
            Settings.Logger.Info("Creating workorder for unit");
            ClickActionLOVForWorkOrder(_searchLinkUnitNo);
        }

        /// <summary>
        /// Search For Component
        /// </summary>
        public void SearchForComponent()
        {
            Settings.Logger.Info("Creating workorder for component");
            ClickActionLOVForWorkOrder(_searchLinkComponent);
        }

        /// <summary>
        /// Verify work order details
        /// </summary>
        public void VerifyWorkOrderInformation()
        {
            Settings.Logger.Info("Verifying workorder number and satus");
            _extendedPage.SwitchToContentFrame();
            string woStatus = _workOrderStatus.GetElementValueByAttribute("ovalue");
            Assert.IsFalse(string.IsNullOrEmpty(woStatus), "work order status is empty");
            VerifyWorkorderNumber();
        }

        /// <summary>
        /// Verifying generated work order
        /// </summary>
        public void VerifyWorkorderNumber()
        {
            WONumber = _workOrderNumber.GetElementValueByAttribute("ovalue");
            Assert.IsFalse(string.IsNullOrEmpty(WONumber), "work order number is empty");
            Settings.Logger.Info($"Created workorder number {WONumber}");
        }

        /// <summary>
        /// Click Action LOV For Work Order
        /// </summary>
        /// <param name="ActionLovLink"></param>
        public void ClickActionLOVForWorkOrder(IWebElement ActionLovLink)
        {
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            Driver.WaitForClickable(_inputWorkOrderNo, "Wo text box");
            _inputWorkOrderNo.Clear();
            WaitUntilDisplayed(_inputWorkOrderNo,"Input workorder number ");
            Driver.DoubleClick(_inputWorkOrderNo, " Input workorder number ");
            Driver.SwitchTo().DefaultContent();
            ActionLovLink.VerifyElementDisplay(" Action list ");
            Driver.WaitForReady();
            ActionLovLink.Click();
        }

        /// <summary>
        /// Click OnWork Order Build
        /// </summary>
        public void ClickOnWorkOrderBuild()
        {
            Driver.WaitForClickable(_buildButton," Build button ");
            Driver.WaitForReady();
            Driver.ScrollIntoViewAndClick(_buildButton, " Build button ");
        }

        /// <summary>
        /// VisitRequestReason
        /// </summary>
        /// <param name="VisitReason"></param>
        public void VisitRequestReason(string VisitReason)
        {
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendedPage.SwitchToContentFrame();         
            Driver.MouseHover(_visitReq, " visit request number ");
            Driver.ScrollIntoViewAndClick(_visitReq, " visit request number");
            _visitReq.SendKeys(VisitReason);
            Settings.Logger.Info($"Entered visit reason {VisitReason}");
            Driver.WaitForReady();
            _visitReq.SendKeys(Keys.Tab);
        }

        /// <summary>
        /// verify work order
        /// </summary>
        public void CreateAndVerifyWorkOrder()
        {
            _extendedPage.SwitchToContentFrame();
            ClickOnWorkOrderBuild();
            Driver.WaitForReady();
            VisitRequestReason("0");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClicKSave();
            _extendedPage.SwitchToContentFrame();
            VerifyWorkorderNumber();
        }

        /// <summary>
        /// Verify Added Action WorkOrder
        /// </summary>
        /// <param name="actionnumber"></param>
        public void VerifyAddedActionWorkOrder(string ActionNumber)
        {
            string actualActionNumber = _unitNo.GetElementValueByAttribute("ovalue");
            Assert.True(ActionNumber.Equals(actualActionNumber.Trim()), "work order status is empty");
            Settings.Logger.Info($" Matched Actual action number : {actualActionNumber} and expacted number as {ActionNumber}");
        }

        /// <summary>
        /// Add Job To Work Order
        /// </summary>
        public void AddJobToWorkOrder()
        {
            Settings.Logger.Info("Adding job in workorder ");
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendedPage.SwitchToContentFrame();
            Driver.MouseHover(_jobTab," job tab ");
            Driver.ScrollIntoViewAndClick(_jobTab," job tab ");
            AddJobInfo();
        }

        /// <summary>
        /// Add Job Info
        /// </summary>
        public void AddJobInfo()
        {
            if (_jobInformation.VerifyElementDisplay("Job information dialog "))
            {
                Driver.SwitchToFrame(_jobFormFrame,"job frame ");
                Driver.WaitForReady();
                _jobCode.SetText(Settings.JobCode, "Settings.JobCode");
                Driver.WaitForReady();
                _jobStatus.SendKeys(Keys.Tab);
                Driver.WaitForReady();
                _jobReason.SetText("0", "Job reason");
                Driver.SwitchTo().DefaultContent();
                Driver.WaitForSomeTime();
                Driver.AcceptAlert();
                _extendedPage.ClicKSave();
            }
        }

        /// <summary>
        /// Verify Created Workorder Job
        /// </summary>
        public void VerifyCreatedWorkorderJob()
        {
            _extendedPage.SwitchToContentFrame();
            Assert.True(_jobLoadedMsg.VerifyElementDisplay("Job loaded"), "Job not added");
            Driver.SwitchToFrame(_jobFormFrame, "job frame ");
            string addworkorferjob = _jobCode.GetElementValueByAttribute("ovalue");
            Assert.IsFalse(string.IsNullOrEmpty(addworkorferjob), "work order number is empty");
        }

        /// <summary>
        /// veify Workorder Job Deletion
        /// </summary>
        public void veifyWorkorderJobDeletion()
        {
            Settings.Logger.Info($"Verifying the Job Deletion from WorkOrder ");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_jobFormFrame, "job frame ");
            Driver.WaitForReady();
            _jobStatus.SetText("CAN", " job status");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClicKSave();
            _extendedPage.SwitchToContentFrame();
            Assert.True(_jobDeletedMsg.VerifyElementDisplay("Job deleted message "), "Job not deleted");
        }

        // <summary>
        //Delete work order
        // </summary>
        public void DeleteAndVerifyWorkOrderDeletion(String WorkOrderNo, string ItemNo)
        {
            Settings.Logger.Info("Deleting existing workorder ");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNo, "WorkOrderNo");
            Driver.WaitForReady();
            _workOrderNumber.Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ActionRequiredWindow("Proceed");
            Driver.WaitForReady();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, ItemNo, "WorkOrderNo");
            Driver.WaitForReady(69);
            Driver.FindElement(By.XPath(canclecbxpath)).Click();
            Driver.WaitForReady();
            Driver.SwitchToFrame(_wolistframe, "workorder list frame ");
            Driver.WaitForReady();
            Assert.True(WorkOrderNo.Equals(_canWOnumber.GetAttribute("value")) && _woStatus.GetAttribute("value").Equals("CANCELLED"), WONumber + " not found cancelled");         
            _extendedPage.VerifySystemDateContainAppdate(_woCloseDate, "WO Closed");
            Settings.Logger.Info(" Verifed work order no : " + WorkOrderNo + " status : CANCELLED ");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Refresh And Verify Work Order Complete Dates
        /// </summary>
        public void VerifyWOCompleteDates(string WorkOrderNumber)
        {
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNumber, "WorkOrderNo");
            Driver.WaitForReady();
            _extendedPage.VerifySystemDateContainAppdate(_woVisitInfoCompleteDate, "WO Visit Info Complete");
            _extendedPage.VerifySystemDateContainAppdate(_woVisitInfoCloseDate, "WO Visit Info Closed");
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Verifed work order no : " + WorkOrderNumber + " Complete Date And Closed Date ");
        }

        /// <summary>
        /// Complete And Close Work Order
        /// </summary>
        /// <param name="WorkOrderNumber"></param>
        public void CompleteAndCloseWorkOrder(string WorkOrderNumber)
        {
            Settings.Logger.Info(" Complete And Close Work Order ");
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNumber, "WorkOrderNo");
            Driver.WaitForReady();
            _woVisitInfoCompleteDate.SetText("now", "Complete Date");
            Driver.WaitForReady();
            _woVisitInfoCloseDate.SetText("now", "Close Date");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            VerifyWOCompleteDates(WorkOrderNumber);
        }

        /// <summary>
        /// Adding Work Request InJob
        /// </summary>
        public void AddWorkRequestInJob(string WorkOrder)
        {
            Settings.Logger.Info(" Adding work request in work order job ");
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrder, "WorkOrderNo");
            Driver.WaitForReady();
            if (_workRequestList.Text.ToString().Contains("1"))
            {
                _workRequestList.ClickElement("work request list ", Driver);
                Driver.SwitchTo().DefaultContent();
                if (_workRequestDialog.VerifyElementDisplay("Work Request Dialog"))
                {
                    if (_workRequesRows.Count > 1)
                    {
                        _addWorkRequest.ClickElement(" Add work request ", Driver);
                        _saveWRBtn.ClickElement("Save work request", Driver);
                    }
                    else
                    {
                        Settings.Logger.Info("WorkRequest is not visible in worklist dialog ");
                        Assert.Fail(" WorkRequest is not visible in worklist dialog ");
                    }
                }
            }
            else
            {
                Settings.Logger.Info(" WorkRequest is not added in workorderlis ");
                Assert.Fail(" WorkRequest is not added in workorderlist");
            }
        }

        /// <summary>
        /// verifying Added Work Request
        /// </summary>
        public void VerifyAddedWorkRequest()
        {
            Settings.Logger.Info(" verifying Added Work Request ");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            if (_workRequestList.Text.ToString().Contains("0"))
            {
                _jobTab.ClickElement("Job Tab", Driver);
                Assert.True(_jobLoadedMsg.VerifyElementDisplay("Job loaded"), "Job not added");
            }
            else {
                Settings.Logger.Info(" WorkRequestList not added in job  ");
                Assert.Fail("Job not added");
            }
        }

        /// <summary>
        /// Fill Labor To WorkOrder
        /// </summary>
        /// <param name="AddLabor"></param>
        /// <param name="WorkOrderNomber"></param>
        public void FillLaborToWorkOrder(AddLabor AddLabor,string WorkOrderNomber)
        {
            Settings.Logger.Info($"Adding Labor to WorkOrder {WorkOrderNomber}");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _laborTab.ClickElement("Labor Tab ", Driver);
            Driver.SwitchToFrame(_woLaborframe, "Labor frame ");
            List<AddLaborRecord> AddLaborRecords = AddLabor.AddLaborRecord;
            foreach (AddLaborRecord AddLaborRecord in AddLaborRecords)
            {
                _extendedPage.GetTableActionElementByRelatedColumnValue(_laborTable, "Job", "", "wlJob").SetText(AddLaborRecord.JobCode, "JobCode");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_laborTable, "Job", AddLaborRecord.JobCode, "wlEmpNo").SetText(AddLaborRecord.EmployeeCode, "EmployeeCode");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_laborTable, "Job", AddLaborRecord.JobCode, "wlPosition").SetText(AddLaborRecord.Position, "Position");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_laborTable, "Job", AddLaborRecord.JobCode, "wlTimeIn").SetText(AddLaborRecord.InDateTime, "InDateTime");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_laborTable, "Job", AddLaborRecord.JobCode, "wlTimeOut").SetText(AddLaborRecord.OutDateTime, "OutDateTime");
            }
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.Save();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Edit Labor To WorkOrder
        /// </summary>
        /// <param name="AddLabor"></param>
        /// <param name="WorkOrderNomber"></param>
        public void EditLaborToWorkOrder(AddLabor AddLabor, string WorkOrderNomber)
        {
            Settings.Logger.Info($"Editing Labor to WorkOrder {WorkOrderNomber}");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _laborTab.ClickElement("Labor Tab ", Driver);
            Driver.SwitchToFrame(_woLaborframe, "Labor frame ");
            List<AddLaborRecord> AddLaborRecords = AddLabor.AddLaborRecord;
            foreach (AddLaborRecord AddLaborRecord in AddLaborRecords)
            {
                 IWebElement OutTime=  _extendedPage.GetTableActionElementByRelatedColumnValue(_laborTable, "Job", AddLaborRecord.JobCode, "wlTimeOut");
                _extendedPage.SelectAllAndClearField(OutTime);
                Driver.WaitForReady();
                OutTime.SetText(AddLaborRecord.OutDateTime, "OutDateTime");
            }
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.Save();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Work Order Labor Tab
        /// </summary>
        /// <param name="AddLabor"></param>
        /// <param name="WorkOrderNomber"></param>
        public void VerifyWorkOrderLaborTab(AddLabor AddLabor, string WorkOrderNomber)
        {
            Settings.Logger.Info($"Verifying  Added Labor Detail  {WorkOrderNomber}");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _laborTab.ClickElement("Labor Tab ", Driver);
            if (AddLabor.AddLaborRecord != null)
            {             
                Driver.SwitchToFrame(_woLaborframe, "Labor frame ");
                List<AddLaborRecord> AddLaborRecords = AddLabor.AddLaborRecord;
                foreach (AddLaborRecord AddLaborRecord in AddLaborRecords)
                {
                    string ActuallaborCode = _extendedPage.GetTableActionElementByRelatedColumnValue(_laborTable, "Job", AddLaborRecord.JobCode, "wlJob").GetAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(AddLaborRecord.JobCode, ActuallaborCode);
                    string ActualEmployeeCode = _extendedPage.GetTableActionElementByRelatedColumnValue(_laborTable, "Job", AddLaborRecord.JobCode, "wlEmpNo").GetAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(AddLaborRecord.EmployeeCode, ActualEmployeeCode);
                    string ActuallEmployeeName = _extendedPage.GetTableActionElementByRelatedColumnValue(_laborTable, "Job", AddLaborRecord.JobCode, "wlEmpName").GetAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(AddLaborRecord.EmployeeName, ActuallEmployeeName);
                    string ActuallPosition = _extendedPage.GetTableActionElementByRelatedColumnValue(_laborTable, "Job", AddLaborRecord.JobCode, "wlPosition").GetAttribute("ovalue");
                    CommonUtil.AssertTrue<string>(AddLaborRecord.Position, ActuallPosition);
                    IWebElement InTime = _extendedPage.GetTableActionElementByRelatedColumnValue(_laborTable, "Job", AddLaborRecord.JobCode, "wlTimeIn");
                    _extendedPage.VerifySystemDateContainAppdate(InTime, "InTime", Convert.ToInt32(AddLaborRecord.InDateTime));
                    IWebElement OutTime = _extendedPage.GetTableActionElementByRelatedColumnValue(_laborTable, "Job", AddLaborRecord.JobCode, "wlTimeOut");
                    _extendedPage.VerifySystemDateContainAppdate(OutTime, "InTime", Convert.ToInt32(AddLaborRecord.OutDateTime));
                }
            }
        }

        /// <summary>
        /// Labor Record Deletion
        /// </summary>
        public void LaborRecordDeletion(string WorkOrderNumber)
        {
            Settings.Logger.Info($"Deleting  Added Labor Detail with work order No-- {WorkOrderNumber}");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNumber, "WorkOrderNo");
            Driver.WaitForReady();
            _laborTab.ClickElement("Labor Tab ", Driver);
            Driver.SwitchToFrame(_woLaborframe, "Labor frame ");
            Settings.Logger.Info(" Deleting Labor  Information ");
            _outDateTime.ClickElement("Out Date time Hour ", Driver);
            Driver.AcceptAlert();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            Driver.AcceptAlert();
            Driver.WaitForReady();
            _extendedPage.ClicKSave();
            _extendedPage.SwitchToContentFrame();
            Assert.True(_LaborChargeDeletetInfo.VerifyElementDisplay("Job deleted message "), "Job not deleted");
            Settings.Logger.Info($"Successfully verified Added Labor Deletion with work order No-- {WorkOrderNumber}");
        }

        /// <summary>
        /// Fill Stock Part Records
        /// </summary>
        /// <param name="AddStocKPart"></param>
        /// <param name="WorkOrderNomber"></param>
        public void FillStockPartRecords(AddStocKPart AddStocKPart, string WorkOrderNomber)
        {
            Settings.Logger.Info($"Adding Stock Part to WorkOrder {WorkOrderNomber}");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);        
            List<StockPartRecord> StockPartRecords = AddStocKPart.StockPartRecords;
            foreach (StockPartRecord StockPartRecord in StockPartRecords)
            {
                Driver.SwitchToFrame(_partInfoframe, "Labor frame ");
                Driver.WaitForReady();
                _extendedPage.SelectAllAndClearField(_extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", "", "wspJob"));
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", "", "wspJob").SetText(StockPartRecord.StockPartJobCode, "StockPartJobCode");
                Driver.WaitForReady();               
                if(!StockPartRecord.PartRefRequired) _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspPartNo").SetText(StockPartRecord.PartNo, "PartNo");
                else{
                    StockPartRecord.PartxRefName = CommonUtil.GetRandomStringWithSpecialChars(6);
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspPartNo").SetText(StockPartRecord.PartxRefName, "PartNo");
                    Driver.WaitForReady();
                    AddPartXref(StockPartRecord.PartRefType, StockPartRecord.VendorName, StockPartRecord.PartNo);
                }
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspEffDate").SendKeys(Keys.Tab);
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspEmpNo").SetText(StockPartRecord.EmployeeCode, "EmployeeCode");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspQty").SetText(StockPartRecord.PartQty, "PartQty");
                Driver.WaitForReady();
                if (StockPartRecord.PartSerialNoRequired)
                {                   
                    PartsAdjustment.MovePartSerialNoList(StockPartRecord.PartSerialNo);
                    Driver.SwitchToFrame(_partInfoframe, "Part frame ");
                }
                _extendedPage.SetCheckBox(_extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspPrintPartTag"), "PrintTag", StockPartRecord.PrintTag);
                Driver.WaitForReady();
                if(StockPartRecord.FailCode!=null) _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspFailCode").SetText(StockPartRecord.FailCode, "FailCode");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspRefNo").SetText(StockPartRecord.RefNo, "RefNo");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspProNo").SetText(StockPartRecord.PRONumber, "PRONumber");
                Driver.WaitForReady();
                if (StockPartRecord.Position != null) _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspJobPosition").SetText(StockPartRecord.Position, "Position");
                Driver.WaitForReady();
                if (StockPartRecord.LotNumberRequired)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspLotEntryBtn").Click();
                    PartsAdjustment.AddLotNumber(StockPartRecord.LotNumber, StockPartRecord.MfgDate, StockPartRecord.ExpDate);
                    Driver.SwitchToFrame(_partInfoframe, "Labor frame ");
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClicKSave();
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Edit Stock Part Records
        /// </summary>
        /// <param name="AddStocKPart"></param>
        /// <param name="WorkOrderNomber"></param>
        public void EditStockPartRecords(AddStocKPart AddStocKPart, string WorkOrderNomber)
        {
            Settings.Logger.Info($"Editing Stock Part to WorkOrder {WorkOrderNomber}");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            List<StockPartRecord> StockPartRecords = AddStocKPart.StockPartRecords;
            foreach (StockPartRecord StockPartRecord in StockPartRecords)
            {
                Driver.SwitchToFrame(_partInfoframe, "Labor frame ");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspRefNo").SetText(StockPartRecord.RefNo, "RefNo");
                Driver.WaitForReady();
                _extendedPage.Save();
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Verify Stock Part Records
        /// </summary>
        /// <param name="AddStocKPart"></param>
        /// <param name="WorkOrderNomber"></param>
        public void VerifyStockPartRecords(AddStocKPart AddStocKPart, string WorkOrderNomber)
        {
            IWebElement? Position = null;
            Settings.Logger.Info($" Verify Stock Part to WorkOrder {WorkOrderNomber}");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            List<StockPartRecord> StockPartRecords = AddStocKPart.StockPartRecords;
            Driver.SwitchToFrame(_partInfoframe, "Labor frame ");
            foreach (StockPartRecord StockPartRecord in StockPartRecords)
            {               
                Driver.WaitForReady();
                IWebElement PartJobCode = _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspJob");
                CommonUtil.VerifyElementValue(PartJobCode, "PartCode", StockPartRecord.StockPartJobCode);
                IWebElement PartNo = _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspPartNo");
                CommonUtil.VerifyElementValue(PartNo, "PartNo", StockPartRecord.PartNo);
                IWebElement EmployeeCode = _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspEmpNo");
                CommonUtil.VerifyElementValue(EmployeeCode, "EmployeeCode", StockPartRecord.EmployeeCode);
                IWebElement PartQty =_extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspQty");
                CommonUtil.VerifyElementValue(PartQty, "PartQty", StockPartRecord.PartQty);
                IWebElement FailCode = _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspFailCode");
                CommonUtil.VerifyElementValue(FailCode, "FailCode", StockPartRecord.FailCode);
                IWebElement RefNo = _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspRefNo");
                CommonUtil.VerifyElementValue(RefNo, "RefNo", StockPartRecord.RefNo);
                IWebElement PRONumber = _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspProNo");
                CommonUtil.VerifyElementValue(PRONumber, "PRONumber", StockPartRecord.ExpectedPRONumber);
               if(StockPartRecord.Position !=null) Position = _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", StockPartRecord.StockPartJobCode, "wspJobPosition");
                CommonUtil.VerifyElementValue(Position, "Position", StockPartRecord.Position);
            }
            Settings.Logger.Info($" Successfully verified Stock Part to WorkOrder {WorkOrderNomber}");
        }

        /// <summary>
        /// Add Job Records
        /// </summary>
        /// <param name="RowCount"></param>
        /// <param name="DataObject"></param>
        public void AddJobRecords(int RowCount, dynamic DataObject)
        {
            Settings.Logger.Info("Adding job Information ");
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollUp();
            _extendedPage.SwitchToContentFrame();
            Driver.MouseHover(_jobTab, " job tab ");
            Driver.ScrollIntoViewAndClick(_jobTab, " job tab ");
            Driver.SwitchToFrame(_jobFormFrame, "job frame ");
            for (int i = 0; i < RowCount; i++)
            {
                AddJobToWorkOrder(i, DataObject[i]);
            }
        }

        /// <summary>
        /// Add Job To WorkOrder
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void AddJobToWorkOrder(int RowNum, JObject DataObject)
        {
            Settings.Logger.Info($" Adding job Information for record No { RowNum} ");
            Driver.WaitForReady();
            _extendedPage.GetInputElementAndSetValue($"{_jobCodename}{RowNum}", CommonUtil.DataForKey(WorkOrderObjects.JobCode, DataObject),"name");
            Driver.WaitForReady();
            _extendedPage.GetElementForInput($"{_jobStatusId}{RowNum}","name").SendKeys(Keys.Tab);
            Driver.WaitForReady();
            _extendedPage.GetInputElementAndSetValue($"{_jobReasonId}{RowNum}","0", "name");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForSomeTime();
            Driver.AcceptAlert();
            _extendedPage.ClicKSave();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_jobFormFrame, "job frame ");
        }

        /// <summary>
        /// Delete And VerifyStockPartRecord
        /// </summary>
        public void DeleteAndVerifyStockPartRecord(string WorkOrderNumber)
        {
            Settings.Logger.Info(" Deleting  and Verify Stock Part Record ");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNumber, "WorkOrderNo");
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            Driver.WaitForReady();
            Driver.SwitchToFrame(_partInfoframe, "Labor frame ");
            _partNumber = null;
            int StockReordCount = _stockPartRecords.Count;
            StockReordCount = _stockPartRecords.Count;
            if (StockReordCount >= 1)
            {
                for (int i = 1; i < StockReordCount; i++)
                {
                    _partNumber = _extendedPage.GetElementForInput($"{_partNumberId}{0}");
                    _partNumber.ClickElement("Part Number", Driver);
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.ClickOnDeleteButton();
                    Driver.WaitForReady();
                    _extendedPage.ClicKSave();
                    _extendedPage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_partInfoframe, "Stock Part frame ");
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            Assert.True(_stockPartDeletetInfo.VerifyElementDisplay("Stock Part deleted message "), "Stock Part not deleted");
        }  

        /// <summary>
        /// Create Work Order With Dept Req
        /// </summary>
        /// <param name="DeptNo"></param>
        /// <param name="DeptReqNo"></param>
        public void CreateWorkOrderWithDeptReq(string DeptNo, string DeptReqNo)
        {
            Settings.Logger.Info(" Creating Work order with dept req.");
            _extendedPage.SwitchToContentFrame();
            _inputWorkOrderNo.SetText(CommonUtil.DataForKey(DeptNo), "Work order number");
            ClickOnWorkOrderBuild();
            _visitReq.SetText(DeptReqNo, "Dept req No");
            Driver.WaitForReady();
            _datetimeWOField.SendKeys(Keys.Tab);
            Driver.WaitForReady();
            VerifyWorkorderNumber();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Enter And Delete Work Order
        /// </summary>
        public void EnterAndDeleteWorkOrder()
        {
            Settings.Logger.Info(" Entering Work order no ");
            SearchForWorkOrder();
            _lov.SearchAndSelectFirstRowData(WONumber);
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            _woVisitInfoOpenDate.SendKeys(Keys.Tab);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Deleting existing workorder ");
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ActionRequiredWindow("Proceed");
        }

        /// <summary>
        /// Verify Department WorkOrder
        /// </summary>
        public void VerifyDepartmentWorkOrder()
        {
            Settings.Logger.Info(" Verifying Department WorkOrder Information");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            _inputWorkOrderNo.SetText(WONumber, "workOrderNumber");
            Driver.WaitForReady();
            string ActualDeptNameValue = _unitNo.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(DepartmentObjects.WoDeptReqDeptNo), ActualDeptNameValue);
            string ActualDeptDescValue = _woDescription.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(DepartmentObjects.WoDeptReqDesc), ActualDeptDescValue);
            string ActualWOStatusValue = _workOrderStatus.GetElementValueByAttribute("ovalue");
            string DeptReqstatus = CommonUtil.DataForKey(DepartmentObjects.WoDeptReqStatus).ToUpper();
            CommonUtil.AssertTrue<string>(DeptReqstatus, ActualWOStatusValue);
            string ActualLocationValue = _woLocation.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(Settings.Location, ActualLocationValue);
            string ActualRequisitionValue = _reqN.GetElementValueByAttribute("ovalue");
            CommonUtil.AssertTrue<string>(DepartmentObjects.WoDeptReqNo, ActualRequisitionValue);
            Settings.Logger.Info(" Successfully Verified Department WorkOrder Information");
        }

        /// <summary>
        /// Close Work Order 
        /// </summary>
        public void CloseWorkOrder(string? WONo = null)
        {
            if (String.IsNullOrEmpty(WONo))
            {
                WONo = WONumber;
            }
            if (!String.IsNullOrEmpty(WONo))
            { 
                Settings.Logger.Info(" Closing Department WorkOrder");
                Driver.SwitchTo().DefaultContent();
                Driver.WaitForReady();
                _extendedPage.ClickOnRefreshButton();
                _extendedPage.SwitchToContentFrame();
                _inputWorkOrderNo.SetText(WONo, "workOrderNumber");             
                Driver.WaitForReady();
                if (_workOrderStatus.GetElementValueByAttribute("ovalue").ToUpper().Trim() != WorkOrderObjects.WorkOrderClosed)
                { 
                    _woVisitInfoCloseDate.SetText("Now", "Visit Information CLOSED Field");
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.ActionRequiredWindow("Yes");
                    Driver.WaitForReady(); 
                    _extendedPage.ClicKSave();
                    Settings.Logger.Info($" Successfully Closed the  WorkOrder {WONo}");
                }
            }          
        }

        /// <summary>
        /// Verify Work Order Status
        /// </summary>
        public void VerifyWorkOrderStatusAsClosed()
        {            
            Settings.Logger.Info(" Closing WorkOrder with Department Requision ");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            _inputWorkOrderNo.SetText(WONumber, "workOrderNumber");
            Driver.WaitForReady();      
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(DepartmentObjects.WoDeptReqUpdatedStatus).ToUpper().Trim(), _workOrderStatus.GetElementValueByAttribute("ovalue").ToUpper().Trim());
            Driver.SwitchTo().DefaultContent();
        }           

        /// <summary>
        /// Fill Non Stock Part Records
        /// </summary>
        /// <param name="AddNonStockPart"></param>
        /// <param name="WorkOrderNomber"></param>
        public void FillNonStockPartRecords(AddNonStockPart AddNonStockPart, string WorkOrderNomber)
        {
            Settings.Logger.Info($"Adding Non Stock Part to WorkOrder {WorkOrderNomber}");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollDown();
            _extendedPage.SwitchToContentFrame();
            List<NonStockPartRecord> NonStockPartRecords = AddNonStockPart.NonStockPartRecord;
            foreach (NonStockPartRecord NonStockPartRecord in NonStockPartRecords)
            {
                Driver.SwitchToFrame(_nonStockPartframe, "NonStock  frame ");
                Driver.WaitForReady();
                _extendedPage.SelectAllAndClearField(_extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", "", "wnspJob"));
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", "", "wnspJob").SetText(NonStockPartRecord.NonStockPartJobCode, "NonStockPartJobCode");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspPartNo").SetText(NonStockPartRecord.PartNo, "PartNo");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspEffDate").SendKeys(Keys.Tab);
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspVendor").SetText(NonStockPartRecord.Vendor, "Vendor");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspEmpNo").SetText(NonStockPartRecord.EmployeeCode, "EmployeeCode");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspQty").SetText(NonStockPartRecord.PartQty, "PartQty");
                Driver.WaitForReady();
                _extendedPage.SetCheckBox(_extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspPrintPartTag"), "PrintTag", NonStockPartRecord.PrintTag);
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspFailCode").SetText(NonStockPartRecord.FailCode, "FailCode");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspRefNo").SetText(NonStockPartRecord.RefNo, "RefNo");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspProNo").SetText(NonStockPartRecord.PRONumber, "PRONumber");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspJobPosition").SetText(NonStockPartRecord.Position, "Position");
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClicKSave();
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Verify Non Stock Part Records
        /// </summary>
        /// <param name="AddNonStockPart"></param>
        /// <param name="WorkOrderNomber"></param>
        public void VerifyNonStockPartRecords(AddNonStockPart AddNonStockPart, string WorkOrderNomber)
        {
            Settings.Logger.Info($"Verifying Non Stock Part to WorkOrder {WorkOrderNomber}");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollDown();
            _extendedPage.SwitchToContentFrame();
            List<NonStockPartRecord> NonStockPartRecords = AddNonStockPart.NonStockPartRecord;
            foreach (NonStockPartRecord NonStockPartRecord in NonStockPartRecords)
            {
                Driver.SwitchToFrame(_nonStockPartframe, "NonStock  frame ");
                Driver.WaitForReady();            
               IWebElement NonStockPartJobCode= _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspJob");
                CommonUtil.VerifyElementValue(NonStockPartJobCode, "NonStockPartJobCode", NonStockPartRecord.NonStockPartJobCode);
                IWebElement PartNo=  _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspPartNo");
                CommonUtil.VerifyElementValue(PartNo, "PartNo", NonStockPartRecord.PartNo);
                IWebElement Vendor=  _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspVendor");
                CommonUtil.VerifyElementValue(Vendor, "Vendor", NonStockPartRecord.Vendor);
                IWebElement EmployeeCode= _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspEmpNo");
                CommonUtil.VerifyElementValue(EmployeeCode, "EmployeeCode", NonStockPartRecord.EmployeeCode);
                IWebElement PartQty= _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspQty");
                CommonUtil.VerifyElementValue(PartQty, "PartQty", NonStockPartRecord.PartQty);
                IWebElement FailCode = _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspFailCode");
                CommonUtil.VerifyElementValue(FailCode, "FailCode", NonStockPartRecord.FailCode);
                IWebElement RefNo= _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspRefNo");
                CommonUtil.VerifyElementValue(RefNo, "RefNo", NonStockPartRecord.RefNo);
                IWebElement PRONumber=  _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspProNo");
                CommonUtil.VerifyElementValue(PRONumber, "PRONumber", NonStockPartRecord.ExpectedPRONumber);
                IWebElement Position= _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspJobPosition");
                CommonUtil.VerifyElementValue(Position, "Position", NonStockPartRecord.Position);
                Driver.SwitchTo().DefaultContent();
            }
        }

        /// <summary>
        /// Edit Non Stock Part Record
        /// </summary>
        /// <param name="AddNonStockPart"></param>
        /// <param name="WorkOrderNomber"></param>
        public void EditNonStockPartRecord(AddNonStockPart AddNonStockPart, string WorkOrderNomber)
        {
            Settings.Logger.Info($"Editing Non Non Stock Part to WorkOrder {WorkOrderNomber}");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollDown();
            _extendedPage.SwitchToContentFrame();
            List<NonStockPartRecord> NonStockPartRecords = AddNonStockPart.NonStockPartRecord;
            foreach (NonStockPartRecord NonStockPartRecord in NonStockPartRecords)
            {
                Driver.SwitchToFrame(_nonStockPartframe, "NonStock  frame ");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspVendor").SetText(NonStockPartRecord.Vendor, "Vendor");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspRefNo").SetText(NonStockPartRecord.RefNo, "RefNo");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", NonStockPartRecord.NonStockPartJobCode, "wnspProNo").SetText(NonStockPartRecord.PRONumber, "PRONumber");
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClicKSave();
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Delete Non Stock Part
        /// </summary>
        public void DeleteNonStockPart(string WorkOrderNomber)
        {
            Settings.Logger.Info($"Deleting Non Stock Part to WorkOrder {WorkOrderNomber}");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollDown();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_nonStockPartframe, "NonStock  frame ");
            _wnsPartNumber = null;
            _wnsPartNumber = _extendedPage.GetAndClickElement($"{_wnspPartNumber}{0}");
            _wnsPartNumber.ClickElement("Part Number", Driver);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ActionRequiredWindow("Yes");
            Driver.WaitForReady();
            _extendedPage.Save();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            Assert.True(_nonStockPartDeletetInfo.VerifyElementDisplay("Job deleted message "), "Information not deleted");
           // _extendedPage.ClickDeleteAndVerifyDeletionMessage(_nonStockPartDeletetInfo);
            Settings.Logger.Info(" Successfully Deleted  Non Stock Part Information");
        }

        /// <summary>
        /// ReloadWO And MoveTo NoN Stock Part Frame
        /// </summary>
        private void ReloadWOAndMoveToNoNStockFrame()
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SaveAndReloadActionCode(_inputWorkOrderNo, WONumber);
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollDown();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_nonStockPartframe, "NonStock  frame ");
        }

        /// <summary>
        /// Fill Commercial ChargeRecords
        /// </summary>
        /// <param name="CommercialCharge"></param>
        /// <param name="WorkOrderNomber"></param>
        public void FillCommercialChargeRecords(CommercialCharge CommercialCharge, string WorkOrderNomber)
        {
            Settings.Logger.Info(" Adding Commercial Charge Information");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _commTab.ClickElement("Comm Tab ", Driver);
            Driver.WaitForReady();
            List<AddCommercialCharge> AddCommercialRecords = CommercialCharge.AddCommercialCharge;
            foreach (AddCommercialCharge CommercialRecord in AddCommercialRecords)
            {
                Driver.SwitchToFrame(_commframe, "Commercial frame ");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", "", "wcJob").SetText(CommercialRecord.CommercialJobCode, "CommercialJobCode");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wcvendor").SetText(CommercialRecord.Vendor, "Vendor");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wcinvno").SetText(CommercialRecord.InvNo, "InvNo");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wclaborcost").SetText(CommercialRecord.laborcost, "laborcost");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wcpartcost").SetText(CommercialRecord.Partcost, "Partcost");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wcmisccost").SetText(CommercialRecord.Misccost, "Misccost");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wctax").SetText(CommercialRecord.Wctax, "Wctax");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wcposition").SetText(CommercialRecord.Position, "Position");
                Driver.WaitForReady();
                _extendedPage.Save();
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Edit Commercial Charge Records
        /// </summary>
        /// <param name="CommercialCharge"></param>
        /// <param name="WorkOrderNomber"></param>
        public void EditCommercialChargeRecords(CommercialCharge CommercialCharge, string WorkOrderNomber)
        {
            Settings.Logger.Info(" Editing Commercial Charge Information");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _commTab.ClickElement("Comm Tab ", Driver);
            Driver.WaitForReady();
            List<AddCommercialCharge> AddCommercialRecords = CommercialCharge.AddCommercialCharge;
            foreach (AddCommercialCharge CommercialRecord in AddCommercialRecords)
            {
                Driver.SwitchToFrame(_commframe, "Commercial frame ");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wcposition").SetText(CommercialRecord.Position, "Position");
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClicKSave();
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Verify Commercial ChargeRecords
        /// </summary>
        /// <param name="CommercialCharge"></param>
        /// <param name="WorkOrderNomber"></param>
        public void VerifyCommercialChargeRecords(CommercialCharge CommercialCharge, string WorkOrderNomber)
        {
            Settings.Logger.Info(" Verifying Commercial Charge Information");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");          
            Driver.WaitForReady();
            _commTab.ClickElement("Comm Tab ", Driver);
            Driver.WaitForReady();
            Driver.SwitchToFrame(_commframe, "Commercial frame ");
            List<AddCommercialCharge> AddCommercialRecords = CommercialCharge.AddCommercialCharge;
            foreach (AddCommercialCharge CommercialRecord in AddCommercialRecords)
            {              
                IWebElement CommercialJobCode= _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wcJob");
                CommonUtil.VerifyElementValue(CommercialJobCode, "CommercialJobCode", CommercialRecord.CommercialJobCode);
                IWebElement Vendor = _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wcvendor");
                CommonUtil.VerifyElementValue(Vendor, "Vendor", CommercialRecord.Vendor);
                IWebElement InvNo = _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wcinvno");
                CommonUtil.VerifyElementValue(InvNo, "InvNo", CommercialRecord.InvNo);
                IWebElement laborcost = _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wclaborcost");
                CommonUtil.VerifyElementValue(laborcost, "laborcost", CommercialRecord.laborcost);
                IWebElement Partcost = _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wcpartcost");
                CommonUtil.VerifyElementValue(Partcost, "Partcost", CommercialRecord.Partcost);
                IWebElement Misccost = _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wcmisccost");
                CommonUtil.VerifyElementValue(Misccost, "Misccost", CommercialRecord.Misccost);
                IWebElement Wctax = _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wctax");
                CommonUtil.VerifyElementValue(Wctax, "Wctax", CommercialRecord.Wctax);
                IWebElement Position = _extendedPage.GetTableActionElementByRelatedColumnValue(_commercialTable, "Job", CommercialRecord.CommercialJobCode, "wcposition");
                CommonUtil.VerifyElementValue(Position, "Position", CommercialRecord.Position);
                Driver.WaitForReady();
                Settings.Logger.Info(" Successfully verified Commercial Charge Information");
            }
        }

        /// <summary>
        /// Verify Commercial Charge Information
        /// </summary>
        /// <param name="RowNum"></param>
        /// <param name="DataObject"></param>
        public void VerifyCommercialChargeInformation(int RowNum,String DataObjectKey)
        {
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WONumber," Work Order ");
            Driver.WaitForReady();
            _commTab.ClickElement("Comm Tab ", Driver);
            Driver.SwitchToFrame(_commframe, "Commercial frame ");
            var AddData = CommonUtil.DataObjectForKey(DataObjectKey);
            var DataObject = AddData[RowNum];
            if (DataObject != null)
            {                
            Settings.Logger.Info(" verifying added Commercial Charge information ");
            string ActualJobCodeValue = _extendedPage.GetAttributeValueForInput($"{_wcJobCode}{RowNum}"); ;
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(WorkOrderObjects.StockPartJobCode, DataObject), ActualJobCodeValue);
            string ActaulVendorValue = _extendedPage.GetAttributeValueForInput($"{_wcvendor}{RowNum}");
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(WorkOrderObjects.Vendor, DataObject), ActaulVendorValue);
            string Actaulinvno = _extendedPage.GetAttributeValueForInput($"{_wcinvno}{RowNum}");
            CommonUtil.AssertTrue<string>(_invnoValue, Actaulinvno);
            string ActuallaborcostValue = _extendedPage.GetAttributeValueForInput($"{_wclaborcost}{RowNum}");
            CommonUtil.AssertTrue<string>("$"+_wclaborcostvalue+".00", ActuallaborcostValue);
            string ActaulpartcostValue = _extendedPage.GetAttributeValueForInput($"{_wcpartcost}{RowNum}");
            CommonUtil.AssertTrue<string>("$"+_wcpartcostValue+".00", ActaulpartcostValue);
            string ActaulMisccostValue = _extendedPage.GetAttributeValueForInput($"{_wcmisccost}{RowNum}");
            CommonUtil.AssertTrue<string>("$"+_wcmisccostValue+".00", ActaulMisccostValue);
            string ActaulTaxValue = _extendedPage.GetAttributeValueForInput($"{_wctax}{RowNum}");
            CommonUtil.AssertTrue<string>("$"+_wctaxValue+".00", ActaulTaxValue);
            string ActaulTotalValue = _extendedPage.GetAttributeValueForInput($"{_wctotal}{RowNum}");
            CommonUtil.AssertTrue<string>(GetTotalCommAmount(), ActaulTotalValue);
            string PositionValue = _extendedPage.GetAttributeValueForInput($"{_wcposition}{RowNum}");
            CommonUtil.AssertTrue<string>(CommonUtil.DataForKey(WorkOrderObjects.Position, DataObject), PositionValue);
            Settings.Logger.Info(" Successfully Verified  Commercial Charge Information");
            }
            else { Assert.Fail("Data not vailable for Commercial charge part "); }
        }

        /// <summary>
        /// Get Total Comm Amount
        /// </summary>
        /// <returns></returns>
        public string GetTotalCommAmount()
        {
            int TotalValue = 0;
            TotalValue = int.Parse(_wclaborcostvalue) + int.Parse(_wcpartcostValue) + int.Parse(_wcmisccostValue) + int.Parse(_wctaxValue);
            string TotalValueString = "$" + Convert.ToString(TotalValue) + ".00";
            return TotalValueString;
        }

        /// <summary>
        /// Delete Commercial Charge Information
        /// </summary>
        public void DeleteCommercialChargeInformation(string WorkOrderNomber)
        {
            _commvendorr = null;
            ReloadWoAndMoveToCommFrame(WorkOrderNomber);
            Driver.WaitForReady();
            _commvendorr = _extendedPage.GetAndClickElement($"{_wcvendor}{0}");
            _commvendorr.ClickElement("Vendor Number", Driver);
            _extendedPage.ClickDeleteAndVerifyDeletionMessage(_commChargetDeletetInfo);
            Settings.Logger.Info(" Successfully Deleted  Commercial Charge Information");
        }

        /// <summary>
        /// ReloadWo And Move To Comm Frame
        /// </summary>
        public void ReloadWoAndMoveToCommFrame(string WorkOrderNomber)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SaveAndReloadActionCode(_inputWorkOrderNo, WorkOrderNomber);
            Driver.WaitForReady();
            _commTab.ClickElement("Comm Tab ", Driver);
            Driver.SwitchToFrame(_commframe, "Commercial frame ");
        }

        /// <summary>
        /// Reload Wo And Move To Fluid Frame
        /// </summary>
        public void ReloadWoAndMoveToFluidFrame(string WorkOrderNo)
        {
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNo, " Work Order ");
            Driver.WaitForReady();
            _fluidtab.ClickElement("Fluid Tab ", Driver);
            Driver.SwitchToFrame(_fluidframe, "Fluid frame ");
        }

        /// <summary>
        /// Fill Fluid Records
        /// </summary>
        /// <param name="Fluid"></param>
        /// <param name="WorkOrderNomber"></param>
        public void FillFluidRecords(Fluid Fluid, string WorkOrderNomber)
        {
            Settings.Logger.Info(" Adding Fluid Charge Information");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _fluidtab.ClickElement("Fuild Tab ", Driver);        
            List<AddFluidRecord> AddFluidRecords = Fluid.AddFluidRecords;
            foreach (AddFluidRecord fluidList in AddFluidRecords)
            {
                Driver.SwitchToFrame(_fluidframe, "fluid frame ");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_fluidTable, "Job", "", "wfJob").SetText(fluidList.FluidJobCode, "FluidJobCode");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_fluidTable, "Job", fluidList.FluidJobCode, "wfHose").SetText(fluidList.HoseNo, "HoseNo");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_fluidTable, "Job", fluidList.FluidJobCode, "wfQty").SetText(fluidList.Quantity, "Quantity");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_fluidTable, "Job", fluidList.FluidJobCode, "wfEmpNo").SetText(fluidList.EmployeeCode, "EmployeeCode");
                _extendedPage.Save();
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
            }
        }

        /// <summary>
        /// Verify Fluid Records
        /// </summary>
        /// <param name="Fluid"></param>
        /// <param name="WorkOrderNomber"></param>
        public void VerifyFluidRecords(Fluid Fluid, string WorkOrderNomber)
        {
            Settings.Logger.Info(" Verifying Fluid Charge Information");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _fluidtab.ClickElement("Fuild Tab ", Driver);
            Driver.SwitchToFrame(_fluidframe, "fluid frame ");
            List<AddFluidRecord> AddFluidRecords = Fluid.AddFluidRecords;
            foreach (AddFluidRecord fluidList in AddFluidRecords)
            {              
                Driver.WaitForReady();
                IWebElement FluidJobCode=  _extendedPage.GetTableActionElementByRelatedColumnValue(_fluidTable, "Job", fluidList.FluidJobCode, "wfJob");
                CommonUtil.VerifyElementValue(FluidJobCode, "FluidJobCode", fluidList.FluidJobCode);
                IWebElement HoseNo= _extendedPage.GetTableActionElementByRelatedColumnValue(_fluidTable, "Job", fluidList.FluidJobCode, "wfHose");
                CommonUtil.VerifyElementValue(HoseNo, "HoseNo", fluidList.HoseNo);
                IWebElement Quantity= _extendedPage.GetTableActionElementByRelatedColumnValue(_fluidTable, "Job", fluidList.FluidJobCode, "wfQty");
                CommonUtil.VerifyElementValue(Quantity, "Quantity", fluidList.Quantity);
                IWebElement EmployeeCode= _extendedPage.GetTableActionElementByRelatedColumnValue(_fluidTable, "Job", fluidList.FluidJobCode, "wfEmpNo");
                CommonUtil.VerifyElementValue(EmployeeCode, "EmployeeCode", fluidList.EmployeeCode);
            }
        }

        /// <summary>
        /// Delete Fluid Information
        /// </summary>
        public void DeleteFluidInformation(string WorkOrderNo)
        {
            _fluidJobCode = null;
            Driver.SwitchTo().DefaultContent();
            ReloadWoAndMoveToFluidFrame(WorkOrderNo);
            Driver.WaitForReady();
            _fluidJobCode = _extendedPage.GetAndClickElement($"{_wfJobCode}{0}");
            _fluidJobCode.ClickElement("Job code ", Driver);
            _extendedPage.ClickDeleteAndVerifyDeletionMessage(_fluidDeletetInfo);
            Settings.Logger.Info(" Successfully Deleted fluid Charge Information");
        }

        /// <summary>
        /// Create WorkOrder
        /// </summary>
        /// <param name="ActionValue"></param>
        public void CreateWorkOrder(string ActionValue)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            _inputWorkOrderNo.SetText(ActionValue, ActionValue);
            ClickOnWorkOrderBuild();
            Driver.WaitForReady();
            VisitRequestReason("0");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClicKSave();
            _extendedPage.SwitchToContentFrame();
            VerifyWorkorderNumber();
            Settings.Logger.Info($"Created the  WorkOrder {WONumber}");
        }

        /// <summary>
        /// Open Exiting Work Order
        /// </summary>
        public void OpenExitingWorkOrder()
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            Driver.PageScrollUp();
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputWorkOrderNo.SetText(WONumber, "workOrderNumber");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Close Opened WorkOrder
        /// </summary>
        /// <param name="ActionValue"></param>
        public void CloseOpenedWorkOrder(string ActionValue)
        {
            string WorkOrderNo=string.Empty;
            _extendedPage.SwitchToContentFrame();
            _inputWorkOrderNo.SetText(ActionValue, ActionValue);
            Driver.WaitForReady();
            WorkOrderNo = _workOrderNumber.GetElementValueByAttribute("ovalue");
            if(String.IsNullOrEmpty(WorkOrderNo)) WorkOrderNo = _workOrderNumber.GetElementValueByAttribute("ovalue");
            if (WorkOrderNo != null)
            {
                Settings.Logger.Info(" Closing opened WorkOrder");
                Driver.WaitForReady();
                if (_workOrderStatus.GetElementValueByAttribute("ovalue").ToUpper().Trim() == WorkOrderObjects.WorkOrderOpen)
                {
                    CloseWorkOrder(WorkOrderNo);
                    WorkOrderNo = null;
                }
            }
        }

        /// <summary>
        /// Create NewWork Order
        /// </summary>
        /// <param name="WorkOrder"></param>
        /// <param name="ItemNo"></param>
        /// <returns></returns>
        public string CreateNewWorkOrder(WorkOrderMain WorkOrder,string ItemNo)
        {
            string WorkOrderNo=String.Empty;
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            if (!string.IsNullOrEmpty(WorkOrder.WorkOrderNo))
            {
                string[] queryparam = { WorkOrder.Location , WorkOrder.WorkOrderNo };
                if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection, "WorkOrderQuery", queryparam, Settings.DBType))
                {
                    FillWorkOrderDetail(WorkOrder, ItemNo);
                    _extendedPage.MoveUpAndSwitchContentFrame();
                    Driver.WaitForReady();
                    _manualWO.SetText(WorkOrder.WorkOrderNo, "");
                }
                else
                {
                    Settings.Logger.Info($" WorkOrder { WorkOrder.WorkOrderNo } already exists in  { WorkOrder.Location }");
                    return WorkOrder.WorkOrderNo;            
                }
            }
            else {
                FillWorkOrderDetail(WorkOrder, ItemNo);
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClicKSave();
            Driver.WaitForReady();
            _extendedPage.MoveUpAndSwitchContentFrame();
            WorkOrderNo = _workOrderNumber.GetElementValueByAttribute("ovalue");
            WorkOrder.WorkOrderNo=WorkOrderNo;
            if (WorkOrder.AddJob != null)
            {
                FillJobTab(WorkOrder);
            }
            Settings.Logger.Info($"Created the  WorkOrder {WorkOrder.WorkOrderNo}");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            return WorkOrder.WorkOrderNo;
        }

        /// <summary>
        /// Fill WorkOrder Detail
        /// </summary>
        /// <param name="WorkOrder"></param>
        /// <param name="ItemNo"></param>
        public void FillWorkOrderDetail(WorkOrderMain WorkOrder, string ItemNo)
        {
            _inputWorkOrderNo.SetText(ItemNo, "");
            ClickOnWorkOrderBuild();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ActionRequiredWindow("Continue");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            VisitRequestReason(WorkOrder.Reason);
        }

        /// <summary>
        /// Fill Job Tab
        /// </summary>
        /// <param name="WorkOrder"></param>
        public void FillJobTab(WorkOrderMain WorkOrder)
        {
            Settings.Logger.Info($"Adding the  Job to WorkOrder {WorkOrder.WorkOrderNo}");
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Adding job in workorder ");
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrder.WorkOrderNo, "WorkOrderNo");
            Driver.WaitForReady();
            _jobTab.ClickElement("JabTab", Driver);
            Driver.WaitForReady();
            if (_jobInformation.VerifyElementDisplay("Job information dialog "))
            {             
                List<AddJob> AddJobList = WorkOrder.AddJob;
                foreach (AddJob AddJob in AddJobList)
                {
                    Driver.SwitchToFrame(_jobFormFrame, "job frame ");
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", "", "wjJob").SetText(AddJob.JobCode, "JobCode");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", AddJob.JobCode, "wjStatus").SendKeys(Keys.Tab);
                    Driver.WaitForSomeTime();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", AddJob.JobCode, "wjJobReason").SetText(AddJob.JobReason, "JobReason");
                    if (String.IsNullOrEmpty(_extendedPage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", AddJob.JobCode, "wjJobReason").GetAttribute("value")))
                    {
                        IWebElement JobElement = _extendedPage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", AddJob.JobCode, "wjJobReason");
                        Driver.WaitForReady();
                        JobElement.SendKeys(AddJob.JobReason);
                        Driver.WaitForReady();
                        JobElement.SendKeys(Keys.Tab);
                    }
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", AddJob.JobCode, "wjEmpCrew").SetText(AddJob.Assignment, "Assignment");
                    Driver.WaitForReady();
                    Driver.SwitchTo().DefaultContent();
                    Driver.WaitForSomeTime();
                    Driver.AcceptAlert();
                    _extendedPage.ClicKSave();
                    _extendedPage.SwitchToContentFrame();
                }
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
            }
            else { Assert.Fail("Job Table not found in work worder"); }
        }

        /// <summary>
        /// Verify Work Order Detail
        /// </summary>
        /// <param name="WorkOrder"></param>
        public void VerifyWorkOrderJobTab(WorkOrderMain WorkOrder)
        {
            Settings.Logger.Info($"Verifying  WorkOrder Detail  {WorkOrder.WorkOrderNo}");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrder.WorkOrderNo, "WorkOrderNo");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputWorkOrderNo, "WorkOrderNo", WorkOrder.WorkOrderNo);
            Driver.WaitForReady();
            if (WorkOrder.AddJob != null)
            {
                VerifyJobTab(WorkOrder);
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verif yJob Tab
        /// </summary>
        /// <param name="WorkOrder"></param>
        public void VerifyJobTab(WorkOrderMain WorkOrder)
        {
            Settings.Logger.Info($"Verifying the  Job Tab to WorkOrder {WorkOrder.WorkOrderNo}");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _jobTab.ClickElement("JabTab", Driver);
            Driver.WaitForReady();
            Driver.SwitchToFrame(_jobFormFrame, "job frame ");
            List<AddJob> AddJobList = WorkOrder.AddJob;
            foreach (AddJob AddJob in AddJobList)
            {
                string ActualJobCode = _extendedPage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", AddJob.JobCode, "wjJob").GetAttribute("ovalue");
                CommonUtil.AssertTrue<string>(AddJob.JobCode, ActualJobCode);
                string ActualJobReason =_extendedPage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", AddJob.JobCode, "wjJobReason").GetAttribute("ovalue");
                CommonUtil.AssertTrue<string>(AddJob.JobReason, ActualJobReason);
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", AddJob.JobCode,
                    "wjStatus"), "Status", AddJob.JobStatus);
            }   
        }

        /// <summary>
        /// Verify WorkOrder
        /// </summary>
        /// <param name="WorkOrder"></param>
        public void VerifyWorkOrder(WorkOrderMain WorkOrder)
        {
            Settings.Logger.Info($"Verifying  WorkOrder Detail  {WorkOrder.WorkOrderNo}");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForSomeTime(30);
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _inputWorkOrderNo.SetText(WorkOrder.WorkOrderNo, "WorkOrderNo");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_workOrderNumber, "WorkOrderNo", WorkOrder.WorkOrderNo);
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_unitNo, "ItemNo", WorkOrder.UnitDepComp);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Fill Non Stock Reserve Parts
        /// </summary>
        /// <param name="StockPart"></param>
        /// <param name="WorkOrderNomber"></param>
        public void FillNonStockReserveParts(AddStocKPart StockPart, string WorkOrderNomber)
        {
            Settings.Logger.Info($"Fill Non Stoc kReserve Parts");
            Settings.Logger.Info($"Adding Non Stock Part to WorkOrder {WorkOrderNomber}");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollDown();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_nonStockPartframe, "NonStock  frame ");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", "", "wnspJob"));
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_nonStockPartTable, "Job", "", "wnspJob").SetText(StockPart.JobCode, "JobCode");
            Driver.WaitForReady();
            FillReservePartDetail(StockPart, _wnspResvPartBtn);
        }

        /// <summary>
        /// Fill Stoc kReserve Parts
        /// </summary>
        /// <param name="AddStocKPart"></param>
        /// <param name="WorkOrderNomber"></param>
        public void FillStockReserveParts(AddStocKPart AddStocKPart, string WorkOrderNomber)
        {
            Settings.Logger.Info($"Fill Stoc kReserve Parts");
            Settings.Logger.Info($"Adding Stock Part to WorkOrder {WorkOrderNomber}");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            Driver.SwitchToFrame(_partInfoframe, "Labor frame ");
            Driver.WaitForReady();
            _extendedPage.SelectAllAndClearField(_extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", "", "wspJob"));
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_stockPartTable, "Job", "", "wspJob").SetText(AddStocKPart.JobCode, "JobCode");
            Driver.WaitForReady();
            FillReservePartDetail(AddStocKPart, _wspResvPartBtn);
        }

        /// <summary>
        /// Fill Reserve PartDetail
        /// </summary>
        /// <param name="StockPart"></param>
        /// <param name="ReservePartButton"></param>
        public void FillReservePartDetail(AddStocKPart StockPart,IWebElement ReservePartButton)
        {
            Settings.Logger.Info($"Fill kReserve Parts");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            if (ReservePartButton.GetText("wnspResvPartBtn").Equals("Reserve Parts (0)"))
            { Assert.Fail("No record  loaded for non stock part  "); };
            Driver.WaitForReady();
            ReservePartButton.ClickElement("wnspResvPartBtn", Driver);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _wrpSelectAllBtn.ClickElement("_wrpSelectAllBtn", Driver);
            int RowNo = 0;
            List<StockPartRecord> NonStockPartRecords = StockPart.StockPartRecords;
            foreach (StockPartRecord NonStockPartRecord in NonStockPartRecords)
            {
                Driver.WaitForReady();
                _extendedPage.GetElementForInput($"wrpEmpNo${RowNo}").SetText(NonStockPartRecord.EmployeeCode, "EmployeeCode");
                Driver.WaitForReady();
                _extendedPage.GetElementForInput($"wrpFailCode${RowNo}").SetText(NonStockPartRecord.FailCode, "FailCode");
                Driver.WaitForReady();
                _extendedPage.GetElementForInput($"pos_code{RowNo}").SetText(NonStockPartRecord.Position, "Position");
                Driver.WaitForReady();
                RowNo++;
            }
            Driver.WaitForSomeTime();
            Driver.FindElement(By.XPath("//button[@id='wrpSaveBtn']")).Click();
            Driver.WaitForReady();
            if (_wrpSaveBtn.VerifyElementDisplay("_wrpSaveBtn"))
            { _wrpSaveBtn.Click(); }
            _extendedPage.Save();
        }

        /// <summary>
        /// Verify Commercial Work Order
        /// </summary>
        /// <param name="workOrderNo"></param>
        /// <param name="unitNo"></param>
        /// <param name="msg"></param>
        public void VerifyCommercialWorkOrder(string workOrderNo, string unitNo, string msg = "N/A")
        {
            Settings.Logger.Info($"Verify Commercial Work Order {workOrderNo}");
            _extendedPage.SwitchToContentFrame();
            _inputWorkOrderNo.SetText(workOrderNo, "WorkOrderNo");
            Driver.WaitForSomeTime(3);
            if (msg != "N/A")
            {
                string alertTxt = Driver.GetAlertText();
                CommonUtil.AssertTrue(msg, alertTxt);
                Driver.AcceptAlert();
            }
            else
            {
                CommonUtil.VerifyElementValue(_unitNo, "Unit No", unitNo);
                CommonUtil.VerifyElementValue(_workOrderNumber, "Work Order No", workOrderNo);
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Adding Warranty Notes To Job
        /// </summary>
        /// <param name="jobs"></param>
        /// <param name="WorkOrderNo"></param>
        public void AddWarrantyNotesToJob(List<AddJob> jobs, string WorkOrderNo)
        {
            Settings.Logger.Info($" Adding Warranty Notes To Job for WorkOrder {WorkOrderNo}");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            _jobTab.ClickElement("Job Tab", Driver);
            Driver.WaitForReady();
            foreach(AddJob job in jobs)
            {
                Driver.SwitchToFrame(_jobFormFrame, "job frame ");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", job.JobCode, "wjStatus", "ovalue").SetText(job.JobStatus, "Status");
                Driver.WaitForReady();
                if(job.WarrNotes)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_jobTable, "Job", job.JobCode, "wjWarrNote", "ovalue").Click();
                    Driver.WaitForReady();
                    Driver.SwitchTo().DefaultContent();
                    Driver.SwitchToFrame(_extendedPage._contentFrame2, "Content 2");
                    _textareaCompnote.SetText(job.Notes.Complaint, "Complaint Notes");
                    Driver.WaitForReady();
                    _textareaCausenote.SetText(job.Notes.Cause, "Cause Notes");
                    Driver.WaitForReady();
                    _textareaCorrnote.SetText(job.Notes.Correction, "Correction Notes");
                    Driver.WaitForReady();
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.ClickOnSaveButton();
                    Driver.WaitForReady();
                    _extendedPage.SwitchToContentFrame();
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Stock Part Record Deletion
        /// </summary>
        /// <param name="WorkOrderNumber"></param>
        public void VerifyStockPartRecordDeletio(string WorkOrderNumber)
        {
            Settings.Logger.Info(" Verify Stock Part Record Deletion");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNumber, "WorkOrderNo");
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            Driver.WaitForReady();
            _extendedPage.VerifyTableRowDeletion(_partInfoframe, _stockPartTableRows, "Stock Part table");
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Successfully Verified Stock Part Information");
        }

        /// <summary>
        /// Verify Non Stock Part Deletion
        /// </summary>
        /// <param name="WorkOrderNomber"></param>
        public void VerifyNonStockPartDeletion(string WorkOrderNomber)
        {
            Settings.Logger.Info($"Deleting Non Stock Part to WorkOrder {WorkOrderNomber}");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            Driver.SwitchTo().DefaultContent();
            Driver.PageScrollDown();
            _extendedPage.SwitchToContentFrame();
            _extendedPage.VerifyTableRowDeletion(_nonStockPartframe, _nonStockPartTableRows, "Non Stock Part table");   
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Successfully Verified  Non Stock Part Information");
        }

        /// <summary>
        /// Add Part Xref
        /// </summary>
        /// <param name="Type"></param>
        /// <param name="TypeName"></param>
        /// <param name="MasterPartName"></param>
        public void AddPartXref(string Type,string TypeName,string MasterPartName)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ActionRequiredWindow("Add a cross-reference");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_contentFrame2, "Labor frame ");
            if(_xrefPartName.VerifyElementDisplay("xrefPartName"))
            {
                _xtype.SelectDropdownUsingValue("Type", Type);
                Driver.WaitForReady();
                _xrefVendor.SetText(TypeName, "TypeName");
                Driver.WaitForReady();
                _mPartNo.SetText(MasterPartName, "MasterPartName");
                Driver.WaitForReady();
            }
            else { Assert.Fail("Add Part Xref not found"); }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClicKSave();
            Driver.AcceptAlert();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_partInfoframe, "Labor frame ");
        }

        /// <summary>
        /// Verify Multiple WorkOrder
        /// </summary>
        /// <param name="WorkOrder"></param>
        public void VerifyMultipleWorkOrder(WorkOrderMain WorkOrder)
        {
            int i = 0;
            foreach(string UnitMo in WorkOrder.UnitList)
            {
                WorkOrder.UnitDepComp = UnitMo;
                WorkOrder.WorkOrderNo = WorkOrder.WorkOrderList[i];
                VerifyWorkOrder(WorkOrder);
                i++;
            }
            Settings.Logger.Info(" Successfully Verified WorkOrder List");
        }

        /// <summary>
        /// Close Multiple WorkOrder
        /// </summary>
        /// <param name="WorkOrderList"></param>
        public void CloseMultipleWorkOrder(List<string> WorkOrderList)
        {
            foreach (string WorkOrderNo in WorkOrderList)
            {
                CloseWorkOrder(WorkOrderNo);
            }
            Settings.Logger.Info(" Successfully Closed WorkOrder List");
        }

        /// <summary>
        /// Close Opened Multiple WorkOrder
        /// </summary>
        /// <param name="UnitList"></param>
        public void CloseOpenedMultipleWorkOrder(List<string> UnitList)
        {           
            foreach (string UnitNo in UnitList)
            {
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnRefreshButton();
                Driver.WaitForReady();
                CloseOpenedWorkOrder(UnitNo);

            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Successfully Closed WorkOrder List");
        }

        /// <summary>
        /// Verify Total Extended Cost
        /// </summary>
        /// <param name="WorkOrderNomber"></param>
        /// <param name="TotalExtendedCost"></param>
        public void VerifyTotalExtendedCost(String WorkOrderNomber,string TotalExtendedCost)
        {           
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSetText(_inputWorkOrderNo, WorkOrderNomber, "WorkOrderNo");
            Driver.WaitForReady();
            _partab.ClickElement("Part Tab ", Driver);
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_wmsTotalextcost, "TotalExtendedCost", TotalExtendedCost);
            Settings.Logger.Info($" Verified TotalExtendedCost Stock Part to WorkOrder {WorkOrderNomber}");
        }
    }
}
