﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Driver;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class DriverTripEntryPageActions : DriverTripEntryPage
    {
        public DriverTripEntryPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Driver Trip Entry
        /// </summary>
        /// <param name="dataObjectValues"></param>
        /// <returns></returns>
        public DriverTripObject CreateNewDriverTripEntry(DriverTripObject dataObjectValues)
        {
            Settings.Logger.Info($" Creating Driver Trip Entry for Driver NO :{dataObjectValues.DriverEntryData.DriverNo}");
            _extendedPage.SwitchToContentFrame();
            FillDriverTripEntryDetails(dataObjectValues);
            if(dataObjectValues.AllocationDetails!=null)
                FillAllocationReasonDetails(dataObjectValues);
            if (dataObjectValues.VehicleDetails != null)
                FillVehicleDetails(dataObjectValues);
            _extendedPage.Save();
            _extendedPage.SwitchToContentFrame();
            dataObjectValues.AllocationDetails.StartDate = _startDate.GetElementValueByAttribute("ovalue");
            dataObjectValues.AllocationDetails.EndDate = _endDate.GetElementValueByAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            return dataObjectValues;
        }

        /// <summary>
        /// Fill Driver Trip Entry Details
        /// </summary>
        /// <param name="dataObjectValues"></param>
        public void FillDriverTripEntryDetails(DriverTripObject dataObjectValues)
        {
            Settings.Logger.Info("Fill Driver Trip Entry Details");
            _driverNo.SetText(dataObjectValues.DriverEntryData.DriverNo, "DriverNo");
            Driver.WaitForReady();       
        }

        /// <summary>
        /// Fill Allocation Reason Details
        /// </summary>
        /// <param name="dataObjectValues"></param>
        public void FillAllocationReasonDetails(DriverTripObject dataObjectValues)
        {
            Settings.Logger.Info("Fill Allocation Reason Details");
            _startDate.SetText(dataObjectValues.AllocationDetails.StartDate, "StartDate");
            Driver.SwitchTo().DefaultContent();
            if (_extendedPage._createDialog.VerifyElementDisplay("Action Required"))
            {
                _extendedPage.ClickOnDialogBoxButton("Create");
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
                Driver.WaitForReady();
            }
            _endDate.SetText(dataObjectValues.AllocationDetails.EndDate, "EndDate");
            _startMiles.SetText(dataObjectValues.AllocationDetails.StartMileage, "StartMileage");
            _endMiles.SetText(dataObjectValues.AllocationDetails.EndMileage, "EndMileage");
            _businessMile.SetText(dataObjectValues.AllocationDetails.BusinessMiles, "BusinessMiles");
            _personalMile.SetText(dataObjectValues.AllocationDetails.PersonalMiles, "PersonalMiles");
            _AllocationReasonCode.SetText(dataObjectValues.AllocationDetails.AllocationCode, "AllocationCode");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Fill Vehicle Details
        /// </summary>
        /// <param name="dataObjectValues"></param>
        public void FillVehicleDetails(DriverTripObject dataObjectValues)
        {
            Settings.Logger.Info("Fill Vehile Details");
            _VechileTypeDropdown.ClickDropDownValuebyContainingText(dataObjectValues.VehicleDetails.SelectVehicleType);
            _unitNumber.SetText(dataObjectValues.VehicleDetails.UnitNo, "UnitNo");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Driver Trip Entry
        /// </summary>
        /// <param name="dataObjectValues"></param>
        public void VerifyDriverTripEntry(DriverTripObject dataObjectValues)
        {
            Settings.Logger.Info("Verify Driver Trip Entry From Table");
            _extendedPage.RefreshAndSetText(_driverNo, dataObjectValues.DriverEntryData.DriverNo, "DriverNo");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_tableFrame, "_tableFrame");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverTripEntryTable, "Unit No", dataObjectValues.VehicleDetails.UnitNo, "UNIT_NO","value","div")
                , "unitno", dataObjectValues.VehicleDetails.UnitNo,false,"value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverTripEntryTable, "Unit No", dataObjectValues.VehicleDetails.UnitNo, "START_DT", "value", "div")
               , "StartDate", dataObjectValues.AllocationDetails.StartDate,false,"value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverTripEntryTable, "Unit No", dataObjectValues.VehicleDetails.UnitNo, "END_DT", "value", "div")
              , "EndDate", dataObjectValues.AllocationDetails.EndDate,false,"value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverTripEntryTable, "Unit No", dataObjectValues.VehicleDetails.UnitNo, "START_MILES", "value", "div")
             , "StartMileage", dataObjectValues.AllocationDetails.StartMileage,false,"value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverTripEntryTable, "Unit No", dataObjectValues.VehicleDetails.UnitNo, "END_MILES", "value", "div")
             , "EndMileage", dataObjectValues.AllocationDetails.EndMileage,false,"value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverTripEntryTable, "Unit No", dataObjectValues.VehicleDetails.UnitNo, "BIZ_MILES", "value", "div")
            , "BusinessMiles", dataObjectValues.AllocationDetails.BusinessMiles,false,"value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverTripEntryTable, "Unit No", dataObjectValues.VehicleDetails.UnitNo, "PERS_MILES", "value", "div")
           , "PersonalMiles", dataObjectValues.AllocationDetails.PersonalMiles,false,"value");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Driver Trip Entry
        /// </summary>
        /// <param name="dataObjectValues"></param>
        public void DeleteDriverTripEntry(DriverTripObject dataObjectValues)
        {
            Settings.Logger.Info("Delete Driver Trip Entry");
            _extendedPage.RefreshAndSetText(_driverNo, dataObjectValues.DriverEntryData.DriverNo, "DriverNo");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_tableFrame, "_tableFrame");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverTripEntryTable, "Unit No", dataObjectValues.VehicleDetails.UnitNo, "UNIT_NO", "value", "div").ClickElement("Unit No",Driver);
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClickOnDialogBoxButton("Delete");           
        }

        /// <summary>
        /// Verify Deleted Driver Trip Entry
        /// </summary>
        /// <param name="dataObjectValues"></param>
        public void VerifyDeleteDriverTripEntry(DriverTripObject dataObjectValues)
        {
            Settings.Logger.Info("Verify Deleted Driver Trip Entry");
            _extendedPage.RefreshAndSetText(_driverNo, dataObjectValues.DriverEntryData.DriverNo, "DriverNo");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_tableFrame, "_tableFrame");
            _extendedPage.VerifyTableColumnDoesNotContainValue(_driverTripEntryTable, "Unit No", dataObjectValues.VehicleDetails.UnitNo, "value", "div");
            Driver.SwitchTo().DefaultContent();
        }
    }
}

