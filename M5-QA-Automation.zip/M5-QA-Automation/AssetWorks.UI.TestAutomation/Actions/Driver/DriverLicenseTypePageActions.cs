﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Driver;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using MongoDB.Driver;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Driver
{
    internal class DriverLicenseTypePageActions : DriverLicenseTypePage
    {
        public DriverLicenseTypePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// CreateDriver License Type
        /// </summary>
        /// <param name=""></param>
        public void CreateDriverLicenseType(DriverLicenseType DataObject) 
        {
            Settings.Logger.Info("------ Creating Driver License Type---------");
            _extendedPage.SwitchToContentFrame();
            _issuingAuthorityTxtBox.SetText(DataObject.issueAuthCode, "_issuingAuthorityTxtBox");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_tableFrame, "_tableFrame");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceTypeTable, _headerLicenceTypeCode, "", "LICENCE_TYPE").SetText(DataObject.Code, "Status code");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceTypeTable, _headerLicenceTypeCode, DataObject.Code, "DESCRIPTION").SetText(DataObject.Description, "StatusDescription");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceTypeTable, _headerLicenceTypeCode, DataObject.Code, "DISABLED_FL").SetCheckBox("Disabled", DataObject.Disabled);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Driver License Type
        /// </summary>
        /// <param name=""></param>
        public void VerifyDriverLicenseType(DriverLicenseType DataObjects)
        {
            Settings.Logger.Info("------ Verifying Driver License Type---------");
            _disabledCheckBox = null;
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            _issuingAuthorityTxtBox.SetText(DataObjects.issueAuthCode, "_issuingAuthorityTxtBox");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_tableFrame, "_tableFrame");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceTypeTable, _headerLicenceTypeCode, DataObjects.Code, "LICENCE_TYPE"), "License Type", DataObjects.Code,false,"value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceTypeTable, _headerLicenceTypeCode, DataObjects.Code, "DESCRIPTION"), "DESCRIPTION", DataObjects.Description,false,"value");
            _disabledCheckBox = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceTypeTable, _headerLicenceTypeCode, DataObjects.Code, "DISABLED_FL");
            CommonUtil.VerifyCheckboxState(_disabledCheckBox, "Check box", DataObjects.Disabled);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Driver License Type
        /// </summary>
        /// <param name=""></param>
        public void UpdateDriverLicenseType(DriverLicenseType DataObject)
        {
            Settings.Logger.Info("------ Update Driver License Type---------");
            _extendedPage.SwitchToContentFrame();
            _issuingAuthorityTxtBox.SetText(DataObject.issueAuthCode, "_issuingAuthorityTxtBox");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_tableFrame, "_tableFrame");
            if (DataObject.Description != null)
            {
                if(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceTypeTable, _headerLicenceTypeCode, DataObject.Code, "DISABLED_FL").Selected)
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceTypeTable, _headerLicenceTypeCode, DataObject.Code, "DISABLED_FL").DeSelectCheckBox("Disabled");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceTypeTable, _headerLicenceTypeCode, DataObject.Code, "DESCRIPTION").SetText(DataObject.Description, "Description");
            }
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceTypeTable, _headerLicenceTypeCode, DataObject.Code, "DISABLED_FL").SetCheckBox("Disabled",DataObject.Disabled);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        ///<summary>
        ///Delete and Verify Driver Licens Type
        ///</summary>
        ///<param name="DataObject"></param>
        public void VerifyDeletedDriverLicenseType(DriverLicenseType DataObject)
        {
            Settings.Logger.Info("------ Update Driver License Type---------");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            _issuingAuthorityTxtBox.SetText(DataObject.issueAuthCode, "_issuingAuthorityTxtBox");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_tableFrame, "_tableFrame");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverLicenceTypeTable, _headerLicenceTypeCode, DataObject.Code, "LICENCE_TYPE").Click();
            _extendedPage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            _issuingAuthorityTxtBox.SetText(DataObject.issueAuthCode, "_issuingAuthorityTxtBox");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_tableFrame, "_tableFrame");
            _extendedPage.VerifyTableColumnDoesNotContainValue(_driverLicenceTypeTable, _headerLicenceTypeCode, DataObject.Code);
        }
    }
}
