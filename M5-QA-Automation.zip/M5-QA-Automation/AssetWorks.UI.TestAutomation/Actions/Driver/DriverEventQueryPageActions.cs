﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Driver;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Driver
{
    internal class DriverEventQueryPageActions : DriverEventQueryPage
    {
        private DriverEventEntryPageActions _eventEnteryPage => new DriverEventEntryPageActions(Driver);
        public DriverEventQueryPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Driver Event Query
        /// </summary>
        /// <param name=""></param>
        public void RetrieveDriverEventQuery(DriverEventQueryObject DataObject) 
        {
            Driver.WaitForReady();
            Settings.Logger.Info("Searching Driver event With A Query");
            _extendedPage.SwitchToContentFrame();

            _driverNo.SetText(DataObject.DriverNo, "_driverNo");
            Driver.WaitForReady();
            _eventClass.SetText(DataObject.EventClass, "_eventClass");
            Driver.WaitForReady();
            _eventType.SetText(DataObject.EventType, "_eventType");
            Driver.WaitForReady();
            _StartDate.SetText(DataObject.StartDate, "_StartDate");
            Driver.WaitForReady();
            _endDate.SetText(DataObject.EndDate, "_endDate");
            Driver.WaitForReady();
            _queryTypeDropdown.ClickDropDownValuebyContainingText(DataObject.QueryType);
            _queryRange.ClickDropDownValuebyContainingText(DataObject.QueryRange);
            Driver.WaitForReady();

            _RetrieveBtn.ClickElement("_RetrieveBtn",Driver);
            
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Created Retrieved event data
        /// </summary>
        /// <param name=""></param>
        public void VerifyRetrivedDriverEventEntry(DriverEventObject DataObjects)
        {
            Driver.WaitForReady();
            Settings.Logger.Info("Verify Driver event That Retrieved");
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_tableFrame, "_tableFrame");

            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverEvtQueryTable, "Driver No", DataObjects.DriverEntryData.DriverNo, "DriverNo")
                , "DriverNo", DataObjects.DriverEntryData.DriverNo, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverEvtQueryTable, "Driver No", DataObjects.DriverEntryData.DriverNo, "EvtType")
               , "Event Type", DataObjects.DriverEntryData.EventType, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverEvtQueryTable, "Driver No", DataObjects.DriverEntryData.DriverNo, "EvtTypeDesc")
              , "Event Type Dec", DataObjects.DriverEntryData.EventTypeDesc, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverEvtQueryTable, "Driver No", DataObjects.DriverEntryData.DriverNo, "EvtClass")
              , "Event Class", DataObjects.DriverEntryData.EventClass, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverEvtQueryTable, "Driver No", DataObjects.DriverEntryData.DriverNo, "EvtDate")
             , "Event Date", DataObjects.DriverEntryData.EventDate, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverEvtQueryTable, "Driver No", DataObjects.DriverEntryData.DriverNo, "EvtLoc")
             , "Event Location", DataObjects.EventCommentsData.EventLocation, false, "value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverEvtQueryTable, "Driver No", DataObjects.DriverEntryData.DriverNo, "EvtRef")
            , "Event Refarence", DataObjects.EventCommentsData.Reference, false, "value");

            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Retrieved event data
        /// </summary>
        /// <param name=""></param>
        public void UpdateRetrivedEvent(DriverEventObject DataObjects)
        {
            Driver.WaitForReady();
            Settings.Logger.Info("Updating Driver event That Retrieved");
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_tableFrame, "_tableFrame");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEvtQueryTable, "Driver No", DataObjects.DriverEntryData.DriverNo, "EvtDate").Click();
            Driver.SwitchTo().DefaultContent();

            string parentWindow = Driver.SwitchToNewWindow();
            _eventEnteryPage.UpdateDriverEventEntry(DataObjects);
            Driver.Close();
            Driver.SwitchTo().Window(parentWindow);
        }
    }
}
