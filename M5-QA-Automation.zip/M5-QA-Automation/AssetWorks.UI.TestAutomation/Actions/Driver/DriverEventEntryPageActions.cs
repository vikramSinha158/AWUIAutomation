﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Driver;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class DriverEventEntryPageActions : DriverEventEntryPage
    {
        public DriverEventEntryPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Driver Event Entry
        /// </summary>
        /// <param name="dataObjectValues"></param>
        /// <returns></returns>
        public DriverEventObject CreateNewDriverEventEntry(DriverEventObject dataObjectValues)
        {
            Settings.Logger.Info($" Creating Driver Event Entry for Driver NO :{dataObjectValues.DriverEntryData.DriverName}, Event Type: {dataObjectValues.DriverEntryData.EventType}");
            #region Driver Event Entry
            _extendedPage.SwitchToContentFrame();
            FillDriverEntryDetails(dataObjectValues);
            Driver.SwitchTo().DefaultContent();
            if (_extendedPage._createDialog.VerifyElementDisplay("Action Required"))
            {
                _extendedPage.ClickOnDialogBoxButton("Create");
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
            }                
            else
            {
                _extendedPage.ClickOnDeleteButton();
                _extendedPage.ClickOnDialogBoxButton("Delete");
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
                FillDriverEntryDetails(dataObjectValues);
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnDialogBoxButton("Create");
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
            }          
            #endregion 
            #region Event Scheduling            
            _plannedDate.SetText(dataObjectValues.EventSchedulingData.PlannedDate, "PlannedDate");
            Driver.WaitForReady();
            _actDate.SetText(dataObjectValues.EventSchedulingData.ActualDate, "ActualDate");
            Driver.WaitForReady();
            _expDate.SetText(dataObjectValues.EventSchedulingData.ExpiryDate, "ExpiryDate");
            Driver.WaitForReady();
            #endregion
            #region Event Comments
            _evtDetail.SetText(dataObjectValues.EventCommentsData.EventDetail, "EventDetail");
            Driver.WaitForReady();
            _evtPlace.SetText(dataObjectValues.EventCommentsData.EventLocation, "EventLocation");
            Driver.WaitForReady();
            _evtRef.SetText(dataObjectValues.EventCommentsData.Reference, "Reference");
            Driver.WaitForReady();
            _evtComment.SetText(dataObjectValues.EventCommentsData.Comment, "Comment");
            Driver.WaitForReady();
            _evtResult.SetText(dataObjectValues.EventCommentsData.Result, "Result");
            Driver.WaitForReady();
            #endregion
            if(dataObjectValues.DriverEntryTable != null)
            {
                #region Table Entry
                Driver.SwitchToFrame(_tableFrame, "Driver Event Entry Table Frame");
                foreach (DriverEntryTable Tabledata in dataObjectValues.DriverEntryTable)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEvtItemsTable, "Item", Tabledata.Item, "evt_value").SetText(Tabledata.Value, "Value");
                }
                Driver.SwitchTo().DefaultContent();
                _extendedPage.SwitchToContentFrame();
                #endregion
            }
            _evtNotes.SetText(dataObjectValues.Notes, "Notes");
            _extendedPage.Save();
            _extendedPage.SwitchToContentFrame();
            dataObjectValues.DriverEntryData.EventDate = _eventDate.GetElementValueByAttribute("ovalue");
            dataObjectValues.EventSchedulingData.PlannedDate = _plannedDate.GetElementValueByAttribute("ovalue");
            dataObjectValues.EventSchedulingData.ActualDate = _actDate.GetElementValueByAttribute("ovalue");
            dataObjectValues.EventSchedulingData.ExpiryDate = _expDate.GetElementValueByAttribute("ovalue");
            Driver.SwitchTo().DefaultContent();
            return dataObjectValues;
        }

        /// <summary>
        /// Fill Driver Entry Details
        /// </summary>
        /// <param name="dataObjectValues"></param>
        public void FillDriverEntryDetails(DriverEventObject dataObjectValues)
        {
            Settings.Logger.Info("Fill Driver Entry Details");
            _driverNo.SetText(dataObjectValues.DriverEntryData.DriverNo, "DriverNo");
            Driver.WaitForReady();
            _evttypCode.SetText(dataObjectValues.DriverEntryData.EventType, "EventType");
            Driver.WaitForReady();
            _eventDate.SetText(dataObjectValues.DriverEntryData.EventDate, "EventDate");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Driver Event Entry
        /// </summary>
        /// <param name="dataObjectValues"></param>
        public void VerifyDriverEventEntry(DriverEventObject dataObjectValues)
        {
            Settings.Logger.Info("Verify Driver Event Entry");
            _extendedPage.RefreshAndSetText(_driverNo, dataObjectValues.DriverEntryData.DriverNo, "DriverNo");
            Driver.WaitForReady();
            #region Driver Event Entry
            _evttypCode.SetText(dataObjectValues.DriverEntryData.EventType, "EventType");
            Driver.WaitForReady();
            _eventDate.SetText(dataObjectValues.DriverEntryData.EventDate, "EventDate");
            Driver.WaitForSomeTime();
            #endregion
            #region Event Scheduling  
            CommonUtil.VerifyElementValue(_plannedDate, "PlannedDate", dataObjectValues.EventSchedulingData.PlannedDate);
            CommonUtil.VerifyElementValue(_actDate, "ActualDate", dataObjectValues.EventSchedulingData.ActualDate);
            CommonUtil.VerifyElementValue(_expDate, "ExpDate", dataObjectValues.EventSchedulingData.ExpiryDate);
            #endregion
            #region Event Comments
            CommonUtil.VerifyElementValue(_evtDetail, "EventDetail", dataObjectValues.EventCommentsData.EventDetail);
            CommonUtil.VerifyElementValue(_evtPlace, "EventLocation", dataObjectValues.EventCommentsData.EventLocation);
            CommonUtil.VerifyElementValue(_evtRef, "Reference", dataObjectValues.EventCommentsData.Reference);
            CommonUtil.VerifyElementValue(_evtComment, "Comment", dataObjectValues.EventCommentsData.Comment);
            CommonUtil.VerifyElementValue(_evtResult, "Result", dataObjectValues.EventCommentsData.Result);
            #endregion
            #region Table Entry
            Driver.SwitchToFrame(_tableFrame, "Driver Event Entry Table Frame");
            foreach (DriverEntryTable Tabledata in dataObjectValues.DriverEntryTable)
            {
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverEvtItemsTable, "Item", Tabledata.Item, "evt_value"), "Value", Tabledata.Value, false, "value");
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            #endregion
            CommonUtil.VerifyElementValue(_evtNotes, "Notes", dataObjectValues.Notes);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Driver Event Entry
        /// </summary>
        /// <param name="dataObjectValues"></param>
        public void UpdateDriverEventEntry(DriverEventObject dataObjectValues)
        {
            Settings.Logger.Info("Update Driver Event Entry");
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            #region Event Comments
            _evtDetail.SetText(dataObjectValues.EventCommentsData.EventDetail, "EventDetail");
            Driver.WaitForReady();
            _evtPlace.SetText(dataObjectValues.EventCommentsData.EventLocation, "EventLocation");
            Driver.WaitForReady();
            _evtRef.SetText(dataObjectValues.EventCommentsData.Reference, "Reference");
            Driver.WaitForReady();
            _evtComment.SetText(dataObjectValues.EventCommentsData.Comment, "Comment");
            Driver.WaitForReady();
            _evtResult.SetText(dataObjectValues.EventCommentsData.Result, "Result");
            Driver.WaitForReady();
            #endregion
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            _evtNotes.SetText(dataObjectValues.Notes, "Notes");
            _extendedPage.Save();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Delete Driver Event Entry
        /// </summary>
        /// <param name="dataObjectValues"></param>
        public void DeleteDriverEventEntry(DriverEventObject dataObjectValues)
        {
            Settings.Logger.Info("Delete Driver Event Entry");
            _extendedPage.RefreshAndSetText(_driverNo, dataObjectValues.DriverEntryData.DriverNo, "DriverNo");
            Driver.WaitForReady();
            #region Driver Event Entry
            _evttypCode.SetText(dataObjectValues.DriverEntryData.EventType, "EventType");
            Driver.WaitForReady();
            _eventDate.SetText(dataObjectValues.DriverEntryData.EventDate, "EventDate");
            Driver.WaitForSomeTime();
            #endregion
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClickOnDialogBoxButton("Delete");           
        }

        /// <summary>
        /// Verify Deleted Driver Event Entry
        /// </summary>
        /// <param name="dataObjectValues"></param>
        public void VerifyDeleteDriverEventEntry(DriverEventObject dataObjectValues)
        {
            Settings.Logger.Info("Verify Deleted Driver Event Entry");
            _extendedPage.RefreshAndSetText(_driverNo, dataObjectValues.DriverEntryData.DriverNo, "DriverNo");
            Driver.WaitForReady();
            #region Driver Event Entry
            FillDriverEntryDetails(dataObjectValues);            
            #endregion
            Driver.SwitchTo().DefaultContent();
            CommonUtil.AssertTrue<bool>(true,_extendedPage._createDialog.VerifyElementDisplay("Action Required"));
            _extendedPage.ClickOnDialogBoxButton("Cancel");
        }
    }
}

