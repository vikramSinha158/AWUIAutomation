﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;


namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class DriverClassCodesPageActions : DriverClassCodesPage
    {
        public DriverClassCodesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Driver Class Code
        /// </summary>
        /// <param name="dataobj"></param>
        /// <returns></returns>
        public string CreateDriverClassCode(DriverClassCode dataobj)
        {
            string ClassCode = string.Empty;
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(dataobj.Code, ref ClassCode, "",5))
            {
                dataobj.Code = ClassCode;
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_driverClassCodesFrame, "Table frame");
                _driverClassCode.SetText(dataobj.Code, "New Customer Type  Code");
                _description.SetText(dataobj.Description, "New Customer Type Code Description ");
                _extendedPage.SetCheckBox(_disabledCheckbox,"Disabled CheckBox", dataobj.Disabled);               
                _extendedPage.Save();
                Settings.Logger.Info("Created Diver Class Code Successfully");
            }
            return dataobj.Code;
        }
       
        /// <summary>
        /// edit Driver Class Code
        /// </summary>
        /// <param name="dataobj"></param>
        public void EditDriverClassCode(DriverClassCode dataobj)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.RefreshAndSwitchToTable(_driverClassCodesFrame, "Table Frame");
            Settings.Logger.Info("Edit Driver Class Code : " + dataobj.Code);
            _extendedPage.SetCheckBox(_extendedPage.GetTableActionElementByRelatedColumnValue(
                 _driverClassCodesTable, "Code", dataobj.Code, "DISABLED_FL"), "", dataobj.Disabled);          
            _extendedPage.Save();
            Settings.Logger.Info("Edited Driver Class code Successfully");
        }

        /// <summary>
        /// Verify Driver Class Code
        /// </summary>
        /// <param name="dataobj"></param>
        public void VerifyDriverClassCode(DriverClassCode dataobj)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_driverClassCodesFrame, "Table frame");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverClassCodesTable, "Code", dataobj.Code, "DESCRIPTION"), "Driver Class Code", dataobj.Description, false, "value");
            CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _driverClassCodesTable, "Code", dataobj.Code, "DISABLED_FL"), "Disable CheckBox", dataobj.Disabled);
            Settings.Logger.Info("Verified Driver Class Code Successfully");
        }

        /// <summary>
        /// Delete Driver Class Code
        /// </summary>
        /// <param name="CustomerTypeData"></param>
        public void DeleteDriverClassCode(DriverClassCode dataobj)
        {
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _driverClassCodesTable, "Code", dataobj.Code, "DRIVER_CLASS").Click();
            _extendedPage.DeleteAndSave();
            Settings.Logger.Info("Deleted Driver Class Code Successfully");
        }

        /// <summary>
        /// Verify Deleted Driver Class Code
        /// </summary>
        /// <param name="dataobj"></param>
        public void VerifyDeletedDriverClassCode(DriverClassCode dataobj)
        {
            Driver.SwitchToFrame(_driverClassCodesFrame, "Table frame");
            _extendedPage.VerifyTableColumnDoesNotContainValue(_driverClassCodesTable, "Code", dataobj.Code);
            Settings.Logger.Info(" Verify Deleted Driver Class Code Successfully");
        }
    }


}   
