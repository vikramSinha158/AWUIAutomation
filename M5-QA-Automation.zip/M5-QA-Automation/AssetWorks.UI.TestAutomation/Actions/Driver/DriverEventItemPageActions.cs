﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Driver;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Driver
{
    internal class DriverEventItemPageActions : DriverEventItemPage
    {
        public DriverEventItemPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Driver Event Item
        /// </summary>
        /// <param name=""></param>
        public void CreateDriverEventItem(DriverEventItem DataObject)
        {
            _extendedPage.SwitchToContentFrame();
            _eventClassTxtBox.SetText(DataObject.Class, "Event Class");
            Driver.WaitForReady();
            _eventTypeTxtBox.SetText(DataObject.Type, "Event Type");
            Driver.SwitchToFrame(_tableFrame, "Table frame");
            Driver.WaitForReady();
            if (_tableEventItem(DataObject.EventItem).Count > 0)
            {
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventItemTable, _headerEventItem, DataObject.EventItem, "EVENT_ITEM").Click();
                _extendedPage.DeleteAndSave();
                Driver.SwitchToFrame(_tableFrame, "Table frame");
            }
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventItemTable, _headerEventItem, "", "EVENT_ITEM").SetText(DataObject.EventItem, "Driver item");
            Driver.WaitForReady();
            if (DataObject.Disabled)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventItemTable, _headerEventItem, DataObject.EventItem, "DISABLED_FL").SelectCheckBox("Disabled");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Created Driver Event Item
        /// </summary>
        /// <param name=""></param>
        public void VerifyDriverEventItem(DriverEventItem DataObject)
        {
            _extendedPage.SwitchToContentFrame();
            _eventClassTxtBox.SetText(DataObject.Class, "Event Class");
            Driver.WaitForReady();
            _eventTypeTxtBox.SetText(DataObject.Type, "Event Type");
            Driver.SwitchToFrame(_tableFrame, "Table frame");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventItemTable, _headerEventItem, DataObject.EventItem, "EVENT_ITEM"), "Event Code", DataObject.EventItem, false, "value");
            _disabledCheckBox = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventItemTable, _headerEventItem, DataObject.EventItem, "DISABLED_FL");
            CommonUtil.VerifyCheckboxState(_disabledCheckBox, "Check box", DataObject.Disabled);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Driver Event Item
        /// </summary>
        /// <param name=""></param>
        public void UpdateDriverEventItem(DriverEventItem DataObject)
        {
            _extendedPage.SwitchToContentFrame();
            _eventClassTxtBox.SetText(DataObject.Class, "Event Class");
            Driver.WaitForReady();
            _eventTypeTxtBox.SetText(DataObject.Type, "Event Type");
            Driver.SwitchToFrame(_tableFrame, "Table frame");
            Driver.WaitForReady();
            if (DataObject.Disabled)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventItemTable, _headerEventItem, DataObject.EventItem, "DISABLED_FL").SelectCheckBox("Disabled");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Delete Driver Event Item
        /// </summary>
        /// <param name=""></param>
        public void VerifyDeleteDriverEventItem(DriverEventItem DataObject)
        {
            _extendedPage.SwitchToContentFrame();
            _eventClassTxtBox.SetText(DataObject.Class, "Event Class");
            Driver.WaitForReady();
            _eventTypeTxtBox.SetText(DataObject.Type, "Event Type");
            Driver.SwitchToFrame(_tableFrame, "Table frame");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventItemTable, _headerEventItem, DataObject.EventItem, "EVENT_ITEM").Click();
            _extendedPage.DeleteAndSave();
            _eventClassTxtBox.SetText(DataObject.Class, "Event Class");
            Driver.WaitForReady();
            _eventTypeTxtBox.SetText(DataObject.Type, "Event Type");
            Driver.SwitchToFrame(_tableFrame, "Table frame");
            Driver.WaitForReady();
            _extendedPage.VerifyTableColumnDoesNotContainValue(_driverEventItemTable, _headerEventItem, DataObject.EventItem);
            Driver.SwitchTo().DefaultContent();
        }
    }
}
