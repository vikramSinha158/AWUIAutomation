﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Driver;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Driver
{
    internal class DriverLicenseIssuingAuthorityPageActions : DriverLicenseIssuingAuthorityPage
    {
        public DriverLicenseIssuingAuthorityPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// CreateDriver License Issuing Authority
        /// </summary>
        /// <param name=""></param>
        public string CreateDriverLicenseIssuingAuthority(DriverLicenseIssuingAuthorities DataObject) 
        {
            string Code=string.Empty;
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(DataObject.Code, ref Code,"DriverLicenseIssueAuthorityCodeQuery",6))
            {
                Settings.Logger.Info("------ Creating Driver License Issuing Authority Code---------");
                _extendedPage.SwitchToTableFrame(_tableFrame);
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverIssueAuthCodeTable, _headerCode, "", "ISSUE_AUTH").SetText(DataObject.Code, "Status code");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverIssueAuthCodeTable, _headerCode, DataObject.Code, "DESCRIPTION").SetText(DataObject.Description, "StatusDescription");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverIssueAuthCodeTable, _headerCode, DataObject.Code, "DISABLED_FL").SetCheckBox("Disabled", DataObject.Disabled);
                Driver.WaitForReady();
                Driver.SwitchTo().DefaultContent();
                _extendedPage.ClickOnSaveButton();
                Driver.WaitForReady();
            }
            return Code;
        }

        /// <summary>
        /// Verify Driver License Issuing Authority
        /// </summary>
        /// <param name=""></param>
        public void VerifyDriverLicenseIssuingAuthority(DriverLicenseIssuingAuthorities DataObjects)
        {
            Settings.Logger.Info("------ Verify Driver License Issuing Authority Code---------");
            _disabledCheckBox = null;
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverIssueAuthCodeTable, _headerCode, DataObjects.Code, "ISSUE_AUTH"), "Issue Auth Code", DataObjects.Code,false,"value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverIssueAuthCodeTable, _headerCode, DataObjects.Code, "DESCRIPTION"), "DESCRIPTION", DataObjects.Description,false,"value");
            _disabledCheckBox = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverIssueAuthCodeTable, _headerCode, DataObjects.Code, "DISABLED_FL");
            CommonUtil.VerifyCheckboxState(_disabledCheckBox, "Check box", DataObjects.Disabled);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Driver License Issuing Authority
        /// </summary>
        /// <param name=""></param>
        public void UpdateDriverLicenseIssuingAuthority(DriverLicenseIssuingAuthorities DataObject)
        {
            Settings.Logger.Info("------ Update Driver License Issuing Authority Code---------");
            _extendedPage.SwitchToTableFrame(_tableFrame);
            if (DataObject.Description != null)
            {
                if(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverIssueAuthCodeTable, _headerCode, DataObject.Code, "DISABLED_FL").Selected)
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_driverIssueAuthCodeTable, _headerCode, DataObject.Code, "DISABLED_FL").DeSelectCheckBox("Disabled");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverIssueAuthCodeTable, _headerCode, DataObject.Code, "DESCRIPTION").SetText(DataObject.Description, "StatusDescription");
            }
            Driver.WaitForReady();
     
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverIssueAuthCodeTable, _headerCode, DataObject.Code, "DISABLED_FL").SetCheckBox("Disabled",DataObject.Disabled);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        ///<summary>
        ///Delete and Verify Driver License Issuing Authority
        ///</summary>
        ///<param name="DataObject"></param>
        public void VerifyDeletedDriverLicenseIssuingAuthority(DriverLicenseIssuingAuthorities DataObject)
        {
            Settings.Logger.Info("------ Delete Driver License Issuing Authority Code---------");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverIssueAuthCodeTable, _headerCode, DataObject.Code, "ISSUE_AUTH").Click();
            _extendedPage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_driverIssueAuthCodeTable, _headerCode, DataObject.Code);
        }
    }
}
