﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Driver;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Driver
{
    internal class DriverTypesPageActions : DriverTypesPage
    {
        public DriverTypesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Driver Type
        /// </summary>
        /// <param name="DataObject"></param>
        public string CreateDriverType(DriverTypesCode DataObject) 
        {
            _extendedPage.SwitchToTableFrame(_tableFrame);
            if(DataObject.Code == "random")
                DataObject.Code = CommonUtil.GetRandomStringWithSpecialChars(6);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverTypeCodesTable, _headerCode, "", "DRIVER_TYPE").SetText(DataObject.Code, "DriverTypeCode");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverTypeCodesTable, _headerCode, DataObject.Code, "DESCRIPTION").SetText(DataObject.Description, "DriverTypeDescription");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            return DataObject.Code; 
        }

        /// <summary>
        /// Verify Created Driver Type
        /// </summary>
        /// <param name="DataObjects"></param>
        public void VerifyDriverType(DriverTypesCode DataObject)
        {
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            Driver.WaitForReady();
            String DriverCode = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverTypeCodesTable, _headerCode, DataObject.Code, "DRIVER_TYPE").GetAttribute("value");
            CommonUtil.AssertTrue<string>(DriverCode, DataObject.Code);
            if (DataObject.Description != null)
            {
                String Description = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverTypeCodesTable, _headerCode, DataObject.Code, "DESCRIPTION").GetAttribute("value");
                CommonUtil.AssertTrue<string>(Description, DataObject.Description);
            }
            if (DataObject.Disabled)
            {
                _disabledCheckBox = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverTypeCodesTable, _headerCode, DataObject.Code, "DISABLED_FL");
                CommonUtil.VerifyCheckboxState(_disabledCheckBox, "Check box", DataObject.Disabled);
            }
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Driver type
        /// </summary>
        /// <param name="DataObject"></param>
        public void UpdateDriverType(DriverTypesCode DataObject)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            if (DataObject.Disabled)
            {
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverTypeCodesTable, _headerCode, DataObject.Code, "DISABLED_FL").SelectCheckBox("Disabled");
                if (DataObject.Description != null)
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_driverTypeCodesTable, _headerCode, DataObject.Code, "DESCRIPTION").SetText(DataObject.Description, "DriverTypeDescription");
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }

        /// <summary>
        /// Delete Created Driver Type
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyDeletedDriverType(DriverTypesCode DataObject)
        {
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverTypeCodesTable, _headerCode, DataObject.Code, "DRIVER_TYPE").Click();
            _extendedPage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_driverTypeCodesTable, _headerCode, DataObject.Code);
        }
    }
}
