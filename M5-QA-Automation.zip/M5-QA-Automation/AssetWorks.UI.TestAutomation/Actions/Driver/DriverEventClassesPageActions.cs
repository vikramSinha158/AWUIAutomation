﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Driver;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Driver
{
    internal class DriverEventClassesPageActions : DriverEventClassesPage
    {
        public DriverEventClassesPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Driver Event Classes code
        /// </summary>
        /// <param name=""></param>
        public void CreateDriverEventClass(DriverEventClass DataObject) 
        {
            _extendedPage.SwitchToTableFrame(_tableFrame);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventClassTable, _headerClass, "", "EVENT_CLASS").SetText(DataObject.Class, "Status code");
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventClassTable, _headerClass, DataObject.Class, "DESCRIPTION").SetText(DataObject.Description, "StatusDescription");
            Driver.WaitForReady();
            if(DataObject.Disabled)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventClassTable, _headerClass, DataObject.Class, "DISABLED_FL").SelectCheckBox("Disabled");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Created Driver Event Class
        /// </summary>
        /// <param name=""></param>
        public void VerifyDriverEventClass(DriverEventClass DataObjects)
        {
            _disabledCheckBox = null;
            _extendedPage.ClickOnRefreshButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventClassTable, _headerClass, DataObjects.Class, "EVENT_CLASS"), "Event Class", DataObjects.Class,false,"value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventClassTable, _headerClass, DataObjects.Class, "DESCRIPTION"), "DESCRIPTION", DataObjects.Description,false,"value");
            _disabledCheckBox = _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventClassTable, _headerClass, DataObjects.Class, "DISABLED_FL");
            CommonUtil.VerifyCheckboxState(_disabledCheckBox, "Check box", DataObjects.Disabled);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Driver Event Class
        /// </summary>
        /// <param name=""></param>
        public void UpdateDriverEventClass(DriverEventClass DataObject)
        {
            _extendedPage.SwitchToTableFrame(_tableFrame);
            if (DataObject.Description != null)
            {
                if(_extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventClassTable, _headerClass, DataObject.Class, "DISABLED_FL").Selected)
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventClassTable, _headerClass, DataObject.Class, "DISABLED_FL").DeSelectCheckBox("Disabled");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventClassTable, _headerClass, DataObject.Class, "DESCRIPTION").SetText(DataObject.Description, "StatusDescription");
            }
            Driver.WaitForReady();
            if (DataObject.Disabled)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventClassTable, _headerClass, DataObject.Class, "DISABLED_FL").SelectCheckBox("Disabled");
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
        }

        ///<summary>
        ///Delete and Verify Driver Event class
        ///</summary>
        ///<param name="DataObject"></param>
        public void VerifyDeletedDriverEventClass(DriverEventClass DataObject)
        {
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            _extendedPage.GetTableActionElementByRelatedColumnValue(_driverEventClassTable, _headerClass, DataObject.Class, "EVENT_CLASS").Click();
            _extendedPage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_tableFrame);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_driverEventClassTable, _headerClass, DataObject.Class);
        }
    }
}
