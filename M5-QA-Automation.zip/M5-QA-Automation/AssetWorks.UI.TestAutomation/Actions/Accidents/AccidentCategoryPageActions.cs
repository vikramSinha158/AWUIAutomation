using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Accidents;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.DevTools.V85.CSS;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Accidents
{
    internal class AccidentCategoryPageActions : AccidentCategoryPage
    {
        public AccidentCategoryPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Accident Category
        /// </summary>
        /// <param name="accidentCategory"></param>
        /// <returns></returns>
        public string CreateAccidentCategory(AccidentCategory accidentCategory)
        {
            if(accidentCategory.CategoryCode==null)
                accidentCategory.CategoryCode = CommonUtil.GetRandomStringWithSpecialChars(5);
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_accidentCategoryFrame, "Table Frame");
            _categoryCode.SetText(accidentCategory.CategoryCode, "New Accident Category");
            Settings.Logger.Info("Create Accident Category");          _categoryDescription.SetText(accidentCategory.CategoryDescription, "Category Description");           
            _extendedPage.Save();            _categoryDescription.SetText(accidentCategory.CategoryDescription, "Category Description");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            return accidentCategory.CategoryCode;
        }
        /// <summary>
        /// Update Accident Category
        /// </summary>
        /// <param name="accidentCategory"></param>
        public void EditAccidentCategory(AccidentCategory accidentCategory)
        {
            _extendedPage.RefreshAndSwitchToTable(_accidentCategoryFrame, "Table Frame");
            Settings.Logger.Info("Update Accident Category");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_accidentCategoryTable,
                "Code", accidentCategory.CategoryCode, "desc").SetText(accidentCategory.CategoryDescription, "Code Description");
            if (!accidentCategory.CategoryEnable)
                _extendedPage.GetTableActionElementByRelatedColumnValue(
               _accidentCategoryTable, "Code", accidentCategory.CategoryCode, "disabled").DeSelectCheckBox("Disabled");           
                _extendedPage.GetTableActionElementByRelatedColumnValue(
             _accidentCategoryTable, "Code", accidentCategory.CategoryCode, "disabled").SelectCheckBox("Disabled", accidentCategory.CategoryEnable);         
            _extendedPage.Save();
            Settings.Logger.Info("Edited Accident Category");
        }
       /// <summary>
        /// Delete AccidentCategory
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteAccidentCategory(string CodeVal)
        {
           _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_accidentCategoryFrame, "Table frame");
            Settings.Logger.Info("Delete Accident Category: " + CodeVal);
            _extendedPage.GetTableActionElementByRelatedColumnValue(
                _accidentCategoryTable, "Code", CodeVal, "desc").Click();
            _extendedPage.DeleteAndSave();
            Settings.Logger.Info("Delete Accident Category"); 
		}

        /// <summary>
        /// Verify Accident Category after deletion
        /// </summary>
        public void VerifyAfterDeletionAccidentCategory(string CodeVal)
        {
            Driver.SwitchToFrame(_accidentCategoryFrame, "Table frame");
            _extendedPage.VerifyTableColumnDoesNotContainValue(_accidentCategoryTable, "Code", CodeVal);
        }

        /// <summary>
        /// VerifyAccidentCategory
        /// </summary>
        /// <param name="accidentCategory"></param>
        public void VerifyAccidentCategory(AccidentCategory accidentCategory)
        {
            _extendedPage.RefreshAndSwitchToTable(_accidentCategoryFrame, "Table Frame");
            Settings.Logger.Info("Verify Accident Category");
            string categoryCode = _extendedPage.GetTableActionElementByRelatedColumnValue(
                _accidentCategoryTable, "Code", accidentCategory.CategoryCode, "code").GetAttribute("value");
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(
                _accidentCategoryTable, "Code", accidentCategory.CategoryCode, "code"), "Category Description", accidentCategory.CategoryCode, false, "Value");
            CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(
               _accidentCategoryTable, "Code", accidentCategory.CategoryCode, "disabled"), "Category Disabled", accidentCategory.CategoryEnable);
            Driver.SwitchTo().DefaultContent();
        }
    }
}