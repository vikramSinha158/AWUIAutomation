using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Accidents;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Accidents
{
    internal class AccidentsTypePageActions : AccidentsTypePage
    {
        public AccidentsTypePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Accident Type
        /// </summary>
        /// <param name="accidentType"></param>
        public string CreateAccidentType(AccidentType accidentType)
        {
            Settings.Logger.Info("Create Accident Type");
            if (accidentType.ATName.ToLower() == "random")
                accidentType.ATName = CommonUtil.GetRandomStringWithSpecialChars(6);
            _extendedPage.SwitchToTableFrame(_accidenttypeframe);
            _accidenttypeinput.SetText(accidentType.ATName, "Accident Type");
            _accidenttypeDescp.SetText(accidentType.ATDescription, "Description");
            if (accidentType.ATDisabled)
                _checkboxDisabled.SelectCheckBox("Disabled");
            Driver.SwitchTo().DefaultContent();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            if (accidentType.Reauthenticate)
            {
                Driver.WaitForReady();
                _inputPassword.SetText(accidentType.Password, "Password");
                Driver.WaitForReady();
                Driver.ClickOnElement(_btnContinue, "Continue");
                Driver.WaitForSomeTime(10);
            }
            return accidentType.ATName;
        }

        /// <summary>
        /// Verify Accident Type
        /// </summary>
        /// <param name="accidentType"></param>
        public void VerifyAccidentType(AccidentType accidentType)
        {
            Settings.Logger.Info("Verify Accident Type");
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_accidenttypeframe);
            CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_accidenttypetable, "Type",
                accidentType.ATName.ToUpper(), "type_no"), "Type", accidentType.ATName.ToUpper(), false, "value");
            if (accidentType.ATDescription != null)
                CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_accidenttypetable, "Description",
                    accidentType.ATDescription, "desc"), "Description", accidentType.ATDescription, false, "value");
            CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(_accidenttypetable, "Type",
                accidentType.ATName.ToUpper(), "disabled"), "disabled", accidentType.ATDisabled);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Update Accident Type
        /// </summary>
        /// <param name="accidentType"></param>
        public void UpdateAccidentTypes(AccidentType accidentType)
        {
            Settings.Logger.Info("Update Accident Type");
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_accidenttypeframe);
            Driver.WaitForSomeTime();
            if (accidentType.ATDescription != null)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_accidenttypetable, "Type",
                    accidentType.ATName.ToUpper(), "desc", "value").SetText(accidentType.ATDescription, "Descrption");
            if (!accidentType.ATDisabled)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_accidenttypetable, "Type",
                    accidentType.ATName.ToUpper(), "disabled").DeSelectCheckBox("disabled");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_accidenttypetable, "Type",
                accidentType.ATName.ToUpper(), "disabled").SelectCheckBox("disabled", accidentType.ATDisabled);
            _extendedPage.Save();
        }

        /// <summary>
        /// Verify Accident Type Deletion
        /// </summary>
        /// <param name="accidentType"></param>
        public void VerifyAccidentTypeDeletion(AccidentType accidentType)
        {
            Settings.Logger.Info("Verify Accident Type Deletion");
            _extendedPage.ClickOnRefreshButton();
            _extendedPage.SwitchToTableFrame(_accidenttypeframe);
            Driver.WaitForReady();
            _extendedPage.GetTableActionElementByRelatedColumnValue(_accidenttypetable, "Type", 
                accidentType.ATName, "desc", "value").Click();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            Driver.WaitForReady();
            _extendedPage.ClickOnSaveButton();
            if (accidentType.Reauthenticate)
            {
                Driver.WaitForReady();
                _inputPassword.SetText(accidentType.Password, "Password");
                Driver.WaitForReady();
                Driver.ClickOnElement(_btnContinue, "Continue");
                Driver.WaitForSomeTime(10);
            }
            _extendedPage.SwitchToTableFrame(_accidenttypeframe);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_accidenttypetable, "Type", accidentType.ATName);
            Driver.SwitchTo().DefaultContent();
        }
    }
}
