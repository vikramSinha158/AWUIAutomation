﻿using OpenQA.Selenium;
using NUnit.Framework;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class WarrantyClaimManagerPageActions : WarrantyClaimManagerPage
    {
        public WarrantyClaimManagerPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Warranty Claim
        /// </summary>
        /// <param name="warrantyClaim"></param>
        /// <returns></returns>
        public string CreateNewWarrantyClaim(WarrantyClaimObject warrantyClaim)
        {
            Settings.Logger.Info("Create Warranty Claim");
            _extendedPage.SwitchToContentFrame();
            _inputVendorNo.SetText(warrantyClaim.VendorNo, "Vendor No");
            Driver.WaitForReady();
            if (warrantyClaim.IsNewClaim)
                _buttonNewClaimNo.ClickElement("New Claim No", Driver);
            Driver.WaitForReady();
            _inputWorkOrderNo.SetText(warrantyClaim.WorkOrderNo, "Work Order No");
            Driver.WaitForReady();
            _inputProcessEmp.SetText(warrantyClaim.ProcessEmp, "Process Emp");
            Driver.WaitForReady();
            _inputCategory.SetText(warrantyClaim.Category, "Category");
            Driver.WaitForReady();
            if (warrantyClaim.Jobs != null)
            {
                Driver.SwitchToFrame(_frameWarrClaimSummary, "Warranty Claim Summary");
                foreach (Jobs job in warrantyClaim.Jobs)
                {
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableWarrClaimSummary, _chargeType,
                        job.ChargeType, "samount"), "Total Cost", job.TotalCost, false, "value");
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_tableWarrClaimSummary, _chargeType, job.ChargeType,
                        "sclaimedFl").SetCheckBox("Claimed", job.Claimed);
                }
            }
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
            Driver.WaitForReady();
            _extendedPage.SwitchToContentFrame();
            warrantyClaim.ClaimNo = _inputClaimNo.GetElementValueByAttribute("ovalue");
            Assert.IsFalse(string.IsNullOrEmpty(warrantyClaim.ClaimNo), "Claim No is empty");
            Settings.Logger.Info($"Created Warranty Claim {warrantyClaim.ClaimNo}");
            Driver.SwitchTo().DefaultContent();
            return warrantyClaim.ClaimNo;
        }
    }
}
