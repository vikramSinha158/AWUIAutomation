﻿using OpenQA.Selenium;
using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Equipment;


namespace AssetWorks.UI.M5.TestAutomation.Actions.Equipment
{
    internal class EquipmentTypesSKUPageActions : EquipmentTypesSKUPage
    {
        public EquipmentTypesSKUPageActions(IWebDriver Driver) : base(Driver) { }
        public string CreateNewEquipmentType(EquipmentTypeSKU EquipmentTypeObject)
        {
            if (EquipmentTypeObject.EquipmentTypeNo == null)
                EquipmentTypeObject.EquipmentTypeNo = "random";
            string EquipTypeNo = string.Empty;
            if (!_extendedPage.CheckDataExistenceAndGetActionCode(EquipmentTypeObject.EquipmentTypeNo, ref EquipTypeNo, "EquipTypeQuery"))
            {
                Settings.Logger.Info($" Create a new Equipment Type: {EquipTypeNo} ");
                EquipmentTypeObject.EquipmentTypeNo = EquipTypeNo.ToUpper();
                _inputEquipmentType.SetText(EquipmentTypeObject.EquipmentTypeNo, "Equipment Type", Driver, _extendedPage._contentFrame, "content frame");
                if (_extendedPage._createDialog.VerifyElementDisplay(" Action Required Dialog "))
                    _extendedPage.ClickOnDialogBoxButton("Create");
                _inputDescription.SetText(EquipmentTypeObject.Description, "Description", Driver, _extendedPage._contentFrame, "content frame");
                _extendedPage.ClickOnSaveButton();
                if (EquipmentTypeObject.EquipmentTypes != null)
                {
                    _extendedPage.SwitchToContentFrame();
                    _inputDescription.SendKeys(Keys.Tab);
                    Driver.SwitchToFrame(_frameEquipmentTypes, "Table frame");
                    Driver.WaitForReady();
                    _inputNewSKU.SetText(EquipmentTypeObject.EquipmentTypes.SKU, "SKU");
                    Driver.WaitForReady();
                    _inputNewSKUDescription.SetText(EquipmentTypeObject.EquipmentTypes.SKUDesc, "SKU Description");
                    Driver.WaitForReady();
                    if (EquipmentTypeObject.EquipmentTypes.IsSerial)
                        _checkboxNewSKUSerial.Click();
                    if (EquipmentTypeObject.EquipmentTypes.Disabled)
                        _checkboxNewSKUDisabled.Click();
                    Driver.SwitchTo().DefaultContent();
                }
                _extendedPage.VerifyCreatedActionNumber(_inputEquipmentType, EquipmentTypeObject.EquipmentTypeNo);
            }
                return EquipmentTypeObject.EquipmentTypeNo;
        }

        /// <summary>
        /// Edit Equipment Type
        /// </summary>
        /// <param name="EquipmentTypeObject"></param>
        /// <returns></returns>
        public void EditEquipmentType(EquipmentTypeSKU EquipmentTypeObject,string EquipType)
        {
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Update Equipment Type");
            _extendedPage.RefreshAndSetText(_inputEquipmentType, EquipType,"Equipment Type");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameEquipmentTypes, "");
            _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentTypes,
            "SKU", EquipmentTypeObject.EquipmentTypes.SKU, "DISABLED_FL").SelectCheckBox("Disabled Checkbox", EquipmentTypeObject.EquipmentTypes.Disabled);
            if (!EquipmentTypeObject.EquipmentTypes.Disabled)
                _extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentTypes,
             "SKU", EquipmentTypeObject.EquipmentTypes.SKU, "DISABLED_FL").DeSelectCheckBox("Disabled Checkbox");
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnSaveButton();
        }
        /// <summary>
        /// Delete Equipment Type
        /// </summary>
        /// <param name="EquipmentTypeObject"></param>
        /// <param name="EquipType"></param>
        public void DeleteEquipmentType(EquipmentTypeSKU EquipmentTypeObject, string EquipType)
        {
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Deleting Equipment Profile Type : ");
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameEquipmentTypes, "");
            _extendedPage.GetTableActionElementByRelatedColumnValue(
            _tableEquipmentTypes, "SKU", EquipmentTypeObject.EquipmentTypes.SKU, "DISABLED_FL").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendedPage.ClickOnDeleteButton();
            _extendedPage.ClickOnSaveButton();
            
        }

        /// <summary>
        /// Verify Equiment Profile Type Record Deletion
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedEquipmentType(string equipType)
        {
            _extendedPage.RefreshAndSwitchToTable(_frameEquipmentTypes, "Equipment Frame");
            Settings.Logger.Info("Verify Equiment Profile Type is Deleted for : " + equipType);
            _extendedPage.VerifyTableColumnDoesNotContainValue(_tableEquipmentTypes, "SKU", equipType);
            Driver.SwitchTo().DefaultContent();
        }

        public void VerifyEquipmentTypeInfo(EquipmentTypeSKU EquipmentTypeObject)
        {
            Settings.Logger.Info(" Verify Equipment Type ");
            _extendedPage.RefreshAndSetText(_inputEquipmentType, EquipmentTypeObject.EquipmentTypeNo, "Equipment Type");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_inputDescription, "Description", EquipmentTypeObject.Description);          
           if (EquipmentTypeObject.EquipmentTypes != null)
            {
             Driver.SwitchToFrame(_frameEquipmentTypes, "Table frame");
             CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentTypes, "SKU",
             EquipmentTypeObject.EquipmentTypes.SKU, "SKU"), "SKU", EquipmentTypeObject.EquipmentTypes.SKU, false, "value");
             CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentTypes, "SKU",
             EquipmentTypeObject.EquipmentTypes.SKU, "SKU_DESCRIPTION"), "SKU Description", EquipmentTypeObject.EquipmentTypes.SKUDesc, false, "value");
             CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentTypes, "SKU",
             EquipmentTypeObject.EquipmentTypes.SKU, "SERIAL_NUMBER_REQ_FL"), "Serial Checkbox", EquipmentTypeObject.EquipmentTypes.IsSerial);
             CommonUtil.VerifyCheckboxState(_extendedPage.GetTableActionElementByRelatedColumnValue(_tableEquipmentTypes, "SKU",
             EquipmentTypeObject.EquipmentTypes.SKU, "DISABLED_FL"), "Disabled Checkbox", EquipmentTypeObject.EquipmentTypes.Disabled);
            }
            Driver.SwitchTo().DefaultContent();
        }
    }
}
