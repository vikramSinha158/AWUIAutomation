﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Equipment;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class EquipCheckOutPageActions : EquipCheckOutPage
    {
        public EquipCheckOutPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Equipment Check Out
        /// </summary>
        /// <param name="DataObject"></param>
        /// <returns></returns>
        public EquipmentCheckOut EquipmentCheckOut(EquipmentCheckOut DataObject)
        {
            Settings.Logger.Info($" Equipment Check Out ");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _REQUEST_EMP_NO.SetText(DataObject.RequestedBy, "Request Employee No");
            Driver.WaitForReady();
            _REQUEST_ID.SetText(DataObject.RequestID, "Request ID");
            Driver.WaitForReady();
            _TARGET_TYPE_SEL.SelectFilterValueHavingEqualValue(DataObject.CheckOutTo);
            Driver.WaitForReady();
            _TARGET_TYPE.SetText(DataObject.CheckOutToValue, "CheckOutTo");
            Driver.WaitForReady();
            _ISSUING_EMP_ID.SetText(DataObject.IssuedBy, "IssuedBy");
            Driver.WaitForReady();
            _CHECKOUT_EMP_ID.SetText(DataObject.PickedUpBy, "PickedUpBy");
            Driver.WaitForReady();
            _RESPONSIBLE_EMP_ID.SetText(DataObject.ResponsibleParty, "ResponsibleParty");
            Driver.WaitForReady();
            _btnRetrieve.ClickElement("Retrieve", Driver);
            Driver.WaitForReady();
            if (DataObject.EquipmentCheckOutTableData != null)
            {
                Driver.SwitchToFrame(_EquipReqSumFrame, "Equip Req Sum Frame");
                Driver.WaitForReady();
                foreach (EquipmentCheckOutTableData CheckOutData in DataObject.EquipmentCheckOutTableData)
                {
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_EquipReqSumFrameTable, "Request ID", CheckOutData.RequestID, "REQUEST_ID").ClickElement("REQUEST_ID", Driver);
                    Driver.WaitForReady();
                    Driver.SwitchTo().DefaultContent();
                    _extendedPage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_EquipmentCheckOutFrame, "Equip CheckOut Frame");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckOutTable, "Equipment Type", CheckOutData.EquipmentType, "EQUIP_NO").SetText(CheckOutData.EquipmentNo, "EquipmentNo");
                    Driver.WaitForReady();
                    _extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckOutTable, "Equipment Type", CheckOutData.EquipmentType, "EST_RETURN_DT").SetText(CheckOutData.EstReturnDate, "EstReturnDate");
                    CheckOutData.CheckOutDate=_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckOutTable, "Equipment Type", CheckOutData.EquipmentType, "aEST_CHECKOUT_DT").GetAttribute("ovalue");
                    Driver.WaitForReady();
                    _extendedPage.AddNotes(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckOutTable, "Equipment Type", CheckOutData.EquipmentType, "NOTE"), CheckOutData.Notes);
                    _extendedPage.SwitchToContentFrame();
                    Driver.SwitchToFrame(_EquipReqSumFrame, "Equip Req Sum Frame");
                }
            }
            _extendedPage.Save();
            return DataObject;
        }

        /// <summary>
        /// Verify No Record in Equipment Table
        /// </summary>
        public void VerifyNoEquipmentTableRecords()
        {
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_EquipReqSumFrame, "Equip Req Sum Frame");                  
            CommonUtil.AssertTrue<int>(0, _extendedPage.GetTotalTableRecords(_EquipReqSumFrameTable));
            Driver.SwitchTo().DefaultContent();
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_EquipmentCheckOutFrame, "Equip CheckOut Frame");
            Driver.WaitForReady();           
            CommonUtil.VerifyElementValue(_EquipmentNoNew, "", string.Empty);
            Driver.SwitchTo().DefaultContent();
        }
    }
}
