﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System.Collections.Generic;


namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class EquipmentRequestPageActions : EquipmentRequestMainPage
    {
        public EquipmentRequestPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Equipment Request
        /// </summary>
        /// <param name="DataObject"></param>
        /// <returns></returns>
        public EquipmentRequest EquipmentRequest(EquipmentRequest DataObject)
        {
            Settings.Logger.Info($" Equipment Request : {DataObject.To} ");
            _extendPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _newEquipmentRequest.ClickElement("New Equipment Request",Driver);
            Driver.WaitForReady();
            _requestEmpID.SetText(DataObject.RequestEmployee, "Request Employee No");
            Driver.WaitForReady();
            _fromLocation.SetText(DataObject.FromLocation, "From Location");
            Driver.WaitForReady();
            _targetType.SelectFilterValueHavingEqualValue(DataObject.To);
            Driver.WaitForReady();
            _targetTypeValue.SetText(DataObject.TargetType, "Target Type Name");
            Driver.WaitForReady();         
            if (DataObject.EquipmentRequestTable != null )
            {
                DataObject.EquipmentRequestTable= FillEquipmentRequestTable(DataObject.EquipmentRequestTable);
            }          
            Driver.SwitchTo().DefaultContent();
            _extendPage.SaveAndChackWarning();
            _extendPage.SwitchToContentFrame();
            DataObject.ReqNo = _requestID.GetElementValueByAttribute("ovalue");         
            return DataObject;
        }
   
        /// <summary>
        /// Fill Equipment Request Table
        /// </summary>
        /// <param name="Tabledata"></param>
        /// <returns></returns>
        public List<EquipmentRequestTable> FillEquipmentRequestTable(List<EquipmentRequestTable> Tabledata)
        {
            Settings.Logger.Info(" Filling Equipment Request Table ");
            Driver.SwitchToFrame(_frameEquipRequest, "Equipment Request Frame");
            int i=0;
            foreach(EquipmentRequestTable DataObject in Tabledata)
            {
                _extendPage.GetElementForInput($"{EuipType}{New}{i}").SetText(DataObject.EquipmentType, "EquipmentType");
                Driver.WaitForReady();
                _extendPage.GetElementForInput($"{SKU}{New}{i}").SetText(DataObject.SKU, "SKU");
                Driver.WaitForReady();
                _extendPage.GetElementForInput($"{PickUpBy}{New}{i}").SetText(DataObject.PickUpBy, "PickUpBy");
                Driver.WaitForReady();
                IWebElement EstCheckOutEle = _extendPage.GetElementForInput($"{EstCheckOut}{New}{i}");
                DataObject.EstCheckOut = EstCheckOutEle.GetElementValueByAttribute("ovalue");
                EstCheckOutEle.SendKeys(Keys.Tab);
                Driver.WaitForReady();
                _extendPage.GetElementForInput($"{EstReturn}{New}{i}").SetText(DataObject.EstReturn, "EstReturn");
                DataObject.EstReturn = _extendPage.GetElementForInput($"{EstReturn}{New}{i}").GetElementValueByAttribute("ovalue");
                _extendPage.GetElementForInput($"{StatusDate}{New}{i}").ClickElement("StatusDate", Driver);
                DataObject.StatusDate = _extendPage.GetElementForInput($"{StatusDate}{New}{i}").GetElementValueByAttribute("ovalue");
                _extendPage.AddNotes(_extendPage.GetElementForInput($"{Notes}{New}{i}","id","button"), DataObject.Notes);
                i++;
            }
            return Tabledata;
        }

        /// <summary>
        /// Verify Equipment request Data
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyEquipmentRequest(EquipmentRequest DataObject)
        {
            Settings.Logger.Info($" Verifying Equipment Request:{DataObject.ReqNo}");          
            Driver.SwitchTo().DefaultContent();
            _extendPage.RefreshAndSetText(_requestID, DataObject.ReqNo, "Request No ");
            Driver.WaitForReady();
            CommonUtil.VerifyElementValue(_requestID, "Request No", DataObject.ReqNo);
            CommonUtil.VerifyElementValue(_requestEmpID, "Request Employee No", DataObject.RequestEmployee);
            CommonUtil.VerifyElementValue(_requestEmpName, "Request Employee Name", DataObject.RequestEmployeeName);
            CommonUtil.VerifyElementValue(_fromLocation, "From Location", DataObject.FromLocation);
            CommonUtil.VerifyElementValue(_fromLocationName, "From Location Name", DataObject.FromLocDesc);
            CommonUtil.VerifyElementValue(_targetType, "To", DataObject.To,true);
            CommonUtil.VerifyElementValue(_targetTypeValue, "Target Type", DataObject.TargetType);
            CommonUtil.VerifyElementValue(_targetTypeName, "Target Type Name", DataObject.TargetTypeName);
            if (DataObject.EquipmentRequestTable != null)
            {
                VerifyEquipmentRequestTable(DataObject.EquipmentRequestTable);
            }
        }

        /// <summary>
        /// Fill Equipment Request Table
        /// </summary>
        /// <param name="TabledataObj"></param>
        public void VerifyEquipmentRequestTable(List<EquipmentRequestTable> TabledataObj)
        {          
            Driver.SwitchToFrame(_frameEquipRequest, "Service code Frame");          
            foreach (EquipmentRequestTable TableData in TabledataObj)
            {
                CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipRequest, "Equipment Type", TableData.EquipmentType,SKU), "SKU", TableData.SKU, false, "value");
                CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipRequest, "Equipment Type", TableData.EquipmentType, Qty), "Qty", TableData.Qty, false, "value");
                CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipRequest, "Equipment Type", TableData.EquipmentType, PickUpBy), "PickUpBy", TableData.PickUpBy,false, "value");
                CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipRequest, "Equipment Type", TableData.EquipmentType, EstCheckOut), "EstCheckOut", TableData.EstCheckOut, false, "value");
                CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipRequest, "Equipment Type", TableData.EquipmentType, EstReturn), "EstReturn", TableData.EstReturn, false, "value");
                CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipRequest, "Equipment Type", TableData.EquipmentType, Status), "Status", TableData.Status, true);
                CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipRequest, "Equipment Type", TableData.EquipmentType, StatusDate), "StatusDate", TableData.StatusDate, false, "value");
                _extendPage.VerifyAddedNotes(_extendPage.GetTableActionElementByRelatedColumnValue(_tableEquipRequest, "Equipment Type", TableData.EquipmentType, Notes), TableData.Notes);
            }
            Driver.SwitchTo().DefaultContent();           
        }

        /// <summary>
        /// Delete Equipment Request
        /// </summary>
        /// <param name="RequestID"></param>
        public void DeleteEquipmentRequest(string RequestID)
        {
            Settings.Logger.Info($" Deleting Equipment Request:{RequestID}");
            _extendPage.RefreshAndSetText(_requestID, RequestID, "Request No ");
             Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnDeleteButton();
            _extendPage.ActionRequiredWindow("Delete");
            Driver.WaitForReady();
        }

        /// <summary>
        /// Verify Equipment Request Deletion
        /// </summary>
        /// <param name="RequestID"></param>
        public void VerifyEquipmentRequestDeletion(string RequestID)
        {
            Settings.Logger.Info($" Verifying Equipment Request Deletion for:{RequestID}");
            _extendPage.RefreshAndSetText(_requestID, RequestID, "Request No ");
            Driver.WaitForSomeTime();
            IAlert alert = Driver.SwitchTo().Alert();
            string  AlertText = alert.Text;
            CommonUtil.AssertTrue(true, AlertText.Contains($"Value {RequestID} not found on file"));
            alert.Accept(); 
        }

    }
}
