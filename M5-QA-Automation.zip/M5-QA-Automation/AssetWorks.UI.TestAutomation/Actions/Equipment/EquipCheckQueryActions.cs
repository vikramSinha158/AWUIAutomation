﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Equipment;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class EquipCheckQueryActions : EquipCheckQueryPage
    {
        public EquipCheckQueryActions(IWebDriver Driver) : base(Driver) { }

       /// <summary>
       ///Fill Equipment Query Data
       /// </summary>
       /// <param name="DataObject"></param>
        public void FillEquipmentQueryData(QueryData DataObject)
        {
            Settings.Logger.Info($"Fill Equipment Query Data ");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _TARGET_TYPE_SEL.SelectFilterValueHavingEqualValue(DataObject.AssignedTo);
            Driver.WaitForReady();
            _TARGET_TYPE.SetText(DataObject.AssignedToValue, "AssignedTo");
            Driver.WaitForReady();
            _FROM_LOCATION.SetText(DataObject.CheckOutLocation, "CheckOutLocation");
            Driver.WaitForReady();
            _CHECK_STATUS.SelectFilterValueHavingEqualValue(DataObject.Status);
            Driver.WaitForReady();
            _RESPONSIBLE_PARTY.SetText(DataObject.ResponsibleParty, "ResponsibleParty");
            Driver.WaitForReady();
            _CHECKOUT_DATE_FROM.SetText(DataObject.CheckOutFromDate, "CheckOutFromDate");
            Driver.WaitForReady();
            _CHECKOUT_DATE_TO.SetText(DataObject.CheckOutToDate, "CheckOutToDate");
            Driver.WaitForReady();
            _RETURN_DATE_FROM.SetText(DataObject.CheckINFromDate, "CheckINFromDate");
            Driver.WaitForReady();
            _RETURN_DATE_TO.SetText(DataObject.CheckINToDate, "CheckINToDate");
            Driver.WaitForReady();
            _TO_LOCATION.SetText(DataObject.CheckINLocation, "CheckINLocation");
            Driver.WaitForReady();
            _EQUIP_NO.SetText(DataObject.EquipmentNo, "Equipment No.");
            Driver.WaitForReady();
            _EQUIPMENT_TYPE.SetText(DataObject.EquipmentType, "EquipmentType");
            Driver.WaitForReady();
            _SKU.SetText(DataObject.SKU, "SKU");
            Driver.WaitForReady();
            _RETURN_REASON.SetText(DataObject.ReturnTeason, "ReturnTeason");
            Driver.WaitForReady();
            _REQUEST_ID.SetText(DataObject.RequestID, "RequestID");
            Driver.WaitForReady();
            _EMPLOYEE_OWNED_FL.SelectFilterValueHavingEqualValue(DataObject.EmployeeOwned);
            Driver.WaitForReady();
            _btnRetrieve.ClickElement("Retrieve", Driver);
            Driver.WaitForReady();           
        }

        /// <summary>
        /// Verify Retrieved Equipment Check Query Data
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyRetrievedEquipCheckQueryData(List<QueryResult> DataObject)
        {
            Settings.Logger.Info($"Verify Retrieved Equipment Check Query Data");
            if (DataObject != null)
            {
                Driver.SwitchToFrame(_EquipmentCheckQueryFrame, "Equip Check Query Frame");
                Driver.WaitForReady();
                foreach (QueryResult QueryData in DataObject)
                {
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckQueryTable, "Request ID", QueryData.RequestID, "EQUIP_NO"), "EQUIP_NO", QueryData.EquipmentNo, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckQueryTable, "Request ID", QueryData.RequestID, "EQUIPMENT_TYPE"), "EQUIPMENT_TYPE", QueryData.EquipmentType, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckQueryTable, "Request ID", QueryData.RequestID, "SKU"), "SKU", QueryData.SKU, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckQueryTable, "Request ID", QueryData.RequestID, "CHECKOUT_DT"), "CHECKOUT_DT", QueryData.CheckOutDate, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckQueryTable, "Request ID", QueryData.RequestID, "RETURN_DT"), "RETURN_DT", QueryData.CheckINDate, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckQueryTable, "Request ID", QueryData.RequestID, "FROM_LOCATION"), "FROM_LOCATION", QueryData.CheckOutLocation, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckQueryTable, "Request ID", QueryData.RequestID, "CHECKIN_LOCATION"), "CHECKIN_LOCATION", QueryData.CheckINLocation, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckQueryTable, "Request ID", QueryData.RequestID, "OUT_CONDITION"), "OUT_CONDITION", QueryData.OutCondition, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckQueryTable, "Request ID", QueryData.RequestID, "IN_CONDITION"), "IN_CONDITION", QueryData.InCondition, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckQueryTable, "Request ID", QueryData.RequestID, "EQUIPMENT_RETURN_REASON"), "EQUIPMENT_RETURN_REASON", QueryData.ReturnReason, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckQueryTable, "Request ID", QueryData.RequestID, "TO"), "Assigned To", QueryData.AssignedTo, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckQueryTable, "Request ID", QueryData.RequestID, "TO_ID"), "Assigned To Number", QueryData.AssignedToNumber, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckQueryTable, "Request ID", QueryData.RequestID, "RESPEMP"), "Resp. Party", QueryData.ResponsibleParty, false, "value");
                    if (!string.IsNullOrEmpty(QueryData.Notes))
                    {                       
                        _extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckQueryTable, "Request ID", QueryData.RequestID, "NOTE").ClickElement("Notes", Driver);
                        Driver.WaitForReady();
                        Driver.SwitchTo().DefaultContent();                       
                        CommonUtil.AssertTrue<string>(QueryData.Notes, _NoteText.GetAttribute("ovalue"));
                        _btnNotesClose.ClickElement("Notes Close Window", Driver);
                        Driver.WaitForReady();
                        _extendedPage.SwitchToContentFrame();
                        Driver.SwitchToFrame(_EquipmentCheckQueryFrame, "Equip Check Query Frame");
                    }
                }
                Driver.SwitchTo().DefaultContent();
            }
        }

    }
}
