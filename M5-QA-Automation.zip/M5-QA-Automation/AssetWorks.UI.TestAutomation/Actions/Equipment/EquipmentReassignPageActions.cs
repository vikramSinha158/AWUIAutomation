﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Equipment;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using RazorEngine.Compilation.ImpromptuInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Equipment
{
    internal class EquipmentReassignPageActions : EquipmentReassignPage
    {
        public EquipmentReassignPageActions(IWebDriver Driver) : base(Driver) { }
        /// <summary>
        /// Retreive Equioment Reassign
        /// </summary>
        /// <param name="equipmentReassign"></param>
        public void RetreiveEquipmentReassign(EquipmentReassign equipmentReassign)
        {
            Settings.Logger.Info("Retreive Equipment Reassign");
            _extendpage.SwitchToContentFrame();
            _assignedTo.SelectFilterValueHavingEqualValue(equipmentReassign.AssignedTo);
            Driver.WaitForReady();
            _responsibleParty.SetText(equipmentReassign.ResponsibleParty, "Responsible Party");
            Driver.WaitForReady();
            _equipmentNo.SetText(equipmentReassign.EquipmentNo, "Equipment No");
            Driver.WaitForReady();
            _fromLocation.SetText(equipmentReassign.CheckOutLocation, "CheckOut Location");
            Driver.WaitForReady();
            _equipmentType.SetText(equipmentReassign.EquipmentType, "Equipment Type");
            Driver.WaitForReady();
            _checkoutDateFrom.SetText(equipmentReassign.CheckOutDateFrom, "Checkout Date From");
            Driver.WaitForReady();
            _checkoutDateTo.SetText(equipmentReassign.CheckOutDateTo, "Checkout To");
            Driver.WaitForReady();
            _buttonRetreive.Click();
            Driver.WaitForReady();
            Driver.SwitchToFrame(_frameReassign, "Frame Reassign");
            Driver.WaitForReady();
            _reassign.SelectCheckBox("Reassign Checkbox");
            Driver.WaitForReady();
            _reassignTo.SelectFilterValueHavingEqualValue("Employee");
            Driver.WaitForReady();
            _reassignNumber.SetText(equipmentReassign.ReassignedNumber, "Reassigned Number");
            Driver.WaitForReady();
            _extendpage.Save();
            Driver.WaitForReady();
        }
        /// <summary>
        /// Verify Equipment Reassign
        /// </summary>
        /// <param name="equipmentReassign"></param>
        public void VerifyEquipmentReassign(EquipmentReassign equipmentReassign)
        {
            Settings.Logger.Info("Verify Equipment Reassign");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnRefreshButton();
            Driver.WaitForReady();
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _assignedTo.SelectFilterValueHavingEqualValue(equipmentReassign.AssignedTo);
            Driver.WaitForReady();
            _responsibleParty.SetText(equipmentReassign.ResponsibleParty, "Responsible Party");
            Driver.WaitForReady();
            _equipmentNo.SetText(equipmentReassign.EquipmentNo, "Equipment No");
            Driver.WaitForReady();
            _fromLocation.SetText(equipmentReassign.CheckOutLocation, "CheckOut Location");
            Driver.WaitForReady();
            _equipmentType.SetText(equipmentReassign.EquipmentType, "Equipment Type");
            Driver.WaitForReady();
            _checkoutDateFrom.SetText(equipmentReassign.CheckOutDateFrom, "Checkout Date From");
            Driver.WaitForReady();
            _checkoutDateTo.SetText(equipmentReassign.CheckOutDateTo, "Checkout To");
            Driver.WaitForReady();
            _buttonRetreive.Click();
            Driver.WaitForReady();
            Driver.SwitchTo().Frame(_frameReassign);
            IWebElement equipmentType= _extendpage.GetTableActionElementByRelatedColumnValue(_tableEquipmentReassign, "Equip No", equipmentReassign.EquipmentNo, "EQUIPMENT_TYPE");
            CommonUtil.VerifyElementValue(equipmentType, "Equipment Type", equipmentReassign.EquipmentType,false,"value");            
            IWebElement SKU = _extendpage.GetTableActionElementByRelatedColumnValue(_tableEquipmentReassign, "Equip No", equipmentReassign.EquipmentNo, "SKU");
            CommonUtil.VerifyElementValue(SKU, "SKU", equipmentReassign.SKU, false, "value");           
            IWebElement checkedOutTo= _extendpage.GetTableActionElementByRelatedColumnValue(_tableEquipmentReassign, "Equip No", equipmentReassign.EquipmentNo, "Checked_OUT_To");
            CommonUtil.VerifyElementValue(checkedOutTo, "Checked Out To", equipmentReassign.CheckedOutTo, false, "value");
            Driver.WaitForReady();
        }
    }
}
