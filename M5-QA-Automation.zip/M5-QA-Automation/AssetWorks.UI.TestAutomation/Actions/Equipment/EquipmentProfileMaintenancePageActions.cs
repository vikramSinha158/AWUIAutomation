﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Equipment;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.Equipment
{
    internal class EquipmentProfileMaintenancePageActions : EquipmentProfileMaintenancePage
    {
        public EquipmentProfileMaintenancePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create New Equipment Profile
        /// </summary>
        /// <param name="EquipmentProfile"></param>
        /// <param name="EquipmentProfileStatus"></param>
        /// <returns></returns>
        public string CreateNewEquipmentProfile(string? EquipmentProfile = "random", string EquipmentProfileStatus= "Active")
        {
            string EquipmentProfileID=String.Empty;
            Settings.Logger.Info(" Create new Equipmen tProfile");
            if (EquipmentProfile.Equals("random",StringComparison.OrdinalIgnoreCase) || String.IsNullOrEmpty(EquipmentProfile))
                EquipmentProfileID = CommonUtil.GetRandomStringWithSpecialChars(5).ToUpper();
            else
                EquipmentProfileID = EquipmentProfile;
            _extendpage.SwitchToContentFrame();
            _equipProfileInput.SetText(EquipmentProfileID, "Equipment Profile Number");     
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow("Create");
            _extendpage.SwitchToContentFrame();
            Driver.WaitForReady();
            _equipProfileDescDetail=_extendpage.EnterDescription(_equipProfileDescInput);
            Driver.WaitForReady();
            _selectEquipProfileStatus.SelectFilterValueHavingEqualValue(EquipmentProfileStatus);
            _equipmentProfileStatus = EquipmentProfileStatus;
            Driver.SwitchTo().DefaultContent();
            _extendpage.VerifyCreatedActionNumber(_equipProfileInput, EquipmentProfileID);
            return EquipmentProfileID;
        }

        /// <summary>
        /// Verify Equipment  Profile
        /// </summary>
        /// <param name="EquipmentProfileID"></param>
        public void VerifyEquipmentProfile(string EquipmentProfileID)
        {            
            _extendpage.RefreshAndSetText(_equipProfileInput, EquipmentProfileID, "Equipment Profile ");
            CommonUtil.VerifyElementValue(_equipProfileInput, "Equipment Profile ID", EquipmentProfileID);
            CommonUtil.VerifyElementValue(_equipProfileDescInput, "Equip Profile Desc Input", _equipProfileDescDetail);
            CommonUtil.VerifyElementValue(_selectEquipProfileStatus, "Equip Profile Status", _equipmentProfileStatus, true);
            Settings.Logger.Info(" Successfully Verified Equipment Profile Maintenance");
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Move Primary Equipment Profile Codes
        /// </summary>
        /// <param name="AssetCode"></param>
        public void MovePrimaryEquipmentProfileCodes(EquipmentProfileeData DataObject,string AssetCode)
        {
            _pAssetCodeList.Clear();
            _pAssetCodeList.Add(AssetCode);
            MoveEquipmentProfileCodeList(_epPriClassFrame, _pAssetClassListLeft, _pAssetClassMoveRight, _pAssetCodeList);
            MoveCategoryEquipmentProfileCodeList(_pApCategoryFrame, _pCategoryListLeft, _pCategoryMoveRight, DataObject.PrimaryEquipmentProfile.PrimaryCategoryCodes[0]);
            _extendpage.ClicKSave();        
            Settings.Logger.Info(" Moved Primary Equipment Profile Codes for ACC and Category ");
        }

        /// <summary>
        /// Verify Primary Equipment Profile Code sTransfer
        /// </summary>
        /// <param name="EquipmentProfileID"></param>
        /// <param name="AssetCode"></param>
        public void VerifyPrimaryEquipmentProfileCodesTransfer(string EquipmentProfileID,string AssetCode, EquipmentProfileeData DataObject)
        {
            _extendpage.RefreshAndSetText(_equipProfileInput, EquipmentProfileID, "Equipment Profile ");
            VerifyEquipmentProfileCodeListTRansfer(_epPriClassFrame,_pAssetClassListRight, AssetCode);
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_pApCategoryFrame, "Code List Frame");
            Driver.ScrollInView(_pCategoryMoveRight);
            CommonUtil.AssertTrue<bool>(true, _pCategoryListRight.ClickDropDownValuebyContainingText(DataObject.PrimaryEquipmentProfile.PrimaryCategoryCodes[0]));
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Successfully Verified Equipment Profile Transfer for Asset Code Class and Category Code ");
        }

        /// <summary>
        /// Reset Primary Equipment Profile Codes
        /// </summary>
        /// <param name="EquipmentProfileID"></param>
        public void ResetPrimaryEquipmentProfileCodes(string EquipmentProfileID, EquipmentProfileeData DataObject)
        {
            _extendpage.RefreshAndSetText(_equipProfileInput, EquipmentProfileID, "Equipment Profile ");
            Driver.SwitchTo().DefaultContent();
            MoveEquipmentProfileCodeList(_epPriClassFrame, _pAssetClassListRight, _pAssetClassMoveLeft, _pAssetCodeList);
            MoveCategoryEquipmentProfileCodeList(_pApCategoryFrame, _pCategoryListRight, _pCategoryMoveLeft, DataObject.PrimaryEquipmentProfile.PrimaryCategoryCodes[0]);
            _extendpage.ClicKSave();
            _extendpage.ClickRefresh();
            Settings.Logger.Info(" Reset Primary Equipment Profile Codes ACC and Category Code");
        }

        /// <summary>
        /// Move Equipment Profile Code List
        /// </summary>
        /// <param name="Frame"></param>
        /// <param name="CodeListElement"></param>
        /// <param name="MoveListElement"></param>
        /// <param name="EquipmentProfileCodeList"></param>
        public void MoveEquipmentProfileCodeList(IWebElement Frame,IWebElement CodeListElement, IWebElement MoveListElement, List<string> EquipmentProfileCodeList)
        {
           _extendpage.SwitchToContentFrame();         
            Driver.SwitchToFrame(Frame, "Code List Frame");
            Driver.WaitForReady();
            _extendpage.SelectMultipleItemFromList(CodeListElement, MoveListElement, EquipmentProfileCodeList);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Verify Equipment Profile Code List TRansfer
        /// </summary>
        /// <param name="Frame"></param>
        /// <param name="EquipmentProfileID"></param>
        /// <param name="CodeListElement"></param>
        /// <param name="CheckCodeName"></param>
        public void VerifyEquipmentProfileCodeListTRansfer(IWebElement Frame,IWebElement CodeListElement, string CheckCodeName)
        {
            Driver.SwitchToFrame(Frame, "Code List Frame");
           CodeListElement.ClickElement("List", Driver);
            CommonUtil.AssertTrue<bool>(true, CodeListElement.ClickDropDownValuebyContainingText(CheckCodeName));
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Move Category Equipment Profile Code List
        /// </summary>
        /// <param name="Frame"></param>
        /// <param name="CodeListElement"></param>
        /// <param name="MoveListElement"></param>
        /// <param name="EquipmentCategoryCode"></param>
        public void MoveCategoryEquipmentProfileCodeList(IWebElement Frame, IWebElement CodeListElement, IWebElement MoveListElement, string  EquipmentCategoryCode)
        {
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(Frame, "Code List Frame");
            Driver.ScrollInView(MoveListElement);
            _extendpage.SelectOneItemFromList(CodeListElement, MoveListElement, EquipmentCategoryCode);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Move Secondary Equipment Profile Codes
        /// </summary>
        /// <param name="DataObject"></param>
        /// <param name="AssetCode"></param>
        public void MoveSecondaryEquipmentProfileCodes(EquipmentProfileeData DataObject, string AssetCode)
        {
            _sAssetCodeList.Clear();
            _sAssetCodeList.Add(AssetCode);
            MoveToSecondaryTab();
            MoveEquipmentProfileCodeList(_epSecClassFrame, _sAssetClassListLeft, _sAsetClassMoveRight, _sAssetCodeList);
            MoveCategoryEquipmentProfileCodeList(_epSecCategoryFrame, _sCategoryListLeft, _sCategoryMoveRight, DataObject.SecondaryEquipmentProfile.SecondaryCategoryCodes[0]);
            _extendpage.ClicKSave();
            Settings.Logger.Info(" Moved Secondary Equipment Profile Codes for ACC and Category ");
        }

        /// <summary>
        /// Verify Secondary Equipment Profile Codes Transfer
        /// </summary>
        /// <param name="EquipmentProfileID"></param>
        /// <param name="AssetCode"></param>
        /// <param name="DataObject"></param>
        public void VerifySecondaryEquipmentProfileCodesTransfer(string EquipmentProfileID, string AssetCode, EquipmentProfileeData DataObject)
        {
            _extendpage.RefreshAndSetText(_equipProfileInput, EquipmentProfileID, "Equipment Profile ");
            _secondaryTab.ClickElement("Secondary", Driver);
            VerifyEquipmentProfileCodeListTRansfer(_epSecClassFrame, _sAssetClassListRight, AssetCode);
            _extendpage.SwitchToContentFrame();
            Driver.SwitchToFrame(_epSecCategoryFrame, "Code List Frame");
            Driver.ScrollInView(_sCategoryMoveRight);
            CommonUtil.AssertTrue<bool>(true, _sCategoryListRight.ClickDropDownValuebyContainingText(DataObject.SecondaryEquipmentProfile.SecondaryCategoryCodes[0]));
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info(" Successfully Verified Equipment Profile Transfer for Asset Code Class and Category Code ");
        }

        /// <summary>
        /// Reset Secondary Equipment Profile Codes
        /// </summary>
        /// <param name="EquipmentProfileID"></param>
        /// <param name="DataObject"></param>
        public void ResetSecondaryEquipmentProfileCodes(string EquipmentProfileID, EquipmentProfileeData DataObject)
        {
            _extendpage.RefreshAndSetText(_equipProfileInput, EquipmentProfileID, "Equipment Profile ");
            _secondaryTab.ClickElement("Secondary", Driver);
            Driver.SwitchTo().DefaultContent();
            MoveEquipmentProfileCodeList(_epSecClassFrame, _sAssetClassListRight, _sAssetClassMoveLeft, _sAssetCodeList);
            MoveCategoryEquipmentProfileCodeList(_epSecCategoryFrame, _sCategoryListRight, _sCategoryMoveLeft, DataObject.SecondaryEquipmentProfile.SecondaryCategoryCodes[0]);
            _extendpage.ClicKSave();
            _extendpage.ClickRefresh();
            Settings.Logger.Info(" Reset Secondary Equipment Profile Codes ACC and Category Code");
        }

        /// <summary>
        /// Move To Secondary Tab
        /// </summary>
        public void MoveToSecondaryTab()
        {
            Driver.PageScrollUp();
            _extendpage.SwitchToContentFrame();
            _secondaryTab.ClickElement("Secondary", Driver);
            Driver.SwitchTo().DefaultContent();
        }

        /// <summary>
        /// Edit Equipment Profile Data
        /// </summary>
        public void EditEquipmentProfileData(EquipmentProfileeData editEquipmentProfileData)
        {
            _extendpage.SwitchToContentFrame();
            Settings.Logger.Info("Edit existing Equipment Profile");           
            _equipProfileInput.SetText(editEquipmentProfileData.EquipmentProfileID, "Equipment Profile Number");
            Driver.WaitForReady();
            _equipProfileDescInput.SetText(editEquipmentProfileData.EquipmentProfileDescription, "Equipment Profile Description");
            Driver.WaitForReady();
            _selectEquipProfileStatus.SelectFilterValueHavingEqualValue(editEquipmentProfileData.EquipmentProfileStatus);
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();         
            _extendpage.ClickOnSaveButton();
            _equipmentProfileStatus = editEquipmentProfileData.EquipmentProfileStatus;
        }       
        // Delete Equipment profile
        public void DeleteEquipmentProfile(string EquipmentId)
        {
            _extendpage.RefreshAndSetText(_equipProfileInput, EquipmentId, "EquipmentId");
            Driver.SwitchTo().DefaultContent();
            _extendpage.ClickOnDeleteButton();
            Driver.SwitchTo().DefaultContent();
            _extendpage.ActionRequiredWindow("Delete");
            _extendpage.ClickOnSaveButton();
            Driver.SwitchTo().DefaultContent();
        }
        
        //Verify Equipment Deleted
        public void VerifyDeletedEquipmentProfile(string EquipmentId)
        {
            _extendpage.RefreshAndSetText(_equipProfileInput,EquipmentId, "EquipmentId");
            Driver.SwitchTo().DefaultContent();
            CommonUtil.AssertTrue(true, _createButton.VerifyElementDisplay("Create Dialog"));
        }
    }
}
