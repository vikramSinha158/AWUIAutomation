﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.Equipment;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class EquipCheckINPageActions : EquipCheckINPage
    {
        public EquipCheckINPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Equipment Check IN
        /// </summary>
        /// <param name="DataObject"></param>
        /// <returns></returns>
        public void RetrieveCheckINData(EquipmentCheckIN DataObject)
        {
            Settings.Logger.Info($"Retrieve Equipment Check IN ");
            _extendedPage.SwitchToContentFrame();
            Driver.WaitForReady();
            _RETURN_EMP_ID.SetText(DataObject.CheckINEmployee, "Return Employee No");
            Driver.WaitForReady();
            _TARGET_TYPE_SEL.SelectFilterValueHavingEqualValue(DataObject.CheckOutTo);
            Driver.WaitForReady();
            _TARGET_TYPE.SetText(DataObject.CheckOutToValue, "CheckOutTo");
            Driver.WaitForReady();
            _RESPONSIBLE_PARTY.SetText(DataObject.ResponsibleParty, "ResponsibleParty");
            Driver.WaitForReady();
            _DATE_FROM.SetText(DataObject.CheckOutFromDate, "CheckOutFromDate");
            Driver.WaitForReady();
            _DATE_TO.SetText(DataObject.CheckOutToDate, "CheckOutToDate");
            Driver.WaitForReady();
            _EQUIPMENT_TYPE.SetText(DataObject.EquipmentType, "CheckOutToDate");
            Driver.WaitForReady();
            _EQUIPMENT_NUM.SetText(DataObject.EquipmentNo, "EquipmentNo");
            Driver.WaitForReady();
            _btnRetrieve.ClickElement("Retrieve", Driver);
            Driver.WaitForReady();           
        }

        /// <summary>
        /// Verify Retrieved CheckIN Table Data
        /// </summary>
        /// <param name="DataObject"></param>
        public void VerifyRetrievedCheckINTableData(List<EquipmentCheckINTableData> DataObject)
        {
            Settings.Logger.Info($"Verify Retrieved Equipment Check IN Data");
            if (DataObject != null)
            {
                Driver.SwitchToFrame(_EquipmentCheckInFrame, "Equip Check IN Frame");
                Driver.WaitForReady();
                foreach (EquipmentCheckINTableData CheckINData in DataObject)
                {
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckInTable, "Equip No", CheckINData.EquipmentNo, "EQUIPMENT_TYPE"), "EQUIPMENT_TYPE", CheckINData.EquipmentType, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckInTable, "Equip No", CheckINData.EquipmentNo, "SKU"), "SKU", CheckINData.SKU, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckInTable, "Equip No", CheckINData.EquipmentNo, "EQUIPMENT_RETURN_REASON"), "EQUIPMENT_RETURN_REASON", CheckINData.ReturnReason, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckInTable, "Equip No", CheckINData.EquipmentNo, "From_Location"), "From_Location", CheckINData.CheckedOutLocation, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckInTable, "Equip No", CheckINData.EquipmentNo, "Checked_Out_TO"), "Checked_Out_TO", CheckINData.CheckedOutTo, false, "value");
                    CommonUtil.VerifyElementValue(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckInTable, "Equip No", CheckINData.EquipmentNo, "CheckedOut_TO_Number"), "CheckedOut_TO_Number", CheckINData.CheckedOutToNumber, false, "value");
                }
            }
        }

        /// <summary>
        /// Check-IN Equipment
        /// </summary>
        /// <param name="DataObject"></param>
        /// <returns></returns>
        public EquipmentCheckIN CheckINEquipment(EquipmentCheckIN DataObject)
        {
            Settings.Logger.Info($"Check IN Equipment Data");
            foreach (EquipmentCheckINTableData CheckINData in DataObject.EquipmentCheckINTableData)
            {
                _extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckInTable, "Equip No", CheckINData.EquipmentNo, "IN_CONDITION").SetText(CheckINData.Condition, "Condition");
                Driver.WaitForReady();
                _extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckInTable, "Equip No", CheckINData.EquipmentNo, "IN_BIN").SetText(CheckINData.BIN, "BIN");
                Driver.WaitForReady();
                _extendedPage.AddNotes(_extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckInTable, "Equip No", CheckINData.EquipmentNo, "NOTE"), CheckINData.Notes);
                Driver.WaitForReady();
                _extendedPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_EquipmentCheckInFrame, "Equip Check IN Frame");
                Driver.WaitForReady();
                CheckINData.CheckInDate = _extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckInTable, "Equip No", CheckINData.EquipmentNo, "RETURN_DT").GetAttribute("value");
                _extendedPage.GetTableActionElementByRelatedColumnValue(_EquipmentCheckInTable, "Equip No", CheckINData.EquipmentNo, "CHECK_IN").SelectCheckBox("CHECK_IN");
            }
            _extendedPage.Save();
            return DataObject;
        }

        /// <summary>
        /// Verify Equipment Table Has No Record
        /// </summary>
        public void VerifyNoEquipmentCheckINTableRecord()
        {
            _extendedPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_EquipmentCheckInFrame, "Equip Req Sum Frame");
            CommonUtil.AssertTrue<int>(0, _extendedPage.GetTotalTableRecords(_EquipmentCheckInTable));
            Driver.SwitchTo().DefaultContent();
        }
    }
}
