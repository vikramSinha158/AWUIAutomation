﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions
{
    internal class VisionRatingPageActions : VisionRatingPage
    {
        public VisionRatingPageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create Vision Ratings
        /// </summary>
        /// <param name="VisionRatingDetail"></param>
        /// <returns></returns>
        public string CreateVisionRatings(VisionRatingDetail VisionRatingDetail)
        {
            string VisionRatingValue = string.Empty;
            _extendpage.SwitchToContentFrame();
            if (!_extendpage.CheckDataExistenceAndGetActionCode(VisionRatingDetail.VisionRating, ref VisionRatingValue, "VisionRatingQuery"))
            {
                VisionRatingDetail.VisionRating = VisionRatingValue;
                Driver.SwitchToFrame(_visionRateFrame, "Vision Rating");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_visionRateTable, "Vision Rating", "", "starRate").SetText(VisionRatingDetail.VisionRating, "Vision Rating");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_visionRateTable, "Vision Rating", VisionRatingDetail.VisionRating, "desc").SetText(VisionRatingDetail.VisionRatingDesc, "VisionRating Description");
                Driver.WaitForReady();
                _extendpage.Save();
                Settings.Logger.Info($" Successfully Creatted Vision Rating {VisionRatingDetail.VisionRating} ");
            }           
            return VisionRatingDetail.VisionRating;
        }
    }
}
