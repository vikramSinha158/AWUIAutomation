﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.DAFCode;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.DAFCode
{
    internal class DAFCodeMaintenancePageActions : DAFCodeMaintenancePage
    {
        public DAFCodeMaintenancePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create DAF Code Maintenance
        /// </summary>
        /// <param name="DAFCodeMaintenanceDetail"></param>
        /// <returns></returns>
        public string CreateDAFCodeMaintenance(DAFCodeMaintenance DAFCodeMaintenanceDetail)
        {           
            _extendpage.SwitchToContentFrame();
            string DAFCode = string.Empty;
            Driver.SwitchToFrame(_dAFDefFrame, "DAFDefFrame");
            if (!_extendpage.CheckDataExistenceAndGetActionCode(DAFCodeMaintenanceDetail.DAFCodeMaintenanceCodes, ref DAFCode, "DAFCodeMaintenanceQuery", 5))
            {
                DAFCodeMaintenanceDetail.DAFCodeMaintenanceCodes = DAFCode;
                _extendpage.GetTableActionElementByRelatedColumnValue(_dAFDefTable, "Code", "", "code").SetText(DAFCodeMaintenanceDetail.DAFCodeMaintenanceCodes, "DAFCodeMaintenanceCodes");
                Driver.WaitForReady();
                _extendpage.GetTableActionElementByRelatedColumnValue(_dAFDefTable, "Code", DAFCodeMaintenanceDetail.DAFCodeMaintenanceCodes, "desc").SetText(DAFCodeMaintenanceDetail.DAFCodeMaintenanceDesc, "DAFCodeMaintenanceDesc");
                Driver.WaitForReady();
                _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_dAFDefTable, "Code", DAFCodeMaintenanceDetail.DAFCodeMaintenanceCodes, "disabled"), "DAFCodeMaintenanceFlag", DAFCodeMaintenanceDetail.DAFCodeMaintenanceFlag);
                _extendpage.Save();
                Driver.WaitForSomeTime();
            }
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Created DAF Code Maintenance for : " + DAFCodeMaintenanceDetail.DAFCodeMaintenanceCodes);
            return DAFCodeMaintenanceDetail.DAFCodeMaintenanceCodes;
        }

        /// <summary>
        /// Verify DAF Code Maintenance
        /// </summary>
        /// <param name="DAFCodeMaintenanceDetail"></param>
        public void VerifyDAFCodeMaintenance(DAFCodeMaintenance DAFCodeMaintenanceDetail)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_dAFDefFrame, "Table frame");
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_dAFDefTable, "Code", DAFCodeMaintenanceDetail.DAFCodeMaintenanceCodes, "code"), "DAFCodeMaintenanceCodes", DAFCodeMaintenanceDetail.DAFCodeMaintenanceCodes, false, "value");
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_dAFDefTable, "Code", DAFCodeMaintenanceDetail.DAFCodeMaintenanceCodes, "desc"), "DAFCodeMaintenanceDesc", DAFCodeMaintenanceDetail.DAFCodeMaintenanceDesc, false, "value");
            CommonUtil.VerifyCheckboxState(_extendpage.GetTableActionElementByRelatedColumnValue(_dAFDefTable, "Code", DAFCodeMaintenanceDetail.DAFCodeMaintenanceCodes, "disabled"), "SmoothShift", DAFCodeMaintenanceDetail.DAFCodeMaintenanceFlag);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("verified DAF Code Maintenance for : " + DAFCodeMaintenanceDetail.DAFCodeMaintenanceCodes);
        }

        /// <summary>
        /// Update Zone Class Codes
        /// </summary>
        /// <param name="DAFCodeMaintenanceDetail"></param>
        public void UpdateDAFCodeMaintenance(DAFCodeMaintenance DAFCodeMaintenanceDetail)
        {
            _extendpage.RefreshAndSwitchToTable(_dAFDefFrame, "Table frame");
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_dAFDefTable, "Code", DAFCodeMaintenanceDetail.DAFCodeMaintenanceCodes, "desc").SetText(DAFCodeMaintenanceDetail.DAFCodeMaintenanceDesc, "DAFCodeMaintenanceDesc");
            Driver.WaitForReady();
            _extendpage.SetCheckBox(_extendpage.GetTableActionElementByRelatedColumnValue(_dAFDefTable, "Code", DAFCodeMaintenanceDetail.DAFCodeMaintenanceCodes, "disabled"), "DAFCodeMaintenanceFlag", DAFCodeMaintenanceDetail.DAFCodeMaintenanceFlag);
            _extendpage.Save();
            Driver.WaitForReady();
            Settings.Logger.Info(" Updated DAF Code Maintenance");
        }

        /// <summary>
        /// Delete DAF Code Maintenance
        /// </summary>
        /// <param name="CodeVal"></param>
        public void DeleteDAFCodeMaintenance(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_dAFDefFrame, "Table frame");
            _extendpage.GetTableActionElementByRelatedColumnValue(_dAFDefTable, "Code", CodeVal, "code").Click();
            Driver.WaitForReady();
            _extendpage.DeleteAndSave();
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Deleted DAF Code Maintenance : " + CodeVal);
        }

        /// <summary>
        /// Verify Deleted DAF Code Maintenance 
        /// </summary>
        /// <param name="CodeVal"></param>
        public void VerifyDeletedDAFCodeMaintenance(string CodeVal)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSwitchToTable(_dAFDefFrame, "Table frame");
            _extendpage.VerifyTableColumnDoesNotContainValue(_dAFDefTable, "Code", CodeVal);
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("Verified DAF Code Maintenance  Deletetion : " + CodeVal);
        }
    }
}
