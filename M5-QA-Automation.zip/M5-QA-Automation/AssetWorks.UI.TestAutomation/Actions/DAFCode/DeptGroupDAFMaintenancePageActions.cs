﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject.DAFCode;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.Actions.DAFCode
{
    internal class DeptGroupDAFMaintenancePageActions : DeptGroupDAFMaintenancePage
    {
        public DeptGroupDAFMaintenancePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Verify Disabled DAF Code Options
        /// </summary>
        /// <param name="DeptGroupDAFMaintenance"></param>
        public void VerifyDAFCodeOptions(DeptGroupDAFMaintenance DeptGroupDAFMaintenance)
        {
            _extendpage.SwitchToContentFrame();
            _deptGroup.SetText(DeptGroupDAFMaintenance.DepartmentGroup, "DepartmentGroup");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_deptGroupDAFFrame, "deptGroupDAFFrame");
            CommonUtil.AssertTrue<bool>(DeptGroupDAFMaintenance.OwningDeptAccessFlag, _extendpage.IsElementDisable(_extendpage.GetTableActionElementByRelatedColumnValue(_deptGroupDAFTable, "DAF Name", DeptGroupDAFMaintenance.DAFName, "owning_access"), "owning access"));
            CommonUtil.AssertTrue<bool>(DeptGroupDAFMaintenance.UsingDeptAccessFlag, _extendpage.IsElementDisable(_extendpage.GetTableActionElementByRelatedColumnValue(_deptGroupDAFTable, "DAF Name", DeptGroupDAFMaintenance.DAFName, "using_access"), "using access"));
            Settings.Logger.Info("verified Disabled DAF Code Options Dept for : " + DeptGroupDAFMaintenance.DAFName);
        }

        /// <summary>
        /// Updateb Dept Group DAF Maintenance
        /// </summary>
        /// <param name="DeptGroupDAFMaintenance"></param>
        public void UpdateDeptGroupDAFMaintenance(DeptGroupDAFMaintenance DeptGroupDAFMaintenance)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_deptGroup, DeptGroupDAFMaintenance.DepartmentGroup, "DepartmentGroup");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_deptGroupDAFFrame, "deptGroupDAFFrame");
            _extendpage.GetTableActionElementByRelatedColumnValue(_deptGroupDAFTable, "DAF Name", DeptGroupDAFMaintenance.DAFName, "owning_access").SelectFilterValueHavingEqualValue(DeptGroupDAFMaintenance.OwningDeptAccess);
            Driver.WaitForReady();
            _extendpage.GetTableActionElementByRelatedColumnValue(_deptGroupDAFTable, "DAF Name", DeptGroupDAFMaintenance.DAFName, "using_access").SelectFilterValueHavingEqualValue(DeptGroupDAFMaintenance.UsingDeptAccess);
            _extendpage.Save();
            Settings.Logger.Info("Updated Dept Group DAF Maintenance : " + DeptGroupDAFMaintenance.DAFName);
        }

        /// <summary>
        /// Verify Dept Group DAF Maintenance
        /// </summary>
        /// <param name="DeptGroupDAFMaintenance"></param>
        public void VerifyDeptGroupDAFMaintenance(DeptGroupDAFMaintenance DeptGroupDAFMaintenance)
        {
            Driver.SwitchTo().DefaultContent();
            _extendpage.RefreshAndSetText(_deptGroup, DeptGroupDAFMaintenance.DepartmentGroup, "DepartmentGroup");
            Driver.WaitForReady();
            Driver.SwitchToFrame(_deptGroupDAFFrame, "deptGroupDAFFrame");
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_deptGroupDAFTable, "DAF Name", DeptGroupDAFMaintenance.DAFName, "owning_access"), "OwningDeptAccess", DeptGroupDAFMaintenance.OwningDeptAccess, true, "value");
            CommonUtil.VerifyElementValue(_extendpage.GetTableActionElementByRelatedColumnValue(_deptGroupDAFTable, "DAF Name", DeptGroupDAFMaintenance.DAFName, "using_access"), "OwningDeptAccess", DeptGroupDAFMaintenance.UsingDeptAccess, true, "value");
            Driver.SwitchTo().DefaultContent();
            Settings.Logger.Info("verified Dept Group DAF Maintenance : " + DeptGroupDAFMaintenance.DAFName);
        }
    }
}
