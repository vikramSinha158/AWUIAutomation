﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.PagesObject;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using System;


namespace AssetWorks.UI.M5.TestAutomation.Actions
    {
        internal class TaxTypePageActions : TaxTypeMainPage
        {
        public TaxTypePageActions(IWebDriver Driver) : base(Driver) { }

        /// <summary>
        /// Create New Tax Type Record
        /// </summary>
        /// <param name="Data"></param>       
        public CreateTaxType CreateTaxType(CreateTaxType Data)
        {
            string Description = string.Empty;
            if (!_extendPage.CheckDataExistenceAndGetActionCode(Data.Description, ref Description, "TaxTypeQuery",12))
            {
                _extendPage.SwitchToContentFrame();
                Driver.SwitchToFrame(_frameTaxType, "Table frame");
                Settings.Logger.Info("Creating Tax Type");
                if (string.IsNullOrEmpty(Data.Class))
                {
                    Data.Class = CommonUtil.GetRandomStringWithSpecialChars(8);
                }
                _inputNewTaxDesc.SetText(Description, "New Tax Descrption");
                _inputNewTaxClass.SetText(Data.Class, "New Tax Class");
                _ckbNewTaxDisabled.SelectCheckBox("Disabled", Data.Disabled);

                Driver.SwitchTo().DefaultContent();
                _extendPage.ClicKSave();
            }
            return Data;
        }

        /// <summary>
        /// Verify the Tax Type Record Data
        /// </summary>
        /// <param name="Data"></param>
        /// <param name="Taxclass"></param>
        public void VerifyTaxRecord(CreateTaxType Data)
        {           
            RefreshAndSwitchToTable();        
            CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_tableTaxType, "Description", Data.Description, "desc"),
                "Description",Data.Description,false,"value");
            CommonUtil.VerifyElementValue(_extendPage.GetTableActionElementByRelatedColumnValue(_tableTaxType, "Description", Data.Description, "taxClass"),
                "Description", Data.Class, false, "value");
            CommonUtil.VerifyCheckboxState(_extendPage.GetTableActionElementByRelatedColumnValue(_tableTaxType, "Description", Data.Description, "disabled"), 
                "disabledCheckBox", Data.Disabled);
        }

        /// <summary>
        /// Edit Tax Type Record
        /// </summary>
        /// <param name="Data"></param>
        /// <param name="ClassVal"></param>
        public void EditTaxRecord(CreateTaxType Data)
        {
            Driver.SwitchTo().DefaultContent();
            RefreshAndSwitchToTable();
            Settings.Logger.Info("Update Tax Type Record for : " + Data.Description);
            _extendPage.GetTableActionElementByRelatedColumnValue(_tableTaxType,
                "Description", Data.Description, "taxClass").SetText(Data.Class, "Tax Class");
            _extendPage.SetCheckBox(_extendPage.GetTableActionElementByRelatedColumnValue(_tableTaxType,
              "Description", Data.Description, "disabled"), "DisabledCheckBox", Data.Disabled);
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnSaveButton();
           
        }

        /// <summary>
        /// Delete Tax Type Record
        /// </summary>
        /// <param name="ClassVal"></param>
        public void DeleteTaxType(string ClassVal)
        {
            Driver.SwitchTo().DefaultContent();
            RefreshAndSwitchToTable();           
            Settings.Logger.Info("Deleting Equipment Profile Type : " + ClassVal);
            _extendPage.GetTableActionElementByRelatedColumnValue(
           _tableTaxType, "Description", ClassVal, "desc").Click();
            Driver.WaitForReady();
            Driver.SwitchTo().DefaultContent();
            _extendPage.ClickOnDeleteButton();
            _extendPage.ClickOnSaveButton();
        }


        /// <summary>
        /// Verify Equiment Tax Type Record Deletion
        /// </summary>
        /// <param name="ClassVal"></param>
        public void VerifyDeletedTaxType(string ClassVal)
        {
            RefreshAndSwitchToTable();
            Settings.Logger.Info("Verify Tax Type is Deleted for : " + ClassVal);
            _extendPage.VerifyTableColumnDoesNotContainValue(_tableTaxType, "Description", ClassVal);
            Driver.SwitchTo().DefaultContent();
        }
        /// <summary>
        /// Refresh And Switch To Table Frame
        /// </summary>
        public void RefreshAndSwitchToTable()
        {
            _extendPage.ClickOnRefreshButton();
            _extendPage.SwitchToContentFrame();
            Driver.SwitchToFrame(_frameTaxType, "Table frame");
        }
    }
    }   
