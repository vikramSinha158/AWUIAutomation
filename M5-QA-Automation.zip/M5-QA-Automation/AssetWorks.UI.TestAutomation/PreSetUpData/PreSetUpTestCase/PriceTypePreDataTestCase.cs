﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class PriceTypePreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/PriceTypesPreTestData.json", "PriceTypesTestData", true,
            TestName = "QA1476_CreatePriceTypes", Description = "M5-Create Price Type as a pre-setup data"), Order(1)]
        public void QA1476_CreatePriceTypes(object[] testParameter)
        {
            Settings.Logger.Info("Step 1 - Navigate To Price Types Page");
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPriceTypesPage();
            List<PriceTypesObjects> priceTypes = CommonUtil.DataObjectForKey("CreatePriceTypes").ToObject<List<PriceTypesObjects>>();
            foreach (PriceTypesObjects priceType in priceTypes)
            {
                List<string> codeList = priceType.CodeList;
                foreach (string code in codeList)
                {
                    priceType.Code = code;
                    Settings.Logger.Info($"Step - Creating Price Type code - {code}");
                    CurrentPage.As<PriceTypesPageActions>().CreateNewPriceType(priceType);
                }
            }
        }
    }
}
