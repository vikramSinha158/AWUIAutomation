﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Driver;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System.Collections.Generic;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.Booking.CustomerMainObjects;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class DriverAllocationReasonsPreDataTestCase : Hooks
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [TestCase("PreSetUpTestData/DriverAllocationReasonsPreTestData.json", "Driver", true, Description = "M5- Create Driver Allocation Reasons Pre Test Data ")]
        public void QA1556_DriverAllocationReasonsPreDataTestCase(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDriverAllocationReasonsScreen();
            List<AllocationReasonsType> DriverObject = CommonUtil.DataObjectForKey("CreateAllocationReasons").ToObject<List<AllocationReasonsType>>();
            if (DriverObject != null)
            {
                foreach (AllocationReasonsType DriverDetail in DriverObject)
                {
                    int i = 0;                
                    List<string> CodeList = DriverDetail.CodeList;
                    foreach (string CodeID in CodeList)
                    {
                        DriverDetail.Code = CodeID;
                        DriverDetail.Description = DriverDetail.DescriptionList[i];
                        CurrentPage.As<DriverAllocationReasonsPageActions>().CreateDriverAllocationReasonCode(DriverDetail);
                        _extendpage.ClickOnRefreshButton();
                        i++;
                    }
                }
            }
            else 
            {
                Assert.Fail("Driver Allocation Reasons Pre-Data Not found");
            }
        }
    }
}
