﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class TaxTypePreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/TaxTypePreTestData.json", "CreateTaxType", true, Description = "M5-Verifying Create Tax Type ")]
        public void QA1509_CreateTaxType(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToTaxTypePage();
            List<CreateTaxType> TaxTypeObject = CommonUtil.DataObjectForKey("AddTaxTypeRecord").ToObject<List<CreateTaxType>>();
            if (TaxTypeObject != null)
            {
                foreach (CreateTaxType TaxDetail in TaxTypeObject)
                {
                    int i = 0;
                    List<string> TClassList = TaxDetail.ClassList;
                    List<string> TDesList = TaxDetail.DescriptionList;
                    foreach (string TDesCode in TDesList)
                    {
                        TaxDetail.Description = TDesCode;
                        TaxDetail.Class = TClassList[i];
                        CurrentPage.As<TaxTypePageActions>().CreateTaxType(TaxDetail);
                        _extendedpage.ClickOnRefreshButton();
                        i++;
                    }
                }
            }
            else
            {
                Assert.Fail("Tax Type Data Not found");
            }
        }
    }
}
