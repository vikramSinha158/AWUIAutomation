﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.BookingTypeCodes;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class BookingTypePreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/BookingCodePreTestData.json", "BookingTypeCodePreData", true, Description = "M5- Create Booking Type Code Pre Data")]
        public void QA1464_BookingTypeCodePreData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBookingTypeCodesPage();
            List<BookingCodeDetails> BookingTypecodeObject = CommonUtil.DataObjectForKey("BookingTypeCode").ToObject<List<BookingCodeDetails>>();
            if (BookingTypecodeObject != null)
            {
                foreach (BookingCodeDetails BookingCodeDetail in BookingTypecodeObject)
                {
                    List<string> BookingCodes = BookingCodeDetail.BookingTypeList;
                    foreach (string BookingCode in BookingCodes)
                    {
                        BookingCodeDetail.BookingType = BookingCode;
                        Settings.Logger.Info($" Check and Create Pre SetUo Data for BookingTypeCode { BookingCode } ");
                        CurrentPage.As<BookingTypeCodesPageActions>().CreateBookingTypeCode(BookingCodeDetail);
                        Driver.SwitchTo().DefaultContent();
                        _extendedpage.ClickOnRefreshButton();
                    }
                }
            }
            else
            {
                Assert.Fail("BookingTypeCode Data Not found");
            }
        }
    }
}
