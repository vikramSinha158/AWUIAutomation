﻿using AssetWorks.UI.Core.Extensions;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class VisionRatingPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/VisionRatingPreTestData.json", "VisionRatingPreData", true, Description = "M5- Create VisionRating Pre Data")]
        public void QA1463_VisionRatingPreData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToVisionRating();
            List<VisionRatingDetail> VisionRatingObject = CommonUtil.DataObjectForKey("VisionRatingCode").ToObject<List<VisionRatingDetail>>();
            if (VisionRatingObject != null)
            {
                foreach (VisionRatingDetail VisionRatingDetail in VisionRatingObject)
                {
                    List<string> VisionRatingCodes = VisionRatingDetail.VisionRatingList;
                    foreach (string VisionRatingCode in VisionRatingCodes)
                    {
                        VisionRatingDetail.VisionRating = VisionRatingCode;
                        Settings.Logger.Info($" Check and Create Pre SetUo Data for Vision Rating { VisionRatingCode } ");
                        CurrentPage.As<VisionRatingPageActions>().CreateVisionRatings(VisionRatingDetail);
                        Driver.SwitchTo().DefaultContent();
                        _extendedpage.ClickOnRefreshButton();
                        Driver.WaitForReady();
                    }
                }
            }
            else
            {
                Assert.Fail("Vision Rating Data Not found");
            }
        }

    }
}
