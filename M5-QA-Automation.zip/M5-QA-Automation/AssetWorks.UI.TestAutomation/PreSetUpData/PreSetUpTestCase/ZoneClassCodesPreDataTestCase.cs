﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Zone;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class ZoneClassCodesPreDataTestCase :Hooks
    {
        [TestCase("PreSetUpTestData/ZoneClassCodesPreTestData.json", "ZoneClassCodes", true, TestName = "CreatePreDataZoneClassCodes", Description = "M5-Create Pre Data Zone Class Codes ")]
        public void CreatePreDataZoneClassCodes(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToZoneClassCodes();
            List<ZoneClassCode> ZoneClassCodeObject = CommonUtil.DataObjectForKey("ZoneClassCodesPreData").ToObject<List<ZoneClassCode>>();
            if (ZoneClassCodeObject != null)
            {
                foreach (ZoneClassCode ZoneClassCodeDetail in ZoneClassCodeObject)
                {
                    List<string> ZoneClassList = ZoneClassCodeDetail.ZoneClassCodesList;
                    foreach (string ZoneCode in ZoneClassList)
                    {
                        ZoneClassCodeDetail.ZoneClassCodes = ZoneCode;
                        CurrentPage.As<ZoneClassCodesPageActions>().CreateZoneClassCodes(ZoneClassCodeDetail);
                        Settings.Logger.Info($" Created Pre setup data for  Zone Class Codes {ZoneCode}");
                        _extendedpage.ClickOnRefreshButton();
                    }
                }
            }
            else
            {
                Assert.Fail("Zone Code  Data Not found");
            }
        }

        [TestCase("PreSetUpTestData/ZoneClassCodesPreTestData.json", "ZoneChargeCodes", true, TestName = "CreatePreDataZoneChargeCodes", Description = "M5-Create Pre Data Zone Class Codes ")]
        public void CreatePreDataZoneChargeCodes(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToZoneChargeCodes();
            List<ZoneChargeCodes> ZoneChargeCodesObject = CommonUtil.DataObjectForKey("ZoneChargeCodesPreData").ToObject<List<ZoneChargeCodes>>();
            if (ZoneChargeCodesObject != null)
            {
                foreach (ZoneChargeCodes ZoneChargeCodesDetail in ZoneChargeCodesObject)
                {
                    List<string> ZoneChargeList = ZoneChargeCodesDetail.ZoneChargeCodeList;
                    foreach (string ZoneCharge in ZoneChargeList)
                    {
                        ZoneChargeCodesDetail.ZoneChargeCode = ZoneCharge;
                        CurrentPage.As<ZoneChargeCodesPagecsActions>().CreateZeoneChargeCodes(ZoneChargeCodesDetail);
                        Settings.Logger.Info($" Created Pre setup data for  Zone Charge Codes {ZoneCharge}");
                        Driver.SwitchTo().DefaultContent();
                        _extendedpage.ClickOnRefreshButton();
                    }
                }
            }
            else
            {
                Assert.Fail("Zone Charge Codes Data Not found");
            }
        }

        [TestCase("PreSetUpTestData/ZoneClassCodesPreTestData.json", "ZonePreData", true, TestName = "CreateZonePreData", Description = "M5-Create Pre Data Zone ")]
        public void CreateZonePreData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToZone();
            List<Zones> ZoneObject = CommonUtil.DataObjectForKey("Zone").ToObject<List<Zones>>();
            if (ZoneObject != null)
            {
                foreach (Zones ZonesDetail in ZoneObject)
                {
                    List<string> ZoneList = ZonesDetail.ZoneCodeList;
                    foreach (string Zone in ZoneList)
                    {
                        ZonesDetail.ZoneCode = Zone;
                        CurrentPage.As<ZonePageActions>().CreateZone(ZonesDetail);
                        Settings.Logger.Info($" Created Pre setup data for  Zone codes {Zone}");
                        Driver.SwitchTo().DefaultContent();
                        _extendedpage.ClickOnRefreshButton();
                    }
                }
            }
            else
            {
                Assert.Fail("Zone Codes Data Not found");
            }
        }
    }
}
