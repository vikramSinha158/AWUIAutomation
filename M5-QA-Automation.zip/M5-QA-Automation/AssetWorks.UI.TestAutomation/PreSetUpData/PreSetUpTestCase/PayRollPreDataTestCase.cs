﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.PayRoll;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System.Collections.Generic;


namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class PayRollPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/PayRollPreTestData.json", "PayRollClassesSteps", true, Description = "M5- Create PayRoll Classes And Steps Pre Data")]
        public void QA1470_CreatePayRollClassStep_PreSetUpData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPayRollClassesAndSteps();
            List<PayrollPayClassesAndSteps> payRollObject = CommonUtil.DataObjectForKey("CreatePayRollClassesSteps").ToObject<List<PayrollPayClassesAndSteps>>();
            if (payRollObject != null)
            {
                foreach (PayrollPayClassesAndSteps payroll in payRollObject)
                {
                    int i = 0;
                    List<string> PayRollClasses = payroll.PayClassList;
                    foreach (string PayRollClass in PayRollClasses)
                    {
                        payroll.PayClass = payroll.PayClassList[i];
                        payroll.PayStep = payroll.PayStepList[i];
                        payroll.Description = payroll.DescriptionList[i];                        
                        Settings.Logger.Info($" Check and Create Pre SetUp Data for PayrollClass: { payroll.PayClass } and PayStep:{ payroll.PayStep} ");
                        CurrentPage.As<PayRollClassStepsPageActions>().CreatePayRollClassesSteps(payroll);
                        i++;
                    }
                }
            }
            else
            {
                Assert.Fail("BookingTypeCode Data Not found");
            }
        }

        [TestCase("PreSetUpTestData/PayRollPreTestData.json", "PayrollTimeTypeMatrix", true, 
            TestName = "QA938_CreatePayrollTimeTypeMatrix", Description = "M5- Create Payroll Time Type Matrix Pre Data")]
        public void QA938_CreatePayrollTimeTypeMatrix(object[] testParameter)
        {
            List<TimeTypes> timeTypes = CommonUtil.DataObjectForKey("TimeTypes").ToObject<List<TimeTypes>>();
            List<TimeTypeMatrix> timeTypeMatrix = CommonUtil.DataObjectForKey("TimeTypeMatrix").ToObject<List<TimeTypeMatrix>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPayrollTimeTypesPage();
            foreach (TimeTypes type in timeTypes)
            {
                CurrentPage.As<PayrollTimeTypesPageActions>().CreatePayrollTimeType(type);
            }
            CurrentPage = _pageNavigate.NavigateToPayrollTimeTypeMatrixPage();
            foreach (TimeTypeMatrix matrix in timeTypeMatrix)
            {
                CurrentPage.As<PayrollTimeTypeMatrixPageActions>().CreatePayrollTimeTypeMatrix(matrix);
            }
        }
    }
}
