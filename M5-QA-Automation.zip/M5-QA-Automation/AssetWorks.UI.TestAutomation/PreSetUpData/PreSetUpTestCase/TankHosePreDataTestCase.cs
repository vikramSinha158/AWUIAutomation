﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class TankHosePreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/ProductTankHosePreTestData.json", "ProdutSetUpTankHosePreData", true, Description = "M5-Verifying Create Billing Code ")]
        public void QA1471_TankHosePreDataTestCase(object[] testParameter)
        {      
            List<ProductSetUpTankHoseObjects> DataObject = CommonUtil.DataObjectForKey("QA1471_CreateProductSetUpTanksHosesPreData").ToObject<List<ProductSetUpTankHoseObjects>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToProductSetupTanksHosePage();
            if (DataObject != null)
            {
                foreach (ProductSetUpTankHoseObjects TankHoseData in DataObject)
                {
                    List<string> LocList = TankHoseData.ProductSetUpTankHose.FuelLocationList;                  
                    foreach (string FuelLoc in LocList)
                    {
                        TankHoseData.ProductSetUpTankHose.FuelLocation = FuelLoc;
                        CurrentPage.As<ProductSetupTanksHosePageActions>().CreateProductTankHose(TankHoseData,true);
                        Driver.SwitchTo().DefaultContent();
                        _extendedpage.ClickOnRefreshButton();
                    }
                }
            }
            else
            {
                Assert.Fail("Product Tank Hose Pre-Data Not found");
            }
        }

    }
}
