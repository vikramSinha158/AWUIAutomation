﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class ProductTankPreDataTestCase : Hooks
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [TestCase("PreSetUpTestData/ProductTankPreTestData.json", "ProductTankPreSetUp", true, Description = "M5-Create Part PreSetUpData ")]
        public void QA1444_CreateProductTankPreSetUpData(object[] testParameter)
        {
            ProductTank DataObject = CommonUtil.DataObjectForKey("ProductTank").ToObject<ProductTank>();
            Settings.Logger.Info(" Step 1 : Navigate To Product SetUp Tank Page ");
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToProductSetupTanksPage();
            Settings.Logger.Info($" Step 2 : Create Product Tank for Fuel Location{DataObject.FuelLocation} ");
            CurrentPage.As<ProductSetupTanksPageActions>().CreateProductTank(DataObject,true);           
        }

        [TestCase("PreSetUpTestData/ProductTankPreTestData.json", "ProductSetupTankTypes", true ,TestName = "CreatePreSetUPProductSetupTankTypes", Description = "M5-Create Pre Set UP Product Setup Tank Types "), Author("Vikram")]
        public void CreatePreSetUPProductSetupTankTypes(object[] testParameter)
        {
            CurrentPage = _pageNavigate.NavigateToProductSetupTankTypes();
            List<ProductSetupTankTypes> ProductSetupTankTypesObject = CommonUtil.DataObjectForKey("CreatePreSetUPProductSetupTankTypes").ToObject<List<ProductSetupTankTypes>>();
            if (ProductSetupTankTypesObject != null)
            {
                foreach (ProductSetupTankTypes ProductSetupTankTypes in ProductSetupTankTypesObject)
                {
                    List<string> ProductSetupTankList = ProductSetupTankTypes.TankTypeList;
                    foreach (string TankType in ProductSetupTankList)
                    {
                        ProductSetupTankTypes.TankType = TankType;
                        CurrentPage.As<ProductSetupTankTypesPageActions>().CreateProductSetupTankTypes(ProductSetupTankTypes);
                        _extendedpage.ClickOnRefreshButton();
                    }
                }
            }
            else
            {
                Assert.Fail("Product Setup Tank Types Data Not found");
            }
        }

    }
}
