﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Dispoal;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class DisposalReasonPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/DisposalReasonPreTestData.json", "DisposalReasonPreData", true, Description = "M5- Create Booking Type Code Pre Data")]
        public void QA1465_CreateDiposalReasonPreData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDisposalReasonPage();
            List<DisposalReasonCodeObjects> DisposalReasonObject = CommonUtil.DataObjectForKey("QA1465_CreateDisposalReason").ToObject<List<DisposalReasonCodeObjects>>();
            if (DisposalReasonObject != null)
            {
                foreach (DisposalReasonCodeObjects DisposalReason in DisposalReasonObject)
                {
                    int i = 0;
                    List<string> DisposalReasonsList = DisposalReason.ReasonList;
                    foreach (string Reason in DisposalReasonsList)
                    {
                        DisposalReason.Reason = Reason;
                        DisposalReason.Description= DisposalReason.DescriptionList[i];
                        Settings.Logger.Info($" Check and Create Pre SetUp Data for DisposalReason { Reason } ");
                        CurrentPage.As<DisposalReasonPageActions>().CreateDisposalReason(DisposalReason);
                        Driver.SwitchTo().DefaultContent();
                        _extendedpage.ClickOnRefreshButton();
                        i++;
                    }
                }
            }
            else
            {
                Assert.Fail("Disposal Reason PreSetUp- Data Not found");
            }
        }
    }
}
