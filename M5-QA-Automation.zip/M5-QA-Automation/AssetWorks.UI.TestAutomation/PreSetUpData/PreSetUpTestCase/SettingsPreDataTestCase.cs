﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class SettingsPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/AvailabilityStatusCodesPreTestData.json", "QA1492_AvailabilityStatusCodes", true,
            TestName = "QA1492_CreateAvailabilityStatusCodes", Description = " M5-Availability Status Codes As a Pre-setup "), Order(1)]
        public void QA1492_CreateAvailabilityStatusCodes(object[] testParameter)
        {
            Settings.Logger.Info(" Step 1 -Navigate To Availability Status Codes ");
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToAvailabilityStatusCodes();
            List<AvailabilityStatusCode> StatusCodesObject = CommonUtil.DataObjectForKey("StatusCodes").ToObject<List<AvailabilityStatusCode>>();
            if (StatusCodesObject != null)
            {
                foreach (AvailabilityStatusCode StatusCode in StatusCodesObject)
                {
                    CurrentPage.As<AvailabilityStatusCodesPageActions>().CreateAvailabilityStatusCode(StatusCode);
                }
            }
            else
            {
                Assert.Fail("Availability Status Codes Not found");
            }
        }
    }
}
