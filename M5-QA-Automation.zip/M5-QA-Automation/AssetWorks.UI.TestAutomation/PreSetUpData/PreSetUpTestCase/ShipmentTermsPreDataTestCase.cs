﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Booking;
using AssetWorks.UI.M5.TestAutomation.Actions.ShipmentTerm;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System.Collections.Generic;

using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.BookingSourceCodeObjects;


namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class ShipmentTermsPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/ShipmentTermsPreTestData.json", "ShipmentTermCodePreData", true, Description = "M5- Create ShipmentCde Pre Data",TestName = "QA1381_ShipmentTermCodePreData"),Author("Varsha")]
        public void QA1381_ShipmentTermCodePreData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToShipmentTermPage();
            List<ShipmentTermsDetails> ShiptermObj = CommonUtil.DataObjectForKey("ShipmentTermCode").ToObject<List<ShipmentTermsDetails>>();
            if (ShiptermObj != null)
            {               
                foreach (ShipmentTermsDetails ShipmentTerm in ShiptermObj)
                {
                    List<string> ShiptermCodes = ShipmentTerm.CodeList;
                    int i = 0;
                    foreach (string ShiptermCode in ShiptermCodes)
                    {                      
                        ShipmentTerm.Code = ShiptermCode;
                        if (ShipmentTerm.DescriptionList[i] != null)
                        {
                            ShipmentTerm.Description = ShipmentTerm.DescriptionList[i];
                        }                        
                        Settings.Logger.Info($" Check and Create Pre SetUp Data for ShipmentTerms { ShipmentTerm.Code } ");
                        CurrentPage.As<ShipmentTermsPageActions>().CreateShipmentTermCode(ShipmentTerm); 
                        Driver.SwitchTo().DefaultContent();
                        _extendedpage.ClickOnRefreshButton();  
                        i++;
                    }
                }
            }
            else
            {
                Assert.Fail("Shipterms Data Not found");
            }
        }
    }
}
