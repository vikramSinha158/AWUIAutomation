﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Booking;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using NUnit.Framework;
using System.Collections.Generic;

using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.BookingSourceCodeObjects;


namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class BookingSourceCodePreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/BookingSourceCodePreTestData.json", "CreateBookingSourceCodePreData", true, Description = "M5- Create Booking Type Code Pre Data")]
        public void QA1461_BookingSourceCodePreData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToBookingSourceCodesPage();
            List<BookingSourceCode> bookingSourceCode = CommonUtil.DataObjectForKey("QA1461_BookingSourceCode").ToObject<List<BookingSourceCode>>();
            if (bookingSourceCode != null)
            {               
                foreach (BookingSourceCode BookingSourceCode in bookingSourceCode)
                {
                    List<string> BookingSourceCodes = BookingSourceCode.BookingCodeList;
                    foreach (string BookingCode in BookingSourceCodes)
                    {
                        BookingSourceCode.BookingCode = BookingCode;
                        Settings.Logger.Info($" Check and Create Pre SetUp Data for BookingSourceCode { BookingSourceCode.BookingCode } ");
                        CurrentPage.As<BookingSourceCodePageActions>().CreateBookingSourceCode(BookingSourceCode); 
                        Driver.SwitchTo().DefaultContent();
                        _extendedpage.ClickOnRefreshButton();                      
                    }
                }
            }
            else
            {
                Assert.Fail("BookingTypeCode Data Not found");
            }
        }
    }
}
