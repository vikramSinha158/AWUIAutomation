﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.MarkUp;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.Location;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class LocationMainPreDataTestCase : Hooks
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [TestCase("PreSetUpTestData/LocationMainPreTestData.json", "MarkupScheme", true, TestName = "QA2041_CreateMarkupSchemePreData",
            Description = "M5- Create Markup Scheme Pre Setup Test Data "), Order(1)]
        public void QA2041_CreateMarkupSchemePreData(object[] testParameter)
        {
            List<CreateMarkUpScheme> markupScheme = CommonUtil.DataObjectForKey("CreateMarkupScheme").ToObject<List<CreateMarkUpScheme>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToMarkUpScheme();
            if (markupScheme != null)
            {
                foreach (CreateMarkUpScheme scheme in markupScheme)
                {
                    CurrentPage.As<MarkUpSchemePageActions>().CreateMarkupScheme(scheme);
                }
            }
            else
                Assert.Fail("Markup Scheme Pre setup data Not found");
        }


        [TestCase("PreSetUpTestData/LocationMainPreTestData.json", "LocationMain", true, TestName = "QA1218_CreateLocationMainPreData",
            Description = "M5- Create Location Main Pre Test Data "), Order(2)]
        public void QA1218_CreateLocationMainPreData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToLocationMain();
            List<LocationMain> LocationMainObject = CommonUtil.DataObjectForKey("CreateLocationPresetUp").ToObject<List<LocationMain>>();
            if (LocationMainObject != null)
            {
                foreach (LocationMain LocationData in LocationMainObject)
                {
                    int i = 0;
                    foreach (string Location in LocationData.LocationList)
                    {
                        LocationData.Location = Location;
                        LocationData.LocationDesc= LocationData.LocationDescList[i];
                        CurrentPage.As<LocationMainPageActions>().CreateLocation(LocationData);
                        _extendpage.ClickRefresh();
                        i++;
                    }
                }
            }
            else 
            {
                Assert.Fail("Location Main Pre-Data Not found");
            }
        }

        [TestCase("PreSetUpTestData/LocationMainPreTestData.json", "LocationGroups", true,
            TestName = "QA1344_AddLocationsToLocationGroups", Description = "M5-Add locations to Location Groups"), Order(3)]
        public void QA1344_AddLocationsToLocationGroups(object[] testParameter)
        {
            List<LocationGroups> LocGroups = CommonUtil.DataObjectForKey("Locations").ToObject<List<LocationGroups>>();
            Settings.Logger.Info(" Step 1 : Navigate To Location Groups Page ");
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToLocationGroupsPage();
            Settings.Logger.Info(" Step 2 : Assign Locations In Group ");
            foreach(LocationGroups LocGroup in LocGroups)
            {
                CurrentPage.As<LocationGroupsPageActions>().AssignLocationsInGroup(LocGroup);
            }
        }
    }
}
