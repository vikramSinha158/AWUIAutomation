﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Units;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class UnitPreDataTestCase : Hooks
    {

        [TestCase("PreSetUpTestData/UnitPreTestData.json", "CreateUnits", true, 
            TestName = "QA997_CreateUnit", Description = " M5 Create Unit(s) "), Order(1)]
        public void QA997_CreateUnit(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateUnitMainPage();
            List<UnitMain> DataObject = CommonUtil.DataObjectForKey("Units").ToObject<List<UnitMain>>();
            if (DataObject != null)
            {
                foreach (UnitMain unit in DataObject)
                {
                    if (unit.UnitNoList != null)
                    {
                        foreach(string unitNo in unit.UnitNoList)
                        {
                            unit.UnitNo = unitNo;
                            CurrentPage.As<UnitMainPageActions>().CreateUnit(unit);
                            if (unit.OperationalClass != null)
                            {
                                string[] queryparam = { unit.UnitNo, unit.OperationalClass };
                                if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection,
                                    "UnitOperClassQuery", queryparam, Settings.DBType))
                                    CurrentPage.As<UnitMainPageActions>().UpdateOperationalClass(unit.UnitNo, unit.OperationalClass);
                            }
                            if (unit.DeptLocationsTab.MotorPoolClass != null || unit.DeptLocationsTab.MotorPoolLocation != null)
                            {
                                string[] qParam = { unit.UnitNo, unit.DeptLocationsTab.MotorPoolLocation, unit.DeptLocationsTab.MotorPoolClass };
                                if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection,
                                    "UnitMotorPoolQuery", qParam, Settings.DBType))
                                    CurrentPage.As<UnitMainPageActions>().UpdateMotorPoolDetails(unit.UnitNo, unit.DeptLocationsTab.MotorPoolClass, unit.DeptLocationsTab.MotorPoolLocation);
                            }
                        }
                    }
                    else
                    {
                        CurrentPage.As<UnitMainPageActions>().CreateUnit(unit);
                        if (unit.OperationalClass != null)
                        {
                            string[] queryparam = { unit.UnitNo, unit.OperationalClass };
                            if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection,
                                "UnitOperClassQuery", queryparam, Settings.DBType))
                                CurrentPage.As<UnitMainPageActions>().UpdateOperationalClass(unit.UnitNo, unit.OperationalClass);
                        }
                        if (unit.DeptLocationsTab.MotorPoolClass != null || unit.DeptLocationsTab.MotorPoolLocation != null)
                        {
                            string[] qParam = { unit.UnitNo, unit.DeptLocationsTab.MotorPoolLocation, unit.DeptLocationsTab.MotorPoolClass };
                            if (Settings.connection != null && CommonUtil.CheckDataExistWithMultipleParams(Settings.connection,
                                "UnitMotorPoolQuery", qParam, Settings.DBType))
                                CurrentPage.As<UnitMainPageActions>().UpdateMotorPoolDetails(unit.UnitNo, unit.DeptLocationsTab.MotorPoolClass, unit.DeptLocationsTab.MotorPoolLocation);
                        }
                    }
                }
            }
        }

        [TestCase("PreSetUpTestData/UnitPreTestData.json", "CreateUnitRequests", true, 
            TestName = "QA1093_CreateUnitRequest", Description = "M5 Create Unit Request(s) "), Order(1)]
        public void QA1093_CreateUnitRequest(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitRequestPage();
            List<UnitRequest> DataObject = CommonUtil.DataObjectForKey("UnitRequests").ToObject<List<UnitRequest>>();
            if (DataObject != null)
            {
                foreach (UnitRequest unitReq in DataObject)
                {
                    if (unitReq.RequestNoList != null)
                    {
                        List<string> RequestList = unitReq.RequestNoList;
                        foreach (string Request in RequestList)
                        {
                            unitReq.RequestNo = Request;
                            CurrentPage.As<UnitRequestPageActions>().CreateUnitRequest(unitReq);
                            _extendedpage.ClickOnRefreshButton();
                        }
                    }
                    else
                    {
                        CurrentPage.As<UnitRequestPageActions>().CreateUnitRequest(unitReq);
                        _extendedpage.ClickOnRefreshButton();
                    }
                }
            }
            else
                Assert.Fail(" Unit Request Data Not Found ");
        }
        
        [TestCase("PreSetUpTestData/UnitGroupPreTestData.json", "GroupUnitPreData", true,
            TestName = "QA1095_CreateUnitGroup", Description = "M5 Create Group Unit"), Order(2)]
        public void QA1095_CreateUnitGroup(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToUnitGroupPage();
            List<GroupUnit> UnitGroupObject = CommonUtil.DataObjectForKey("GroupUnit").ToObject<List<GroupUnit>>();
            foreach (GroupUnit UnitGroupDetail in UnitGroupObject)
            {
                List<string> UnitGroupNameList = UnitGroupDetail.GroupUnitList;
                foreach (string UnitGroupName in UnitGroupNameList)
                {
                    CurrentPage.As<UnitGroupPageActions>().CreateNewUnitGroup(UnitGroupDetail, UnitGroupName);
                }
            }
        }
    }
}
