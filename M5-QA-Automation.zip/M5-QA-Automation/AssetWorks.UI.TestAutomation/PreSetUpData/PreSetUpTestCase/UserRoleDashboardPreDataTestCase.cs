﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.Dashboard;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class UserRoleDashboardPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/UserRoleDashboardPreTestData.json", "CreateUserRoleDashboard", true,
            TestName = "QA1477_CreateUserRoleForDashboard", Description = "M5-Create UserRole For Dashboard")]
        public void QA1477_CreateUserRoleForDashboard(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEditDashboardPage();
            List<EditDashboardObjects> userRoles = CommonUtil.DataObjectForKey("QA1477UserRole").ToObject<List<EditDashboardObjects>>();
            foreach (EditDashboardObjects userRole in userRoles)
            {
                List<string> userList = userRole.UserRoleList;
                int i = 0;
                foreach (string user in userList)
                {
                    userRole.UserRole = user;
                    userRole.DashboardName= userRole.DashboardNameList[i];
                    CurrentPage.As<EditDashboardPageActions>().CreateUserRoleForDashboards(userRole);
                    Driver.SwitchTo().DefaultContent();
                    _extendedpage.ClickRefresh();                   
                    i++;
                }
                
            }
        }
    }
}
