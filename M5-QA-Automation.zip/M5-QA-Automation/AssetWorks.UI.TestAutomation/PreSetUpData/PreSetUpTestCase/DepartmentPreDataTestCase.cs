﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.Department;
using AssetWorks.UI.M5.TestAutomation.Common;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class DepartmentPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/DepartmentPreTestData.json", "CreateDepartments", true,
            TestName = "QA1094_CreateDepartments", Description = "M5-Department pre setup data Create departments")]
        public void QA1094_CreateDepartments(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDepartmentMainPage();
            List<DepartmentMain> departments = CommonUtil.DataObjectForKey("Departments").ToObject<List<DepartmentMain>>();
            foreach (DepartmentMain department in departments)
            {
                List<string> departmentList = department.DepartmentList;
                foreach (string departmentNo in departmentList)
                {
                    department.DepartmentNo = departmentNo;
                    CurrentPage.As<DepartmentMainPageActions>().CreateNewDepartment(department);
                }
            }
        }

        [TestCase("PreSetUpTestData/DepartmentPreTestData.json", "DepartmentQuoteRulesPreData", true, TestName = "CreatePreSetUpDepartmentQuoteRules", Description = "Update Department Quote Rules"), Author("Vikram")]
        public void CreatePreSetUpDepartmentQuoteRules(object[] testParameter)
        {
            DepartmentQuoteRules DepartmentQuoteRules = CommonUtil.DataObjectForKey("DepartmentQuoteRules").ToObject<DepartmentQuoteRules>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDepartmentQuoteRules();
            Settings.Logger.Info(" Step 1 : Create PreSetup for Department Quote Rules");
            CurrentPage.As<DepartmentQuoteRulesPageActions>().UpdateDepartmentQuoteRules(DepartmentQuoteRules);          
        }
    }
}
