﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class AssetClassPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/AssetClassPreTestData.json", "AssetClassCodesPreSetUpData", true, Description = "M5-Create Asset Class As a pre-setup")]
        public void QA1469_CreateAssetClassPreSetUpData(object[] testParameter)
        {
            List<AssetClassCode> AssetClassObj = CommonUtil.DataObjectForKey("QA1469_CreateACC").ToObject<List<AssetClassCode>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToAssetClassCodesPage();
            if (AssetClassObj != null)
            {
                foreach (AssetClassCode AssetClasses in AssetClassObj)
                {
                    int i = 0;
                    List<string> ClassList = AssetClasses.CodeList;
                    foreach (string AssetClass in ClassList)
                    {
                        AssetClasses.Code = AssetClass;
                        AssetClasses.Desc = AssetClasses.DescList[i];
                        CurrentPage.As<AssetClassCodesPageActions>().CreateAssetClassCode(AssetClasses);
                        i++;
                    }
                }
            }
            else
            {
                Assert.Fail("Asset Class Pre-SetUp Data Not found");
            }
        }

    }
}
