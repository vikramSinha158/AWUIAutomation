﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class TaxSchemePreDataTestCase : Hooks
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [TestCase("PreSetUpTestData/TaxSchemePreTestData.json", "TaxSchemePreData", true, Description = "M5- Create Employee Training Course Pre Test Data ")]
        public void QA1396_TaxSchemePreData(object[] testParameter)
        {            
            List<TaxScheme> TaxSchemeObject = CommonUtil.DataObjectForKey("CreateTaxSchemeList").ToObject<List<TaxScheme>>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToTaxSchemePage();
            if (TaxSchemeObject != null)
            {
                foreach (TaxScheme TaxSchemeData in TaxSchemeObject)
                {                    
                    for (int i = 0; i < TaxSchemeData.CreateTaxScheme.AppliedTo.Count; i++)
                    {
                        TaxSchemeData.CreateTaxScheme.TaxScheme=TaxSchemeData.CreateTaxScheme.TaxSchemeList[i];
                        TaxSchemeData.CreateTaxScheme.TaxSchemeDesc = TaxSchemeData.CreateTaxScheme.TaxSchemeDescList[i];
                        CurrentPage.As<TaxSchemePageActions>().CreateTaxScheme(TaxSchemeData.CreateTaxScheme.AppliedTo[i], TaxSchemeData);
                    }
                }
            }
            else 
            {
                Assert.Fail("Tax Scheme Pre-Data Not found");
            }
        }
    }
}
