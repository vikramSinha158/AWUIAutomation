﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class CategoryPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/CategoryPreTestData.json", "QA1349_CreateCategoryPreSetup", true,
            TestName = "QA1349_CreateCategoryPreSetup", Description = "M5-Create Category to Create Unit Request")]
        public void QA1349_CreateCategoryPreSetup(object[] testParameter)
        {
            List<CategoryMainObjects> categoryList = CommonUtil.DataObjectForKey("CreateCategory").ToObject<List<CategoryMainObjects>>();
            Settings.Logger.Info(" Step 1 : Navigate To Category Main Page ");
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToCategoryMainPage();
            foreach (CategoryMainObjects category in categoryList)
            {
                foreach (string code in category.CategoryCodeList)
                {
                    category.CategoryCode = code;
                    Settings.Logger.Info($" Step : Create Category Main Code - {code}");
                    CurrentPage.As<CategoryMainPageActions>().CreateCategoryCode(category);
                }
            }
        }

    }
}
