﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Parts;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class PartPreDataTestCase : Hooks
    {

        [TestCase("PreSetUpTestData/PartPreTestData.json", "CreatePartPreSetUpData", true,
            TestName = "QA1000_CreatePartPreSetUpData", Description = "M5-Create Part PreSetUpData "), Order(1)]
        public void QA1000_CreatePartPreSetUpData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartMainCatalogPage();
            List<PartsMainCatalog> PartsMainObject = CommonUtil.DataObjectForKey("PartsMainInfo").ToObject<List<PartsMainCatalog>>();
            if (PartsMainObject != null)
            {
                foreach (PartsMainCatalog partsMainInfo in PartsMainObject)
                {
                    if (partsMainInfo.PartNumberList != null)
                    {
                        foreach (string partsNumber in partsMainInfo.PartNumberList)
                        {
                            partsMainInfo.PartNumber = partsNumber;
                            CurrentPage.As<PartMainCatalogPageActions>().CreateNewPart(partsMainInfo);
                            _extendedpage.ClickOnRefreshButton();
                        }
                    }
                }
            }
            else
            {
                Assert.Fail("Parts Main Data Not found");
            }
        }

        [TestCase("PreSetUpTestData/PartPreTestData.json", "CreatePartsInventoryLocation", true, 
            TestName = "QA1392_CreatePartsInventoryLocationPreSetUpData", Description = "M5-Add Part to Part Inventory Location Manager"), Order(2)]
        public void QA1392_CreatePartsInventoryLocationPreSetUpData(object[] testParameter)
        {
            List<PartsInventoryLocationObjects> objPartsInvLoc = CommonUtil.DataObjectForKey("PartsInvLocInfo").ToObject<List<PartsInventoryLocationObjects>>();
            if (objPartsInvLoc != null)
            {
                Settings.Logger.Info(" Step 1 : Navigate To Part Inventory Location Manager Page ");
                CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartInventoryLocationManager();
                foreach (PartsInventoryLocationObjects partInvLoc in objPartsInvLoc)
                {
                    if (partInvLoc.NumberList != null)
                    {
                        foreach (string partNo in partInvLoc.NumberList)
                        {
                            partInvLoc.Number = partNo;
                            Settings.Logger.Info($" Step : Create Part Inventory Location for - {partNo}");
                            CurrentPage.As<PartInventoryLocationPageActions>().CreateNewPartInventoryLocation(partInvLoc);
                        }
                    }
                    else
                        CurrentPage.As<PartInventoryLocationPageActions>().CreateNewPartInventoryLocation(partInvLoc);
                }
            }
            else
            {
                Assert.Fail("Part Inventory Location Data Not found");
            }
        }

        [TestCase("PreSetUpTestData/PartPreTestData.json", "CreatePartsInventoryAdjustment", true, 
            TestName = "QA1448_CreatePartsInventoryAdjustmentPreSetUpData", Description = "M5-Add Part to Part Inventory Adjustment"), Order(3)]
        public void QA1448_CreatePartsInventoryAdjustmentPreSetUpData(object[] testParameter)
        {
            List<PartsAdjustmentObjects> objPartsInvAdj = CommonUtil.DataObjectForKey("InventoryAdjustment").ToObject<List<PartsAdjustmentObjects>>();
            if (objPartsInvAdj != null)
            {
                Settings.Logger.Info(" Step 1 : Navigate To Part Inventory Adjustment Page ");
                CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartAdjustment();
                foreach (PartsAdjustmentObjects partInvAdj in objPartsInvAdj)
                {
                    if (partInvAdj.NumberList != null)
                    {
                        foreach (string partNo in partInvAdj.NumberList)
                        {
                            partInvAdj.Number = partNo;
                            Settings.Logger.Info($" Step : Create Part Inventory Adjustment for - {partNo}");
                            CurrentPage.As<PartsAdjustmentPageActions>().CreateNewPartAdjustment(partInvAdj);
                        }
                    }
                }
            }
            else
            {
                Assert.Fail("Part Inventory Adjustment Data Not found");
            }
        }


        [TestCase("PreSetUpTestData/PartPreTestData.json", "CreatePartClassPreSetUpData", true, 
            TestName = "QA1310_CreatePartClassCodePreSetupData", Description = "M5 - Part Class Code-Create with Pre-Setup Data"), Order(1)]
        public void QA1310_CreatePartClassCodePreSetupData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartClassCodesPage();
            List<PartsClassCodesObjects> partsClassCodesObjects = CommonUtil.DataObjectForKey("PartsClassCodes").ToObject<List<PartsClassCodesObjects>>();
            if (partsClassCodesObjects != null)
            {
                foreach (PartsClassCodesObjects partsClassCodeObject in partsClassCodesObjects)
                {
                    if (partsClassCodeObject.CodeList != null)
                    {
                        foreach (string code in partsClassCodeObject.CodeList)
                        {
                            partsClassCodeObject.Code = code;
                            CurrentPage.As<PartClassCodesPageActions>().CreateNewPartClassCode(partsClassCodeObject);
                            _extendedpage.ClickOnRefreshButton();
                        }
                    }
                }
            }
            else
            {
                Assert.Fail("Parts Class Code Data Not found");
            }
        }

        [TestCase("PreSetUpTestData/PartPreTestData.json", "CreateHazardClass", true, 
            TestName = "QA1455_PreSetupDataCreateHazardClass", Description = "M5-Pre-Setup Data create Hazard Class"), Order(1)]
        public void QA1455_PreSetupDataCreateHazardClass(object[] testParameter)
        {
            List<HazardousMaterialCodeObjects> objHazardClass = CommonUtil.DataObjectForKey("HazardClassCodes").ToObject<List<HazardousMaterialCodeObjects>>();
            if (objHazardClass != null)
            {
                Settings.Logger.Info(" Step 1 : Navigate To Hazardous Material Page ");
                CurrentPage = CurrentPage.As<HomePageActions>().NavigateToHazardousMaterialPage();
                foreach (HazardousMaterialCodeObjects HazardClass in objHazardClass)
                {
                    if (HazardClass.ShipNameList != null)
                    {
                        foreach (string code in HazardClass.ShipNameList)
                        {
                            HazardClass.ShipName = code;
                            Settings.Logger.Info($" Step : Create Hazardous Material Code - {code}");
                            CurrentPage.As<HazardousMaterialPageActions>().CreateHazardousMaterialCode(HazardClass);
                        }
                    }
                }
            }
            else
            {
                Assert.Fail("Hazard Class Data Not found");
            }
        }
		
        [TestCase("PreSetUpTestData/PartPreTestData.json", "CreatePartChargeCode", true,
            TestName = "QA1454_CreatePartChargeCode", Description = "M5-Pre-setup Data for Create Part Charge Code"), Order(1)]
        public void QA1454_CreatePartChargeCode(object[] testParameter)
        {
            List<PartChargeCodeObjects> objPartChargeCode = CommonUtil.DataObjectForKey("PartChargeCodes").ToObject<List<PartChargeCodeObjects>>();
            if (objPartChargeCode != null)
            {
                CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartChargeCodePage();
                foreach (PartChargeCodeObjects partChargeCode in objPartChargeCode)
                {
                    if (partChargeCode.ChargeCodeList != null)
                    {
                        foreach (string code in partChargeCode.ChargeCodeList)
                        {
                            partChargeCode.ChargeCode = code;
                            CurrentPage.As<PartChargeCodePageActions>().CreatePartChargeCode(partChargeCode);
                        }
                    }
                    else
                        CurrentPage.As<PartChargeCodePageActions>().CreatePartChargeCode(partChargeCode);
                }
            }
            else
            {
                Assert.Fail("Part Charge Code Data Not found");
            }
        }

        [TestCase("PreSetUpTestData/PartPreTestData.json", "CreateCostCategoryCode", true,
            TestName = "QA1454_CreateCostCategoryCode", Description = "M5-Pre-setup Data for Create Cost Category Code"), Order(1)]
        public void QA1454_CreateCostCategoryCode(object[] testParameter)
        {
            List<CostCategoryCodeObjects> objCostCategoryCode = CommonUtil.DataObjectForKey("CostCategoryCodes").ToObject<List<CostCategoryCodeObjects>>();
            if (objCostCategoryCode != null)
            {
                CurrentPage = CurrentPage.As<HomePageActions>().NavigateToCostCategoryCodesPage();
                foreach (CostCategoryCodeObjects costCategoryCode in objCostCategoryCode)
                {
                    if (costCategoryCode.CodeList != null)
                    {
                        foreach (string code in costCategoryCode.CodeList)
                        {
                            costCategoryCode.Code = code;
                            CurrentPage.As<CostCategoryCodesPageActions>().CreateCostCategoryCode(costCategoryCode);
                        }
                    }
                    else
                        CurrentPage.As<CostCategoryCodesPageActions>().CreateCostCategoryCode(costCategoryCode);
                }
            }
            else
            {
                Assert.Fail("Cost Category Code Data Not found");
            }
        }


        [TestCase("PreSetUpTestData/PartPreTestData.json", "CreateWarrantyPart", true,
            TestName = "QA1462_CreateWarrantyPartPreSetUpData", Description = "M5-Create Warranty Parts As a pre-setup"), Order(1)]
        public void QA1462_CreateWarrantyPartPreSetUpData(object[] testParameter)
        {
            List<PartsMainCatalog> PartsMainObject = CommonUtil.DataObjectForKey("PartInfo").ToObject<List<PartsMainCatalog>>();
            if (PartsMainObject != null)
            {
                Settings.Logger.Info(" Step 1 : Navigate To Part Main Catalog Page ");
                CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartMainCatalogPage();
                foreach (PartsMainCatalog partsMainInfo in PartsMainObject)
                {
                    if (partsMainInfo.PartNumberList != null)
                    {
                        foreach (string partsNumber in partsMainInfo.PartNumberList)
                        {
                            partsMainInfo.PartNumber = partsNumber;
                            Settings.Logger.Info($" Step : Create Warranty Part {partsNumber}");
                            CurrentPage.As<PartMainCatalogPageActions>().CreateNewWarrantyPart(partsMainInfo);
                        }
                    }
                }
            }
            else
            {
                Assert.Fail("Warranty Parts Data Not found");
            }
        }
    }
}