﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class EmissionsPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/EmissionsRatingPreTestData.json", "EmissionsRatingPreTestData", true, Description = "M5- Create Pre Data Emissions Rating")]
        public void QA1460_EmissionsRating(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmissionsRating();
            List<EmissionsRating> EmissionsRatingObject = CommonUtil.DataObjectForKey("EmissionsRating").ToObject<List<EmissionsRating>>();
            if (EmissionsRatingObject != null)
            {
                foreach (EmissionsRating EmissionsRatingDetail in EmissionsRatingObject)
                {
                    List<string> EmissionsRatingList = EmissionsRatingDetail.EmissionsRatingList;
                    foreach (string EmissionsRatingValue in EmissionsRatingList)
                    {
                        EmissionsRatingDetail.EmissionsRatingValue = EmissionsRatingValue;
                        Settings.Logger.Info($" Check and Create Pre SetUo Data for Emissions Rating { EmissionsRatingValue } ");
                        CurrentPage.As<EmissionsRatingPageActions>().CreateEmissionsRating(EmissionsRatingDetail);
                        Driver.SwitchTo().DefaultContent();
                        _extendedpage.ClickOnRefreshButton();
                    }
                }
            }
            else
            {
                Assert.Fail("Emissions Rating Data Not found");
            }
        }
    }
}
