﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.FuelProduct;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class ProductNumberPreDataTestCase : Hooks
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [TestCase("PreSetUpTestData/ProductNumberPreTestData.json", "CreateProductMainPreSetUpData",true, Description = "M5-Create Part PreSetUpData ")]
        public void QA1443_CreateProductNumberPreSetUpData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToFuelProductsMain();
            List<FuelProducts> ProductMainObject = CommonUtil.DataObjectForKey("FuelProducts").ToObject<List<FuelProducts>>();
            if (ProductMainObject != null)
            {
                foreach (FuelProducts productinfo in ProductMainObject)
                {
                    if (productinfo.ProductNumberList != null)
                        foreach (string productNumber in productinfo.ProductNumberList)
                        {
                            productinfo.ProductNumber= productNumber;
                            CurrentPage.As<FuelProductPageActions>().CreateFuelProduct(productinfo);
                            Driver.SwitchTo().DefaultContent();
                            _extendpage.ClickOnRefreshButton();
                        }
                }
            }
            else
            {
                Assert.Fail("Create Product Number PreSetUp Data Not found");
            }
        }
    
    }
}
