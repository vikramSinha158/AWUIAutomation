﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Driver;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System.Collections.Generic;
using static AssetWorks.UI.M5.TestAutomation.TestDataObjects.Booking.CustomerMainObjects;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class DriverLicenseIssueAuthorityPreDataTestCase : Hooks
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [TestCase("PreSetUpTestData/DriverLicenseIssuingAuthorityPreTestData.json", "Driver", true, Description = "M5- Create Driver License Issuing Authority Pre Test Data ")]
        public void QA1551_DriverLicenseIssueAuthorityPreDataTestCase(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDriverLicenseIssuingAuthority();
            List<DriverLicenseIssuingAuthorities> DriverObject = CommonUtil.DataObjectForKey("createLicenseIssuingAuthorityPreSetUp").ToObject<List<DriverLicenseIssuingAuthorities>>();
            if (DriverObject != null)
            {
                foreach (DriverLicenseIssuingAuthorities DriverDetail in DriverObject)
                {
                    int i = 0;                
                    List<string> CodeList = DriverDetail.CodeList;
                    foreach (string CodeID in CodeList)
                    {
                        DriverDetail.Code = CodeID;
                        DriverDetail.Description = DriverDetail.DescriptionList[i];
                        CurrentPage.As<DriverLicenseIssuingAuthorityPageActions>().CreateDriverLicenseIssuingAuthority(DriverDetail);
                        _extendpage.ClickOnRefreshButton();
                        i++;
                    }
                }
            }
            else 
            {
                Assert.Fail("Driver License Issuing Authority Pre-Data Not found");
            }
        }
    }
}
