﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class TechSpecPreDataTestCase : Hooks
    {
        internal ExtendedPageActions _extendpage => new ExtendedPageActions(Driver);

        [TestCase("PreSetUpTestData/TechSpecPreTestData.json", "TechSpecPreData", true, Description = "M5-Verifying Create TechSpec Pre Test Data ")]
        public void QA999_CreateTechSpec(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToTechSpecMainPage();
            List<TechSpecMain> TechSpecObject = CommonUtil.DataObjectForKey("TechSpecMainData").ToObject<List<TechSpecMain>>();
            if (TechSpecObject != null)
            {
                foreach (TechSpecMain TechSpecDetail in TechSpecObject)
                {
                     List<string> TechSpecNoList = TechSpecDetail.TechSpecList;
                    foreach (string TechSpec in TechSpecNoList)
                    {
                        CurrentPage.As<TechSpecMainPageActions>().CreateTechSpec(TechSpecDetail, TechSpec);
                        _extendpage.ClickOnRefreshButton();
                    }
                }
            }
            else {
                Assert.Fail("Tech Spec Data Not found");
            }
        }
    }
}
