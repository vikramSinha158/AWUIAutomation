﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class ApplicationUserPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/ApplicationUserPreTestData.json", "ApplicationUserPreData", true,
            TestName = "QA1656_CreateApplicationUser", Description = "M5 Create Application User"), Order(1)]
        public void QA1656_CreateApplicationUser(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToApplicationUserMaintenancePage();
            List<ApplicationUser> ApplicationUsers = CommonUtil.DataObjectForKey("ApplicationUser").ToObject<List<ApplicationUser>>();
            foreach (ApplicationUser applicationUser in ApplicationUsers)
            {
                if (applicationUser.UserList != null)
                {
                    foreach(string user in applicationUser.UserList)
                    {
                        applicationUser.User = user;
                        CurrentPage.As<AppUserMaintenancePageActions>().CreateApplicationUser(applicationUser);
                        _extendedpage.ClickOnRefreshButton();
                    }
                }
                else
                    CurrentPage.As<AppUserMaintenancePageActions>().CreateApplicationUser(applicationUser);
            }
        }
    }
}
