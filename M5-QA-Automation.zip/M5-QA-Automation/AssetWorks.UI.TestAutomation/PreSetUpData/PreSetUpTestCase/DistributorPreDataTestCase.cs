﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.Department;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class DistributorPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/DistributorPreTestData.json", "CreateDistributorMain", true,
            TestName = "QA1445_CreateDistributorPreSetUpData", Description = "M5-Distributor Main Pre Setup Data")]
        public void QA1445_CreateDistributorPreSetUpData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDistributorMain();
            List<DistributorMainObjects> distributorsList = CommonUtil.DataObjectForKey("Distributors").ToObject<List<DistributorMainObjects>>();
            foreach (DistributorMainObjects distributor in distributorsList)
            {
                int i=0;
                List<string> distNoList = distributor.DistributorNumberList;
                foreach (string distributorNo in distNoList)
                {                    
                    distributor.DistributorNumber= distributor.DistributorNumberList[i];
                    distributor.DistributorName=distributor.DistributorNameList[i];                  
                    CurrentPage.As<DistributorMainPageActions>().CreateDistributor(distributor);
                    i++;
                }
            }
        }
    }
}
