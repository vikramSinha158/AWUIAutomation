﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.TestSuite;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class TestSuitePreDataTestCase : Hooks
    {
       
        [TestCase("PreSetUpTestData/TestSuitePreTestData.json", "TestSuitePreData", true, Description = "M5- Test Suite Pre Data")]
        public void CreateTestSuitePreData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToTestSuitePage();
            TestSuite TestSuiteRecords = CommonUtil.DataObjectForKey("TestSuite").ToObject<TestSuite>();
            List<TestSuiteDetails> TestSuiteDetails = TestSuiteRecords.TestSuiteDetails;
            if (TestSuiteDetails != null)
            {
                foreach (TestSuiteDetails TestSuiteDetail in TestSuiteDetails)
                {
                    List<string> TestSuiteNameList = TestSuiteDetail.TestSuiteList;
                    foreach (string TestSuiteName in TestSuiteNameList)
                    {
                        TestSuiteDetail.TestSuiteNo = TestSuiteName;
                        CurrentPage.As<TestSuitePageActions>().CreateTestSuite(TestSuiteDetail);
                        _extendedpage.ClickOnRefreshButton();
                    }
                }
            }
            else
            {
                Assert.Fail("Test Suite Data Not found");
            }
        }
    }
}
