﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class PartKitPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/PartKitPreTestData.json", "PartKitPreData", true, Description = "M5- Create Booking Type Code Pre Data")]
        public void QA1592_PartKitPreData(object[] testParameter)
        {
            List<PartsKit> partsKitObjectList = CommonUtil.DataObjectForKey("PartKitData").ToObject<List<PartsKit>>();
            Settings.Logger.Info(" Step 1 : Navigate To Parts Kit Page ");
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPartsKitPage();
            if (partsKitObjectList != null)
            {                
                foreach (PartsKit partKitdata in partsKitObjectList)
                {
                    List<string> KitCodes = partKitdata.CodeList;
                    foreach (string kitCode in KitCodes)
                    {
                        partKitdata.KitCode = kitCode;
                        Settings.Logger.Info($" Check and Create Pre SetUp Data for PartKitCode { partKitdata.KitCode } ");
                        CurrentPage.As<PartsKitPageActions>().CreatePartsKit(partKitdata);
                        Driver.SwitchTo().DefaultContent();
                        _extendedpage.ClickOnRefreshButton();                      
                    }
                }
            }
            else
            {
                Assert.Fail("PartkitCode Data Not found");
            }
        }
    }
}
