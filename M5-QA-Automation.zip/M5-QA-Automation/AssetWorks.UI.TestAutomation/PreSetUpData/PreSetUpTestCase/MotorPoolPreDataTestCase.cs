﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.MotorPool;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class MotorPoolPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/MotorPoolPreTestData.json", "MotorPoolRentalClass", true,
            TestName = "QA1605_CreateMotorPoolRentalClass", Description = "M5-Create Motor Pool Rental Class"), Order(1)]
        public void QA1605_CreateMotorPoolRentalClass(object[] testParameter)
        {
            IList<MPRentalClass> RentalClass = CommonUtil.DataObjectForKey("RentalClass").ToObject<IList<MPRentalClass>>();
            Settings.Logger.Info(" Step 1 : Navigate To Motor Pool Rental Class Page ");
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToMotorPoolRentalClassPage();
            Settings.Logger.Info(" Step 2 : Create Motor Pool Rental Class ");
            foreach (MPRentalClass mPRentalClass in RentalClass)
            {
                CurrentPage.As<MotorPoolRentalClassPageActions>().CreateNewMotorPoolRentalClass(mPRentalClass);
            }
        }
    }
}
