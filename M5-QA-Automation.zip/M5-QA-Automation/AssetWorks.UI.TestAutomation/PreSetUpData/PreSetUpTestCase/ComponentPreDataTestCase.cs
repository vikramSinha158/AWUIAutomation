﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class ComponentPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/ComponentPreTestData.json", "Component", true,
            TestName = "QA1562_CreateComponentPreSetUpData", Description = "M5-Create Component Pre SetUp Data")]
        public void QA1562_CreateComponentPreSetUpData(object[] testParameter)
        {         
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateComponentMainPage();
            Settings.Logger.Info($" Step : Create Component Main Code");           
            Settings.ComponentNumber = CurrentPage.As<ComponentMainPageActions>().CreateComponent("CreateComponentQA1573");
        }

    }
}
