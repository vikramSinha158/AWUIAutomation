﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class VEDClassCodesPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/VEDClassCodesTestPreData.json", "VEDClassCodesPreData", true, Description = "M5- Create Pre Data VED Class Codes")]
        public void QA1361_VEDClassCodes(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToVEDClassCodes();
            List<VEDClassCodes> VEDClassCodesObject = CommonUtil.DataObjectForKey("VEDClassCodes").ToObject<List<VEDClassCodes>>();
            if (VEDClassCodesObject != null)
            {
                foreach (VEDClassCodes VEDClassCodesDetail in VEDClassCodesObject)
                {
                    List<string> VEDClassCodesList = VEDClassCodesDetail.VEDClassCodeList;
                    foreach (string VEDClassCodeValue in VEDClassCodesList)
                    {
                        VEDClassCodesDetail.VEDClassCode = VEDClassCodeValue;
                        Settings.Logger.Info($" Check and Create Pre SetUo Data for VED Class Codes { VEDClassCodeValue } ");
                        CurrentPage.As<VEDClassCodesPageActions>().CreateVEDClassCodes(VEDClassCodesDetail);
                        Driver.SwitchTo().DefaultContent();
                        _extendedpage.ClickOnRefreshButton();
                    }
                }
            }
            else
            {
                Assert.Fail("VEDClassCodes Data Not found");
            }
        }
    }
}
