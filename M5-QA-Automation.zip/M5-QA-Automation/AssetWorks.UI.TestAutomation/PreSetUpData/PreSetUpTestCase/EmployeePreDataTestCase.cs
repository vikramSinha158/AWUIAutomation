﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.Employee;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System.Collections.Generic;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class EmployeePreDataTestCase : Hooks
    {      

        [TestCase("PreSetUpTestData/EmployeePreTestData.json", "CreateEmployee", true, Description = "M5-Create Employee PreData Required Fields"), Order(1)]
        public void QA1003_CreateEmployeeRequiredParameters(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            List<CreateEmployeeObject> DataObjectList = CommonUtil.DataObjectForKey("CreateEmployeeRequiredData").ToObject<List<CreateEmployeeObject>>();
            if (DataObjectList != null)
            {
                foreach (CreateEmployeeObject DataObject in DataObjectList)
                {
                    List<string> EmployeeIDList = DataObject.EmployeeData.EmployeeIDList;
                    int i = 0;
                    foreach (string EmployeeID in EmployeeIDList)
                    {
                        DataObject.EmployeeData.EmployeeID = DataObject.EmployeeData.EmployeeIDList[i];
                        DataObject.EmployeeData.EmpName = DataObject.EmployeeData.EmpNameList[i];
                        CurrentPage.As<EmployeeMainPageActions>().CreateNewEmployee(DataObject);
                        _extendedpage.ClickOnRefreshButton();
                        i++;
                    }
                }
            }          
        }

        [TestCase("PreSetUpTestData/EmployeePreTestData.json", "EmployeeShiftAssignment", true, TestName = "QA1474_CreateEmployeeShiftAssignment",
            Description = "M5-Create Employee shift assignment as a pre-setup"), Order(2)]
        public void QA1474_CreateEmployeeShiftAssignment(object[] testParameter)
        {
            Settings.Logger.Info("Step 1 - Navigate To Employee Shift Assignment Page");
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeShiftAssignmentPage();
            List<EmployeeShiftAssign> DataObjectList = CommonUtil.DataObjectForKey("EmployeeShiftAssign").ToObject<List<EmployeeShiftAssign>>();
            if (DataObjectList != null)
            {
                foreach (EmployeeShiftAssign DataObject in DataObjectList)
                {
                    Settings.Logger.Info($"Step - Shift Assignment on Employee - {DataObject.EmployeeNo}");
                    CurrentPage.As<EmployeeShiftAssignPageActions>().AssignShifts(DataObject);
                    _extendedpage.ClickOnRefreshButton();
                }
            }
        }

        [TestCase("PreSetUpTestData/EmployeePreTestData.json", "CreateEmployee", true, Description = "M5-Create Employee PreData More Fields")]
        public void QA1270_CreateEmployeeMoreParameters(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            List<CreateEmployeeObject> DataObjectList = CommonUtil.DataObjectForKey("CreateEmployeeMoreParameters").ToObject<List<CreateEmployeeObject>>();
            if (DataObjectList != null)
            {
                foreach (CreateEmployeeObject DataObject in DataObjectList)
                {
                    List<string> EmployeeIDList = DataObject.EmployeeData.EmployeeIDList;
                    int i = 0;
                    foreach (string EmployeeID in EmployeeIDList)
                    {
                        DataObject.EmployeeData.EmployeeID = DataObject.EmployeeData.EmployeeIDList[i];
                        DataObject.EmployeeData.EmpName = DataObject.EmployeeData.EmpNameList[i];
                        CurrentPage.As<EmployeeMainPageActions>().CreateNewEmployee(DataObject);
                        i++;
                    }
                }
            }
        }

        [TestCase("PreSetUpTestData/ShiftMaintenancePreTestData.json", "ShiftMaintenancePreData", true, Description = "M5-Creating Pre setup Maintenance Code ")]
        public void QA1350_ShiftMaintenanceCode(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToShiftMaintenance();
            List<ShiftMaintenance> ShiftMaintenancebject = CommonUtil.DataObjectForKey("ShiftMaintenanceData").ToObject<List<ShiftMaintenance>>();
            if (ShiftMaintenancebject != null)
            {
                foreach (ShiftMaintenance ShiftMaintenanceDetail in ShiftMaintenancebject)
                {
                    List<string> ShiftList = ShiftMaintenanceDetail.ShiftNumberList;
                    foreach (string ShiftCode in ShiftList)
                    {
                        ShiftMaintenanceDetail.ShiftNumber = ShiftCode;
                        Settings.Logger.Info($" Check and Create Pre SetUo Data  for Shift Maintenance Number { ShiftCode} ");
                        CurrentPage.As<ShiftMaintenancePageActions>().CreateShiftMaintenance(ShiftMaintenanceDetail);
                        _extendedpage.ClickOnRefreshButton();
                    }
                }
            }
            else
            {
                Assert.Fail("Shift Maintenance  Data Not found");
            }
        }

        [TestCase("PreSetUpTestData/EmployeePreTestData.json", "CreateEmployee", true, Description = "M5-Create Employee PreData Driver")]
        public void QA1553_EmployeeDriverPreSetUp(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToEmployeeMainPage();
            List<CreateEmployeeObject> DataObjectList = CommonUtil.DataObjectForKey("CreateEmployeeDriverClass").ToObject<List<CreateEmployeeObject>>();
            if (DataObjectList != null)
            {
                foreach (CreateEmployeeObject DataObject in DataObjectList)
                {
                    List<string> EmployeeIDList = DataObject.EmployeeData.EmployeeIDList;
                    int i = 0;
                    foreach (string EmployeeID in EmployeeIDList)
                    {
                        DataObject.EmployeeData.EmployeeID = DataObject.EmployeeData.EmployeeIDList[i];
                        DataObject.EmployeeData.EmpName = DataObject.EmployeeData.EmpNameList[i];
                        CurrentPage.As<EmployeeMainPageActions>().CreateNewEmployee(DataObject);
                        i++;
                    }
                }
            }
        }
    }
}
