﻿using NUnit.Framework;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using AssetWorks.UI.M5.TestAutomation.Actions.SystemCodes;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class SystemCodesPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/SystemCodesPreTestData.json", "WarrantyCategoryCodes", true, TestName = "QA1682_WarrantyCategoryCode",
            Description = "M5 Pre-setup for category (Claim Category Definition)"), Order(1)]
        public void QA1682_WarrantyCategoryCode(object[] testParameter)
        {
            WarrantyCategoryCodes WarrCategorys = CommonUtil.DataObjectForKey("WarrantyCategory").ToObject<WarrantyCategoryCodes>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToClaimCategoryDefinitionPage();
            foreach (string category in WarrCategorys.WarrantyCategoryList)
            {
                WarrCategorys.WarrantyCategory = category;
                CurrentPage.As<ClaimCategoryDefinitionPageActions>().CreateWarrantyCategoryCode(WarrCategorys);
            }
        }

        [TestCase("PreSetUpTestData/SystemCodesPreTestData.json", "PositionCodes", true, TestName = "QA1682_PositionCode",
            Description = "M5 Pre-setup for Position (Position Codes)"), Order(1)]
        public void QA1682_PositionCode(object[] testParameter)
        {
            PositionCodeObj PosCodes = CommonUtil.DataObjectForKey("Codes").ToObject<PositionCodeObj>();
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToPositionCodePage();
            foreach (string code in PosCodes.PositionList)
            {
                PosCodes.Position = code;
                CurrentPage.As<PositionCodesPageActions>().CreatePositionCode(PosCodes);
            }
        }
    }
}
