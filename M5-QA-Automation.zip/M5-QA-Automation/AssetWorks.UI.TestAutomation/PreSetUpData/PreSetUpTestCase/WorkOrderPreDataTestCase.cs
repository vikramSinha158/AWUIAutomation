﻿using NUnit.Framework;
using System.Collections.Generic;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class WorkOrderPreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/WorkOrderPreTestData.json", "WorkOrderPreData", true,
            TestName = "QA1447_CreateWorkOrderOreData", Description = "M5-Verifying Create WorkOrderMain Number ")]
        public void QA1447_CreateWorkOrderOreData(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateWorkOrderMainPage();
            List<WorkOrderMain> WorkOrderbject = CommonUtil.DataObjectForKey("WorkOrderPreDataList").ToObject<List<WorkOrderMain>>();
            if (WorkOrderbject != null)
            {
                foreach (WorkOrderMain WorkOrderDetail in WorkOrderbject)
                {
                    Settings.Logger.Info($" Check and Create Pre SetUo Data for WorkOrderMain { WorkOrderDetail.WorkOrderNo } ");
                    CurrentPage.As<WorkOrderMainPageActions>().CreateNewWorkOrder(WorkOrderDetail, WorkOrderDetail.UnitDepComp);
                    Driver.SwitchTo().DefaultContent();
                    _extendedpage.ClickOnRefreshButton();
                }
            }
            else
            {
                Assert.Fail("WorkOrderMain Data Not found");
            }
        }

    }
}
