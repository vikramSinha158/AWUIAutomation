﻿using AssetWorks.UI.M5.TestAutomation.Actions;
using AssetWorks.UI.M5.TestAutomation.Actions.DAFCode;
using AssetWorks.UI.M5.TestAutomation.Common;
using AssetWorks.UI.M5.TestAutomation.Hook;
using AssetWorks.UI.M5.TestAutomation.TestDataObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.M5.TestAutomation.PreSetUpData.PreSetUpTestCase
{
    [TestFixture]
    [Category("PreDataSetUp")]
    internal class DAFCodeMaintenancePreDataTestCase : Hooks
    {
        [TestCase("PreSetUpTestData/DAFCodeMaintenancePreTestData.json", "DAFCodeMaintenance", true, TestName = "CreatePreDataDAFCodeMaintenance", Description = "M5-Create Pre Data DAF Code Maintenance")]
        public void CreatePreDataDAFCodeMaintenance(object[] testParameter)
        {
            CurrentPage = CurrentPage.As<HomePageActions>().NavigateToDAFCodeMaintenance();
            List<DAFCodeMaintenance> DAFCodeMaintenanceObject = CommonUtil.DataObjectForKey("DAFCodeMaintenancePreData").ToObject<List<DAFCodeMaintenance>>();
            if (DAFCodeMaintenanceObject != null)
            {
                foreach (DAFCodeMaintenance DAFCodeMaintenanceDetail in DAFCodeMaintenanceObject)
                {
                    List<string> DAFCodeList = DAFCodeMaintenanceDetail.DAFCodeMaintenanceList;
                    foreach (string DAFCode in DAFCodeList)
                    {
                        DAFCodeMaintenanceDetail.DAFCodeMaintenanceCodes = DAFCode;
                        CurrentPage.As<DAFCodeMaintenancePageActions>().CreateDAFCodeMaintenance(DAFCodeMaintenanceDetail);
                        Settings.Logger.Info($" Created Pre setup data for  DAF Code Maintenance {DAFCode}");
                        _extendedpage.ClickOnRefreshButton();
                    }
                }
            }
            else
            {
                Assert.Fail("DAF Code Maintenance Data Not found");
            }
        }
    }
}
